"""Initial schema — all tables with client_id isolation

Revision ID: 0001
Revises:
Create Date: 2026-05-22
"""
from typing import Sequence, Union

import sqlalchemy as sa
from sqlalchemy.dialects import postgresql
from alembic import op

revision: str = "0001"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.execute("CREATE EXTENSION IF NOT EXISTS vector")
    op.execute('CREATE EXTENSION IF NOT EXISTS "uuid-ossp"')

    op.create_table(
        "client_config",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("uuid_generate_v4()")),
        sa.Column("client_name", sa.String(), nullable=False),
        sa.Column("waba_number", sa.String(), nullable=False, unique=True),
        sa.Column("waba_phone_number_id", sa.String(), nullable=False),
        sa.Column("waba_token", sa.String(), nullable=False),
        sa.Column("project_ids", postgresql.ARRAY(postgresql.UUID(as_uuid=True)), server_default="{}"),
        sa.Column("prompt_overrides", postgresql.JSONB(), server_default="{}"),
        sa.Column("crm_type", sa.String(), nullable=True),
        sa.Column("crm_token", sa.String(), nullable=True),
        sa.Column("language_config", postgresql.JSONB(), server_default='{"primary_language":"english","regional_languages":[],"formality_level":"formal","hindi_pronoun":"aap"}'),
        sa.Column("broker_wa_numbers", postgresql.ARRAY(sa.String()), server_default="{}"),
        sa.Column("google_calendar_id", sa.String(), nullable=True),
        sa.Column("active", sa.Boolean(), nullable=False, server_default=sa.text("true")),
        sa.Column("created_at", sa.DateTime(), nullable=False, server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(), nullable=False, server_default=sa.text("now()")),
    )

    op.create_table(
        "leads",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("uuid_generate_v4()")),
        sa.Column("client_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("client_config.id"), nullable=False),
        sa.Column("phone", sa.String(), nullable=False),
        sa.Column("name", sa.String(), nullable=True),
        sa.Column("email", sa.String(), nullable=True),
        sa.Column("language_pref", sa.String(), nullable=False, server_default="english"),
        sa.Column("intent", sa.String(), nullable=False, server_default="unknown"),
        sa.Column("budget_min", sa.BigInteger(), nullable=True),
        sa.Column("budget_max", sa.BigInteger(), nullable=True),
        sa.Column("timeline_months", sa.Integer(), nullable=True),
        sa.Column("urgency", sa.String(), nullable=False, server_default="unknown"),
        sa.Column("financing_status", sa.String(), nullable=False, server_default="unknown"),
        sa.Column("location_preferences", postgresql.JSONB(), server_default="[]"),
        sa.Column("property_type", sa.String(), nullable=False, server_default="any"),
        sa.Column("family_size", sa.Integer(), nullable=True),
        sa.Column("score", sa.Integer(), nullable=True),
        sa.Column("tier", sa.String(), nullable=True),
        sa.Column("stage", sa.String(), nullable=False, server_default="new"),
        sa.Column("source_channel", sa.String(), nullable=False, server_default="whatsapp"),
        sa.Column("assigned_agent_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False, server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(), nullable=False, server_default=sa.text("now()")),
    )
    op.create_index("ix_leads_client_id", "leads", ["client_id"])
    op.create_index("ix_lead_client_stage", "leads", ["client_id", "stage"])
    op.create_unique_constraint("uq_lead_client_phone", "leads", ["client_id", "phone"])

    op.create_table(
        "conversations",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("uuid_generate_v4()")),
        sa.Column("client_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("client_config.id"), nullable=False),
        sa.Column("lead_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("leads.id"), nullable=False),
        sa.Column("channel", sa.String(), nullable=False, server_default="whatsapp"),
        sa.Column("status", sa.String(), nullable=False, server_default="active"),
        sa.Column("summary", sa.Text(), nullable=True),
        sa.Column("started_at", sa.DateTime(), nullable=False, server_default=sa.text("now()")),
        sa.Column("last_message_at", sa.DateTime(), nullable=False, server_default=sa.text("now()")),
    )
    op.create_index("ix_conversations_client_id", "conversations", ["client_id"])

    op.create_table(
        "messages",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("uuid_generate_v4()")),
        sa.Column("client_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("client_config.id"), nullable=False),
        sa.Column("conversation_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("conversations.id"), nullable=False),
        sa.Column("direction", sa.String(), nullable=False),
        sa.Column("content", sa.Text(), nullable=False),
        sa.Column("message_type", sa.String(), nullable=False, server_default="text"),
        sa.Column("channel_message_id", sa.String(), nullable=True),
        sa.Column("timestamp", sa.DateTime(), nullable=False, server_default=sa.text("now()")),
    )
    op.create_index("ix_messages_client_id", "messages", ["client_id"])
    op.create_index("ix_message_conversation", "messages", ["conversation_id", "timestamp"])

    op.create_table(
        "consent_log",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("uuid_generate_v4()")),
        sa.Column("client_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("client_config.id"), nullable=False),
        sa.Column("lead_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("leads.id"), nullable=False),
        sa.Column("consent_type", sa.String(), nullable=False),
        sa.Column("source", sa.String(), nullable=False),
        sa.Column("granted_at", sa.DateTime(), nullable=False, server_default=sa.text("now()")),
        sa.Column("metadata", postgresql.JSONB(), nullable=True),
    )
    op.create_index("ix_consent_log_client_id", "consent_log", ["client_id"])

    op.create_table(
        "billing_events",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("uuid_generate_v4()")),
        sa.Column("client_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("client_config.id"), nullable=False),
        sa.Column("lead_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("leads.id"), nullable=True),
        sa.Column("event_type", sa.String(), nullable=False),
        sa.Column("amount_inr", sa.Integer(), nullable=True),
        sa.Column("metadata", postgresql.JSONB(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False, server_default=sa.text("now()")),
    )
    op.create_index("ix_billing_events_client_id", "billing_events", ["client_id"])

    op.create_table(
        "brochure_chunks",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("uuid_generate_v4()")),
        sa.Column("client_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("client_config.id"), nullable=False),
        sa.Column("project_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("project_name", sa.String(), nullable=False),
        sa.Column("chunk_type", sa.String(), nullable=False),
        sa.Column("text", sa.Text(), nullable=False),
        sa.Column("embedding", sa.Text(), nullable=True),  # pgvector handled post-migration
        sa.Column("page_number", sa.Integer(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False, server_default=sa.text("now()")),
    )
    op.create_index("ix_brochure_chunks_client_id", "brochure_chunks", ["client_id"])
    op.create_index("ix_brochure_chunks_project_id", "brochure_chunks", ["project_id"])

    # Add the actual vector column after table creation (requires pgvector extension)
    op.execute("ALTER TABLE brochure_chunks ALTER COLUMN embedding TYPE vector(1536) USING NULL::vector(1536)")
    op.execute("CREATE INDEX ix_brochure_embedding_cosine ON brochure_chunks USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100)")

    op.create_table(
        "eval_results",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, server_default=sa.text("uuid_generate_v4()")),
        sa.Column("client_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("client_config.id"), nullable=True),
        sa.Column("conversation_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("conversations.id"), nullable=True),
        sa.Column("eval_name", sa.String(), nullable=False),
        sa.Column("score", sa.String(), nullable=False),
        sa.Column("details", postgresql.JSONB(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False, server_default=sa.text("now()")),
    )


def downgrade() -> None:
    op.drop_table("eval_results")
    op.drop_table("brochure_chunks")
    op.drop_table("billing_events")
    op.drop_table("consent_log")
    op.drop_table("messages")
    op.drop_table("conversations")
    op.drop_table("leads")
    op.drop_table("client_config")
