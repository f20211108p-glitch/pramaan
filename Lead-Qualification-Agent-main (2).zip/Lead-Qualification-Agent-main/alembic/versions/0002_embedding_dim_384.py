"""Switch embedding dimension from 1536 (OpenAI) to 384 (fastembed multilingual-e5-small).

Reason: using free local fastembed instead of paid OpenAI embeddings.
Model: intfloat/multilingual-e5-small — supports English, Hindi, Hinglish.

Revision ID: 0002
Revises: 0001
Create Date: 2026-05-23
"""
from alembic import op

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Drop the old IVFFlat index (can't alter indexed vector column in-place)
    op.drop_index("ix_brochure_embedding_cosine", table_name="brochure_chunks")

    # Change vector dimension from 1536 to 384
    op.execute(
        "ALTER TABLE brochure_chunks ALTER COLUMN embedding TYPE vector(384)"
    )

    # Recreate IVFFlat cosine index for 384-dim vectors
    op.execute("""
        CREATE INDEX ix_brochure_embedding_cosine
        ON brochure_chunks
        USING ivfflat (embedding vector_cosine_ops)
        WITH (lists = 100)
    """)


def downgrade() -> None:
    op.drop_index("ix_brochure_embedding_cosine", table_name="brochure_chunks")
    op.execute(
        "ALTER TABLE brochure_chunks ALTER COLUMN embedding TYPE vector(1536)"
    )
    op.execute("""
        CREATE INDEX ix_brochure_embedding_cosine
        ON brochure_chunks
        USING ivfflat (embedding vector_cosine_ops)
        WITH (lists = 100)
    """)
