"""Add billing_model column to client_config.

Supports per-client billing visibility:
  - "direct" — fixed fee, no billing tab in dashboard
  - "per_visit" — per site-visit pricing, billing tab visible
  - "per_lead" — per qualified-lead pricing, billing tab visible

Revision ID: 0003
Revises: 0002
Create Date: 2026-05-28
"""
from alembic import op
import sqlalchemy as sa

revision = "0003"
down_revision = "0002"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "client_config",
        sa.Column("billing_model", sa.String(), nullable=False, server_default="direct"),
    )


def downgrade() -> None:
    op.drop_column("client_config", "billing_model")
