"""Add users table for dashboard authentication.

Supports two roles:
  - "admin" — Pramaan team, full access to all clients
  - "client" — Developer team (Prestige, Lodha), scoped to their client_id

Seeds a default admin user: admin@getpramaan.com / pramaan2026

Revision ID: 0004
Revises: 0003
Create Date: 2026-05-29
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import UUID
from passlib.context import CryptContext

revision = "0004"
down_revision = "0003"
branch_labels = None
depends_on = None

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def upgrade() -> None:
    op.create_table(
        "users",
        sa.Column("id", UUID(as_uuid=True), primary_key=True, server_default=sa.text("gen_random_uuid()")),
        sa.Column("email", sa.String(), nullable=False, unique=True),
        sa.Column("password_hash", sa.String(), nullable=False),
        sa.Column("name", sa.String(), nullable=False),
        sa.Column("role", sa.String(), nullable=False, server_default="client"),
        sa.Column("client_id", UUID(as_uuid=True), sa.ForeignKey("client_config.id"), nullable=True),
        sa.Column("active", sa.Boolean(), nullable=False, server_default=sa.text("true")),
        sa.Column("created_at", sa.DateTime(), nullable=False, server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(), nullable=False, server_default=sa.func.now()),
    )

    # Seed default admin user
    op.execute(
        sa.text(
            "INSERT INTO users (email, password_hash, name, role) VALUES (:email, :pw, :name, 'admin')"
        ).bindparams(
            email="admin@getpramaan.com",
            pw=pwd_context.hash("pramaan2026"),
            name="Pramaan Admin",
        )
    )


def downgrade() -> None:
    op.drop_table("users")
