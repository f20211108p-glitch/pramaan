"""Billing idempotency — a lead can be billed as 'qualified_lead' exactly once.

The scorer fires a billing event when a lead first transitions to HOT.
Without a DB-level guarantee, two concurrent graph runs (or a replayed
DLQ message) could double-bill. The partial unique index makes the
"only once per lead" rule enforceable where it cannot race: the database.

Also deduplicates any existing double-billed rows (keeps the earliest).

Revision ID: 0005
Revises: 0004
Create Date: 2026-06-11
"""
from alembic import op
import sqlalchemy as sa

revision = "0005"
down_revision = "0004"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Remove any historical duplicates first (keep earliest per lead+type)
    op.execute(
        """
        DELETE FROM billing_events b
        USING billing_events earlier
        WHERE b.event_type IN ('qualified_lead', 'site_visit_booked')
          AND earlier.event_type = b.event_type
          AND b.client_id = earlier.client_id
          AND b.lead_id = earlier.lead_id
          AND b.lead_id IS NOT NULL
          AND (
            earlier.created_at < b.created_at
            OR (earlier.created_at = b.created_at AND earlier.id < b.id)
          )
        """
    )
    # One qualified_lead AND one site_visit_booked per lead, ever.
    # event_type is part of the key so a lead can have one of EACH.
    op.create_index(
        "uq_billing_once_per_type",
        "billing_events",
        ["client_id", "lead_id", "event_type"],
        unique=True,
        postgresql_where=sa.text(
            "event_type IN ('qualified_lead', 'site_visit_booked')"
        ),
    )


def downgrade() -> None:
    op.drop_index("uq_billing_once_per_type", table_name="billing_events")
