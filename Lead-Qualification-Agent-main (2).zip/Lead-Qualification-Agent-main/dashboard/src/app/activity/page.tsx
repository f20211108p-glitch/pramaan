"use client";

import { useEffect, useState } from "react";
import { useClient } from "@/components/ClientProvider";
import { getActivityFeed } from "@/lib/api";
import type { ActivityItem } from "@/lib/types";
import { TierBadge } from "@/components/TierBadge";
import { formatPhone, timeAgo } from "@/lib/utils";
import { Loader2, ArrowDownLeft, ArrowUpRight, RefreshCw } from "lucide-react";
import Link from "next/link";

export default function ActivityPage() {
  const { currentClientId } = useClient();
  const [activity, setActivity] = useState<ActivityItem[]>([]);
  const [count, setCount] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [limit, setLimit] = useState(50);

  const fetchActivity = async () => {
    if (!currentClientId) return;
    setLoading(true);
    setError(null);
    try {
      const data = await getActivityFeed(currentClientId, limit);
      setActivity(data.activity);
      setCount(data.count);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : "Failed to load activity");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchActivity(); }, [currentClientId, limit]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-[28px] font-serif" style={{ color: "var(--pramaan-text)" }}>
            Activity Feed
          </h1>
          <p className="text-[13px] mt-1" style={{ color: "var(--pramaan-text-muted)" }}>
            {count} recent messages across all leads
          </p>
        </div>
        <button onClick={fetchActivity} className="pramaan-btn-ghost !p-2.5 !rounded-xl" title="Refresh">
          <RefreshCw className="h-4 w-4" />
        </button>
      </div>

      <div className="pramaan-card">
        {loading ? (
          <div className="flex items-center justify-center h-32">
            <Loader2 className="h-6 w-6 animate-spin" style={{ color: "var(--pramaan-gold)" }} />
          </div>
        ) : error ? (
          <div className="p-5 text-[13px]" style={{ color: "var(--tier-hot)" }}>{error}</div>
        ) : activity.length === 0 ? (
          <div className="text-center py-14 text-[13px]" style={{ color: "var(--pramaan-text-muted)" }}>
            No activity yet. Messages will appear here once leads start chatting.
          </div>
        ) : (
          <div className="divide-y" style={{ borderColor: "var(--pramaan-border-subtle)" }}>
            {activity.map((item, i) => {
              const isInbound = item.direction === "inbound";
              return (
                <div
                  key={`${item.conversation_id}-${item.timestamp}-${i}`}
                  className="px-5 py-4 transition-colors"
                  onMouseEnter={(e) => (e.currentTarget.style.background = "var(--pramaan-gold-light)")}
                  onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                >
                  <div className="flex items-start gap-3">
                    <div className="mt-1">
                      {isInbound ? (
                        <ArrowDownLeft className="h-4 w-4" style={{ color: "var(--tier-cold)" }} />
                      ) : (
                        <ArrowUpRight className="h-4 w-4" style={{ color: "var(--pramaan-gold)" }} />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <Link href={`/leads/${item.lead_id}`} className="text-[13px] font-medium hover:opacity-70" style={{ color: "var(--pramaan-text)" }}>
                          {item.lead_name || formatPhone(item.lead_phone)}
                        </Link>
                        <TierBadge tier={item.lead_tier} />
                        <span className="text-[10px]" style={{ color: "var(--pramaan-text-muted)" }}>{item.message_type}</span>
                      </div>
                      <p className="text-[12px] mt-1 truncate" style={{ color: "var(--pramaan-text-secondary)" }}>
                        {isInbound ? "" : "Bot: "}
                        {item.content.slice(0, 150)}{item.content.length > 150 ? "..." : ""}
                      </p>
                      <p className="text-[10px] mt-1" style={{ color: "var(--pramaan-text-muted)" }}>
                        {timeAgo(item.timestamp)} &middot; {formatPhone(item.lead_phone)}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {activity.length >= limit && (
          <div className="border-t p-4 text-center" style={{ borderColor: "var(--pramaan-border-subtle)" }}>
            <button onClick={() => setLimit((prev) => prev + 50)} className="text-[13px] font-medium" style={{ color: "var(--pramaan-gold)" }}>
              Load more...
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
