"use client";

import { useEffect, useState, useCallback } from "react";
import { useClient } from "@/components/ClientProvider";
import { listBillingEvents } from "@/lib/api";
import type { BillingEvent } from "@/lib/types";
import { timeAgo } from "@/lib/utils";
import { Loader2, RefreshCw, Receipt } from "lucide-react";
import Link from "next/link";

export default function BillingPage() {
  const { currentClientId } = useClient();
  const [events, setEvents] = useState<BillingEvent[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [offset, setOffset] = useState(0);
  const limit = 25;

  const fetchEvents = useCallback(async () => {
    if (!currentClientId) return;
    setLoading(true);
    setError(null);
    try {
      const data = await listBillingEvents(currentClientId, limit, offset);
      setEvents(data.events);
      setTotal(data.total);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : "Failed to load billing events");
    } finally {
      setLoading(false);
    }
  }, [currentClientId, offset]);

  useEffect(() => { fetchEvents(); }, [fetchEvents]);

  const totalPages = Math.ceil(total / limit);
  const currentPage = Math.floor(offset / limit) + 1;
  const totalRevenue = events.reduce((sum, e) => sum + (e.amount_inr ?? 0), 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-[28px] font-serif" style={{ color: "var(--pramaan-text)" }}>
            Billing
          </h1>
          <p className="text-[13px] mt-1" style={{ color: "var(--pramaan-text-muted)" }}>
            {total} billing events tracked
          </p>
        </div>
        <button onClick={fetchEvents} className="pramaan-btn-ghost !p-2.5 !rounded-xl" title="Refresh">
          <RefreshCw className="h-4 w-4" />
        </button>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <div className="pramaan-card p-5">
          <p className="text-[11px] font-medium tracking-wider uppercase" style={{ color: "var(--pramaan-text-muted)" }}>Events (this page)</p>
          <p className="text-2xl font-serif mt-2" style={{ color: "var(--pramaan-text)" }}>{events.length}</p>
        </div>
        <div className="pramaan-card p-5">
          <p className="text-[11px] font-medium tracking-wider uppercase" style={{ color: "var(--pramaan-text-muted)" }}>Revenue (this page)</p>
          <p className="text-2xl font-serif mt-2" style={{ color: "var(--stage-converted)" }}>
            {totalRevenue > 0 ? `₹${totalRevenue.toFixed(0)}` : "-"}
          </p>
        </div>
        <div className="pramaan-card p-5">
          <p className="text-[11px] font-medium tracking-wider uppercase" style={{ color: "var(--pramaan-text-muted)" }}>All-time Events</p>
          <p className="text-2xl font-serif mt-2" style={{ color: "var(--pramaan-text)" }}>{total}</p>
        </div>
      </div>

      {/* Table */}
      <div className="pramaan-card">
        {loading ? (
          <div className="flex items-center justify-center h-32">
            <Loader2 className="h-6 w-6 animate-spin" style={{ color: "var(--pramaan-gold)" }} />
          </div>
        ) : error ? (
          <div className="p-5 text-[13px]" style={{ color: "var(--tier-hot)" }}>{error}</div>
        ) : events.length === 0 ? (
          <div className="text-center py-14">
            <Receipt className="h-10 w-10 mx-auto" style={{ color: "var(--pramaan-border)" }} />
            <p className="text-[13px] mt-3" style={{ color: "var(--pramaan-text-muted)" }}>
              No billing events recorded yet.
            </p>
          </div>
        ) : (
          <table className="w-full text-[13px]">
            <thead>
              <tr className="text-left border-b" style={{ borderColor: "var(--pramaan-border-subtle)", color: "var(--pramaan-text-muted)" }}>
                <th className="px-5 py-3 text-[10px] font-semibold tracking-wider uppercase">Event Type</th>
                <th className="px-5 py-3 text-[10px] font-semibold tracking-wider uppercase">Amount</th>
                <th className="px-5 py-3 text-[10px] font-semibold tracking-wider uppercase">Lead</th>
                <th className="px-5 py-3 text-[10px] font-semibold tracking-wider uppercase">Date</th>
                <th className="px-5 py-3 text-[10px] font-semibold tracking-wider uppercase">Details</th>
              </tr>
            </thead>
            <tbody>
              {events.map((evt) => (
                <tr
                  key={evt.id}
                  className="border-b transition-colors"
                  style={{ borderColor: "var(--pramaan-border-subtle)" }}
                  onMouseEnter={(e) => (e.currentTarget.style.background = "var(--pramaan-gold-light)")}
                  onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                >
                  <td className="px-5 py-3">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-medium" style={{ background: "var(--pramaan-gold-light)", color: "var(--pramaan-gold-hover)" }}>
                      {evt.event_type}
                    </span>
                  </td>
                  <td className="px-5 py-3 font-medium" style={{ color: "var(--pramaan-text)" }}>
                    {evt.amount_inr != null ? `₹${evt.amount_inr.toFixed(0)}` : "-"}
                  </td>
                  <td className="px-5 py-3">
                    {evt.lead_id ? (
                      <Link href={`/leads/${evt.lead_id}`} className="text-[11px] font-mono hover:opacity-70" style={{ color: "var(--pramaan-gold)" }}>
                        {evt.lead_id.slice(0, 8)}...
                      </Link>
                    ) : (
                      <span className="text-[11px]" style={{ color: "var(--pramaan-text-muted)" }}>-</span>
                    )}
                  </td>
                  <td className="px-5 py-3" style={{ color: "var(--pramaan-text-secondary)" }}>
                    {timeAgo(evt.created_at)}
                  </td>
                  <td className="px-5 py-3 text-[11px] max-w-xs truncate" style={{ color: "var(--pramaan-text-muted)" }}>
                    {evt.extra_data ? JSON.stringify(evt.extra_data).slice(0, 80) : "-"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        {totalPages > 1 && (
          <div className="flex items-center justify-between px-5 py-3 border-t" style={{ borderColor: "var(--pramaan-border-subtle)" }}>
            <p className="text-[12px]" style={{ color: "var(--pramaan-text-muted)" }}>
              Page {currentPage} of {totalPages}
            </p>
            <div className="flex gap-2">
              <button onClick={() => setOffset(Math.max(0, offset - limit))} disabled={offset === 0} className="pramaan-btn-ghost !py-1.5 !px-3 text-[12px]">
                Previous
              </button>
              <button onClick={() => setOffset(offset + limit)} disabled={currentPage >= totalPages} className="pramaan-btn-ghost !py-1.5 !px-3 text-[12px]">
                Next
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
