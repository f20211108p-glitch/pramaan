import type { Metadata } from "next";
import "./globals.css";
import AuthProvider from "@/components/AuthProvider";
import ClientProvider from "@/components/ClientProvider";
import ExtensionErrorSuppressor from "@/components/ExtensionErrorSuppressor";
import AppShell from "@/components/AppShell";

export const metadata: Metadata = {
  title: "PRAMAAN — Intelligent Lead Qualification",
  description: "Less Noise. More Buyers. Premium real estate lead intelligence platform.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="h-full antialiased" suppressHydrationWarning>
      <head />
      <body className="h-full pramaan-grain" suppressHydrationWarning>
        <ExtensionErrorSuppressor />
        <AuthProvider>
          <ClientProvider>
            <AppShell>{children}</AppShell>
          </ClientProvider>
        </AuthProvider>
      </body>
    </html>
  );
}
