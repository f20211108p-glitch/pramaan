"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { useClient } from "@/components/ClientProvider";
import { getLeadDetail, getLeadTimeline, exportConversation } from "@/lib/api";
import type { LeadDetail, LeadTimeline } from "@/lib/types";
import { TierBadge, StageBadge } from "@/components/TierBadge";
import ChatView from "@/components/ChatView";
import LeadInsightCard from "@/components/LeadInsightCard";
import { formatBudgetRange, formatPhone, timeAgo, scoreColor } from "@/lib/utils";
import {
  Loader2, ArrowLeft, Phone, Mail, MapPin, Home,
  Calendar, DollarSign, Users, MessageSquare, Clock,
  Download, ChevronDown, ChevronRight,
} from "lucide-react";

type Tab = "conversations" | "timeline" | "billing";

export default function LeadDetailPage() {
  const params = useParams();
  const router = useRouter();
  const leadId = params.id as string;
  const { currentClientId } = useClient();
  const [detail, setDetail] = useState<LeadDetail | null>(null);
  const [timeline, setTimeline] = useState<LeadTimeline | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<Tab>("conversations");
  const [expandedConvo, setExpandedConvo] = useState<string | null>(null);

  useEffect(() => {
    if (!currentClientId || !leadId) return;
    setLoading(true);
    setError(null);
    Promise.all([
      getLeadDetail(currentClientId, leadId),
      getLeadTimeline(currentClientId, leadId),
    ])
      .then(([d, t]) => {
        setDetail(d);
        setTimeline(t);
        if (d.conversations.length > 0) setExpandedConvo(d.conversations[0].id);
      })
      .catch((e) => setError(e instanceof Error ? e.message : "Failed to load lead"))
      .finally(() => setLoading(false));
  }, [currentClientId, leadId]);

  const handleExportConvo = async (conversationId: string) => {
    if (!currentClientId) return;
    try {
      const text = await exportConversation(currentClientId, conversationId, "text");
      const blob = new Blob([text], { type: "text/plain" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `conversation_${conversationId.slice(0, 8)}.txt`;
      a.click();
      URL.revokeObjectURL(url);
    } catch { alert("Export failed"); }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-7 w-7 animate-spin" style={{ color: "var(--pramaan-gold)" }} />
      </div>
    );
  }

  if (error || !detail) {
    return (
      <div className="space-y-4">
        <button onClick={() => router.push("/leads")} className="flex items-center gap-1 text-[13px]" style={{ color: "var(--pramaan-text-muted)" }}>
          <ArrowLeft className="h-4 w-4" /> Back to Leads
        </button>
        <div className="pramaan-card p-6" style={{ borderColor: "var(--tier-hot)" }}>
          <p style={{ color: "var(--tier-hot)" }}>{error || "Lead not found"}</p>
        </div>
      </div>
    );
  }

  const { lead, conversations, billing_events, consents, summary } = detail;

  return (
    <div className="space-y-6">
      <button onClick={() => router.push("/leads")} className="flex items-center gap-1 text-[13px] hover:opacity-70 transition-opacity" style={{ color: "var(--pramaan-text-muted)" }}>
        <ArrowLeft className="h-4 w-4" /> Back to Leads
      </button>

      {/* Lead profile */}
      <div className="pramaan-card p-6">
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-[24px] font-serif" style={{ color: "var(--pramaan-text)" }}>
                {lead.name || formatPhone(lead.phone)}
              </h1>
              <TierBadge tier={lead.tier} />
              <StageBadge stage={lead.stage} />
            </div>
            <div className="flex items-center gap-4 mt-2 text-[12px]" style={{ color: "var(--pramaan-text-muted)" }}>
              <span className="flex items-center gap-1"><Phone className="h-3.5 w-3.5" />{formatPhone(lead.phone)}</span>
              {lead.email && <span className="flex items-center gap-1"><Mail className="h-3.5 w-3.5" />{lead.email}</span>}
              <span className="flex items-center gap-1"><Clock className="h-3.5 w-3.5" />Created {timeAgo(lead.created_at)}</span>
            </div>
          </div>
          <div className="text-right">
            <div className={scoreColor(lead.score)}>Score: {lead.score ?? "-"}</div>
            <p className="text-[11px] mt-1" style={{ color: "var(--pramaan-text-muted)" }}>Updated {timeAgo(lead.updated_at)}</p>
          </div>
        </div>

        {/* Details grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6 pt-5 border-t" style={{ borderColor: "var(--pramaan-border-subtle)" }}>
          <InfoItem icon={<DollarSign className="h-4 w-4" />} label="Budget" value={formatBudgetRange(lead.budget_min, lead.budget_max)} />
          <InfoItem icon={<Home className="h-4 w-4" />} label="Property Type" value={lead.property_type || "-"} />
          <InfoItem icon={<Calendar className="h-4 w-4" />} label="Timeline" value={lead.timeline_months ? `${lead.timeline_months} month${lead.timeline_months > 1 ? "s" : ""}` : "-"} />
          <InfoItem icon={<Users className="h-4 w-4" />} label="Family Size" value={lead.family_size?.toString() || "-"} />
          <InfoItem icon={<MapPin className="h-4 w-4" />} label="Locations" value={lead.location_preferences?.length ? lead.location_preferences.join(", ") : "-"} />
          <InfoItem label="Intent" value={lead.intent || "-"} />
          <InfoItem label="Urgency" value={lead.urgency || "-"} />
          <InfoItem label="Financing" value={lead.financing_status || "-"} />
        </div>
      </div>

      {/* Summary row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <SummaryCard label="Conversations" value={summary.total_conversations} />
        <SummaryCard label="Messages" value={summary.total_messages} />
        <SummaryCard label="Billing Events" value={summary.total_billing_events} />
        <SummaryCard label="Consent" value={summary.has_consent ? "Granted" : "Pending"} isText />
      </div>

      {/* AI Sales Insight */}
      {currentClientId && (
        <LeadInsightCard clientId={currentClientId} leadId={leadId} />
      )}

      {/* Tabs */}
      <div className="border-b" style={{ borderColor: "var(--pramaan-border)" }}>
        <nav className="flex gap-8">
          {(["conversations", "timeline", "billing"] as Tab[]).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className="pb-3 text-[13px] font-medium border-b-2 transition-colors capitalize"
              style={{
                borderColor: activeTab === tab ? "var(--pramaan-gold)" : "transparent",
                color: activeTab === tab ? "var(--pramaan-gold)" : "var(--pramaan-text-muted)",
              }}
            >
              {tab}
            </button>
          ))}
        </nav>
      </div>

      {/* Tab: Conversations */}
      {activeTab === "conversations" && (
        <div className="space-y-4">
          {conversations.length === 0 ? (
            <p className="text-[13px] text-center py-10" style={{ color: "var(--pramaan-text-muted)" }}>No conversations yet.</p>
          ) : (
            conversations.map((convo) => (
              <div key={convo.id} className="pramaan-card overflow-hidden">
                {/* Use div instead of button to avoid nested <button> violation */}
                <div
                  role="button"
                  tabIndex={0}
                  onClick={() => setExpandedConvo(expandedConvo === convo.id ? null : convo.id)}
                  onKeyDown={(e) => e.key === "Enter" && setExpandedConvo(expandedConvo === convo.id ? null : convo.id)}
                  className="w-full flex items-center justify-between p-4 transition-colors cursor-pointer"
                  onMouseEnter={(e) => (e.currentTarget.style.background = "var(--pramaan-gold-light)")}
                  onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                >
                  <div className="flex items-center gap-3">
                    <MessageSquare className="h-4 w-4" style={{ color: "var(--pramaan-text-muted)" }} />
                    <div className="text-left">
                      <p className="text-[13px] font-medium" style={{ color: "var(--pramaan-text)" }}>{convo.channel} conversation</p>
                      <p className="text-[11px]" style={{ color: "var(--pramaan-text-muted)" }}>
                        {convo.message_count ?? 0} messages &middot; {convo.status} &middot; {timeAgo(convo.last_message_at)}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={(e) => { e.stopPropagation(); handleExportConvo(convo.id); }} className="p-1 rounded hover:opacity-70" title="Export conversation">
                      <Download className="h-3.5 w-3.5" style={{ color: "var(--pramaan-text-muted)" }} />
                    </button>
                    {expandedConvo === convo.id ? (
                      <ChevronDown className="h-4 w-4" style={{ color: "var(--pramaan-text-muted)" }} />
                    ) : (
                      <ChevronRight className="h-4 w-4" style={{ color: "var(--pramaan-text-muted)" }} />
                    )}
                  </div>
                </div>
                {expandedConvo === convo.id && (
                  <div className="border-t max-h-96 overflow-y-auto" style={{ borderColor: "var(--pramaan-border-subtle)", background: "var(--pramaan-bg)" }}>
                    {convo.summary && (
                      <div className="px-5 py-2 border-b" style={{ background: "var(--pramaan-gold-light)", borderColor: "var(--pramaan-border-subtle)" }}>
                        <p className="text-[11px]" style={{ color: "var(--pramaan-gold-hover)" }}>
                          <strong>Summary:</strong> {convo.summary}
                        </p>
                      </div>
                    )}
                    <ChatView messages={convo.messages || []} />
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      )}

      {/* Tab: Timeline */}
      {activeTab === "timeline" && timeline && (
        <div className="pramaan-card">
          <div className="px-5 py-4 border-b" style={{ borderColor: "var(--pramaan-border-subtle)" }}>
            <h3 className="text-[11px] font-semibold tracking-wider uppercase" style={{ color: "var(--pramaan-text-muted)" }}>
              Timeline ({timeline.total_events} events)
            </h3>
          </div>
          <div className="divide-y" style={{ borderColor: "var(--pramaan-border-subtle)" }}>
            {timeline.events.length === 0 ? (
              <p className="text-[13px] text-center py-10" style={{ color: "var(--pramaan-text-muted)" }}>No timeline events.</p>
            ) : (
              timeline.events.map((evt, i) => (
                <div key={i} className="px-5 py-3 flex items-start gap-3">
                  <div className="mt-1.5 w-2 h-2 rounded-full flex-shrink-0" style={{ background: evt.type === "message" ? "var(--pramaan-gold)" : "var(--stage-converted)" }} />
                  <div className="flex-1 min-w-0">
                    <p className="text-[13px]" style={{ color: "var(--pramaan-text)" }}>
                      {evt.type === "message" ? (
                        <>
                          <span className="font-medium">{(evt.data.direction as string) === "inbound" ? "Lead" : "Bot"}</span>:{" "}
                          <span style={{ color: "var(--pramaan-text-secondary)" }}>
                            {(evt.data.content as string)?.slice(0, 120)}{((evt.data.content as string)?.length ?? 0) > 120 ? "..." : ""}
                          </span>
                        </>
                      ) : (
                        <>
                          <span className="font-medium" style={{ color: "var(--stage-converted)" }}>Billing:</span>{" "}
                          <span style={{ color: "var(--pramaan-text-secondary)" }}>{evt.data.event_type as string}{evt.data.amount_inr ? ` - ₹${evt.data.amount_inr}` : ""}</span>
                        </>
                      )}
                    </p>
                    <p className="text-[10px] mt-0.5" style={{ color: "var(--pramaan-text-muted)" }}>{new Date(evt.timestamp).toLocaleString()}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Tab: Billing */}
      {activeTab === "billing" && (
        <div className="pramaan-card">
          <div className="px-5 py-4 border-b" style={{ borderColor: "var(--pramaan-border-subtle)" }}>
            <h3 className="text-[11px] font-semibold tracking-wider uppercase" style={{ color: "var(--pramaan-text-muted)" }}>
              Billing Events ({billing_events.length})
            </h3>
          </div>
          {billing_events.length === 0 ? (
            <p className="text-[13px] text-center py-10" style={{ color: "var(--pramaan-text-muted)" }}>No billing events for this lead.</p>
          ) : (
            <table className="w-full text-[13px]">
              <thead>
                <tr className="text-left border-b" style={{ borderColor: "var(--pramaan-border-subtle)", color: "var(--pramaan-text-muted)" }}>
                  <th className="px-5 py-2 text-[10px] font-semibold tracking-wider uppercase">Type</th>
                  <th className="px-5 py-2 text-[10px] font-semibold tracking-wider uppercase">Amount</th>
                  <th className="px-5 py-2 text-[10px] font-semibold tracking-wider uppercase">Date</th>
                  <th className="px-5 py-2 text-[10px] font-semibold tracking-wider uppercase">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y" style={{ borderColor: "var(--pramaan-border-subtle)" }}>
                {billing_events.map((evt) => (
                  <tr key={evt.id} className="transition-colors" onMouseEnter={(e) => (e.currentTarget.style.background = "var(--pramaan-gold-light)")} onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}>
                    <td className="px-5 py-2 font-medium" style={{ color: "var(--pramaan-text)" }}>{evt.event_type}</td>
                    <td className="px-5 py-2" style={{ color: "var(--pramaan-text-secondary)" }}>{evt.amount_inr != null ? `₹${evt.amount_inr.toFixed(0)}` : "-"}</td>
                    <td className="px-5 py-2" style={{ color: "var(--pramaan-text-muted)" }}>{new Date(evt.created_at).toLocaleDateString()}</td>
                    <td className="px-5 py-2 text-[11px]" style={{ color: "var(--pramaan-text-muted)" }}>{evt.extra_data ? JSON.stringify(evt.extra_data).slice(0, 60) : "-"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}

      {/* Consent */}
      {consents.length > 0 && (
        <div className="pramaan-card">
          <div className="px-5 py-4 border-b" style={{ borderColor: "var(--pramaan-border-subtle)" }}>
            <h3 className="text-[11px] font-semibold tracking-wider uppercase" style={{ color: "var(--pramaan-text-muted)" }}>Consent Records</h3>
          </div>
          <div className="divide-y" style={{ borderColor: "var(--pramaan-border-subtle)" }}>
            {consents.map((c) => (
              <div key={c.id} className="px-5 py-3 flex items-center justify-between">
                <div>
                  <p className="text-[13px] font-medium" style={{ color: "var(--pramaan-text)" }}>{c.consent_type}</p>
                  <p className="text-[11px]" style={{ color: "var(--pramaan-text-muted)" }}>Source: {c.source}</p>
                </div>
                <p className="text-[11px]" style={{ color: "var(--pramaan-text-muted)" }}>{new Date(c.granted_at).toLocaleDateString()}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function InfoItem({ icon, label, value }: { icon?: React.ReactNode; label: string; value: string }) {
  return (
    <div className="flex items-start gap-2">
      {icon && <span className="mt-0.5" style={{ color: "var(--pramaan-text-muted)" }}>{icon}</span>}
      <div>
        <p className="text-[11px]" style={{ color: "var(--pramaan-text-muted)" }}>{label}</p>
        <p className="text-[13px] font-medium" style={{ color: "var(--pramaan-text)" }}>{value}</p>
      </div>
    </div>
  );
}

function SummaryCard({ label, value, isText }: { label: string; value: number | string; isText?: boolean }) {
  return (
    <div className="pramaan-card p-5">
      <p className="text-[11px] font-medium tracking-wider uppercase" style={{ color: "var(--pramaan-text-muted)" }}>{label}</p>
      <p className="text-xl font-serif mt-2" style={{
        color: isText ? (value === "Granted" ? "var(--stage-converted)" : "var(--pramaan-gold)") : "var(--pramaan-text)",
      }}>
        {value}
      </p>
    </div>
  );
}
