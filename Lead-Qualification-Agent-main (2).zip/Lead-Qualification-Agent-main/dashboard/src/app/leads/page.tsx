"use client";

import { useEffect, useState, useCallback } from "react";
import { useClient } from "@/components/ClientProvider";
import { listLeads, bulkUpdateLeads, exportLeadsCSV } from "@/lib/api";
import type { Lead } from "@/lib/types";
import LeadTable from "@/components/LeadTable";
import { Loader2, Download, Filter, RefreshCw } from "lucide-react";

export default function LeadsPage() {
  const { currentClientId } = useClient();
  const [leads, setLeads] = useState<Lead[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [tierFilter, setTierFilter] = useState<string>("");
  const [stageFilter, setStageFilter] = useState<string>("");
  const [search, setSearch] = useState("");
  const [offset, setOffset] = useState(0);
  const limit = 25;
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [bulkStage, setBulkStage] = useState("");

  const fetchLeads = useCallback(async () => {
    if (!currentClientId) return;
    setLoading(true);
    setError(null);
    try {
      const data = await listLeads(currentClientId, {
        tier: tierFilter || undefined,
        stage: stageFilter || undefined,
        search: search || undefined,
        limit,
        offset,
      });
      setLeads(data.leads);
      setTotal(data.total);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : "Failed to load leads");
    } finally {
      setLoading(false);
    }
  }, [currentClientId, tierFilter, stageFilter, search, offset]);

  useEffect(() => { fetchLeads(); }, [fetchLeads]);
  useEffect(() => { setOffset(0); }, [tierFilter, stageFilter, search]);

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const handleBulkUpdate = async () => {
    if (!currentClientId || selectedIds.size === 0 || !bulkStage) return;
    try {
      await bulkUpdateLeads(currentClientId, Array.from(selectedIds), { stage: bulkStage });
      setSelectedIds(new Set());
      setBulkStage("");
      fetchLeads();
    } catch (e: unknown) {
      alert("Bulk update failed: " + (e instanceof Error ? e.message : ""));
    }
  };

  const handleExport = async () => {
    if (!currentClientId) return;
    try {
      const csv = await exportLeadsCSV(currentClientId, tierFilter || undefined, stageFilter || undefined);
      const blob = new Blob([csv], { type: "text/csv" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `leads_export_${new Date().toISOString().slice(0, 10)}.csv`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (e: unknown) {
      alert("Export failed: " + (e instanceof Error ? e.message : ""));
    }
  };

  const totalPages = Math.ceil(total / limit);
  const currentPage = Math.floor(offset / limit) + 1;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-[28px] font-serif" style={{ color: "var(--pramaan-text)" }}>
            Leads
          </h1>
          <p className="text-[13px] mt-1" style={{ color: "var(--pramaan-text-muted)" }}>
            {total} total leads in pipeline
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button onClick={fetchLeads} className="pramaan-btn-ghost !p-2.5 !rounded-xl" title="Refresh">
            <RefreshCw className="h-4 w-4" />
          </button>
          <button onClick={handleExport} className="pramaan-btn-ghost flex items-center gap-2">
            <Download className="h-4 w-4" />
            Export CSV
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="pramaan-card p-4">
        <div className="flex flex-wrap items-center gap-3">
          <Filter className="h-4 w-4" style={{ color: "var(--pramaan-text-muted)" }} />
          <input
            type="text"
            placeholder="Search phone or name..."
            className="pramaan-input w-60"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <select className="pramaan-select" value={tierFilter} onChange={(e) => setTierFilter(e.target.value)}>
            <option value="">All Tiers</option>
            <option value="hot">Hot</option>
            <option value="warm">Warm</option>
            <option value="cold">Cold</option>
          </select>
          <select className="pramaan-select" value={stageFilter} onChange={(e) => setStageFilter(e.target.value)}>
            <option value="">All Stages</option>
            <option value="new">New</option>
            <option value="qualifying">Qualifying</option>
            <option value="qualified">Qualified</option>
            <option value="scheduling">Scheduling</option>
            <option value="nurturing">Nurturing</option>
            <option value="handed_off">Handed Off</option>
            <option value="converted">Converted</option>
            <option value="lost">Lost</option>
          </select>
        </div>
      </div>

      {/* Bulk actions */}
      {selectedIds.size > 0 && (
        <div className="pramaan-card p-4 flex items-center gap-3" style={{ background: "var(--pramaan-gold-light)" }}>
          <span className="text-[13px] font-medium" style={{ color: "var(--pramaan-gold-hover)" }}>
            {selectedIds.size} selected
          </span>
          <select className="pramaan-select text-[13px]" value={bulkStage} onChange={(e) => setBulkStage(e.target.value)}>
            <option value="">Move to stage...</option>
            <option value="qualifying">Qualifying</option>
            <option value="qualified">Qualified</option>
            <option value="scheduling">Scheduling</option>
            <option value="nurturing">Nurturing</option>
            <option value="handed_off">Handed Off</option>
            <option value="converted">Converted</option>
            <option value="lost">Lost</option>
          </select>
          <button onClick={handleBulkUpdate} disabled={!bulkStage} className="pramaan-btn !py-2 !px-4 text-[13px]">
            Apply
          </button>
          <button
            onClick={() => setSelectedIds(new Set())}
            className="text-[13px] font-medium"
            style={{ color: "var(--pramaan-text-muted)" }}
          >
            Clear
          </button>
        </div>
      )}

      {/* Table */}
      <div className="pramaan-card">
        {loading ? (
          <div className="flex items-center justify-center h-32">
            <Loader2 className="h-6 w-6 animate-spin" style={{ color: "var(--pramaan-gold)" }} />
          </div>
        ) : error ? (
          <div className="p-5 text-[13px]" style={{ color: "var(--tier-hot)" }}>{error}</div>
        ) : (
          <LeadTable leads={leads} clientId={currentClientId!} showSelect selectedIds={selectedIds} onToggle={toggleSelect} />
        )}

        {totalPages > 1 && (
          <div className="flex items-center justify-between px-5 py-3 border-t" style={{ borderColor: "var(--pramaan-border-subtle)" }}>
            <p className="text-[12px]" style={{ color: "var(--pramaan-text-muted)" }}>
              Page {currentPage} of {totalPages}
            </p>
            <div className="flex gap-2">
              <button onClick={() => setOffset(Math.max(0, offset - limit))} disabled={offset === 0} className="pramaan-btn-ghost !py-1.5 !px-3 text-[12px]">
                Previous
              </button>
              <button onClick={() => setOffset(offset + limit)} disabled={currentPage >= totalPages} className="pramaan-btn-ghost !py-1.5 !px-3 text-[12px]">
                Next
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
