/**
 * Login page layout — no sidebar, no header, just the full-screen login form.
 */
export default function LoginLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
