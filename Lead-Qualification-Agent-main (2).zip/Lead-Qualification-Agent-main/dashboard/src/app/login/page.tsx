"use client";

import { useState } from "react";
import Image from "next/image";
import { useAuth } from "@/components/AuthProvider";
import { Loader2 } from "lucide-react";

export default function LoginPage() {
  const { login, user } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // If already logged in, show nothing (AuthProvider will redirect)
  if (user) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await login(email, password);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Login failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="min-h-screen flex items-center justify-center px-4"
      style={{ background: "var(--pramaan-bg)" }}
    >
      {/* Decorative gold curves — inspired by brand imagery */}
      <div
        className="fixed top-0 right-0 w-64 h-96 opacity-[0.08] pointer-events-none"
        style={{
          background: "linear-gradient(135deg, var(--pramaan-gold) 0%, transparent 70%)",
          borderRadius: "0 0 0 100%",
        }}
      />
      <div
        className="fixed bottom-0 left-0 w-64 h-96 opacity-[0.08] pointer-events-none"
        style={{
          background: "linear-gradient(315deg, var(--pramaan-gold) 0%, transparent 70%)",
          borderRadius: "0 100% 0 0",
        }}
      />

      <div className="w-full max-w-md">
        {/* Logo + Brand */}
        <div className="text-center mb-10">
          {/* Seal mark — Pramaan logo */}
          <Image
            src="/pramaan-seal.svg"
            alt="Pramaan"
            width={80}
            height={80}
            className="mx-auto mb-5 drop-shadow-lg"
            priority
          />

          <h1
            className="text-[28px] font-serif tracking-[0.15em] uppercase"
            style={{ color: "var(--pramaan-text)" }}
          >
            PRAMAAN
          </h1>
          <div className="flex items-center justify-center gap-3 mt-2">
            <div className="w-12 h-px" style={{ background: "var(--pramaan-gold)" }} />
            <span
              className="text-[11px] tracking-[0.2em] uppercase italic"
              style={{ color: "var(--pramaan-text-muted)" }}
            >
              proof over promises
            </span>
            <div className="w-12 h-px" style={{ background: "var(--pramaan-gold)" }} />
          </div>
        </div>

        {/* Login Card */}
        <div className="pramaan-card p-8">
          <h2
            className="text-[18px] font-serif text-center mb-1"
            style={{ color: "var(--pramaan-text)" }}
          >
            Welcome back
          </h2>
          <p
            className="text-[13px] text-center mb-6"
            style={{ color: "var(--pramaan-text-muted)" }}
          >
            Sign in to your dashboard
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label
                className="block text-[12px] font-medium uppercase tracking-wide mb-1.5"
                style={{ color: "var(--pramaan-text-secondary)" }}
              >
                Email
              </label>
              <input
                type="email"
                className="pramaan-input w-full"
                placeholder="you@company.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                autoFocus
                autoComplete="email"
              />
            </div>

            <div>
              <label
                className="block text-[12px] font-medium uppercase tracking-wide mb-1.5"
                style={{ color: "var(--pramaan-text-secondary)" }}
              >
                Password
              </label>
              <input
                type="password"
                className="pramaan-input w-full"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                autoComplete="current-password"
              />
            </div>

            {error && (
              <div
                className="text-[13px] px-4 py-3 rounded-xl"
                style={{
                  background: "var(--tier-hot-bg)",
                  color: "var(--tier-hot)",
                  border: "1px solid #E8C5C3",
                }}
              >
                {error}
              </div>
            )}

            <button
              type="submit"
              className="pramaan-btn w-full flex items-center justify-center gap-2"
              disabled={loading || !email || !password}
            >
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Signing in...
                </>
              ) : (
                "Sign In"
              )}
            </button>
          </form>
        </div>

        {/* Footer */}
        <p
          className="text-center text-[11px] mt-6"
          style={{ color: "var(--pramaan-text-muted)" }}
        >
          Less Noise. More Buyers.
        </p>
        <p
          className="text-center text-[10px] mt-1"
          style={{ color: "var(--pramaan-text-muted)", opacity: 0.6 }}
        >
          getpramaan.com
        </p>
      </div>
    </div>
  );
}
