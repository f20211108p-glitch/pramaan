"use client";

import { useState, useEffect } from "react";
import { useAuth } from "@/components/AuthProvider";
import { useClient } from "@/components/ClientProvider";
import { getAuthHeaders } from "@/lib/auth";
import {
  Loader2,
  Building2,
  UserPlus,
  CheckCircle2,
  AlertCircle,
  ChevronRight,
} from "lucide-react";

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

interface OnboardingUser {
  id: string;
  email: string;
  name: string;
  role: string;
  client_id: string | null;
  client_name: string | null;
  active: boolean;
}

export default function OnboardingPage() {
  const { user, isAdmin } = useAuth();
  const { clients } = useClient();

  // Step 1: Create Client
  const [clientName, setClientName] = useState("");
  const [wabaNumber, setWabaNumber] = useState("");
  const [wabaPhoneNumberId, setWabaPhoneNumberId] = useState("");
  const [wabaToken, setWabaToken] = useState("");
  const [brokerNumbers, setBrokerNumbers] = useState("");
  const [billingModel, setBillingModel] = useState("direct");
  const [crmType, setCrmType] = useState("");

  // Step 2: Create User
  const [userEmail, setUserEmail] = useState("");
  const [userPassword, setUserPassword] = useState("");
  const [userName, setUserName] = useState("");
  const [selectedClientId, setSelectedClientId] = useState("");

  // State
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [createdClientId, setCreatedClientId] = useState<string | null>(null);
  const [existingUsers, setExistingUsers] = useState<OnboardingUser[]>([]);

  // Load existing users
  useEffect(() => {
    if (!isAdmin) return;
    fetch(`${API_BASE}/auth/users`, {
      headers: { ...getAuthHeaders() },
    })
      .then((r) => r.json())
      .then((data) => setExistingUsers(data.users || []))
      .catch(() => {});
  }, [isAdmin, success]);

  if (!isAdmin) {
    return (
      <div className="pramaan-card p-8 text-center max-w-lg mx-auto mt-16">
        <AlertCircle
          className="h-12 w-12 mx-auto mb-4"
          style={{ color: "var(--tier-hot)" }}
        />
        <h2
          className="text-[18px] font-serif mb-2"
          style={{ color: "var(--pramaan-text)" }}
        >
          Admin Access Required
        </h2>
        <p
          className="text-[13px]"
          style={{ color: "var(--pramaan-text-secondary)" }}
        >
          Only Pramaan administrators can onboard new clients.
        </p>
      </div>
    );
  }

  const handleCreateClient = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    setLoading(true);

    try {
      const res = await fetch(`${API_BASE}/admin/clients`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...getAuthHeaders(),
        },
        body: JSON.stringify({
          client_name: clientName,
          waba_number: wabaNumber,
          waba_phone_number_id: wabaPhoneNumberId,
          waba_token: wabaToken,
          broker_wa_numbers: brokerNumbers
            .split(",")
            .map((n) => n.trim())
            .filter(Boolean),
          billing_model: billingModel,
          crm_type: crmType || null,
        }),
      });

      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.detail || `Failed (${res.status})`);
      }

      const client = await res.json();
      setCreatedClientId(client.id);
      setSelectedClientId(client.id);
      setSuccess(`Client "${clientName}" created successfully!`);
      setStep(2);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Failed to create client");
    } finally {
      setLoading(false);
    }
  };

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    setLoading(true);

    try {
      const res = await fetch(`${API_BASE}/auth/users`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...getAuthHeaders(),
        },
        body: JSON.stringify({
          email: userEmail,
          password: userPassword,
          name: userName,
          role: "client",
          client_id: selectedClientId || createdClientId,
        }),
      });

      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.detail || `Failed (${res.status})`);
      }

      setSuccess(`User "${userName}" created! They can now login at /login`);
      setUserEmail("");
      setUserPassword("");
      setUserName("");
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Failed to create user");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 max-w-3xl">
      {/* Page header */}
      <div>
        <h1
          className="text-[28px] font-serif"
          style={{ color: "var(--pramaan-text)" }}
        >
          Client Onboarding
        </h1>
        <p
          className="text-[13px] mt-1"
          style={{ color: "var(--pramaan-text-muted)" }}
        >
          Set up a new developer client on the Pramaan platform
        </p>
      </div>

      {/* Steps indicator */}
      <div className="flex items-center gap-3">
        <div
          className="flex items-center gap-2 px-4 py-2 rounded-xl text-[13px] font-medium"
          style={{
            background:
              step === 1
                ? "var(--pramaan-gold-light)"
                : "var(--pramaan-card)",
            color:
              step === 1
                ? "var(--pramaan-gold-hover)"
                : "var(--pramaan-text-muted)",
            border: `1px solid ${step === 1 ? "var(--pramaan-gold)" : "var(--pramaan-border)"}`,
          }}
        >
          <Building2 className="h-4 w-4" />
          1. Create Client
        </div>
        <ChevronRight
          className="h-4 w-4"
          style={{ color: "var(--pramaan-text-muted)" }}
        />
        <div
          className="flex items-center gap-2 px-4 py-2 rounded-xl text-[13px] font-medium"
          style={{
            background:
              step === 2
                ? "var(--pramaan-gold-light)"
                : "var(--pramaan-card)",
            color:
              step === 2
                ? "var(--pramaan-gold-hover)"
                : "var(--pramaan-text-muted)",
            border: `1px solid ${step === 2 ? "var(--pramaan-gold)" : "var(--pramaan-border)"}`,
          }}
        >
          <UserPlus className="h-4 w-4" />
          2. Create Login
        </div>
      </div>

      {/* Feedback */}
      {error && (
        <div
          className="px-4 py-3 rounded-xl text-[13px] flex items-center gap-2"
          style={{
            background: "var(--tier-hot-bg)",
            color: "var(--tier-hot)",
            border: "1px solid #E8C5C3",
          }}
        >
          <AlertCircle className="h-4 w-4 shrink-0" />
          {error}
        </div>
      )}
      {success && (
        <div
          className="px-4 py-3 rounded-xl text-[13px] flex items-center gap-2"
          style={{
            background: "#EFF5EF",
            color: "#5A8A5A",
            border: "1px solid #C3E0C3",
          }}
        >
          <CheckCircle2 className="h-4 w-4 shrink-0" />
          {success}
        </div>
      )}

      {/* Step 1: Create Client */}
      {step === 1 && (
        <div className="pramaan-card p-6">
          <h3
            className="text-[16px] font-serif mb-4"
            style={{ color: "var(--pramaan-text)" }}
          >
            New Client Details
          </h3>
          <form onSubmit={handleCreateClient} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-[12px] font-medium uppercase tracking-wide mb-1.5" style={{ color: "var(--pramaan-text-secondary)" }}>
                  Client Name *
                </label>
                <input
                  className="pramaan-input w-full"
                  placeholder="e.g. Prestige Group"
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  required
                />
              </div>
              <div>
                <label className="block text-[12px] font-medium uppercase tracking-wide mb-1.5" style={{ color: "var(--pramaan-text-secondary)" }}>
                  Billing Model
                </label>
                <select
                  className="pramaan-select w-full"
                  value={billingModel}
                  onChange={(e) => setBillingModel(e.target.value)}
                >
                  <option value="direct">Direct (Fixed Fee)</option>
                  <option value="per_visit">Per Site Visit</option>
                  <option value="per_lead">Per Qualified Lead</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-[12px] font-medium uppercase tracking-wide mb-1.5" style={{ color: "var(--pramaan-text-secondary)" }}>
                  WhatsApp Number *
                </label>
                <input
                  className="pramaan-input w-full"
                  placeholder="919876543210"
                  value={wabaNumber}
                  onChange={(e) => setWabaNumber(e.target.value)}
                  required
                />
              </div>
              <div>
                <label className="block text-[12px] font-medium uppercase tracking-wide mb-1.5" style={{ color: "var(--pramaan-text-secondary)" }}>
                  WABA Phone Number ID *
                </label>
                <input
                  className="pramaan-input w-full"
                  placeholder="From Meta Business Manager"
                  value={wabaPhoneNumberId}
                  onChange={(e) => setWabaPhoneNumberId(e.target.value)}
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-[12px] font-medium uppercase tracking-wide mb-1.5" style={{ color: "var(--pramaan-text-secondary)" }}>
                WABA Access Token *
              </label>
              <input
                type="password"
                className="pramaan-input w-full"
                placeholder="WhatsApp Business API token"
                value={wabaToken}
                onChange={(e) => setWabaToken(e.target.value)}
                required
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-[12px] font-medium uppercase tracking-wide mb-1.5" style={{ color: "var(--pramaan-text-secondary)" }}>
                  Broker WhatsApp Numbers
                </label>
                <input
                  className="pramaan-input w-full"
                  placeholder="919000000001, 919000000002"
                  value={brokerNumbers}
                  onChange={(e) => setBrokerNumbers(e.target.value)}
                />
                <p className="text-[10px] mt-1" style={{ color: "var(--pramaan-text-muted)" }}>
                  Comma-separated broker numbers for notifications
                </p>
              </div>
              <div>
                <label className="block text-[12px] font-medium uppercase tracking-wide mb-1.5" style={{ color: "var(--pramaan-text-secondary)" }}>
                  CRM Type
                </label>
                <select
                  className="pramaan-select w-full"
                  value={crmType}
                  onChange={(e) => setCrmType(e.target.value)}
                >
                  <option value="">None</option>
                  {/* Value must match the backend adapter registry key ("selldo") */}
                  <option value="selldo">Sell.Do</option>
                  <option value="webhook">Custom Webhook</option>
                </select>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="submit"
                className="pramaan-btn flex items-center gap-2"
                disabled={loading}
              >
                {loading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Building2 className="h-4 w-4" />
                )}
                Create Client
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Step 2: Create User Login */}
      {step === 2 && (
        <div className="pramaan-card p-6">
          <h3
            className="text-[16px] font-serif mb-4"
            style={{ color: "var(--pramaan-text)" }}
          >
            Create Dashboard Login
          </h3>
          <form onSubmit={handleCreateUser} className="space-y-4">
            <div>
              <label className="block text-[12px] font-medium uppercase tracking-wide mb-1.5" style={{ color: "var(--pramaan-text-secondary)" }}>
                Assign to Client
              </label>
              <select
                className="pramaan-select w-full"
                value={selectedClientId || createdClientId || ""}
                onChange={(e) => setSelectedClientId(e.target.value)}
              >
                {createdClientId && (
                  <option value={createdClientId}>
                    {clientName} (just created)
                  </option>
                )}
                {clients
                  .filter((c) => c.id !== createdClientId)
                  .map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.client_name}
                    </option>
                  ))}
              </select>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-[12px] font-medium uppercase tracking-wide mb-1.5" style={{ color: "var(--pramaan-text-secondary)" }}>
                  User Name *
                </label>
                <input
                  className="pramaan-input w-full"
                  placeholder="e.g. Rajesh Kumar"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  required
                />
              </div>
              <div>
                <label className="block text-[12px] font-medium uppercase tracking-wide mb-1.5" style={{ color: "var(--pramaan-text-secondary)" }}>
                  Email *
                </label>
                <input
                  type="email"
                  className="pramaan-input w-full"
                  placeholder="user@prestige.com"
                  value={userEmail}
                  onChange={(e) => setUserEmail(e.target.value)}
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-[12px] font-medium uppercase tracking-wide mb-1.5" style={{ color: "var(--pramaan-text-secondary)" }}>
                Password *
              </label>
              <input
                type="password"
                className="pramaan-input w-full"
                placeholder="Min 8 characters"
                value={userPassword}
                onChange={(e) => setUserPassword(e.target.value)}
                required
                minLength={6}
              />
            </div>

            <div className="flex items-center justify-between pt-2">
              <button
                type="button"
                className="pramaan-btn-ghost"
                onClick={() => setStep(1)}
              >
                Back to Step 1
              </button>
              <button
                type="submit"
                className="pramaan-btn flex items-center gap-2"
                disabled={loading}
              >
                {loading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <UserPlus className="h-4 w-4" />
                )}
                Create User
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Existing users table */}
      {existingUsers.length > 0 && (
        <div className="pramaan-card">
          <div
            className="px-5 py-4 border-b"
            style={{ borderColor: "var(--pramaan-border-subtle)" }}
          >
            <h3
              className="text-[11px] font-semibold tracking-wider uppercase"
              style={{ color: "var(--pramaan-text-muted)" }}
            >
              Existing Users
            </h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-[13px]">
              <thead>
                <tr
                  style={{
                    borderBottom: "1px solid var(--pramaan-border-subtle)",
                  }}
                >
                  <th className="text-left px-5 py-3 text-[11px] font-medium uppercase tracking-wide" style={{ color: "var(--pramaan-text-muted)" }}>
                    Name
                  </th>
                  <th className="text-left px-5 py-3 text-[11px] font-medium uppercase tracking-wide" style={{ color: "var(--pramaan-text-muted)" }}>
                    Email
                  </th>
                  <th className="text-left px-5 py-3 text-[11px] font-medium uppercase tracking-wide" style={{ color: "var(--pramaan-text-muted)" }}>
                    Role
                  </th>
                  <th className="text-left px-5 py-3 text-[11px] font-medium uppercase tracking-wide" style={{ color: "var(--pramaan-text-muted)" }}>
                    Client
                  </th>
                </tr>
              </thead>
              <tbody>
                {existingUsers.map((u) => (
                  <tr
                    key={u.id}
                    style={{
                      borderBottom: "1px solid var(--pramaan-border-subtle)",
                    }}
                  >
                    <td className="px-5 py-3" style={{ color: "var(--pramaan-text)" }}>
                      {u.name}
                    </td>
                    <td className="px-5 py-3 font-mono text-[12px]" style={{ color: "var(--pramaan-text-secondary)" }}>
                      {u.email}
                    </td>
                    <td className="px-5 py-3">
                      <span
                        className="px-2 py-0.5 rounded-full text-[10px] font-medium uppercase tracking-wide"
                        style={{
                          background:
                            u.role === "admin"
                              ? "var(--pramaan-gold-light)"
                              : "var(--tier-cold-bg)",
                          color:
                            u.role === "admin"
                              ? "var(--pramaan-gold-hover)"
                              : "var(--tier-cold)",
                        }}
                      >
                        {u.role}
                      </span>
                    </td>
                    <td className="px-5 py-3" style={{ color: "var(--pramaan-text-secondary)" }}>
                      {u.client_name || (u.role === "admin" ? "All clients" : "-")}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
