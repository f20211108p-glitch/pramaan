"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { useClient } from "@/components/ClientProvider";
import { getDashboardHome } from "@/lib/api";
import type { DashboardHome } from "@/lib/types";
import StatsCards from "@/components/StatsCards";
import PipelineChart from "@/components/PipelineChart";
import LeadTable from "@/components/LeadTable";
import ActivityFeed from "@/components/ActivityFeed";
import { Loader2 } from "lucide-react";

export default function DashboardPage() {
  const { currentClientId, loading: clientLoading, error: clientError, clients } = useClient();
  const [data, setData] = useState<DashboardHome | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!currentClientId) return;
    setLoading(true);
    setError(null);
    getDashboardHome(currentClientId)
      .then(setData)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, [currentClientId]);

  if (clientLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2
          className="h-7 w-7 animate-spin"
          style={{ color: "var(--pramaan-gold)" }}
        />
      </div>
    );
  }

  // Backend offline or no clients configured
  if (!currentClientId) {
    return (
      <div className="pramaan-card p-8 text-center max-w-lg mx-auto mt-16">
        <Image
          src="/pramaan-seal.svg"
          alt="Pramaan"
          width={56}
          height={56}
          className="mx-auto mb-4"
        />
        <h2 className="text-[18px] font-serif mb-2" style={{ color: "var(--pramaan-text)" }}>
          {clientError ? "Backend Unreachable" : "No Clients Yet"}
        </h2>
        <p className="text-[13px]" style={{ color: "var(--pramaan-text-secondary)" }}>
          {clientError
            ? "Could not connect to the LeadEngine API. Start the backend server and refresh."
            : "No client accounts found. Run the onboarding script to create your first client."}
        </p>
        {clientError && (
          <p className="text-[11px] mt-3 font-mono px-3 py-2 rounded-lg" style={{ background: "var(--tier-hot-bg)", color: "var(--tier-hot)" }}>
            {clientError}
          </p>
        )}
        <p className="text-[11px] mt-4" style={{ color: "var(--pramaan-text-muted)" }}>
          API: {process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000"}
        </p>
        {clients.length === 0 && !clientError && (
          <p className="text-[11px] mt-2" style={{ color: "var(--pramaan-text-muted)" }}>
            Run: <code className="font-mono">python scripts/onboard_client.py</code>
          </p>
        )}
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2
          className="h-7 w-7 animate-spin"
          style={{ color: "var(--pramaan-gold)" }}
        />
      </div>
    );
  }

  if (error) {
    return (
      <div
        className="pramaan-card p-6"
        style={{ borderColor: "var(--tier-hot)", background: "var(--tier-hot-bg)" }}
      >
        <p className="font-medium" style={{ color: "var(--tier-hot)" }}>
          Failed to load dashboard
        </p>
        <p className="text-[13px] mt-1" style={{ color: "var(--pramaan-text-secondary)" }}>
          {error}
        </p>
        <p className="text-[11px] mt-2" style={{ color: "var(--pramaan-text-muted)" }}>
          Make sure the backend is running at{" "}
          {process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000"}
        </p>
      </div>
    );
  }

  if (!data) return null;

  return (
    <div className="space-y-8">
      {/* Page header */}
      <div>
        <h1
          className="text-[28px] font-serif"
          style={{ color: "var(--pramaan-text)" }}
        >
          Overview
        </h1>
        <p
          className="text-[13px] mt-1"
          style={{ color: "var(--pramaan-text-muted)" }}
        >
          Pipeline intelligence for {data.client.client_name}
        </p>
      </div>

      <StatsCards stats={data.stats} />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <PipelineChart stats={data.stats} />
        </div>

        <div className="pramaan-card">
          <div
            className="px-5 py-4 border-b"
            style={{ borderColor: "var(--pramaan-border-subtle)" }}
          >
            <h3
              className="text-[11px] font-semibold tracking-wider uppercase"
              style={{ color: "var(--pramaan-text-muted)" }}
            >
              Recent Activity
            </h3>
          </div>
          <div className="max-h-96 overflow-y-auto">
            <ActivityFeed items={data.recent_activity} />
          </div>
        </div>
      </div>

      {data.hot_leads.length > 0 && (
        <div className="pramaan-card">
          <div
            className="px-5 py-4 border-b"
            style={{ borderColor: "var(--pramaan-border-subtle)" }}
          >
            <h3
              className="text-[11px] font-semibold tracking-wider uppercase flex items-center gap-2"
              style={{ color: "var(--tier-hot)" }}
            >
              <span className="w-2 h-2 rounded-full" style={{ background: "var(--tier-hot)" }} />
              Hot Leads — Needs Attention
            </h3>
          </div>
          <LeadTable leads={data.hot_leads} clientId={currentClientId!} />
        </div>
      )}

      <div className="pramaan-card">
        <div
          className="px-5 py-4 border-b"
          style={{ borderColor: "var(--pramaan-border-subtle)" }}
        >
          <h3
            className="text-[11px] font-semibold tracking-wider uppercase"
            style={{ color: "var(--pramaan-text-muted)" }}
          >
            Recently Updated
          </h3>
        </div>
        <LeadTable leads={data.recent_leads} clientId={currentClientId!} />
      </div>
    </div>
  );
}
