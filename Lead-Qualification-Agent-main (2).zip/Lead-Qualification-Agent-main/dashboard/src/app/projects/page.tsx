"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import { useClient } from "@/components/ClientProvider";
import { listProjects, ingestBrochure, deleteProjectChunks } from "@/lib/api";
import type { Project } from "@/lib/api";
import {
  Loader2,
  FolderOpen,
  Upload,
  Trash2,
  FileText,
  Plus,
  X,
} from "lucide-react";

export default function ProjectsPage() {
  const { currentClientId } = useClient();
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Upload state
  const [showUpload, setShowUpload] = useState(false);
  const [projectName, setProjectName] = useState("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadResult, setUploadResult] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Delete state
  const [deleting, setDeleting] = useState<string | null>(null);

  const fetchProjects = useCallback(async () => {
    if (!currentClientId) return;
    setLoading(true);
    setError(null);
    try {
      const data = await listProjects(currentClientId);
      setProjects(Array.isArray(data) ? data : []);
    } catch (e: unknown) {
      // Projects endpoint may not exist yet
      setError(e instanceof Error ? e.message : "Failed to load projects");
      setProjects([]);
    } finally {
      setLoading(false);
    }
  }, [currentClientId]);

  useEffect(() => {
    fetchProjects();
  }, [fetchProjects]);

  const handleUpload = async () => {
    if (!currentClientId || !selectedFile || !projectName.trim()) return;
    setUploading(true);
    setUploadResult(null);
    try {
      const result = await ingestBrochure(
        currentClientId,
        projectName.trim(),
        selectedFile
      );
      setUploadResult(
        `Ingested "${projectName.trim()}" — ${result.chunks_ingested} chunks created`
      );
      setProjectName("");
      setSelectedFile(null);
      if (fileInputRef.current) fileInputRef.current.value = "";
      fetchProjects();
    } catch (e: unknown) {
      setUploadResult(
        `Upload failed: ${e instanceof Error ? e.message : "Unknown error"}`
      );
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async (projectId: string, name: string) => {
    if (!currentClientId) return;
    if (!confirm(`Delete all chunks for "${name}"? This cannot be undone.`))
      return;
    setDeleting(name);
    try {
      await deleteProjectChunks(currentClientId, projectId);
      fetchProjects();
    } catch (e: unknown) {
      alert(
        `Delete failed: ${e instanceof Error ? e.message : "Unknown error"}`
      );
    } finally {
      setDeleting(null);
    }
  };

  return (
    <div className="space-y-8 max-w-4xl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1
            className="text-[28px] font-serif"
            style={{ color: "var(--pramaan-text)" }}
          >
            Projects
          </h1>
          <p
            className="text-[13px] mt-1"
            style={{ color: "var(--pramaan-text-muted)" }}
          >
            Manage brochure PDFs for RAG-powered property queries
          </p>
        </div>
        <button
          onClick={() => setShowUpload(!showUpload)}
          className="pramaan-btn flex items-center gap-2"
        >
          {showUpload ? (
            <X className="h-4 w-4" />
          ) : (
            <Plus className="h-4 w-4" />
          )}
          {showUpload ? "Cancel" : "Add Project"}
        </button>
      </div>

      {/* Upload form */}
      {showUpload && (
        <div className="pramaan-card p-6 space-y-5">
          <h3
            className="text-[15px] font-serif"
            style={{ color: "var(--pramaan-text)" }}
          >
            Upload Brochure PDF
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label
                className="text-[12px] font-medium block mb-2"
                style={{ color: "var(--pramaan-text-secondary)" }}
              >
                Project Name
              </label>
              <input
                type="text"
                className="pramaan-input w-full"
                placeholder="e.g. Prestige Sunrise Park"
                value={projectName}
                onChange={(e) => setProjectName(e.target.value)}
              />
            </div>
            <div>
              <label
                className="text-[12px] font-medium block mb-2"
                style={{ color: "var(--pramaan-text-secondary)" }}
              >
                PDF File
              </label>
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf"
                className="pramaan-input w-full text-[13px] file:mr-4 file:py-1 file:px-3 file:rounded-lg file:border-0 file:text-[12px] file:font-medium file:cursor-pointer"
                style={{
                  // @ts-expect-error custom property
                  "--tw-file-bg": "var(--pramaan-gold-light)",
                }}
                onChange={(e) =>
                  setSelectedFile(e.target.files?.[0] || null)
                }
              />
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={handleUpload}
              disabled={!selectedFile || !projectName.trim() || uploading}
              className="pramaan-btn flex items-center gap-2"
            >
              {uploading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Upload className="h-4 w-4" />
              )}
              {uploading ? "Ingesting..." : "Upload & Ingest"}
            </button>

            {uploadResult && (
              <p
                className="text-[13px]"
                style={{
                  color: uploadResult.includes("failed")
                    ? "var(--tier-hot)"
                    : "var(--stage-converted)",
                }}
              >
                {uploadResult}
              </p>
            )}
          </div>
        </div>
      )}

      {/* Project list */}
      <div className="pramaan-card">
        <div
          className="px-6 py-4 border-b"
          style={{ borderColor: "var(--pramaan-border-subtle)" }}
        >
          <h3
            className="text-[11px] font-semibold tracking-wider uppercase"
            style={{ color: "var(--pramaan-text-muted)" }}
          >
            Ingested Projects ({projects.length})
          </h3>
        </div>

        {loading ? (
          <div className="flex items-center justify-center h-32">
            <Loader2
              className="h-6 w-6 animate-spin"
              style={{ color: "var(--pramaan-gold)" }}
            />
          </div>
        ) : error && projects.length === 0 ? (
          <div className="text-center py-14 space-y-3">
            <FolderOpen
              className="h-10 w-10 mx-auto"
              style={{ color: "var(--pramaan-border)" }}
            />
            <p
              className="text-[13px]"
              style={{ color: "var(--pramaan-text-muted)" }}
            >
              No projects yet. Upload a brochure PDF to get started.
            </p>
          </div>
        ) : projects.length === 0 ? (
          <div className="text-center py-14 space-y-3">
            <FolderOpen
              className="h-10 w-10 mx-auto"
              style={{ color: "var(--pramaan-border)" }}
            />
            <p
              className="text-[13px]"
              style={{ color: "var(--pramaan-text-muted)" }}
            >
              No projects ingested. Upload a brochure to enable property Q&A.
            </p>
          </div>
        ) : (
          <div className="divide-y" style={{ borderColor: "var(--pramaan-border-subtle)" }}>
            {projects.map((project) => (
              <div
                key={project.project_name}
                className="px-6 py-4 flex items-center justify-between transition-colors"
                onMouseEnter={(e) =>
                  (e.currentTarget.style.background = "var(--pramaan-gold-light)")
                }
                onMouseLeave={(e) =>
                  (e.currentTarget.style.background = "transparent")
                }
              >
                <div className="flex items-center gap-4">
                  <div
                    className="p-2.5 rounded-xl"
                    style={{ background: "var(--pramaan-gold-light)" }}
                  >
                    <FileText
                      className="h-5 w-5"
                      style={{ color: "var(--pramaan-gold)" }}
                    />
                  </div>
                  <div>
                    <p
                      className="text-[14px] font-medium"
                      style={{ color: "var(--pramaan-text)" }}
                    >
                      {project.project_name}
                    </p>
                    <p
                      className="text-[12px] mt-0.5"
                      style={{ color: "var(--pramaan-text-muted)" }}
                    >
                      {project.chunk_count} chunks indexed
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => handleDelete(project.project_id, project.project_name)}
                  disabled={deleting === project.project_name}
                  className="p-2 rounded-lg transition-colors"
                  style={{ color: "var(--pramaan-text-muted)" }}
                  onMouseEnter={(e) =>
                    (e.currentTarget.style.color = "var(--tier-hot)")
                  }
                  onMouseLeave={(e) =>
                    (e.currentTarget.style.color = "var(--pramaan-text-muted)")
                  }
                  title="Delete project chunks"
                >
                  {deleting === project.project_name ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Trash2 className="h-4 w-4" />
                  )}
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
