"use client";

import { useEffect, useState, useCallback } from "react";
import { useClient } from "@/components/ClientProvider";
import {
  listProjects,
  getQATemplate,
  listProjectQA,
  ingestProjectQA,
} from "@/lib/api";
import type { Project } from "@/lib/api";
import type { QATemplate, QAPair } from "@/lib/types";
import {
  Loader2,
  Save,
  Check,
  ChevronDown,
  ChevronRight,
  HelpCircle,
} from "lucide-react";

interface AnswerMap {
  [question: string]: string;
}

export default function ProjectQAPage() {
  const { currentClientId } = useClient();
  const [projects, setProjects] = useState<Project[]>([]);
  const [selectedProjectId, setSelectedProjectId] = useState<string>("");
  const [template, setTemplate] = useState<QATemplate | null>(null);
  const [answers, setAnswers] = useState<AnswerMap>({});
  const [existingCount, setExistingCount] = useState(0);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [expandedCategories, setExpandedCategories] = useState<Set<string>>(new Set());

  // Initial load: projects + template
  useEffect(() => {
    if (!currentClientId) return;
    setLoading(true);
    setError(null);
    Promise.all([
      listProjects(currentClientId).catch(() => [] as Project[]),
      getQATemplate(),
    ])
      .then(([projectsResp, tmpl]) => {
        // listProjects API actually returns {projects:[...]} — unwrap if needed
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const raw = projectsResp as any;
        const list: Project[] = Array.isArray(raw)
          ? raw
          : Array.isArray(raw?.projects)
          ? raw.projects
          : [];
        setProjects(list);
        setTemplate(tmpl);
        if (tmpl?.categories?.length) {
          setExpandedCategories(new Set(tmpl.categories.map((c) => c.name)));
        }
        if (list.length > 0) {
          setSelectedProjectId(list[0].project_id);
        }
      })
      .catch((e) => setError(e instanceof Error ? e.message : "Failed to load"))
      .finally(() => setLoading(false));
  }, [currentClientId]);

  // When a project is selected, fetch its existing Q&A
  const loadExisting = useCallback(async () => {
    if (!currentClientId || !selectedProjectId) return;
    try {
      const resp = await listProjectQA(currentClientId, selectedProjectId);
      const map: AnswerMap = {};
      for (const p of resp.qa_pairs || []) {
        if (p.question) map[p.question] = p.answer;
      }
      setAnswers(map);
      setExistingCount(resp.qa_pairs?.length || 0);
    } catch {
      setAnswers({});
      setExistingCount(0);
    }
  }, [currentClientId, selectedProjectId]);

  useEffect(() => {
    void loadExisting();
  }, [loadExisting]);

  const selectedProject = projects.find((p) => p.project_id === selectedProjectId);

  const handleSave = async () => {
    if (!currentClientId || !selectedProject) return;
    setSaving(true);
    setSaved(false);
    try {
      const pairs: QAPair[] = [];
      for (const cat of template?.categories || []) {
        for (const q of cat.questions) {
          const ans = (answers[q] || "").trim();
          if (ans) {
            pairs.push({ question: q, answer: ans, category: cat.name });
          }
        }
      }
      await ingestProjectQA(
        currentClientId,
        selectedProject.project_id,
        selectedProject.project_name,
        pairs,
        true
      );
      setSaved(true);
      setExistingCount(pairs.length);
      setTimeout(() => setSaved(false), 3000);
    } catch (e) {
      alert("Save failed: " + (e instanceof Error ? e.message : ""));
    } finally {
      setSaving(false);
    }
  };

  const toggleCategory = (name: string) => {
    setExpandedCategories((prev) => {
      const next = new Set(prev);
      if (next.has(name)) next.delete(name);
      else next.add(name);
      return next;
    });
  };

  const answeredCount = Object.values(answers).filter((v) => v.trim()).length;
  const totalQuestions = template?.categories.reduce((acc, c) => acc + c.questions.length, 0) || 0;

  if (!currentClientId) {
    return (
      <div className="pramaan-card p-6">
        <p className="text-[13px]" style={{ color: "var(--pramaan-text-muted)" }}>
          Select a client from the header.
        </p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-7 w-7 animate-spin" style={{ color: "var(--pramaan-gold)" }} />
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-[28px] font-serif" style={{ color: "var(--pramaan-text)" }}>
            Project Q&amp;A
          </h1>
          <p className="text-[13px] mt-1" style={{ color: "var(--pramaan-text-muted)" }}>
            Builder-supplied answers. Used as context by the AI when leads ask.
          </p>
        </div>
        <button
          onClick={handleSave}
          disabled={saving || !selectedProjectId}
          className="pramaan-btn flex items-center gap-2"
        >
          {saving ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : saved ? (
            <Check className="h-4 w-4" />
          ) : (
            <Save className="h-4 w-4" />
          )}
          {saving ? "Saving…" : saved ? "Saved" : "Save Answers"}
        </button>
      </div>

      {error && (
        <div className="pramaan-card p-4" style={{ borderColor: "var(--tier-hot)" }}>
          <p className="text-[12px]" style={{ color: "var(--tier-hot)" }}>{error}</p>
        </div>
      )}

      {/* Project selector */}
      <div className="pramaan-card">
        <div
          className="flex items-center justify-between px-5 py-4 border-b"
          style={{ borderColor: "var(--pramaan-border-subtle)" }}
        >
          <h3
            className="text-[11px] font-semibold tracking-wider uppercase"
            style={{ color: "var(--pramaan-text-muted)" }}
          >
            Project
          </h3>
          <p className="text-[11px]" style={{ color: "var(--pramaan-text-muted)" }}>
            {answeredCount} / {totalQuestions} answered &middot; {existingCount} saved
          </p>
        </div>
        <div className="px-5 py-4">
          {projects.length === 0 ? (
            <p className="text-[12px]" style={{ color: "var(--pramaan-text-muted)" }}>
              No projects yet. Upload a brochure first on the Projects page.
            </p>
          ) : (
            <select
              className="pramaan-select w-full max-w-md"
              value={selectedProjectId}
              onChange={(e) => setSelectedProjectId(e.target.value)}
            >
              {projects.map((p) => (
                <option key={p.project_id} value={p.project_id}>
                  {p.project_name}
                </option>
              ))}
            </select>
          )}
        </div>
      </div>

      {/* Questionnaire */}
      {template && selectedProjectId && (
        <div className="space-y-4">
          {template.categories.map((cat) => {
            const expanded = expandedCategories.has(cat.name);
            const catAnswered = cat.questions.filter((q) => (answers[q] || "").trim()).length;
            return (
              <div key={cat.name} className="pramaan-card">
                <button
                  onClick={() => toggleCategory(cat.name)}
                  className="w-full flex items-center justify-between px-5 py-4 border-b"
                  style={{ borderColor: "var(--pramaan-border-subtle)" }}
                >
                  <div className="flex items-center gap-2">
                    {expanded ? (
                      <ChevronDown className="h-4 w-4" style={{ color: "var(--pramaan-text-muted)" }} />
                    ) : (
                      <ChevronRight className="h-4 w-4" style={{ color: "var(--pramaan-text-muted)" }} />
                    )}
                    <h3
                      className="text-[13px] font-medium"
                      style={{ color: "var(--pramaan-text)" }}
                    >
                      {cat.name}
                    </h3>
                  </div>
                  <span
                    className="text-[11px]"
                    style={{
                      color:
                        catAnswered === cat.questions.length
                          ? "#7A8C5C"
                          : "var(--pramaan-text-muted)",
                    }}
                  >
                    {catAnswered} / {cat.questions.length}
                  </span>
                </button>
                {expanded && (
                  <div
                    className="divide-y"
                    style={{ borderColor: "var(--pramaan-border-subtle)" }}
                  >
                    {cat.questions.map((q, i) => (
                      <div key={i} className="px-5 py-4">
                        <div className="flex items-start gap-2 mb-2">
                          <HelpCircle
                            className="h-3.5 w-3.5 flex-shrink-0 mt-0.5"
                            style={{ color: "var(--pramaan-gold)" }}
                          />
                          <p
                            className="text-[12px] font-medium"
                            style={{ color: "var(--pramaan-text)" }}
                          >
                            {q}
                          </p>
                        </div>
                        <textarea
                          className="pramaan-input w-full text-[12px] min-h-[60px] resize-y"
                          placeholder="Type the answer here (leave blank if unknown)"
                          value={answers[q] || ""}
                          onChange={(e) =>
                            setAnswers((prev) => ({ ...prev, [q]: e.target.value }))
                          }
                        />
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
