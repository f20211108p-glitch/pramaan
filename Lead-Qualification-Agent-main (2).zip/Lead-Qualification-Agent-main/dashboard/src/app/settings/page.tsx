"use client";

import { useEffect, useState } from "react";
import { useClient } from "@/components/ClientProvider";
import { getClient, updateClient } from "@/lib/api";
import type { Client } from "@/lib/types";
import {
  Loader2,
  Building2,
  Phone,
  Globe,
  Settings2,
  Save,
  Check,
  Bell,
  MapPin,
} from "lucide-react";

export default function SettingsPage() {
  const { currentClientId } = useClient();
  const [client, setClient] = useState<Client | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Editable fields
  const [clientName, setClientName] = useState("");
  const [brokerNumbers, setBrokerNumbers] = useState("");
  const [calendarId, setCalendarId] = useState("");
  const [crmType, setCrmType] = useState("");
  const [billingModel, setBillingModel] = useState("direct");
  const [primaryLanguage, setPrimaryLanguage] = useState("hinglish");
  const [formality, setFormality] = useState("formal");
  const [followupEnabled, setFollowupEnabled] = useState(true);
  const [siteAddress, setSiteAddress] = useState("");
  const [siteMapUrl, setSiteMapUrl] = useState("");

  // Save state
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (!currentClientId) return;
    setLoading(true);
    setError(null);
    getClient(currentClientId)
      .then((c) => {
        setClient(c);
        setClientName(c.client_name);
        setBrokerNumbers(c.broker_wa_numbers?.join(", ") || "");
        setCalendarId(c.google_calendar_id || "");
        setCrmType(c.crm_type || "");
        setBillingModel(c.billing_model || "direct");
        const lc = c.language_config as Record<string, string> | null;
        setPrimaryLanguage(lc?.primary_language || "hinglish");
        setFormality(lc?.formality_level || "formal");
        const po = c.prompt_overrides as Record<string, unknown> | null;
        setFollowupEnabled(po?.followup_enabled !== false);
        setSiteAddress((po?.site_address as string) || "");
        setSiteMapUrl((po?.site_map_url as string) || "");
      })
      .catch((e) => setError(e instanceof Error ? e.message : "Failed to load"))
      .finally(() => setLoading(false));
  }, [currentClientId]);

  const handleSave = async () => {
    if (!currentClientId) return;
    setSaving(true);
    setSaved(false);
    try {
      const updates: Record<string, unknown> = {
        client_name: clientName,
        broker_wa_numbers: brokerNumbers
          .split(",")
          .map((s) => s.trim())
          .filter(Boolean),
        google_calendar_id: calendarId || null,
        crm_type: crmType || null,
        billing_model: billingModel,
        language_config: {
          primary_language: primaryLanguage,
          formality_level: formality,
          hindi_pronoun: formality === "formal" ? "aap" : "tum",
        },
        prompt_overrides: {
          ...(client?.prompt_overrides as Record<string, unknown> || {}),
          followup_enabled: followupEnabled,
          site_address: siteAddress || undefined,
          site_map_url: siteMapUrl || undefined,
        },
      };
      const updated = await updateClient(currentClientId, updates as Partial<Client>);
      setClient(updated);
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (e: unknown) {
      alert("Save failed: " + (e instanceof Error ? e.message : ""));
    } finally {
      setSaving(false);
    }
  };

  if (!currentClientId) {
    return (
      <div className="pramaan-card p-6" style={{ borderColor: "var(--pramaan-border)" }}>
        <p className="text-[13px]" style={{ color: "var(--pramaan-text-muted)" }}>
          No client selected. Start the backend and select a client from the header.
        </p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-7 w-7 animate-spin" style={{ color: "var(--pramaan-gold)" }} />
      </div>
    );
  }

  if (error || !client) {
    return (
      <div className="pramaan-card p-6" style={{ borderColor: "var(--tier-hot)" }}>
        <p style={{ color: "var(--tier-hot)" }}>{error || "Client not found"}</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 max-w-3xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-[28px] font-serif" style={{ color: "var(--pramaan-text)" }}>
            Settings
          </h1>
          <p className="text-[13px] mt-1" style={{ color: "var(--pramaan-text-muted)" }}>
            Client configuration
          </p>
        </div>
        <button onClick={handleSave} disabled={saving} className="pramaan-btn flex items-center gap-2">
          {saving ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : saved ? (
            <Check className="h-4 w-4" />
          ) : (
            <Save className="h-4 w-4" />
          )}
          {saving ? "Saving..." : saved ? "Saved" : "Save Changes"}
        </button>
      </div>

      {/* General */}
      <Section title="General" icon={<Building2 className="h-4 w-4" />}>
        <EditField label="Client Name" value={clientName} onChange={setClientName} />
        <ReadField label="Client ID" value={client.id} mono />
        <ReadField label="Status" value={client.active ? "Active" : "Inactive"} badge={client.active ? "green" : "red"} />
        <ReadField label="Created" value={new Date(client.created_at).toLocaleDateString()} />
      </Section>

      {/* WhatsApp */}
      <Section title="WhatsApp" icon={<Phone className="h-4 w-4" />}>
        <ReadField label="WABA Number" value={client.waba_number} />
        <ReadField label="Phone Number ID" value={client.waba_phone_number_id} mono />
        <EditField label="Broker Numbers" value={brokerNumbers} onChange={setBrokerNumbers} placeholder="Comma-separated, e.g. +919820099999, +919820011111" />
      </Section>

      {/* Integrations */}
      <Section title="Integrations" icon={<Settings2 className="h-4 w-4" />}>
        <div className="px-5 py-4 flex items-center justify-between gap-4">
          <p className="text-[12px] font-medium w-40" style={{ color: "var(--pramaan-text-secondary)" }}>CRM Type</p>
          <select className="pramaan-select flex-1 max-w-xs" value={crmType} onChange={(e) => setCrmType(e.target.value)}>
            <option value="">Not configured</option>
            <option value="selldo">Sell.Do</option>
            <option value="webhook">Webhook</option>
          </select>
        </div>
        <EditField label="Google Calendar ID" value={calendarId} onChange={setCalendarId} placeholder="calendar-id@group.calendar.google.com" />
        <div className="px-5 py-4 flex items-center justify-between gap-4">
          <p className="text-[12px] font-medium w-40" style={{ color: "var(--pramaan-text-secondary)" }}>Billing Model</p>
          <select className="pramaan-select flex-1 max-w-xs" value={billingModel} onChange={(e) => setBillingModel(e.target.value)}>
            <option value="direct">Direct</option>
            <option value="per_visit">Per Visit</option>
            <option value="per_lead">Per Lead</option>
          </select>
        </div>
      </Section>

      {/* AI / Language */}
      <Section title="AI Configuration" icon={<Globe className="h-4 w-4" />}>
        <div className="px-5 py-4 flex items-center justify-between gap-4">
          <p className="text-[12px] font-medium w-40" style={{ color: "var(--pramaan-text-secondary)" }}>Primary Language</p>
          <select className="pramaan-select flex-1 max-w-xs" value={primaryLanguage} onChange={(e) => setPrimaryLanguage(e.target.value)}>
            <option value="english">English</option>
            <option value="hindi">Hindi</option>
            <option value="hinglish">Hinglish</option>
          </select>
        </div>
        <div className="px-5 py-4 flex items-center justify-between gap-4">
          <p className="text-[12px] font-medium w-40" style={{ color: "var(--pramaan-text-secondary)" }}>Formality</p>
          <select className="pramaan-select flex-1 max-w-xs" value={formality} onChange={(e) => setFormality(e.target.value)}>
            <option value="formal">Formal (aap)</option>
            <option value="casual">Casual (tum)</option>
          </select>
        </div>
      </Section>

      {/* Follow-ups */}
      <Section title="Follow-ups" icon={<Bell className="h-4 w-4" />}>
        <div className="px-5 py-4 flex items-center justify-between gap-4">
          <div className="w-40 flex-shrink-0">
            <p className="text-[12px] font-medium" style={{ color: "var(--pramaan-text-secondary)" }}>Auto Follow-ups</p>
            <p className="text-[10px] mt-0.5" style={{ color: "var(--pramaan-text-muted)" }}>
              HOT leads: 24h &bull; WARM leads: 48h
            </p>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              className="sr-only peer"
              checked={followupEnabled}
              onChange={(e) => setFollowupEnabled(e.target.checked)}
            />
            <div className="w-9 h-5 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:rounded-full after:h-4 after:w-4 after:transition-all"
              style={{
                background: followupEnabled ? "var(--pramaan-gold)" : "var(--pramaan-border)",
                // toggle thumb
              }}
            >
              <div className="absolute top-[2px] h-4 w-4 rounded-full bg-white transition-all"
                style={{ left: followupEnabled ? "18px" : "2px" }}
              />
            </div>
          </label>
        </div>
        <ReadField
          label="HOT Schedule"
          value="Nudge at 12h if no slot picked"
        />
        <ReadField
          label="WARM Schedule"
          value="Nudge at 24-48h if qualification stalled"
        />
      </Section>

      {/* Site Visit / Maps */}
      <Section title="Site Visit" icon={<MapPin className="h-4 w-4" />}>
        <EditField
          label="Site Address"
          value={siteAddress}
          onChange={setSiteAddress}
          placeholder="e.g. Shreeji Greens, Gotri Road, Vadodara 390021"
        />
        <EditField
          label="Google Maps URL"
          value={siteMapUrl}
          onChange={setSiteMapUrl}
          placeholder="https://maps.google.com/?q=... (auto-generated if empty)"
        />
      </Section>
    </div>
  );
}

/* ── Helper components ────────────────────────────────────────── */

function Section({
  title,
  icon,
  children,
}: {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <div className="pramaan-card">
      <div
        className="flex items-center gap-2 px-5 py-4 border-b"
        style={{ borderColor: "var(--pramaan-border-subtle)" }}
      >
        <span style={{ color: "var(--pramaan-text-muted)" }}>{icon}</span>
        <h3
          className="text-[11px] font-semibold tracking-wider uppercase"
          style={{ color: "var(--pramaan-text-muted)" }}
        >
          {title}
        </h3>
      </div>
      <div className="divide-y" style={{ borderColor: "var(--pramaan-border-subtle)" }}>
        {children}
      </div>
    </div>
  );
}

function ReadField({
  label,
  value,
  mono,
  badge,
}: {
  label: string;
  value: string;
  mono?: boolean;
  badge?: "green" | "red";
}) {
  return (
    <div className="px-5 py-4 flex items-center justify-between gap-4">
      <p className="text-[12px] font-medium w-40" style={{ color: "var(--pramaan-text-secondary)" }}>
        {label}
      </p>
      {badge ? (
        <span
          className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-semibold"
          style={{
            background: badge === "green" ? "#EFF5EF" : "var(--tier-hot-bg)",
            color: badge === "green" ? "#5A8A5A" : "var(--tier-hot)",
          }}
        >
          {value}
        </span>
      ) : (
        <p
          className={`text-[13px] text-right ${mono ? "font-mono text-[11px]" : ""}`}
          style={{ color: "var(--pramaan-text)" }}
        >
          {value}
        </p>
      )}
    </div>
  );
}

function EditField({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  return (
    <div className="px-5 py-4 flex items-center justify-between gap-4">
      <p className="text-[12px] font-medium w-40 flex-shrink-0" style={{ color: "var(--pramaan-text-secondary)" }}>
        {label}
      </p>
      <input
        type="text"
        className="pramaan-input flex-1 max-w-xs text-[13px]"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
      />
    </div>
  );
}
