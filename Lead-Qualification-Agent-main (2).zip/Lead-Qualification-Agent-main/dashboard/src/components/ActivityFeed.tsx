"use client";

import { ArrowDownLeft, ArrowUpRight } from "lucide-react";
import type { ActivityItem } from "@/lib/types";
import { TierBadge } from "./TierBadge";
import { formatPhone, timeAgo } from "@/lib/utils";

interface Props {
  items: ActivityItem[];
}

export default function ActivityFeed({ items }: Props) {
  if (items.length === 0) {
    return (
      <div
        className="text-center py-10 text-[13px]"
        style={{ color: "var(--pramaan-text-muted)" }}
      >
        No activity yet.
      </div>
    );
  }

  return (
    <div className="space-y-1">
      {items.map((item, i) => (
        <div
          key={`${item.conversation_id}-${item.timestamp}-${i}`}
          className="flex items-start gap-3 px-4 py-3 rounded-xl transition-colors"
          style={{ cursor: "default" }}
          onMouseEnter={(e) =>
            (e.currentTarget.style.background = "var(--pramaan-gold-light)")
          }
          onMouseLeave={(e) =>
            (e.currentTarget.style.background = "transparent")
          }
        >
          {/* Direction indicator */}
          <div
            className="mt-1 p-1.5 rounded-full"
            style={{
              background: item.direction === "inbound" ? "var(--tier-cold-bg)" : "var(--pramaan-gold-light)",
            }}
          >
            {item.direction === "inbound" ? (
              <ArrowDownLeft
                className="h-3 w-3"
                style={{ color: "var(--tier-cold)" }}
              />
            ) : (
              <ArrowUpRight
                className="h-3 w-3"
                style={{ color: "var(--pramaan-gold)" }}
              />
            )}
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-0.5">
              <span
                className="font-medium text-[13px] truncate"
                style={{ color: "var(--pramaan-text)" }}
              >
                {item.lead_name || formatPhone(item.lead_phone)}
              </span>
              <TierBadge tier={item.lead_tier} />
            </div>
            <p
              className="text-[12px] line-clamp-2"
              style={{ color: "var(--pramaan-text-secondary)" }}
            >
              {item.content}
            </p>
            <p
              className="text-[10px] mt-1"
              style={{ color: "var(--pramaan-text-muted)" }}
            >
              {timeAgo(item.timestamp)}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
}
