"use client";

import Image from "next/image";
import { usePathname } from "next/navigation";
import { useAuth } from "./AuthProvider";
import Sidebar from "./Sidebar";
import Header from "./Header";
import { Loader2 } from "lucide-react";

/**
 * AppShell — wraps the app with sidebar + header for authenticated pages.
 * Login page gets a clean full-screen layout.
 */
export default function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const { user, loading, mounted } = useAuth();

  // Login page — no shell
  if (pathname === "/login") {
    return <>{children}</>;
  }

  // Loading auth state (or not yet mounted on client)
  if (!mounted || loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <Image
            src="/pramaan-seal.svg"
            alt="Pramaan"
            width={56}
            height={56}
            className="mx-auto mb-4"
            priority
          />
          <Loader2
            className="h-5 w-5 animate-spin mx-auto"
            style={{ color: "var(--pramaan-gold)" }}
          />
        </div>
      </div>
    );
  }

  // Not authenticated — AuthProvider will redirect to /login
  if (!user) {
    return null;
  }

  // Authenticated — show full dashboard shell
  return (
    <div className="flex h-full">
      <Sidebar />
      <div className="flex-1 flex flex-col min-h-screen overflow-hidden">
        <Header />
        <main className="flex-1 overflow-y-auto p-8">{children}</main>
      </div>
    </div>
  );
}
