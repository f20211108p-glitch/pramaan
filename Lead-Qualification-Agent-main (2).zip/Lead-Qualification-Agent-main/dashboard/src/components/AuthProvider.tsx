"use client";

import {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  type ReactNode,
} from "react";
import { usePathname, useRouter } from "next/navigation";
import {
  type AuthUser,
  getToken,
  getStoredUser,
  login as apiLogin,
  clearAuth,
  fetchMe,
} from "@/lib/auth";

interface AuthContextValue {
  user: AuthUser | null;
  loading: boolean;
  mounted: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  isAdmin: boolean;
}

const AuthContext = createContext<AuthContextValue>({
  user: null,
  loading: true,
  mounted: false,
  login: async () => {},
  logout: () => {},
  isAdmin: false,
});

export function useAuth() {
  return useContext(AuthContext);
}

export default function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [mounted, setMounted] = useState(false);
  const router = useRouter();
  const pathname = usePathname();

  // Mark as mounted (client-side only) — prevents hydration mismatch
  useEffect(() => {
    setMounted(true);
  }, []);

  // Check existing session on mount
  useEffect(() => {
    if (!mounted) return;

    const token = getToken();
    if (!token) {
      setLoading(false);
      return;
    }

    // Try stored user first for instant hydration
    const stored = getStoredUser();
    if (stored) {
      setUser(stored);
      setLoading(false);
    }

    // Validate token in background
    fetchMe()
      .then((u) => setUser(u))
      .catch(() => {
        clearAuth();
        setUser(null);
      })
      .finally(() => setLoading(false));
  }, [mounted]);

  // Redirect to login if not authenticated (except on /login page)
  useEffect(() => {
    if (mounted && !loading && !user && pathname !== "/login") {
      router.replace("/login");
    }
  }, [mounted, loading, user, pathname, router]);

  const login = useCallback(async (email: string, password: string) => {
    const result = await apiLogin(email, password);
    setUser(result.user);
    router.replace("/");
  }, [router]);

  const logout = useCallback(() => {
    clearAuth();
    setUser(null);
    router.replace("/login");
  }, [router]);

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        mounted,
        login,
        logout,
        isAdmin: user?.role === "admin",
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}
