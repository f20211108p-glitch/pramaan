"use client";

import type { Message } from "@/lib/types";
import { cn } from "@/lib/utils";

interface Props {
  messages: Message[];
}

export default function ChatView({ messages }: Props) {
  if (messages.length === 0) {
    return (
      <div
        className="text-center py-10 text-[13px]"
        style={{ color: "var(--pramaan-text-muted)" }}
      >
        No messages in this conversation.
      </div>
    );
  }

  return (
    <div className="space-y-3 p-5">
      {messages.map((msg) => {
        const isInbound = msg.direction === "inbound";
        return (
          <div
            key={msg.id}
            className={cn("flex", isInbound ? "justify-start" : "justify-end")}
          >
            <div
              className={cn(
                "max-w-[75%] rounded-2xl px-4 py-3 text-[13px]",
                isInbound ? "rounded-bl-md" : "rounded-br-md"
              )}
              style={{
                background: isInbound ? "var(--pramaan-border-subtle)" : "var(--pramaan-gold)",
                color: isInbound ? "var(--pramaan-text)" : "white",
              }}
            >
              <p className="whitespace-pre-wrap leading-relaxed">{msg.content}</p>
              <p
                className="text-[10px] mt-1.5 opacity-60"
              >
                {new Date(msg.timestamp).toLocaleTimeString([], {
                  hour: "2-digit",
                  minute: "2-digit",
                })}
              </p>
            </div>
          </div>
        );
      })}
    </div>
  );
}
