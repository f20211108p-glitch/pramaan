"use client";

import {
  createContext,
  useContext,
  useState,
  useEffect,
  type ReactNode,
} from "react";
import { listClients } from "@/lib/api";
import { useAuth } from "./AuthProvider";
import type { Client } from "@/lib/types";

interface ClientContextValue {
  clients: Client[];
  currentClientId: string | null;
  currentClient: Client | null;
  setCurrentClientId: (id: string) => void;
  loading: boolean;
  error: string | null;
}

const ClientContext = createContext<ClientContextValue>({
  clients: [],
  currentClientId: null,
  currentClient: null,
  setCurrentClientId: () => {},
  loading: true,
  error: null,
});

export function useClient() {
  return useContext(ClientContext);
}

export default function ClientProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [clients, setClients] = useState<Client[]>([]);
  const [currentClientId, setCurrentClientId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Don't fetch until user is authenticated
    if (!user) {
      setLoading(false);
      return;
    }

    // Client role — scope to their client_id
    if (user.role === "client" && user.client_id) {
      // Fetch only their client
      listClients()
        .then((data) => {
          const myClient = data.clients.find(
            (c: Client) => c.id === user.client_id
          );
          if (myClient) {
            setClients([myClient]);
            setCurrentClientId(myClient.id);
          } else {
            setClients(data.clients.filter((c: Client) => c.id === user.client_id));
          }
        })
        .catch((e) => setError(e.message))
        .finally(() => setLoading(false));
      return;
    }

    // Admin role — fetch all clients
    listClients()
      .then((data) => {
        setClients(data.clients);
        if (data.clients.length > 0 && !currentClientId) {
          setCurrentClientId(data.clients[0].id);
        }
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, [user]); // eslint-disable-line react-hooks/exhaustive-deps

  const currentClient =
    clients.find((c) => c.id === currentClientId) ?? null;

  return (
    <ClientContext.Provider
      value={{
        clients,
        currentClientId,
        currentClient,
        setCurrentClientId,
        loading,
        error,
      }}
    >
      {children}
    </ClientContext.Provider>
  );
}
