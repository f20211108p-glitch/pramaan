"use client";

import { useEffect } from "react";

/**
 * Suppresses unhandled promise rejections from browser extensions
 * (MetaMask, wallet injectors, etc.) that would otherwise pollute
 * the Next.js dev error overlay. These are not our errors.
 */
export default function ExtensionErrorSuppressor() {
  useEffect(() => {
    const handler = (event: PromiseRejectionEvent) => {
      const msg =
        event.reason?.message ||
        event.reason?.toString?.() ||
        String(event.reason ?? "");

      const isExtensionError =
        msg.includes("MetaMask") ||
        msg.includes("ethereum") ||
        msg.includes("MetaMask extension not found") ||
        msg.includes("Cannot redefine property") ||
        event.reason?.stack?.includes("chrome-extension://");

      if (isExtensionError) {
        event.preventDefault();
        event.stopImmediatePropagation();
      }
    };

    window.addEventListener("unhandledrejection", handler);
    return () => window.removeEventListener("unhandledrejection", handler);
  }, []);

  return null;
}
