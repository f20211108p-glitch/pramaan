"use client";

import { useClient } from "./ClientProvider";
import { useAuth } from "./AuthProvider";
import { ChevronDown, Circle, Shield } from "lucide-react";

export default function Header() {
  const { clients, currentClient, setCurrentClientId } = useClient();
  const { user, isAdmin } = useAuth();

  return (
    <header
      className="px-8 py-4 flex items-center justify-between border-b"
      style={{
        background: "var(--pramaan-card)",
        borderColor: "var(--pramaan-border)",
      }}
    >
      <div className="flex items-center gap-4">
        {/* Client selector — only for admins */}
        {isAdmin ? (
          <div className="relative">
            <select
              className="pramaan-select pr-10 font-medium text-[14px] min-w-[200px]"
              value={currentClient?.id ?? ""}
              onChange={(e) => setCurrentClientId(e.target.value)}
              disabled={clients.length === 0}
            >
              {clients.length === 0 ? (
                <option value="">— No clients —</option>
              ) : (
                clients.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.client_name}
                  </option>
                ))
              )}
            </select>
            <ChevronDown
              className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 pointer-events-none"
              style={{ color: "var(--pramaan-text-muted)" }}
            />
          </div>
        ) : (
          /* Client users see their company name */
          <div className="flex items-center gap-2">
            <span
              className="font-serif text-[16px]"
              style={{ color: "var(--pramaan-text)" }}
            >
              {currentClient?.client_name || user?.client_name || "Dashboard"}
            </span>
          </div>
        )}
      </div>

      <div className="flex items-center gap-4">
        {/* Admin badge */}
        {isAdmin && (
          <span
            className="flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-medium tracking-wide uppercase"
            style={{
              background: "var(--pramaan-gold-light)",
              color: "var(--pramaan-gold-hover)",
            }}
          >
            <Shield className="h-3 w-3" />
            Admin
          </span>
        )}

        {currentClient?.crm_type && (
          <span
            className="px-3 py-1 rounded-full text-[11px] font-medium tracking-wide uppercase"
            style={{
              background: "var(--pramaan-gold-light)",
              color: "var(--pramaan-gold-hover)",
            }}
          >
            CRM: {currentClient.crm_type}
          </span>
        )}
        <div className="flex items-center gap-2">
          <Circle
            className="h-2 w-2"
            fill={currentClient?.active ? "#7BA17B" : "#A17B7B"}
            stroke="none"
          />
          <span
            className="text-[12px] font-medium"
            style={{ color: "var(--pramaan-text-muted)" }}
          >
            {currentClient?.active ? "Active" : "Inactive"}
          </span>
        </div>
      </div>
    </header>
  );
}
