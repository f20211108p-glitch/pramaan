"use client";

import { useEffect, useState, useCallback } from "react";
import { getLeadInsight } from "@/lib/api";
import type { LeadInsight } from "@/lib/types";
import {
  Loader2,
  Sparkles,
  RefreshCw,
  TrendingUp,
  AlertTriangle,
  Target,
  CheckCircle2,
  Flame,
} from "lucide-react";

interface Props {
  clientId: string;
  leadId: string;
}

export default function LeadInsightCard({ clientId, leadId }: Props) {
  const [insight, setInsight] = useState<LeadInsight | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(
    async (force = false) => {
      setLoading(true);
      setError(null);
      try {
        const result = await getLeadInsight(clientId, leadId, force);
        setInsight(result);
      } catch (e) {
        setError(e instanceof Error ? e.message : "Failed to load insight");
      } finally {
        setLoading(false);
      }
    },
    [clientId, leadId]
  );

  useEffect(() => {
    void load(false);
  }, [load]);

  if (loading && !insight) {
    return (
      <div
        className="pramaan-card p-5 flex items-center gap-3"
        style={{ borderColor: "var(--pramaan-border)" }}
      >
        <Loader2 className="h-4 w-4 animate-spin" style={{ color: "var(--pramaan-gold)" }} />
        <p className="text-[13px]" style={{ color: "var(--pramaan-text-muted)" }}>
          Analysing conversation…
        </p>
      </div>
    );
  }

  if (error || !insight) {
    return (
      <div className="pramaan-card p-5" style={{ borderColor: "var(--tier-hot)" }}>
        <p className="text-[12px]" style={{ color: "var(--tier-hot)" }}>
          {error || "No insight available"}
        </p>
      </div>
    );
  }

  const probColor =
    insight.close_probability >= 60
      ? "#7A8C5C"
      : insight.close_probability >= 30
      ? "#C4A862"
      : "#9F9F9F";
  const urgencyColor =
    insight.urgency_level === "high"
      ? "#C26B5A"
      : insight.urgency_level === "medium"
      ? "#C4A862"
      : "#9F9F9F";

  return (
    <div className="pramaan-card">
      {/* Header */}
      <div
        className="flex items-center justify-between px-5 py-4 border-b"
        style={{ borderColor: "var(--pramaan-border-subtle)" }}
      >
        <div className="flex items-center gap-2">
          <Sparkles className="h-4 w-4" style={{ color: "var(--pramaan-gold)" }} />
          <h3
            className="text-[11px] font-semibold tracking-wider uppercase"
            style={{ color: "var(--pramaan-text-muted)" }}
          >
            AI Sales Insight
          </h3>
          {insight.cached && (
            <span
              className="text-[10px] px-1.5 py-0.5 rounded"
              style={{
                background: "var(--pramaan-border-subtle)",
                color: "var(--pramaan-text-muted)",
              }}
            >
              cached
            </span>
          )}
        </div>
        <button
          onClick={() => void load(true)}
          disabled={loading}
          className="flex items-center gap-1 text-[11px]"
          style={{ color: "var(--pramaan-text-muted)" }}
        >
          {loading ? (
            <Loader2 className="h-3 w-3 animate-spin" />
          ) : (
            <RefreshCw className="h-3 w-3" />
          )}
          Refresh
        </button>
      </div>

      {/* Top row — Probability + Urgency */}
      <div
        className="grid grid-cols-2 divide-x"
        style={{ borderColor: "var(--pramaan-border-subtle)" }}
      >
        <div className="px-5 py-4">
          <p
            className="text-[10px] font-semibold tracking-wider uppercase mb-1"
            style={{ color: "var(--pramaan-text-muted)" }}
          >
            Close Probability
          </p>
          <div className="flex items-baseline gap-2">
            <p
              className="text-[28px] font-serif"
              style={{ color: probColor }}
            >
              {insight.close_probability}%
            </p>
            <TrendingUp className="h-4 w-4" style={{ color: probColor }} />
          </div>
          {/* Bar */}
          <div
            className="mt-2 h-1.5 rounded-full"
            style={{ background: "var(--pramaan-border-subtle)" }}
          >
            <div
              className="h-full rounded-full transition-all"
              style={{
                width: `${insight.close_probability}%`,
                background: probColor,
              }}
            />
          </div>
        </div>
        <div className="px-5 py-4">
          <p
            className="text-[10px] font-semibold tracking-wider uppercase mb-1"
            style={{ color: "var(--pramaan-text-muted)" }}
          >
            Urgency
          </p>
          <div className="flex items-center gap-2">
            <Flame className="h-4 w-4" style={{ color: urgencyColor }} />
            <p
              className="text-[18px] font-medium capitalize"
              style={{ color: urgencyColor }}
            >
              {insight.urgency_level}
            </p>
          </div>
        </div>
      </div>

      {/* Summary */}
      <div
        className="px-5 py-4 border-t"
        style={{ borderColor: "var(--pramaan-border-subtle)" }}
      >
        <p
          className="text-[10px] font-semibold tracking-wider uppercase mb-2"
          style={{ color: "var(--pramaan-text-muted)" }}
        >
          Summary
        </p>
        <p className="text-[13px] leading-relaxed" style={{ color: "var(--pramaan-text)" }}>
          {insight.summary}
        </p>
      </div>

      {/* Next action */}
      <div
        className="px-5 py-4 border-t"
        style={{ borderColor: "var(--pramaan-border-subtle)" }}
      >
        <div className="flex items-center gap-2 mb-2">
          <Target className="h-3.5 w-3.5" style={{ color: "var(--pramaan-gold)" }} />
          <p
            className="text-[10px] font-semibold tracking-wider uppercase"
            style={{ color: "var(--pramaan-text-muted)" }}
          >
            Next Action
          </p>
        </div>
        <p className="text-[13px]" style={{ color: "var(--pramaan-text)" }}>
          {insight.next_action}
        </p>
      </div>

      {/* Signals + Concerns side-by-side */}
      <div
        className="grid grid-cols-2 divide-x border-t"
        style={{ borderColor: "var(--pramaan-border-subtle)" }}
      >
        <div className="px-5 py-4">
          <div className="flex items-center gap-2 mb-2">
            <CheckCircle2 className="h-3.5 w-3.5" style={{ color: "#7A8C5C" }} />
            <p
              className="text-[10px] font-semibold tracking-wider uppercase"
              style={{ color: "var(--pramaan-text-muted)" }}
            >
              Buying Signals
            </p>
          </div>
          {insight.buying_signals.length === 0 ? (
            <p className="text-[12px]" style={{ color: "var(--pramaan-text-muted)" }}>
              None detected yet
            </p>
          ) : (
            <ul className="space-y-1.5">
              {insight.buying_signals.map((s, i) => (
                <li
                  key={i}
                  className="text-[12px] flex items-start gap-1.5"
                  style={{ color: "var(--pramaan-text)" }}
                >
                  <span style={{ color: "#7A8C5C" }}>•</span>
                  <span>{s}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
        <div className="px-5 py-4">
          <div className="flex items-center gap-2 mb-2">
            <AlertTriangle className="h-3.5 w-3.5" style={{ color: "#C26B5A" }} />
            <p
              className="text-[10px] font-semibold tracking-wider uppercase"
              style={{ color: "var(--pramaan-text-muted)" }}
            >
              Concerns
            </p>
          </div>
          {insight.concerns.length === 0 ? (
            <p className="text-[12px]" style={{ color: "var(--pramaan-text-muted)" }}>
              None detected
            </p>
          ) : (
            <ul className="space-y-1.5">
              {insight.concerns.map((c, i) => (
                <li
                  key={i}
                  className="text-[12px] flex items-start gap-1.5"
                  style={{ color: "var(--pramaan-text)" }}
                >
                  <span style={{ color: "#C26B5A" }}>•</span>
                  <span>{c}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      {/* Talking points */}
      {insight.talking_points.length > 0 && (
        <div
          className="px-5 py-4 border-t"
          style={{ borderColor: "var(--pramaan-border-subtle)" }}
        >
          <p
            className="text-[10px] font-semibold tracking-wider uppercase mb-2"
            style={{ color: "var(--pramaan-text-muted)" }}
          >
            Talking Points
          </p>
          <ul className="space-y-1.5">
            {insight.talking_points.map((t, i) => (
              <li
                key={i}
                className="text-[12px] flex items-start gap-1.5"
                style={{ color: "var(--pramaan-text)" }}
              >
                <span style={{ color: "var(--pramaan-gold)" }}>→</span>
                <span>{t}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
