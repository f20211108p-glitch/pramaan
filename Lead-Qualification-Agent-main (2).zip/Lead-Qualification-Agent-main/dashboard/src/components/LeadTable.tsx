"use client";

import Link from "next/link";
import type { Lead } from "@/lib/types";
import { TierBadge, StageBadge } from "./TierBadge";
import {
  formatPhone,
  formatBudgetRange,
  timeAgo,
  scoreColor,
} from "@/lib/utils";

interface Props {
  leads: Lead[];
  clientId: string;
  showSelect?: boolean;
  selectedIds?: Set<string>;
  onToggle?: (id: string) => void;
}

export default function LeadTable({
  leads,
  clientId,
  showSelect = false,
  selectedIds,
  onToggle,
}: Props) {
  if (leads.length === 0) {
    return (
      <div
        className="text-center py-14 text-[13px]"
        style={{ color: "var(--pramaan-text-muted)" }}
      >
        No leads found.
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-[13px]">
        <thead>
          <tr
            className="border-b text-left"
            style={{
              borderColor: "var(--pramaan-border-subtle)",
              color: "var(--pramaan-text-muted)",
            }}
          >
            {showSelect && <th className="py-3 px-5 w-10" />}
            <th className="py-3 px-5 text-[11px] font-semibold tracking-wider uppercase">Lead</th>
            <th className="py-3 px-5 text-[11px] font-semibold tracking-wider uppercase">Score</th>
            <th className="py-3 px-5 text-[11px] font-semibold tracking-wider uppercase">Tier</th>
            <th className="py-3 px-5 text-[11px] font-semibold tracking-wider uppercase">Stage</th>
            <th className="py-3 px-5 text-[11px] font-semibold tracking-wider uppercase">Budget</th>
            <th className="py-3 px-5 text-[11px] font-semibold tracking-wider uppercase">Intent</th>
            <th className="py-3 px-5 text-[11px] font-semibold tracking-wider uppercase">Updated</th>
          </tr>
        </thead>
        <tbody>
          {leads.map((lead) => (
            <tr
              key={lead.id}
              className="border-b transition-colors cursor-pointer"
              style={{ borderColor: "var(--pramaan-border-subtle)" }}
              onMouseEnter={(e) =>
                (e.currentTarget.style.background = "var(--pramaan-gold-light)")
              }
              onMouseLeave={(e) =>
                (e.currentTarget.style.background = "transparent")
              }
            >
              {showSelect && (
                <td className="py-3 px-5">
                  <input
                    type="checkbox"
                    checked={selectedIds?.has(lead.id) ?? false}
                    onChange={() => onToggle?.(lead.id)}
                    className="rounded"
                    style={{ accentColor: "var(--pramaan-gold)" }}
                  />
                </td>
              )}
              <td className="py-3 px-5">
                <Link
                  href={`/leads/${lead.id}?client=${clientId}`}
                  style={{ color: "var(--pramaan-text)" }}
                  className="hover:opacity-75"
                >
                  <div className="font-medium">{lead.name || "Unknown"}</div>
                  <div
                    className="text-[11px] mt-0.5"
                    style={{ color: "var(--pramaan-text-muted)" }}
                  >
                    {formatPhone(lead.phone)}
                  </div>
                </Link>
              </td>
              <td className="py-3 px-5">
                <span className={scoreColor(lead.score)}>
                  {lead.score ?? "-"}
                </span>
              </td>
              <td className="py-3 px-5">
                <TierBadge tier={lead.tier} />
              </td>
              <td className="py-3 px-5">
                <StageBadge stage={lead.stage} />
              </td>
              <td
                className="py-3 px-5"
                style={{ color: "var(--pramaan-text-secondary)" }}
              >
                {formatBudgetRange(lead.budget_min, lead.budget_max)}
              </td>
              <td
                className="py-3 px-5 capitalize"
                style={{ color: "var(--pramaan-text-secondary)" }}
              >
                {lead.intent}
              </td>
              <td
                className="py-3 px-5 text-[11px]"
                style={{ color: "var(--pramaan-text-muted)" }}
              >
                {timeAgo(lead.updated_at)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
