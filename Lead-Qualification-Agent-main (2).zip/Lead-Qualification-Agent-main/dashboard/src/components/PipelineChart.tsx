"use client";

import type { PipelineStats } from "@/lib/types";

interface Props {
  stats: PipelineStats;
}

const STAGE_ORDER = [
  "new",
  "qualifying",
  "qualified",
  "scheduling",
  "nurturing",
  "handed_off",
  "converted",
  "lost",
];

const STAGE_COLORS: Record<string, string> = {
  new: "#B5A48E",
  qualifying: "#C4A265",
  qualified: "#7BA17B",
  scheduling: "#8B7BAD",
  nurturing: "#7B8FA1",
  handed_off: "#6BA17B",
  converted: "#5A8A5A",
  lost: "#A17B7B",
};

export default function PipelineChart({ stats }: Props) {
  const total = stats.total_leads || 1;

  return (
    <div className="pramaan-card p-6">
      <h3
        className="text-[12px] font-medium tracking-wide uppercase mb-5"
        style={{ color: "var(--pramaan-text-muted)" }}
      >
        Pipeline by Stage
      </h3>

      <div className="space-y-3">
        {STAGE_ORDER.map((stage) => {
          const count = stats.by_stage?.[stage] ?? 0;
          const pct = Math.round((count / total) * 100);
          return (
            <div key={stage} className="flex items-center gap-3">
              <span
                className="text-[11px] w-24 text-right capitalize font-medium"
                style={{ color: "var(--pramaan-text-secondary)" }}
              >
                {stage.replace(/_/g, " ")}
              </span>
              <div
                className="flex-1 h-4 rounded-full overflow-hidden"
                style={{ background: "var(--pramaan-border-subtle)" }}
              >
                <div
                  className="h-full rounded-full transition-all duration-500"
                  style={{
                    width: `${Math.max(pct, count > 0 ? 3 : 0)}%`,
                    background: STAGE_COLORS[stage] || "#B5A48E",
                  }}
                />
              </div>
              <span
                className="text-[11px] font-semibold w-8 tabular-nums"
                style={{ color: "var(--pramaan-text)" }}
              >
                {count}
              </span>
            </div>
          );
        })}
      </div>

      {/* Tier summary */}
      <div
        className="mt-6 pt-5 border-t flex justify-around text-center"
        style={{ borderColor: "var(--pramaan-border-subtle)" }}
      >
        {(["hot", "warm", "cold"] as const).map((tier) => {
          const count = stats.by_tier?.[tier] ?? 0;
          const colors: Record<string, string> = {
            hot: "var(--tier-hot)",
            warm: "var(--pramaan-gold)",
            cold: "var(--tier-cold)",
          };
          return (
            <div key={tier}>
              <p
                className="text-2xl font-serif"
                style={{ color: colors[tier] }}
              >
                {count}
              </p>
              <p
                className="text-[10px] uppercase tracking-widest mt-1 font-medium"
                style={{ color: "var(--pramaan-text-muted)" }}
              >
                {tier}
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
}
