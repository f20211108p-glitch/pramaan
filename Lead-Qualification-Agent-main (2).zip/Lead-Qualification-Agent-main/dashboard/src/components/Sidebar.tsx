"use client";

import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useClient } from "./ClientProvider";
import { useAuth } from "./AuthProvider";
import {
  LayoutDashboard,
  Users,
  Activity,
  Receipt,
  Settings,
  FolderOpen,
  UserPlus,
  LogOut,
  HelpCircle,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface NavItem {
  href: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  visible?: (billingModel: string, isAdmin: boolean) => boolean;
}

const NAV_ITEMS: NavItem[] = [
  { href: "/", label: "Overview", icon: LayoutDashboard },
  { href: "/leads", label: "Leads", icon: Users },
  { href: "/projects", label: "Projects", icon: FolderOpen },
  { href: "/projects/qa", label: "Project Q&A", icon: HelpCircle },
  { href: "/activity", label: "Activity", icon: Activity },
  {
    href: "/billing",
    label: "Billing",
    icon: Receipt,
    visible: (billingModel) => billingModel !== "direct",
  },
  { href: "/settings", label: "Settings", icon: Settings },
  {
    href: "/onboarding",
    label: "Onboarding",
    icon: UserPlus,
    visible: (_bm, isAdmin) => isAdmin,
  },
];

export default function Sidebar() {
  const pathname = usePathname();
  const { currentClient } = useClient();
  const { user, logout, isAdmin } = useAuth();
  const billingModel = currentClient?.billing_model ?? "direct";

  return (
    <aside
      className="w-64 flex flex-col min-h-screen"
      style={{ background: "var(--pramaan-sidebar)" }}
    >
      {/* Logo */}
      <div className="px-6 pt-8 pb-6">
        <div className="flex items-center gap-3">
          {/* PRAMAAN seal — light variant for dark sidebar */}
          <Image
            src="/pramaan-seal-light.svg"
            alt="Pramaan"
            width={40}
            height={40}
            priority
          />
          <div>
            <h1
              className="text-[17px] font-serif tracking-[0.12em]"
              style={{ color: "#F5EFE0" }}
            >
              PRAMAAN
            </h1>
            <p
              className="text-[10px] tracking-[0.2em] uppercase"
              style={{ color: "var(--pramaan-text-muted)" }}
            >
              Lead Intelligence
            </p>
          </div>
        </div>
      </div>

      {/* Divider */}
      <div className="mx-5 border-t" style={{ borderColor: "#3D3028" }} />

      {/* Nav */}
      <nav className="flex-1 px-4 py-6 space-y-1">
        {NAV_ITEMS.filter(
          (item) => !item.visible || item.visible(billingModel, isAdmin)
        ).map((item) => {
          const isActive =
            item.href === "/"
              ? pathname === "/"
              : pathname.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-3 px-4 py-2.5 rounded-xl text-[13px] font-medium transition-all duration-200",
                isActive
                  ? "text-white"
                  : "hover:text-white"
              )}
              style={{
                color: isActive ? "#FFFDF9" : "var(--pramaan-sidebar-text)",
                background: isActive ? "var(--pramaan-sidebar-hover)" : "transparent",
                boxShadow: isActive ? "inset 0 0 0 1px rgba(196, 162, 101, 0.2)" : "none",
              }}
            >
              <item.icon
                className={`h-[18px] w-[18px] ${isActive ? "text-[#C4A265]" : ""}`}
              />
              {item.label}
            </Link>
          );
        })}
      </nav>

      {/* User info + Logout */}
      <div
        className="px-4 py-4 border-t"
        style={{ borderColor: "#3D3028" }}
      >
        {user && (
          <div className="flex items-center gap-3 px-2 mb-3">
            <div
              className="w-8 h-8 rounded-full flex items-center justify-center text-[12px] font-bold uppercase"
              style={{
                background: "var(--pramaan-sidebar-hover)",
                color: "var(--pramaan-gold)",
              }}
            >
              {user.name.charAt(0)}
            </div>
            <div className="flex-1 min-w-0">
              <p
                className="text-[12px] font-medium truncate"
                style={{ color: "#F5EFE0" }}
              >
                {user.name}
              </p>
              <p
                className="text-[10px] truncate"
                style={{ color: "var(--pramaan-text-muted)" }}
              >
                {user.role === "admin" ? "Pramaan Admin" : user.client_name || user.email}
              </p>
            </div>
          </div>
        )}
        <button
          onClick={logout}
          className="flex items-center gap-2 px-4 py-2 rounded-xl text-[12px] font-medium w-full transition-all duration-200"
          style={{
            color: "var(--pramaan-sidebar-text)",
            background: "transparent",
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.background = "var(--pramaan-sidebar-hover)";
            e.currentTarget.style.color = "#F5EFE0";
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.background = "transparent";
            e.currentTarget.style.color = "var(--pramaan-sidebar-text)";
          }}
        >
          <LogOut className="h-4 w-4" />
          Sign Out
        </button>
      </div>

      {/* Footer */}
      <div
        className="px-6 py-3 text-[11px]"
        style={{
          color: "var(--pramaan-text-muted)",
        }}
      >
        <p>Less Noise. More Buyers.</p>
      </div>
    </aside>
  );
}
