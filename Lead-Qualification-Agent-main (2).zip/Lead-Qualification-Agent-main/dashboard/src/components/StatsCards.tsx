"use client";

import { Users, MessageSquare, Flame, TrendingUp } from "lucide-react";
import type { PipelineStats } from "@/lib/types";

interface Props {
  stats: PipelineStats;
}

export default function StatsCards({ stats }: Props) {
  const cards = [
    {
      label: "Total Leads",
      value: stats.total_leads,
      icon: Users,
      iconColor: "var(--pramaan-gold)",
      iconBg: "var(--pramaan-gold-light)",
    },
    {
      label: "Hot Leads",
      value: stats.by_tier?.hot ?? 0,
      icon: Flame,
      iconColor: "var(--tier-hot)",
      iconBg: "var(--tier-hot-bg)",
    },
    {
      label: "Conversations",
      value: stats.total_conversations,
      icon: MessageSquare,
      iconColor: "#7B6BA1",
      iconBg: "#F0EDF5",
    },
    {
      label: "Conversion Events",
      value: stats.total_billing_events,
      icon: TrendingUp,
      iconColor: "#5A8A5A",
      iconBg: "#EFF5EF",
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
      {cards.map((card) => (
        <div key={card.label} className="pramaan-card p-6">
          <div className="flex items-center justify-between">
            <div>
              <p
                className="text-[12px] font-medium tracking-wide uppercase"
                style={{ color: "var(--pramaan-text-muted)" }}
              >
                {card.label}
              </p>
              <p
                className="text-3xl font-serif mt-2"
                style={{ color: "var(--pramaan-text)" }}
              >
                {card.value}
              </p>
            </div>
            <div
              className="p-3 rounded-xl"
              style={{ background: card.iconBg }}
            >
              <card.icon
                className="h-5 w-5"
                style={{ color: card.iconColor }}
              />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
