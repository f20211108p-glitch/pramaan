import { cn, tierColor, stageColor } from "@/lib/utils";

export function TierBadge({ tier }: { tier: string | null | undefined }) {
  if (!tier) return <span className="text-[var(--pramaan-text-muted)] text-xs">-</span>;
  return (
    <span
      className={cn(
        "inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-semibold tracking-wider uppercase border",
        tierColor(tier)
      )}
    >
      {tier}
    </span>
  );
}

export function StageBadge({ stage }: { stage: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-medium tracking-wide capitalize",
        stageColor(stage)
      )}
    >
      {stage.replace(/_/g, " ")}
    </span>
  );
}
