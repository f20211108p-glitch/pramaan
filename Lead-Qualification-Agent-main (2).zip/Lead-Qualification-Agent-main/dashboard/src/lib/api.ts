/**
 * LeadEngine API client.
 *
 * All calls go to the FastAPI backend via server-side fetch (Next.js server components)
 * or client-side fetch (React hooks). The admin key is read from env vars.
 */

import type {
  Client,
  DashboardHome,
  Lead,
  LeadDetail,
  LeadTimeline,
  ActivityItem,
  BillingEvent,
  Conversation,
  Message,
  LeadInsight,
  QAPair,
  QATemplate,
} from "./types";

import { getAuthHeaders } from "./auth";

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

// ── Fetch wrapper ──────────────────────────────────────────────────────────

async function apiFetch<T>(path: string, options?: RequestInit): Promise<T> {
  const url = `${API_BASE}${path}`;
  const res = await fetch(url, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...getAuthHeaders(),
      ...options?.headers,
    },
    cache: "no-store",
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`API error ${res.status}: ${text}`);
  }

  // Handle streaming responses (CSV, text exports)
  const contentType = res.headers.get("content-type") || "";
  if (contentType.includes("text/csv") || contentType.includes("text/plain")) {
    return (await res.text()) as unknown as T;
  }

  return res.json();
}

// ── Dashboard endpoints ────────────────────────────────────────────────────

export async function getDashboardHome(clientId: string): Promise<DashboardHome> {
  return apiFetch(`/dashboard/${clientId}/home`);
}

export async function getLeadDetail(
  clientId: string,
  leadId: string
): Promise<LeadDetail> {
  return apiFetch(`/dashboard/${clientId}/leads/${leadId}/detail`);
}

export async function getLeadTimeline(
  clientId: string,
  leadId: string
): Promise<LeadTimeline> {
  return apiFetch(`/dashboard/${clientId}/leads/${leadId}/timeline`);
}

export async function getActivityFeed(
  clientId: string,
  limit = 30
): Promise<{ activity: ActivityItem[]; count: number }> {
  return apiFetch(`/dashboard/${clientId}/activity?limit=${limit}`);
}

export async function bulkUpdateLeads(
  clientId: string,
  leadIds: string[],
  fields: { stage?: string; tier?: string; assigned_agent_id?: string }
): Promise<{ updated: number }> {
  return apiFetch(`/dashboard/${clientId}/leads/bulk-update`, {
    method: "POST",
    body: JSON.stringify({ lead_ids: leadIds, ...fields }),
  });
}

export async function exportLeadsCSV(
  clientId: string,
  tier?: string,
  stage?: string
): Promise<string> {
  const params = new URLSearchParams();
  if (tier) params.set("tier", tier);
  if (stage) params.set("stage", stage);
  const qs = params.toString() ? `?${params}` : "";
  return apiFetch(`/dashboard/${clientId}/leads/export${qs}`);
}

export async function exportConversation(
  clientId: string,
  conversationId: string,
  format: "text" | "json" = "text"
): Promise<string> {
  return apiFetch(
    `/dashboard/${clientId}/conversations/${conversationId}/export?format=${format}`
  );
}

// ── Admin CRUD endpoints ───────────────────────────────────────────────────

export async function listClients(): Promise<{ clients: Client[] }> {
  return apiFetch("/admin/clients");
}

export async function getClient(clientId: string): Promise<Client> {
  return apiFetch(`/admin/clients/${clientId}`);
}

export async function listLeads(
  clientId: string,
  params?: { tier?: string; stage?: string; search?: string; limit?: number; offset?: number }
): Promise<{ leads: Lead[]; total: number; limit: number; offset: number }> {
  const qs = new URLSearchParams();
  if (params?.tier) qs.set("tier", params.tier);
  if (params?.stage) qs.set("stage", params.stage);
  if (params?.search) qs.set("search", params.search);
  if (params?.limit) qs.set("limit", String(params.limit));
  if (params?.offset) qs.set("offset", String(params.offset));
  const q = qs.toString() ? `?${qs}` : "";
  return apiFetch(`/admin/clients/${clientId}/leads${q}`);
}

export async function getLead(clientId: string, leadId: string): Promise<Lead> {
  return apiFetch(`/admin/clients/${clientId}/leads/${leadId}`);
}

export async function updateLead(
  clientId: string,
  leadId: string,
  fields: Partial<Lead>
): Promise<Lead> {
  return apiFetch(`/admin/clients/${clientId}/leads/${leadId}`, {
    method: "PATCH",
    body: JSON.stringify(fields),
  });
}

export async function getConversationMessages(
  clientId: string,
  conversationId: string
): Promise<{ messages: Message[] }> {
  return apiFetch(
    `/admin/clients/${clientId}/conversations/${conversationId}/messages`
  );
}

export async function listBillingEvents(
  clientId: string,
  limit = 50,
  offset = 0
): Promise<{ events: BillingEvent[]; total: number }> {
  return apiFetch(
    `/admin/clients/${clientId}/billing?limit=${limit}&offset=${offset}`
  );
}

export async function getPipelineStats(
  clientId: string
): Promise<Record<string, unknown>> {
  return apiFetch(`/admin/clients/${clientId}/stats`);
}

// ── Client management ─────────────────────────────────────────────────────

export async function updateClient(
  clientId: string,
  fields: Partial<Client>
): Promise<Client> {
  return apiFetch(`/admin/clients/${clientId}`, {
    method: "PATCH",
    body: JSON.stringify(fields),
  });
}

// ── Project / Brochure management ─────────────────────────────────────────

export interface Project {
  project_id: string;
  project_name: string;
  chunk_count: number;
  ingested_at?: string | null;
}

export async function listProjects(
  clientId: string
): Promise<Project[]> {
  // Backend returns { client_id, projects: [...] }
  const data = await apiFetch<{ projects: Project[] }>(
    `/admin/projects?client_id=${clientId}`
  );
  return data.projects ?? [];
}

export async function ingestBrochure(
  clientId: string,
  projectName: string,
  file: File
): Promise<{
  status: string;
  chunks_ingested: number;
  project_id?: string;
  pages_extracted?: number;
}> {
  const url = `${API_BASE}/admin/ingest`;
  const formData = new FormData();
  formData.append("file", file);
  formData.append("client_id", clientId);
  formData.append("project_name", projectName);

  const res = await fetch(url, {
    method: "POST",
    headers: { ...getAuthHeaders() },
    body: formData,
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Upload failed ${res.status}: ${text}`);
  }
  return res.json();
}

export async function deleteProjectChunks(
  clientId: string,
  projectId: string
): Promise<{ deleted: number }> {
  // Matches backend route: DELETE /admin/projects/{project_id}/chunks?client_id=...
  return apiFetch(
    `/admin/projects/${encodeURIComponent(projectId)}/chunks?client_id=${clientId}`,
    { method: "DELETE" }
  );
}

// ── Lead Insight ────────────────────────────────────────────────────────────

export async function getLeadInsight(
  clientId: string,
  leadId: string,
  refresh = false
): Promise<LeadInsight> {
  const q = refresh ? "?refresh=true" : "";
  return apiFetch(`/dashboard/${clientId}/leads/${leadId}/insight${q}`);
}

// ── Project Q&A ────────────────────────────────────────────────────────────

export async function getQATemplate(): Promise<QATemplate> {
  return apiFetch(`/admin/qa-template`);
}

export async function listProjectQA(
  clientId: string,
  projectId: string
): Promise<{ qa_pairs: QAPair[] }> {
  return apiFetch(`/admin/projects/${projectId}/qa?client_id=${clientId}`);
}

export async function ingestProjectQA(
  clientId: string,
  projectId: string,
  projectName: string,
  qaPairs: QAPair[],
  replaceExisting = true
): Promise<{ ingested: number; project_id: string }> {
  return apiFetch(`/admin/projects/qa`, {
    method: "POST",
    body: JSON.stringify({
      client_id: clientId,
      project_id: projectId,
      project_name: projectName,
      qa_pairs: qaPairs,
      replace_existing: replaceExisting,
    }),
  });
}

export async function deleteProjectQA(
  clientId: string,
  projectId: string
): Promise<{ deleted: number }> {
  return apiFetch(
    `/admin/projects/${projectId}/qa?client_id=${clientId}`,
    { method: "DELETE" }
  );
}
