/**
 * Auth utilities — JWT token management for LeadEngine dashboard.
 *
 * Two roles:
 *   - admin: Pramaan team, sees all clients
 *   - client: Developer (Prestige, Lodha), sees only their client data
 */

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
const TOKEN_KEY = "pramaan_token";
const USER_KEY = "pramaan_user";

export interface AuthUser {
  id: string;
  email: string;
  name: string;
  role: "admin" | "client";
  client_id: string | null;
  client_name: string | null;
}

export interface LoginResult {
  access_token: string;
  token_type: string;
  user: AuthUser;
}

// ── Token persistence ─────────────────────────────────────────────────────

export function getToken(): string | null {
  if (typeof window === "undefined") return null;
  return localStorage.getItem(TOKEN_KEY);
}

export function getStoredUser(): AuthUser | null {
  if (typeof window === "undefined") return null;
  const raw = localStorage.getItem(USER_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

export function setAuth(token: string, user: AuthUser): void {
  localStorage.setItem(TOKEN_KEY, token);
  localStorage.setItem(USER_KEY, JSON.stringify(user));
}

export function clearAuth(): void {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
}

// ── API calls ─────────────────────────────────────────────────────────────

export async function login(email: string, password: string): Promise<LoginResult> {
  const res = await fetch(`${API_BASE}/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password }),
  });

  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data.detail || `Login failed (${res.status})`);
  }

  const result: LoginResult = await res.json();
  setAuth(result.access_token, result.user);
  return result;
}

export async function fetchMe(): Promise<AuthUser> {
  const token = getToken();
  if (!token) throw new Error("Not authenticated");

  const res = await fetch(`${API_BASE}/auth/me`, {
    headers: { Authorization: `Bearer ${token}` },
  });

  if (!res.ok) {
    if (res.status === 401) {
      clearAuth();
      throw new Error("Session expired");
    }
    throw new Error("Failed to fetch user info");
  }

  return res.json();
}

/**
 * Get auth headers for API calls.
 * Returns Bearer token if logged in.
 *
 * NOTE: never put an admin key in a NEXT_PUBLIC_ env var — anything
 * NEXT_PUBLIC_ is compiled into the public JS bundle and readable by
 * anyone. The backend only accepts JWT Bearer tokens.
 */
export function getAuthHeaders(): Record<string, string> {
  const token = getToken();
  return token ? { Authorization: `Bearer ${token}` } : {};
}
