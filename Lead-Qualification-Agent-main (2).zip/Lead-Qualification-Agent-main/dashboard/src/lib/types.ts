/**
 * TypeScript types matching LeadEngine backend models.
 * Keep in sync with src/api/admin.py + src/api/dashboard.py response models.
 */

// ── Core entities ──────────────────────────────────────────────────────────

export interface Client {
  id: string;
  client_name: string;
  waba_number: string;
  waba_phone_number_id: string;
  broker_wa_numbers: string[] | null;
  google_calendar_id: string | null;
  crm_type: string | null;
  language_config: Record<string, unknown> | null;
  prompt_overrides: Record<string, unknown> | null;
  billing_model: "direct" | "per_visit" | "per_lead";
  active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Lead {
  id: string;
  client_id: string;
  phone: string;
  name: string | null;
  email: string | null;
  language_pref: string;
  intent: string;
  budget_min: number | null;
  budget_max: number | null;
  timeline_months: number | null;
  urgency: string;
  financing_status: string;
  location_preferences: string[] | null;
  property_type: string;
  family_size: number | null;
  score: number | null;
  tier: string | null;
  stage: string;
  source_channel: string;
  created_at: string;
  updated_at: string;
}

export interface Conversation {
  id: string;
  client_id: string;
  lead_id: string;
  channel: string;
  status: string;
  summary: string | null;
  started_at: string;
  last_message_at: string;
  messages?: Message[];
  message_count?: number;
}

export interface Message {
  id: string;
  conversation_id: string;
  direction: "inbound" | "outbound";
  content: string;
  message_type: string;
  channel_message_id: string | null;
  timestamp: string;
}

export interface BillingEvent {
  id: string;
  client_id: string;
  lead_id: string | null;
  event_type: string;
  amount_inr: number | null;
  extra_data: Record<string, unknown> | null;
  created_at: string;
}

export interface ConsentLog {
  id: string;
  client_id: string;
  lead_id: string;
  consent_type: string;
  source: string;
  granted_at: string;
}

// ── Dashboard response shapes ──────────────────────────────────────────────

export interface PipelineStats {
  total_leads: number;
  by_tier: Record<string, number>;
  by_stage: Record<string, number>;
  total_conversations: number;
  total_messages: number;
  total_billing_events: number;
}

export interface DashboardHome {
  client: {
    id: string;
    client_name: string;
    crm_type: string | null;
    crm_configured: boolean;
    billing_model: "direct" | "per_visit" | "per_lead";
  };
  stats: PipelineStats;
  hot_leads: Lead[];
  recent_leads: Lead[];
  recent_activity: ActivityItem[];
}

export interface ActivityItem {
  direction: "inbound" | "outbound";
  content: string;
  message_type: string;
  timestamp: string;
  conversation_id: string;
  lead_id: string;
  lead_phone: string;
  lead_name: string | null;
  lead_tier: string | null;
}

export interface LeadDetail {
  lead: Lead;
  conversations: Conversation[];
  billing_events: BillingEvent[];
  consents: ConsentLog[];
  summary: {
    total_conversations: number;
    total_messages: number;
    total_billing_events: number;
    has_consent: boolean;
  };
}

export interface TimelineEvent {
  type: "message" | "billing";
  timestamp: string;
  data: Record<string, unknown>;
}

export interface LeadTimeline {
  lead_id: string;
  lead_phone: string;
  lead_name: string | null;
  events: TimelineEvent[];
  total_events: number;
}

// ── Lead Insight ───────────────────────────────────────────────────────────

export interface LeadInsight {
  summary: string;
  close_probability: number;
  buying_signals: string[];
  concerns: string[];
  next_action: string;
  talking_points: string[];
  urgency_level: "low" | "medium" | "high";
  generated_at: string;
  cached: boolean;
}

// ── Project Q&A ────────────────────────────────────────────────────────────

export interface QAPair {
  id?: string;
  question: string;
  answer: string;
  category?: string | null;
  created_at?: string | null;
}

export interface QATemplate {
  version: number;
  description: string;
  categories: { name: string; questions: string[] }[];
}

// ── Tier/Stage enums ───────────────────────────────────────────────────────

export type Tier = "hot" | "warm" | "cold";
export type Stage =
  | "new"
  | "qualifying"
  | "qualified"
  | "scheduling"
  | "nurturing"
  | "handed_off"
  | "converted"
  | "lost";
