import { clsx, type ClassValue } from "clsx";

export function cn(...inputs: ClassValue[]) {
  return clsx(inputs);
}

/** Format INR amount in lakhs / crores */
export function formatBudget(amount: number | null | undefined): string {
  if (amount == null) return "-";
  if (amount >= 10_000_000) {
    return `₹${(amount / 10_000_000).toFixed(1)} Cr`;
  }
  return `₹${Math.round(amount / 100_000)}L`;
}

/** Format budget range */
export function formatBudgetRange(
  min: number | null | undefined,
  max: number | null | undefined
): string {
  if (min == null && max == null) return "Not specified";
  if (min != null && max != null) return `${formatBudget(min)} – ${formatBudget(max)}`;
  if (min != null) return `${formatBudget(min)}+`;
  return `Up to ${formatBudget(max)}`;
}

/** Tier badge color — PRAMAAN palette */
export function tierColor(tier: string | null | undefined): string {
  switch (tier) {
    case "hot":
      return "bg-[var(--tier-hot-bg)] text-[var(--tier-hot)] border-[#E8C5C3]";
    case "warm":
      return "bg-[var(--tier-warm-bg)] text-[var(--tier-warm)] border-[#E8DCC3]";
    case "cold":
      return "bg-[var(--tier-cold-bg)] text-[var(--tier-cold)] border-[#C3CDD8]";
    default:
      return "bg-[var(--pramaan-gold-light)] text-[var(--pramaan-text-muted)] border-[var(--pramaan-border)]";
  }
}

/** Stage badge color — muted, sophisticated */
export function stageColor(stage: string): string {
  const colors: Record<string, string> = {
    new: "bg-[#F5F0E8] text-[#8B7355]",
    qualifying: "bg-[#FBF6EC] text-[#B08C4C]",
    qualified: "bg-[#EFF5EF] text-[#5A8A5A]",
    scheduling: "bg-[#F0EDF5] text-[#7B6BA1]",
    nurturing: "bg-[#EDF0F5] text-[#6B7FA1]",
    handed_off: "bg-[#EDF5EF] text-[#5A8A6B]",
    converted: "bg-[#E8F0E8] text-[#4A7A4A]",
    lost: "bg-[#F5EDEB] text-[#8A5A5A]",
  };
  return colors[stage] || "bg-[var(--pramaan-gold-light)] text-[var(--pramaan-text-secondary)]";
}

/** Relative time */
export function timeAgo(dateStr: string): string {
  const now = Date.now();
  const then = new Date(dateStr).getTime();
  const diffMs = now - then;
  const diffMin = Math.floor(diffMs / 60_000);
  if (diffMin < 1) return "just now";
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `${diffHr}h ago`;
  const diffDays = Math.floor(diffHr / 24);
  if (diffDays < 7) return `${diffDays}d ago`;
  return new Date(dateStr).toLocaleDateString();
}

/** Format phone for display */
export function formatPhone(phone: string): string {
  if (!phone) return "-";
  const clean = phone.replace(/\D/g, "");
  if (clean.length === 12 && clean.startsWith("91")) {
    return `+91 ${clean.slice(2, 7)} ${clean.slice(7)}`;
  }
  return phone;
}

/** Score color — PRAMAAN palette */
export function scoreColor(score: number | null | undefined): string {
  if (score == null) return "text-[var(--pramaan-text-muted)]";
  if (score >= 70) return "text-[var(--tier-hot)] font-bold";
  if (score >= 40) return "text-[var(--pramaan-gold)] font-semibold";
  return "text-[var(--tier-cold)]";
}
