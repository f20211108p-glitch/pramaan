# WhatsApp Business API (WABA) Setup — Pramaan LeadEngine

Complete record of how we set up Meta's WhatsApp Business Cloud API for LeadEngine.  
Completed: June 2026 | App: LeadEngine | WABA: Praman (Udhyam name)

---

## Table of Contents

1. [Prerequisites](#1-prerequisites)
2. [Meta Business Verification](#2-meta-business-verification)
3. [Facebook Developer App Setup](#3-facebook-developer-app-setup)
4. [WhatsApp Business Account (WABA) Configuration](#4-whatsapp-business-account-waba-configuration)
5. [Phone Number Registration](#5-phone-number-registration)
6. [Webhook Configuration](#6-webhook-configuration)
7. [Publishing the App (Live Mode)](#7-publishing-the-app-live-mode)
8. [LeadEngine Client Config](#8-leadengine-client-config)
9. [Generating a Permanent System User Token](#9-generating-a-permanent-system-user-token)
10. [WhatsApp Pricing](#10-whatsapp-pricing)
11. [Credentials Reference](#11-credentials-reference)
12. [Common Errors & Fixes](#12-common-errors--fixes)

---

## 1. Prerequisites

Before starting, have these ready:

- **Udhyam Registration Certificate** (for business verification — use the exact legal name on the certificate)
- **Facebook account** (personal — used to manage Business Manager)
- **Phone number** to register as WhatsApp Business number (must not be active on personal WhatsApp)
- **Website** with privacy policy (Meta checks this during app review)
- **Debit/Credit card** for Meta billing activation (₹3 is charged and refunded as verification)

> **Important — Name mismatch**: If your Udhyam says "Praman" but your website says "Pramaan", use the **Udhyam/legal name** ("Praman") everywhere Meta asks for business name. The WhatsApp display name shown to customers can be different ("Pramaan").

---

## 2. Meta Business Verification

### Step 1 — Create a Facebook Page
1. Go to [facebook.com/pages/create](https://facebook.com/pages/create)
2. Choose **Business or Brand**
3. Enter page name (e.g., "Pramaan Real Estate")
4. Category: Real Estate Agency
5. Skip WhatsApp connection for now
6. You can use **your own Facebook account** — the page belongs to whoever creates it

### Step 2 — Set Up Meta Business Suite
1. Go to [business.facebook.com](https://business.facebook.com)
2. Create a new Business Account if not already done
3. Business name: use legal name from Udhyam (e.g., "Praman")
4. Add your Facebook Page to this Business Account

### Step 3 — Business Verification
1. In Business Suite → **Settings** → **Business info**
2. Scroll to **Verifications** section
3. Click **Start Verification**
4. Upload Udhyam Registration Certificate
5. Meta reviews in 1–3 business days (sometimes instantly)
6. Status shows: **Verified** ✅

> Do NOT do this from the "Authorisations and verifications" section — that's for Ads. Business verification for WhatsApp API is under Business Settings → Business info.

---

## 3. Facebook Developer App Setup

1. Go to [developers.facebook.com](https://developers.facebook.com)
2. Click **My Apps** → **Create App**
3. Use case: **Other** (not the pre-built ones)
4. App type: **Business**
5. App name: e.g., "LeadEngine"
6. Business account: select your verified business (Praman)
7. Click **Create App**

### Add WhatsApp Product
1. In the app dashboard, scroll down to **Add a Product**
2. Find **WhatsApp** → click **Set up**
3. This creates a WhatsApp Business Account (WABA) linked to your developer app

---

## 4. WhatsApp Business Account (WABA) Configuration

After adding WhatsApp product:

1. Left sidebar → **WhatsApp** → **API Setup**
2. You'll see:
   - **Phone Number ID** (e.g., `1066221309917332`)
   - **WhatsApp Business Account ID** (e.g., `1291946789756320`)
   - **Temporary access token** (expires in 24 hours)

### Business Display Name
- Set during phone number registration
- Can differ from legal name (e.g., display name "Pramaan" vs legal name "Praman")
- Meta reviews display names — common names approved in minutes

---

## 5. Phone Number Registration

### Option A — Register a New Number
1. **WhatsApp** → **API Setup** → **Add phone number**
2. Enter your WhatsApp Business number (e.g., +91 90161 88202)
3. Receive OTP via SMS or call
4. Enter OTP to verify
5. Set display name

### Option B — Migrate Existing Number
- If the number is already on personal/business WhatsApp, you must delete that account first
- Meta migration wizard walks you through it

### After Registration
- Your Phone Number ID is now the real one (not the test sandbox number)
- Note it down — this goes into LeadEngine's client config

---

## 6. Webhook Configuration

### Where to Configure
**developers.facebook.com** → Your App → **WhatsApp** → **Configuration** → **Webhook**

> Do NOT configure webhooks on the "Authorisations" page or Ads pages — wrong location.

### Setup
1. **Callback URL**: Your server's public URL + `/webhook`  
   Example: `https://your-tunnel.trycloudflare.com/webhook`  
   Production: `https://your-railway-app.railway.app/webhook`

2. **Verify Token**: Must match `WHATSAPP_VERIFY_TOKEN` in your `.env`  
   LeadEngine default: `leadengine_verify_2026`

3. Click **Verify and Save** — Meta sends a GET request to confirm

4. After saving, click **Manage** and enable the **`messages`** field

### Local Testing with Cloudflare Tunnel (free, no signup)
```bash
# In a separate terminal — no account needed
cloudflared tunnel --url http://localhost:8000
```
Copy the generated URL (e.g., `https://xxx.trycloudflare.com`) as your callback URL.

> **ngrok requires signup** — use Cloudflare Tunnel instead for quick testing.

---

## 7. Publishing the App (Live Mode)

By default, your Meta app is in **Development mode** — it only receives test webhooks sent from the dashboard.

**To receive real WhatsApp messages:**

1. **developers.facebook.com** → Your App → **App Settings** → **Basic**
2. Fill in:
   - Privacy Policy URL (your website's privacy page)
   - Terms of Service URL
   - App icon
3. Go to top of page → toggle **Development** → **Live**
4. Confirm the mode change

> Until you do this, messages from real phone numbers will NOT reach your webhook.

---

## 8. LeadEngine Client Config

Each client in LeadEngine stores their WABA credentials in the database (`client_config` table).

### Pramaan Test Client (id: `5090db5f-f6bb-4e82-8b68-cfc7ff0288d0`)

| Field | Value |
|-------|-------|
| `waba_phone_number_id` | `1066221309917332` |
| `waba_number` | `919016188202` |
| `waba_business_account_id` | `1291946789756320` |
| `broker_wa_numbers` | `["+919016188202"]` |

### Setting/Updating Client Config via API

```bash
# PATCH to update WABA credentials for a client
curl -X PATCH http://localhost:8000/admin/clients/<CLIENT_ID> \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <YOUR_JWT_TOKEN>" \
  -d '{
    "waba_token": "YOUR_ACCESS_TOKEN",
    "waba_phone_number_id": "1066221309917332",
    "waba_number": "919016188202"
  }'
```

> The `waba_token` field stores the WhatsApp access token per client — NOT a global env var.

---

## 9. Generating a Permanent System User Token

The default token from the API Setup page **expires in 24 hours**. For production use, generate a permanent token:

### Steps
1. Go to **[business.facebook.com](https://business.facebook.com)** → **Settings** (gear icon)
2. Left menu → **Users** → **System Users**
3. Click **Add** → Name it (e.g., "LeadEngine Bot") → Role: **Admin**
4. Click **Generate New Token**
5. Select your app (LeadEngine)
6. Enable these permissions:
   - `whatsapp_business_messaging`
   - `whatsapp_business_management`
7. Click **Generate Token**
8. **Copy and save immediately** — it won't be shown again

### Add to LeadEngine
Update the client config via PATCH API (see Section 8) with the new permanent token.

---

## 10. WhatsApp Pricing

### Conversation-Based Billing (India rates, 2026)

| Type | Who Starts | Cost |
|------|-----------|------|
| **Service** | Customer messages you | **FREE** |
| **Marketing** | You message customer (promotional) | ~₹0.58/conversation |
| **Utility** | You message customer (transactional) | ~₹0.14/conversation |
| **Authentication** | OTP messages | ~₹0.14/conversation |

### LeadEngine Use Case = FREE

- Leads send you messages → **Service conversations** → **₹0**
- AI replies within 24-hour window → same conversation = no extra charge
- You only pay if you **proactively message** leads with templates after the 24-hr window

### Free Tier
- First **1,000 service conversations/month** are free (additional free buffer on top of above)
- Applies per WABA

### Meta Billing Setup
- Add debit/credit card at **business.facebook.com → Billing**
- ₹3 verification charge is refunded automatically
- Billing kicks in only when you send paid (business-initiated) messages

---

## 11. Credentials Reference

Store these securely — never commit to git.

### Environment Variables (`.env`)
```env
WHATSAPP_VERIFY_TOKEN=leadengine_verify_2026   # Must match Meta webhook config
```

### Per-Client DB Fields
```
waba_token              = <access token from Meta — permanent or 24hr>
waba_phone_number_id    = <Phone Number ID from Meta API Setup page>
waba_number             = <phone in E.164 format without +, e.g. 919016188202>
waba_business_account_id = <WABA ID from Meta>
```

### Meta Dashboard URLs
| Purpose | URL |
|---------|-----|
| Developer App | [developers.facebook.com/apps](https://developers.facebook.com/apps) |
| Business Settings | [business.facebook.com/settings](https://business.facebook.com/settings) |
| WABA Manager | [business.facebook.com/wa/manage](https://business.facebook.com/wa/manage) |
| API Setup | App → WhatsApp → API Setup |
| Webhook Config | App → WhatsApp → Configuration |

---

## 12. Common Errors & Fixes

### "The callback URL or verify token couldn't be validated"
- **Cause**: Local server not running, or tunnel URL changed
- **Fix**: Ensure `uvicorn` is running on port 8000 AND tunnel is active, then retry verification

### "Messages not arriving at webhook"
- **Cause 1**: App still in **Development** mode → toggle to **Live**
- **Cause 2**: `messages` webhook field not subscribed → WhatsApp → Configuration → Manage → enable `messages`
- **Cause 3**: Wrong Phone Number ID in client config → PATCH with correct ID

### "Token expired" / "Invalid OAuth access token"
- **Cause**: Using 24-hour temporary token
- **Fix**: Generate permanent System User token (Section 9)

### Onboarding Form Bug
- The onboarding form currently accepts any text in the `waba_phone_number_id` field (no validation)
- After onboarding, always verify the phone number ID via PATCH API with the correct value from Meta's API Setup page

### "Can't see client in dashboard dropdown"
- Hard refresh: `Ctrl + Shift + R`
- If still missing, check the client was created with status `active` in DB

---

## Architecture Note

```
Customer WhatsApp → Meta Cloud API → POST /webhook (LeadEngine)
                                          ↓
                                    Verify signature
                                          ↓
                                    Route by waba_phone_number_id
                                          ↓
                                    LangGraph AI Engine
                                          ↓
                                    POST to Meta Graph API
                                          ↓
                                    Customer gets AI reply
```

LeadEngine is **multi-tenant** — each client has their own WABA token and Phone Number ID stored in the DB. A single LeadEngine instance handles multiple real estate clients, routing inbound messages by phone number ID.

---

*Document created June 2026. Update when adding new clients or rotating tokens.*
