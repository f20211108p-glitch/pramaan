"""Check brochure chunks per client."""
import asyncio
import asyncpg


async def check():
    conn = await asyncpg.connect("postgresql://lead:leadpass@localhost:5432/leadengine")

    rows = await conn.fetch(
        "SELECT client_id, project_name, chunk_type, COUNT(*) as cnt "
        "FROM brochure_chunks "
        "GROUP BY client_id, project_name, chunk_type "
        "ORDER BY client_id, project_name, chunk_type"
    )
    print("=== BROCHURE CHUNKS BY CLIENT/PROJECT ===")
    for r in rows:
        print(f"  client={r['client_id']}  project={r['project_name']}  type={r['chunk_type']}  count={r['cnt']}")

    # Also show client names
    clients = await conn.fetch("SELECT id, client_name, waba_phone_number_id FROM client_configs")
    print("\n=== CLIENTS ===")
    for c in clients:
        print(f"  {c['id']}  name={c['client_name']}  waba={c['waba_phone_number_id']}")

    await conn.close()


asyncio.run(check())
