"""Check current state of lead 918769448883."""
import asyncio
import asyncpg


async def check():
    conn = await asyncpg.connect("postgresql://lead:leadpass@localhost:5432/leadengine")

    lead = await conn.fetchrow(
        "SELECT id, name, phone, stage, intent, score, tier, "
        "budget_min, budget_max, timeline_months, financing_status, "
        "location_preferences, property_type, family_size, language_pref "
        "FROM leads WHERE phone = '918769448883'"
    )
    if lead:
        print("=== LEAD ===")
        for key in lead.keys():
            print(f"  {key}: {lead[key]}")
    else:
        print("No lead found for 918769448883")

    # Check messages
    msgs = await conn.fetch(
        "SELECT m.direction, m.content "
        "FROM messages m "
        "JOIN conversations c ON m.conversation_id = c.id "
        "JOIN leads l ON c.lead_id = l.id "
        "WHERE l.phone = '918769448883' "
        "ORDER BY m.id"
    )
    if msgs:
        print(f"\n=== MESSAGES ({len(msgs)}) ===")
        for m in msgs:
            print(f"  [{m['direction']}] {m['content'][:120]}".encode('utf-8', errors='replace').decode('utf-8'))
    else:
        print("\nNo messages found")

    await conn.close()


asyncio.run(check())
