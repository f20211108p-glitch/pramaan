"""Check prompt_overrides in client_config."""
import asyncio
import asyncpg


async def check():
    conn = await asyncpg.connect("postgresql://lead:leadpass@localhost:5432/leadengine")
    rows = await conn.fetch("SELECT id, client_name, prompt_overrides FROM client_config")
    for r in rows:
        print(f"id={r['id']}  name={r['client_name']}")
        print(f"  type={type(r['prompt_overrides'])}")
        print(f"  repr={repr(r['prompt_overrides'])}")
    await conn.close()


asyncio.run(check())
