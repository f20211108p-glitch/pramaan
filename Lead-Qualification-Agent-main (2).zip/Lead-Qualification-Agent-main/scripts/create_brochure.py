from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.units import cm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
from reportlab.lib.enums import TA_CENTER

OUTPUT = r"C:\Users\Hp\Downloads\Shreeji_Greens_Vadodara_Brochure.pdf"

doc = SimpleDocTemplate(OUTPUT, pagesize=A4,
    rightMargin=2*cm, leftMargin=2*cm, topMargin=2*cm, bottomMargin=2*cm)

green = colors.HexColor("#1a7a3c")
gold  = colors.HexColor("#c9a84c")

title_style   = ParagraphStyle("title",   fontSize=26, textColor=green, alignment=TA_CENTER, fontName="Helvetica-Bold", spaceAfter=6)
sub_style     = ParagraphStyle("sub",     fontSize=13, textColor=gold,  alignment=TA_CENTER, fontName="Helvetica-Bold", spaceAfter=4)
dev_style     = ParagraphStyle("dev",     fontSize=11, textColor=colors.grey, alignment=TA_CENTER, spaceAfter=6)
section_style = ParagraphStyle("section", fontSize=13, textColor=green, fontName="Helvetica-Bold", spaceBefore=14, spaceAfter=4)
body_style    = ParagraphStyle("body",    fontSize=10, leading=15, spaceAfter=4)
bullet_style  = ParagraphStyle("bullet",  fontSize=10, leading=15, leftIndent=14, spaceAfter=2)
note_style    = ParagraphStyle("note",    fontSize=8, textColor=colors.grey, spaceAfter=4)

story = []

story.append(Paragraph("SHREEJI GREENS", title_style))
story.append(Paragraph("Premium 1, 2 & 3 BHK Residences | Vadodara, Gujarat", sub_style))
story.append(Paragraph("By Pramaan Developers Pvt. Ltd.", dev_style))
story.append(HRFlowable(width="100%", thickness=2, color=green, spaceAfter=10))

story.append(Paragraph("Project Highlights", section_style))
highlights = [
    ["RERA Registration", "GJ/REA/VADODARA/AA01234/250101"],
    ["Location",          "Gotri Road, Vadodara, Gujarat - 390021"],
    ["Project Status",    "Under Construction"],
    ["Possession",        "December 2027"],
    ["Total Towers",      "3 Towers, Ground + 14 Floors"],
    ["Total Units",       "336 Units"],
]
t = Table(highlights, colWidths=[6*cm, 10*cm])
t.setStyle(TableStyle([
    ("BACKGROUND",  (0,0), (0,-1), colors.HexColor("#e8f5ee")),
    ("TEXTCOLOR",   (0,0), (0,-1), green),
    ("FONTNAME",    (0,0), (0,-1), "Helvetica-Bold"),
    ("FONTSIZE",    (0,0), (-1,-1), 10),
    ("GRID",        (0,0), (-1,-1), 0.5, colors.lightgrey),
    ("ROWBACKGROUNDS", (0,0), (-1,-1), [colors.white, colors.HexColor("#f9f9f9")]),
    ("PADDING",     (0,0), (-1,-1), 6),
]))
story.append(t)

story.append(Paragraph("Floor Plans & Pricing", section_style))
pricing_data = [
    ["Configuration",  "Carpet Area", "Built-up Area", "Price"],
    ["1 BHK Compact",  "420 sqft",    "550 sqft",      "Rs. 28 Lakh onwards"],
    ["2 BHK Classic",  "620 sqft",    "810 sqft",      "Rs. 45 Lakh onwards"],
    ["2 BHK Premium",  "740 sqft",    "965 sqft",      "Rs. 58 Lakh onwards"],
    ["2 BHK Luxe",     "820 sqft",    "1070 sqft",     "Rs. 72 Lakh onwards"],
    ["3 BHK Classic",  "980 sqft",    "1280 sqft",     "Rs. 85 Lakh onwards"],
    ["3 BHK Premium",  "1150 sqft",   "1500 sqft",     "Rs. 1.05 Crore onwards"],
]
pt = Table(pricing_data, colWidths=[4*cm, 3.5*cm, 3.5*cm, 5*cm])
pt.setStyle(TableStyle([
    ("BACKGROUND",  (0,0), (-1,0), green),
    ("TEXTCOLOR",   (0,0), (-1,0), colors.white),
    ("FONTNAME",    (0,0), (-1,0), "Helvetica-Bold"),
    ("FONTSIZE",    (0,0), (-1,-1), 10),
    ("GRID",        (0,0), (-1,-1), 0.5, colors.lightgrey),
    ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#f0f8f3")]),
    ("PADDING",     (0,0), (-1,-1), 6),
    ("ALIGN",       (1,0), (-1,-1), "CENTER"),
]))
story.append(pt)
story.append(Paragraph("* Prices inclusive of basic amenity charges. GST, stamp duty & registration extra.", note_style))

story.append(Paragraph("Payment Plan", section_style))
payment_data = [
    ["Stage",                              "Amount"],
    ["Booking Amount",                     "Rs. 51,000"],
    ["On Agreement (within 30 days)",      "10% of unit cost"],
    ["On Plinth",                          "10%"],
    ["On Ground Floor Slab",               "10%"],
    ["On 5th Floor Slab",                  "10%"],
    ["On 10th Floor Slab",                 "10%"],
    ["On Terrace Slab",                    "15%"],
    ["On Brickwork Completion",            "10%"],
    ["On Plumbing & Electrical",           "10%"],
    ["On Possession",                      "Balance + Registration"],
]
pay_t = Table(payment_data, colWidths=[9*cm, 7*cm])
pay_t.setStyle(TableStyle([
    ("BACKGROUND",  (0,0), (-1,0), gold),
    ("TEXTCOLOR",   (0,0), (-1,0), colors.white),
    ("FONTNAME",    (0,0), (-1,0), "Helvetica-Bold"),
    ("FONTSIZE",    (0,0), (-1,-1), 10),
    ("GRID",        (0,0), (-1,-1), 0.5, colors.lightgrey),
    ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#fffbf0")]),
    ("PADDING",     (0,0), (-1,-1), 6),
]))
story.append(pay_t)
story.append(Paragraph("Home Loan available from SBI, HDFC, ICICI, Bank of Baroda. EMI from Rs. 18,500/month for 2 BHK Classic (20-yr tenure, 8.5% interest).", body_style))

story.append(Paragraph("World-Class Amenities", section_style))
amenities = [
    "Clubhouse (8,000 sqft) with banquet hall and party lawn",
    "Swimming Pool with kids splash zone and deck seating",
    "Fully equipped Gymnasium with modern equipment",
    "Yoga & Meditation Garden with landscape design",
    "Cricket Net Practice Area and Badminton Court",
    "Children's Play Area with imported equipment",
    "Jogging Track (350m) with landscaped garden",
    "Senior Citizens Corner with seating pavilion",
    "Indoor Games Room (Table Tennis, Carom, Chess)",
    "24/7 CCTV Surveillance with security cabin",
    "3-tier security with RFID access control",
    "100% Power Backup for common areas and lifts",
    "EV Charging Points in basement parking",
    "Solar panels for common area lighting",
    "Rainwater Harvesting and STP Plant",
]
for a in amenities:
    story.append(Paragraph("- " + a, bullet_style))

story.append(Paragraph("Location Advantages", section_style))
story.append(Paragraph(
    "Shreeji Greens is on Gotri Road, one of Vadodara's fastest-growing residential corridors, "
    "minutes from top schools, hospitals, malls and Vadodara Railway Station.", body_style))

loc_data = [
    ["Landmark",                         "Distance"],
    ["Vadodara Railway Station",         "4.5 km (12 min)"],
    ["Vadodara Airport",                 "7 km (18 min)"],
    ["Gotri Government Hospital",        "1.2 km (4 min)"],
    ["Sama-Savli Road (NH-48)",          "2 km (6 min)"],
    ["Inorbit Mall Vadodara",            "3 km (8 min)"],
    ["DPS Vadodara (School)",            "1.5 km (5 min)"],
    ["Navrachana University",            "2.5 km (7 min)"],
    ["GIDC Vadodara (Business Hub)",     "5 km (12 min)"],
]
lt = Table(loc_data, colWidths=[9*cm, 7*cm])
lt.setStyle(TableStyle([
    ("BACKGROUND",  (0,0), (-1,0), green),
    ("TEXTCOLOR",   (0,0), (-1,0), colors.white),
    ("FONTNAME",    (0,0), (-1,0), "Helvetica-Bold"),
    ("FONTSIZE",    (0,0), (-1,-1), 10),
    ("GRID",        (0,0), (-1,-1), 0.5, colors.lightgrey),
    ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#f0f8f3")]),
    ("PADDING",     (0,0), (-1,-1), 6),
]))
story.append(lt)

story.append(Paragraph("Specifications", section_style))
specs = [
    ("Structure",    "RCC framed, earthquake-resistant (Seismic Zone III), AAC block walls with weather-proof paint"),
    ("Flooring",     "Living/Dining/Bedrooms: Vitrified tiles 800x800mm | Kitchen: Anti-skid ceramic | Bathrooms: Designer tiles"),
    ("Kitchen",      "Granite platform, SS sink with mixer, chimney provision, modular layout option"),
    ("Doors",        "Main door: Teak frame + laminated flush door with digital lock provision | Internal: Hardwood frame"),
    ("Windows",      "UPVC sliding windows with mosquito mesh and MS safety grills"),
    ("Bathrooms",    "Jaquar/Cera CP fittings, EWC, hot-cold mixer, exhaust fan provision, mirror with light"),
    ("Electrical",   "Concealed Havells/Polycab wiring, Legrand modular switches, 2 AC points per bedroom, geyser point in bathrooms"),
    ("Painting",     "Internal: OBD finish | External: Weathershield exterior emulsion"),
]
for label, val in specs:
    story.append(Paragraph("<b>" + label + ":</b> " + val, body_style))

story.append(HRFlowable(width="100%", thickness=1, color=green, spaceBefore=10, spaceAfter=6))
story.append(Paragraph("Contact Pramaan Developers", section_style))
story.append(Paragraph("Sales Office: Ground Floor, Shreeji Greens Site Office, Gotri Road, Vadodara 390021", body_style))
story.append(Paragraph("Phone: +91 90161 88202  |  Email: sales@getpramaan.in  |  Website: www.getpramaan.in", body_style))
story.append(Paragraph("Office Hours: Monday to Saturday, 10:00 AM to 7:00 PM  |  Site Visits by Appointment", body_style))

doc.build(story)
print("PDF created at:", OUTPUT)
