"""
Generate a sample real estate brochure PDF for testing the RAG pipeline.
Run: python scripts/create_sample_pdf.py
Creates: scripts/sample_brochure.pdf
"""
import fitz  # PyMuPDF
from pathlib import Path


def create_sample_brochure():
    doc = fitz.open()

    pages_content = [
        # Page 1: General / Overview
        """PARADISE HEIGHTS
Premium 2 & 3 BHK Residences in Andheri West, Mumbai

Welcome to Paradise Heights — an iconic residential tower offering luxurious apartments
in the heart of Andheri West. Developed by Demo Realty Group, this project is designed
for modern families who value comfort, convenience, and connectivity.

RERA Registration: P51900012345
Project Status: Under Construction
Expected Possession: December 2027
Total Floors: 32
Total Units: 256""",

        # Page 2: Floor Plans
        """FLOOR PLANS & CONFIGURATIONS

2 BHK Compact
Carpet Area: 650 sqft | Built-up Area: 850 sqft
Bedrooms: 2 | Bathrooms: 2 | Balcony: 1
Configuration: Living + Dining + Kitchen + 2 Bedrooms + 2 Toilets

2 BHK Premium
Carpet Area: 780 sqft | Built-up Area: 1020 sqft
Bedrooms: 2 | Bathrooms: 2 | Balcony: 2
Configuration: Living + Dining + Modular Kitchen + 2 Bedrooms + 2 Toilets + Utility

3 BHK Luxury
Carpet Area: 1050 sqft | Built-up Area: 1380 sqft
Bedrooms: 3 | Bathrooms: 3 | Balcony: 2
Configuration: Living + Dining + Modular Kitchen + 3 Bedrooms + 3 Toilets + Servant Room""",

        # Page 3: Pricing
        """PRICING DETAILS

2 BHK Compact: ₹1.15 Crore onwards (₹17,700 per sqft)
2 BHK Premium: ₹1.38 Crore onwards (₹17,700 per sqft)
3 BHK Luxury: ₹1.86 Crore onwards (₹17,700 per sqft)

PAYMENT PLAN:
Booking Amount: ₹5,00,000
Agreement Value: 10% within 30 days
Construction-linked plan available
GST: 5% (after input credit adjustment)
Stamp Duty: 6% (Maharashtra)
Registration: ₹30,000

EMI starting from ₹85,000/month for 2 BHK (20-year tenure, 8.5% interest rate)
Home loan available from SBI, HDFC, ICICI, Axis Bank""",

        # Page 4: Amenities
        """WORLD-CLASS AMENITIES

Clubhouse & Recreation:
- 15,000 sqft Clubhouse with multi-purpose hall
- Temperature-controlled Swimming Pool
- Fully equipped Gymnasium with steam & sauna
- Yoga and meditation room
- Indoor games room (table tennis, carrom, chess)

Sports & Fitness:
- Half basketball court
- Badminton court
- Jogging track (400m)
- Children's play area with imported equipment
- Open-air amphitheatre

Security & Convenience:
- 24/7 CCTV surveillance
- 3-tier security with access control
- Smart home automation ready
- EV charging stations in parking
- 100% power backup for common areas
- Rainwater harvesting
- Organic waste composting""",

        # Page 5: Location
        """LOCATION ADVANTAGES

Paradise Heights is located on SV Road, Andheri West — one of Mumbai's most
sought-after residential corridors.

Connectivity:
- Andheri Railway Station: 1.2 km (5 minutes)
- Andheri Metro Station: 0.8 km (3 minutes)
- Western Express Highway: 2.5 km (10 minutes)
- Mumbai International Airport: 4 km (15 minutes)
- Bandra-Worli Sea Link: 8 km (20 minutes)

Social Infrastructure:
- D.N. Nagar School: 0.5 km
- Kokilaben Dhirubhai Ambani Hospital: 3 km
- InOrbit Mall: 1.5 km
- Lokhandwala Market: 2 km
- Juhu Beach: 3 km

Business Hubs:
- Andheri MIDC (IT hub): 2 km
- Goregaon Film City: 5 km
- BKC Business District: 10 km""",

        # Page 6: Specifications
        """SPECIFICATIONS

Structure:
- RCC framed structure with earthquake-resistant design (Seismic Zone III)
- External walls: AAC blocks with weather-proof paint

Flooring:
- Living, Dining, Bedrooms: Italian marble / vitrified tiles (800x1600mm)
- Kitchen: Anti-skid ceramic tiles
- Bathrooms: Designer ceramic tiles (wall & floor)
- Balcony: Natural stone / anti-skid tiles

Kitchen:
- Modular kitchen with granite platform
- Stainless steel sink with mixer
- Provision for water purifier and chimney
- Electrical points for refrigerator, microwave, dishwasher

Doors & Windows:
- Main door: Teak wood frame with laminated flush door (digital lock provision)
- Internal doors: Hardwood frame with laminated flush doors
- Windows: Powder-coated aluminium with toughened glass (UPVC optional)

Bathroom Fittings:
- Branded CP fittings (Kohler / Grohe / equivalent)
- Wall-hung toilet (Kohler / Roca)
- Hot & cold mixer provision
- Anti-skid designer tiles"""
    ]

    for content in pages_content:
        page = doc.new_page(width=595, height=842)  # A4 size
        # Insert text with formatting
        text_rect = fitz.Rect(50, 50, 545, 792)
        page.insert_textbox(
            text_rect,
            content,
            fontsize=10,
            fontname="helv",
        )

    output_path = Path(__file__).parent / "sample_brochure.pdf"
    doc.save(str(output_path))
    doc.close()
    print(f"Created: {output_path} ({len(pages_content)} pages)")
    return str(output_path)


if __name__ == "__main__":
    create_sample_brochure()
