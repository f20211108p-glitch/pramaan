"""Fix broker_wa_numbers — remove + prefix Meta doesn't accept."""
import asyncio
import asyncpg


async def fix():
    conn = await asyncpg.connect("postgresql://lead:leadpass@localhost:5432/leadengine")
    rows = await conn.fetch("SELECT id, client_name, broker_wa_numbers FROM client_config")
    for r in rows:
        numbers = r["broker_wa_numbers"] or []
        print(f"{r['client_name']}: {numbers}")
        # Strip + prefix from all numbers
        fixed = [n.lstrip("+") for n in numbers]
        if fixed != numbers:
            await conn.execute(
                "UPDATE client_config SET broker_wa_numbers = $1 WHERE id = $2",
                fixed, r["id"],
            )
            print(f"  Fixed → {fixed}")
        else:
            print(f"  OK (no change)")
    await conn.close()


asyncio.run(fix())
