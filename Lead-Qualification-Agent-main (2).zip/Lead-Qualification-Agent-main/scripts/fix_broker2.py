"""Fix broker_wa_numbers — strip + from all clients."""
import asyncio
import asyncpg


async def fix():
    conn = await asyncpg.connect("postgresql://lead:leadpass@localhost:5432/leadengine")
    rows = await conn.fetch("SELECT id, client_name, broker_wa_numbers FROM client_config")
    for r in rows:
        nums = list(r["broker_wa_numbers"] or [])
        fixed = [n.lstrip("+") for n in nums]
        if fixed != nums:
            await conn.execute(
                "UPDATE client_config SET broker_wa_numbers = $1 WHERE id = $2",
                fixed, r["id"],
            )
            print(f"Fixed: {r['client_name']} {nums} -> {fixed}")
        else:
            print(f"OK:    {r['client_name']} {nums}")
    await conn.close()


asyncio.run(fix())
