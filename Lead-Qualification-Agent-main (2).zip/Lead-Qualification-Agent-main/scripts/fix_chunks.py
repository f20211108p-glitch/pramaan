"""Delete Paradise Heights from Pramaan Test client and reset lead."""
import asyncio
import asyncpg

PRAMAAN_CLIENT = "5090db5f-f6bb-4e82-8b68-cfc7ff0288d0"


async def fix():
    conn = await asyncpg.connect("postgresql://lead:leadpass@localhost:5432/leadengine")

    # Delete Paradise Heights from Pramaan Test
    r = await conn.execute(
        "DELETE FROM brochure_chunks WHERE client_id = $1 AND project_name = 'Paradise Heights'",
        PRAMAAN_CLIENT,
    )
    print(f"Deleted Paradise Heights chunks: {r}")

    # Show remaining
    rows = await conn.fetch(
        "SELECT project_name, chunk_type FROM brochure_chunks WHERE client_id = $1",
        PRAMAAN_CLIENT,
    )
    print(f"\nRemaining chunks for Pramaan Test:")
    for r in rows:
        print(f"  {r['project_name']} - {r['chunk_type']}")

    # Reset lead
    for tbl in ("consent_log", "billing_events"):
        try:
            await conn.execute(
                f"DELETE FROM {tbl} WHERE lead_id IN (SELECT id FROM leads WHERE phone = '918769448883')"
            )
        except Exception:
            pass
    await conn.execute(
        "DELETE FROM messages WHERE conversation_id IN "
        "(SELECT c.id FROM conversations c JOIN leads l ON c.lead_id = l.id WHERE l.phone = '918769448883')"
    )
    await conn.execute(
        "DELETE FROM conversations WHERE lead_id IN (SELECT id FROM leads WHERE phone = '918769448883')"
    )
    await conn.execute("DELETE FROM leads WHERE phone = '918769448883'")
    print("\nLead 918769448883 reset!")

    await conn.close()


asyncio.run(fix())
