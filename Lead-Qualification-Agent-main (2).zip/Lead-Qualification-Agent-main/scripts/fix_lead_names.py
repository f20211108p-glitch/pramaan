"""One-time script to backfill lead names for existing leads."""
import asyncio
from src.db.engine import AsyncSessionFactory
from sqlalchemy import text

async def main():
    async with AsyncSessionFactory() as db:
        r = await db.execute(text("SELECT phone, name FROM leads"))
        for row in r.fetchall():
            print(f"  {row[0]} -> {row[1]}")
        await db.execute(text("UPDATE leads SET name = 'Satish Sharma' WHERE phone = '919876500011' AND name IS NULL"))
        await db.execute(text("UPDATE leads SET name = 'Rahul Kumar' WHERE phone = '919876500001' AND name IS NULL"))
        await db.commit()
        print("DONE - names updated")

asyncio.run(main())
