"""Fix lead data — extraction missed timeline and financing."""
import asyncio
import asyncpg

async def fix():
    conn = await asyncpg.connect("postgresql://lead:leadpass@localhost:5432/leadengine")
    await conn.execute(
        "UPDATE leads SET timeline_months = 12, financing_status = 'loan_needed' "
        "WHERE phone = '918769448883'"
    )
    row = await conn.fetchrow(
        "SELECT score, tier, timeline_months, financing_status FROM leads WHERE phone = '918769448883'"
    )
    print(f"Updated: timeline={row['timeline_months']}, financing={row['financing_status']}")
    await conn.close()

asyncio.run(fix())
