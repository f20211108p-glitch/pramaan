"""Set brochure_url on the Pramaan Test client config."""
import asyncio
import json
import asyncpg

BROCHURE_URL = (
    "https://zitynxbvmpsvnmegoiek.supabase.co/storage/v1/object/public/"
    "brochures/shreeji-greens/Shreeji_Greens_Vadodara_Brochure.pdf"
)


async def fix():
    conn = await asyncpg.connect("postgresql://lead:leadpass@localhost:5432/leadengine")

    # Update ALL client configs with brochure info
    rows = await conn.fetch("SELECT id, client_name, prompt_overrides FROM client_config")
    for r in rows:
        raw = r["prompt_overrides"]
        overrides = json.loads(raw) if isinstance(raw, str) and raw else (raw or {})
        overrides["brochure_url"] = BROCHURE_URL
        overrides["brochure_filename"] = "Shreeji_Greens_Brochure.pdf"
        overrides["site_address"] = (
            "Ground Floor, Shreeji Greens Site Office, Gotri Road, Vadodara 390021"
        )
        await conn.execute(
            "UPDATE client_config SET prompt_overrides = $1::jsonb WHERE id = $2",
            json.dumps(overrides), r["id"],
        )
        print(f"Updated {r['client_name']} ({r['id']})")

    # Verify
    rows = await conn.fetch("SELECT id, client_name, prompt_overrides FROM client_config")
    for r in rows:
        print(f"\n{r['client_name']}: {r['prompt_overrides']}")

    await conn.close()


asyncio.run(fix())
