#!/usr/bin/env python3
"""
Interactive client onboarding script for LeadEngine.

Walks through the full onboarding flow:
  1. Collect client info (name, WABA credentials, language, brokers, CRM)
  2. Create client via Admin API
  3. Upload brochure PDFs
  4. Verify setup
  5. Print manual checklist (Meta templates, webhook URL, etc.)

Usage:
  python scripts/onboard_client.py
  python scripts/onboard_client.py --base-url https://your-domain.com --admin-key your_secret
"""
import argparse
import json
import os
import sys
from pathlib import Path

try:
    import httpx
except ImportError:
    print("ERROR: httpx not installed. Run: pip install httpx")
    sys.exit(1)


# ── Defaults ─────────────────────────────────────────────────────────────────

DEFAULT_BASE_URL = "http://localhost:8000"
DEFAULT_ADMIN_KEY = os.getenv("SECRET_KEY", "change_me_in_production")


# ── Helpers ──────────────────────────────────────────────────────────────────

def ask(prompt: str, default: str = "", required: bool = True) -> str:
    """Prompt user for input with optional default."""
    suffix = f" [{default}]" if default else ""
    while True:
        value = input(f"  {prompt}{suffix}: ").strip()
        if not value and default:
            return default
        if value:
            return value
        if not required:
            return ""
        print("    (required — please enter a value)")


def ask_choice(prompt: str, choices: list[str], default: str = "") -> str:
    """Prompt user to pick from a list."""
    choices_str = " / ".join(choices)
    suffix = f" [{default}]" if default else ""
    while True:
        value = input(f"  {prompt} ({choices_str}){suffix}: ").strip().lower()
        if not value and default:
            return default
        if value in choices:
            return value
        print(f"    (pick one of: {choices_str})")


def ask_list(prompt: str, required: bool = False) -> list[str]:
    """Prompt for comma-separated list."""
    raw = input(f"  {prompt}: ").strip()
    if not raw:
        return []
    return [x.strip() for x in raw.split(",") if x.strip()]


def print_header(text: str) -> None:
    print(f"\n{'=' * 60}")
    print(f"  {text}")
    print(f"{'=' * 60}\n")


def print_step(n: int, text: str) -> None:
    print(f"\n── Step {n}: {text} ──\n")


# ── Step 1: Collect info ─────────────────────────────────────────────────────

def collect_client_info() -> dict:
    """Interactive collection of client details."""
    print_step(1, "Collect client information")

    client_name = ask("Client name (e.g. 'Prestige Group')")
    waba_number = ask("WABA phone number (e.g. +919876543210)")
    waba_phone_number_id = ask("WABA Phone Number ID (from Meta Business Manager)")
    waba_token = ask("WABA Token (from Meta)")

    primary_language = ask_choice(
        "Primary language",
        ["english", "hindi", "hinglish"],
        default="hinglish",
    )
    formality_level = ask_choice(
        "Formality level",
        ["formal", "casual"],
        default="formal",
    )
    hindi_pronoun = "aap" if formality_level == "formal" else "tum"

    broker_numbers = ask_list(
        "Broker WhatsApp numbers (comma-separated, e.g. +919820099999,+919820011111)"
    )

    crm_type = ask_choice(
        "CRM type",
        ["selldo", "webhook", "none"],
        default="none",
    )
    crm_token = ""
    if crm_type != "none":
        crm_token = ask("CRM API token/URL", required=False)

    google_calendar_id = ask(
        "Google Calendar ID (or press Enter to skip)",
        required=False,
    )

    billing_model = ask_choice(
        "Billing model",
        ["direct", "per_visit", "per_lead"],
        default="direct",
    )

    return {
        "client_name": client_name,
        "waba_number": waba_number,
        "waba_phone_number_id": waba_phone_number_id,
        "waba_token": waba_token,
        "broker_wa_numbers": broker_numbers,
        "google_calendar_id": google_calendar_id or None,
        "crm_type": crm_type if crm_type != "none" else None,
        "crm_token": crm_token or None,
        "billing_model": billing_model,
        "language_config": {
            "primary_language": primary_language,
            "formality_level": formality_level,
            "hindi_pronoun": hindi_pronoun,
        },
    }


# ── Step 2: Create client via API ────────────────────────────────────────────

def create_client(base_url: str, admin_key: str, data: dict) -> dict:
    """POST /admin/clients — create the client."""
    print_step(2, "Create client via API")

    url = f"{base_url}/admin/clients"
    headers = {"x-admin-key": admin_key, "Content-Type": "application/json"}

    print(f"  POST {url}")
    print(f"  Payload: {json.dumps(data, indent=2, default=str)[:500]}")

    try:
        resp = httpx.post(url, json=data, headers=headers, timeout=30)
        resp.raise_for_status()
        result = resp.json()
        client_id = result.get("id", result.get("client_id", "unknown"))
        print(f"\n  CLIENT CREATED: {client_id}")
        print(f"  Name: {result.get('client_name', data['client_name'])}")
        return result
    except httpx.HTTPStatusError as e:
        print(f"\n  ERROR: {e.response.status_code} — {e.response.text}")
        sys.exit(1)
    except httpx.ConnectError:
        print(f"\n  ERROR: Cannot connect to {base_url}")
        print("  Is the server running? Try: make dev")
        sys.exit(1)


# ── Step 3: Upload brochures ─────────────────────────────────────────────────

def upload_brochures(base_url: str, admin_key: str, client_id: str) -> None:
    """Upload PDF brochures for RAG."""
    print_step(3, "Upload brochure PDFs")

    pdf_folder = ask(
        "Path to folder with PDF brochures (or press Enter to skip)",
        required=False,
    )

    if not pdf_folder:
        print("  Skipped brochure upload.")
        return

    folder = Path(pdf_folder)
    if not folder.exists() or not folder.is_dir():
        print(f"  WARNING: Folder '{pdf_folder}' not found. Skipping.")
        return

    pdfs = list(folder.glob("*.pdf"))
    if not pdfs:
        print(f"  No PDF files found in '{pdf_folder}'. Skipping.")
        return

    print(f"  Found {len(pdfs)} PDF(s):")
    for pdf in pdfs:
        print(f"    - {pdf.name} ({pdf.stat().st_size // 1024} KB)")

    url = f"{base_url}/admin/ingest"
    headers = {"x-admin-key": admin_key}

    for pdf in pdfs:
        project_name = pdf.stem.replace("_", " ").replace("-", " ").title()
        project_name = ask(f"Project name for '{pdf.name}'", default=project_name)

        print(f"  Uploading {pdf.name} as '{project_name}'...")

        try:
            with open(pdf, "rb") as f:
                files = {"file": (pdf.name, f, "application/pdf")}
                data = {"client_id": client_id, "project_name": project_name}
                resp = httpx.post(url, files=files, data=data, headers=headers, timeout=120)
                resp.raise_for_status()
                result = resp.json()
                chunks = result.get("chunks_created", "?")
                print(f"  Ingested: {chunks} chunks created")
        except httpx.HTTPStatusError as e:
            print(f"  ERROR uploading {pdf.name}: {e.response.status_code} — {e.response.text}")
        except Exception as e:
            print(f"  ERROR uploading {pdf.name}: {e}")


# ── Step 4: Verify ───────────────────────────────────────────────────────────

def verify_setup(base_url: str, admin_key: str, client_id: str) -> None:
    """Check that the client was created correctly."""
    print_step(4, "Verify setup")

    headers = {"x-admin-key": admin_key}

    # Check client exists
    try:
        resp = httpx.get(f"{base_url}/admin/clients/{client_id}", headers=headers, timeout=10)
        resp.raise_for_status()
        client = resp.json()
        print(f"  Client: {client.get('client_name', 'OK')}")
        print(f"  WABA:   {client.get('waba_phone_number_id', '?')}")
        print(f"  Active: {client.get('active', '?')}")
        brokers = client.get("broker_wa_numbers", [])
        print(f"  Brokers: {len(brokers)} configured")
        print(f"  Language: {client.get('language_config', {}).get('primary_language', '?')}")
        print(f"  Billing: {client.get('billing_model', '?')}")
    except Exception as e:
        print(f"  WARNING: Could not verify client: {e}")
        return

    # Check brochure chunks
    try:
        resp = httpx.get(
            f"{base_url}/admin/projects",
            params={"client_id": client_id},
            headers=headers,
            timeout=10,
        )
        if resp.status_code == 200:
            projects = resp.json()
            if isinstance(projects, list):
                print(f"  Projects: {len(projects)} ingested")
                for p in projects:
                    print(f"    - {p.get('project_name', '?')}: {p.get('chunk_count', '?')} chunks")
            else:
                print(f"  Projects: {projects}")
    except Exception:
        print("  (Could not check brochure projects — endpoint may not be available)")


# ── Step 5: Print manual checklist ───────────────────────────────────────────

def print_checklist(waba_number: str, base_url: str) -> None:
    """Print things that still need to be done manually."""
    print_step(5, "Manual checklist")

    print("  The following steps must be completed manually:\n")
    print("  [ ] Submit WhatsApp templates to Meta for approval:")
    print("      - hot_lead_notification  (utility template)")
    print("      - appointment_confirmation  (utility template)")
    print("      - daily_digest  (utility template)")
    print("      - stale_reengagement  (marketing template)")
    print("      - warm_lead_digest  (utility template)")
    print("")
    print("  [ ] Wait 24-48 hours for template approval")
    print("")
    domain = base_url.replace("http://", "").replace("https://", "")
    print(f"  [ ] Set WABA webhook URL in Meta Business Manager:")
    print(f"      https://{domain}/webhook/whatsapp")
    print("")
    print("  [ ] Subscribe to 'messages' webhook field in Meta dashboard")
    print("")
    print("  [ ] If Google Calendar configured:")
    print("      Share calendar with the service account email")
    print("")
    print("  [ ] If CRM configured:")
    print("      Verify API token and field mappings")
    print("")
    print(f"  [ ] Send a test message from any WhatsApp to {waba_number}")
    print("      to verify the full pipeline works")


# ── Main ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Onboard a new client to LeadEngine",
    )
    parser.add_argument(
        "--base-url",
        default=DEFAULT_BASE_URL,
        help=f"LeadEngine API base URL (default: {DEFAULT_BASE_URL})",
    )
    parser.add_argument(
        "--admin-key",
        default=DEFAULT_ADMIN_KEY,
        help="Admin API key (or set SECRET_KEY env var)",
    )
    parser.add_argument(
        "--non-interactive",
        action="store_true",
        help="Read from stdin JSON instead of interactive prompts",
    )
    args = parser.parse_args()

    print_header("LeadEngine — Client Onboarding")

    if args.non_interactive:
        # Non-interactive mode: read JSON from stdin
        print("  Reading client data from stdin (non-interactive mode)...\n")
        data = json.loads(sys.stdin.read())
    else:
        # Interactive mode
        data = collect_client_info()

    # Confirm before creating
    print(f"\n  Ready to create client '{data['client_name']}' at {args.base_url}")
    confirm = input("  Proceed? (y/N): ").strip().lower()
    if confirm not in ("y", "yes"):
        print("  Aborted.")
        sys.exit(0)

    # Create
    result = create_client(args.base_url, args.admin_key, data)
    client_id = str(result.get("id", result.get("client_id", "")))

    if not client_id or client_id == "unknown":
        print("  ERROR: Could not determine client ID from API response.")
        print(f"  Response: {json.dumps(result, indent=2)[:500]}")
        sys.exit(1)

    # Upload brochures
    if not args.non_interactive:
        upload_brochures(args.base_url, args.admin_key, client_id)

    # Verify
    verify_setup(args.base_url, args.admin_key, client_id)

    # Checklist
    print_checklist(data["waba_number"], args.base_url)

    print_header("Onboarding complete!")
    print(f"  Client ID: {client_id}")
    print(f"  Dashboard: {args.base_url}/dashboard/home?client_id={client_id}")
    print(f"  Test by messaging {data['waba_number']} from any WhatsApp\n")


if __name__ == "__main__":
    main()
