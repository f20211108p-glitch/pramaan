"""
Quick API test — proves every component works with real Claude.

What this tests (in order):
  Step 1: API key is valid — direct Claude Haiku call
  Step 2: Language detection — real classify() call
  Step 3: Lead extraction — real extract_structured() call (tool_use)
  Step 4: Response generation — real generate() call
  Step 5: Full pipeline routing with mocked graph → proves DB writes

NOTE: Step 5 mocks graph.invoke() — the graph loop issue is a separate
      LangGraph state design topic. Steps 1-4 prove real Claude works.
      Cost: ~$0.005 total

Run: .\.venv\Scripts\python.exe scripts/quicktest.py
"""
import asyncio
import sys
import uuid
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from sqlalchemy import select
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.pool import NullPool

from src.config import get_settings
from src.db.tables import ClientConfig, Lead, Message, ConsentLog, BillingEvent

settings = get_settings()

# ── Check API key ─────────────────────────────────────────────────────────────
if not settings.anthropic_api_key or "sk-ant-..." in settings.anthropic_api_key:
    print("❌ ANTHROPIC_API_KEY not set in .env")
    sys.exit(1)

print("=" * 65)
print("  LeadEngine — Quick API Test")
print("=" * 65)
print(f"\n✅ API Key: {settings.anthropic_api_key[:12]}...{settings.anthropic_api_key[-4:]}")

# ─────────────────────────────────────────────────────────────────────────────
# STEP 1: Direct API call
# ─────────────────────────────────────────────────────────────────────────────
print("\n[1/5] Direct Claude API call...")
import anthropic
from src.engine.llm import HAIKU_MODEL, SONNET_MODEL

raw_client = anthropic.Anthropic(api_key=settings.anthropic_api_key)
r = raw_client.messages.create(
    model=HAIKU_MODEL,
    max_tokens=10,
    messages=[{"role": "user", "content": "Say: ready"}],
)
print(f"  ✅ Haiku responded: '{r.content[0].text}'")
print(f"     tokens: {r.usage.input_tokens} in / {r.usage.output_tokens} out")

# ─────────────────────────────────────────────────────────────────────────────
# STEP 2: Language detection (classify)
# ─────────────────────────────────────────────────────────────────────────────
print("\n[2/5] Language detection (real classify call)...")
from src.engine.llm import classify, load_prompt

lang_prompt = load_prompt("language_detect.txt")
user_msg = "Hi, mujhe 2BHK chahiye Whitefield mein"
detected_lang = classify(
    system_prompt=lang_prompt,
    user_text=user_msg,
    valid_values=["english", "hindi", "hinglish", "regional"],
)
print(f"  ✅ Message:  '{user_msg}'")
print(f"     Language: '{detected_lang}'  ← Claude detected this")

# ─────────────────────────────────────────────────────────────────────────────
# STEP 3: Lead extraction (extract_structured with tool_use)
# ─────────────────────────────────────────────────────────────────────────────
print("\n[3/5] Lead extraction (real extract_structured / tool_use)...")
from src.engine.llm import extract_structured
from src.engine.nodes.qualifier import EXTRACTION_TOOL_SCHEMA

extract_prompt = load_prompt("qualifier_extract.txt")
extraction = extract_structured(
    system_prompt=extract_prompt,
    user_text=user_msg,
    tool_name="extract_lead_info",
    tool_schema=EXTRACTION_TOOL_SCHEMA,
)
confidence = extraction.pop("extracted_confidence", 0)
print(f"  ✅ Extracted fields (confidence={confidence:.2f}):")
for k, v in extraction.items():
    if v is not None:
        print(f"     {k}: {v}")

# ─────────────────────────────────────────────────────────────────────────────
# STEP 4: Response generation (generate)
# ─────────────────────────────────────────────────────────────────────────────
print("\n[4/5] Response generation (real Claude Sonnet)...")
from src.engine.llm import generate

qualifier_prompt = load_prompt("qualifier_hinglish.txt").format(
    client_name="Prestige Group Test",
    filled_fields_summary="- Location: Whitefield\n- Property type: apartment",
    awaiting_info="- budget\n- timeline\n- financing",
    rag_context="",
    formality_instruction="Use formal tone with 'aap' pronoun.",
    turn_count=1,
)
bot_reply = generate(
    system_prompt=qualifier_prompt,
    user_text=user_msg,
    max_tokens=100,
)
print(f"  ✅ Bot reply:")
print(f"     '{bot_reply}'")

# ─────────────────────────────────────────────────────────────────────────────
# STEP 5: Full pipeline (router + DB) with mocked graph
# ─────────────────────────────────────────────────────────────────────────────
print("\n[5/5] Full pipeline (routing + DB writes)...")

CLIENT_ID = uuid.UUID("aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee")
WABA_PHONE_ID = "TEST_PHONE_ID"
LEAD_PHONE = "+919999900000"

payload = {
    "object": "whatsapp_business_account",
    "entry": [{
        "id": "WABA_ID",
        "changes": [{
            "value": {
                "messaging_product": "whatsapp",
                "metadata": {
                    "display_phone_number": "+919820011111",
                    "phone_number_id": WABA_PHONE_ID,
                },
                "messages": [{
                    "from": LEAD_PHONE.lstrip("+"),
                    "id": f"wamid.quicktest_{uuid.uuid4().hex[:8]}",
                    "timestamp": "1716500000",
                    "text": {"body": user_msg},
                    "type": "text",
                }],
                "contacts": [{"profile": {"name": "Test Lead"}, "wa_id": LEAD_PHONE.lstrip("+")}],
            },
            "field": "messages",
        }],
    }],
}

# Simulated engine result — uses the REAL reply from step 4
def _mock_invoke(state, config):
    msgs = list(state.get("messages", []))
    msgs.append({"role": "assistant", "content": bot_reply})
    return {
        **state,
        "messages": msgs,
        "lead": {
            **state.get("lead", {}),
            "score": 20,
            "tier": "warm",
            "stage": "qualifying",
            "intent": "buyer",
            "language_pref": detected_lang,
            "location_preferences": extraction.get("locations") or [],
            "property_type": extraction.get("property_type") or "any",
        },
        "next_action": "nurture",
        "billing_event": None,
    }


async def run():
    engine = create_async_engine(settings.database_url, poolclass=NullPool)
    factory = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

    # Verify seed client exists
    async with factory() as db:
        r = await db.execute(select(ClientConfig).where(ClientConfig.id == CLIENT_ID))
        if not r.scalar_one_or_none():
            print("  ⚠  Test client not in DB. Run seed first:")
            print("     .venv\\Scripts\\python.exe scripts\\seed_client.py")
            await engine.dispose()
            return

    from unittest.mock import patch, AsyncMock, MagicMock

    with patch("src.channels.router.WhatsAppChannel.send_message", new_callable=AsyncMock), \
         patch("src.channels.router.WhatsAppChannel.mark_as_read", new_callable=AsyncMock), \
         patch("src.channels.router.is_duplicate", new_callable=AsyncMock, return_value=False), \
         patch("src.core.tenant._get_redis") as mock_redis_fn:

        mock_redis = AsyncMock()
        mock_redis.get = AsyncMock(return_value=None)
        mock_redis.setex = AsyncMock()
        mock_redis_fn.return_value = mock_redis

        from src.channels.router import MessageRouter
        router = MessageRouter()
        router._graph = MagicMock()
        router._graph.invoke = _mock_invoke  # Uses real Claude output from step 4

        async with factory() as db:
            result = await router.route_inbound(payload, db)

    lead_id = result.get("lead_id")
    print(f"  ✅ Pipeline completed. lead_id={lead_id[:8]}...")

    # Show DB state
    async with factory() as db:
        lead = (await db.execute(select(Lead).where(Lead.id == lead_id))).scalar_one()
        msgs = (await db.execute(select(Message).where(Message.client_id == CLIENT_ID))).scalars().all()
        consents = (await db.execute(select(ConsentLog).where(ConsentLog.client_id == CLIENT_ID))).scalars().all()

    print(f"\n  📋 Lead in DB:")
    print(f"     phone:         {lead.phone}")
    print(f"     language_pref: {lead.language_pref}  ← detected by Claude")
    print(f"     intent:        {lead.intent}")
    print(f"     stage:         {lead.stage}")
    print(f"     location_pref: {lead.location_preferences}  ← extracted by Claude")

    print(f"\n  💬 Messages saved: {len(msgs)}")
    for m in msgs[-2:]:  # show last 2
        icon = "👤" if m.direction == "inbound" else "🤖"
        print(f"     {icon} [{m.direction}] {m.content[:70]}")

    print(f"\n  ✅ Consent: {len(consents)} record (first_message)")

    await engine.dispose()

    print("\n" + "=" * 65)
    print("  All 5 steps passed!")
    print()
    print("  Real Claude calls made:")
    print(f"    classify()          → language='{detected_lang}'")
    print(f"    extract_structured() → {[k for k,v in extraction.items() if v]}")
    print(f"    generate()          → response ready")
    print()
    print("  Next: add API credits → run simulate_conversation.py")
    print("  for the full 4-turn demo with real graph.")
    print("=" * 65)


asyncio.run(run())
