﻿import asyncio, os
os.environ["DATABASE_URL"] = "postgresql+asyncpg://lead:leadpass@localhost:5432/leadengine"
from sqlalchemy.ext.asyncio import create_async_engine
from sqlalchemy import text

async def reset():
    engine = create_async_engine(os.environ["DATABASE_URL"])
    async with engine.begin() as conn:
        r = await conn.execute(text("""
            WITH deleted_messages AS (
                DELETE FROM messages WHERE conversation_id IN (
                    SELECT c.id FROM conversations c
                    JOIN leads l ON c.lead_id = l.id
                    WHERE l.phone = '918769448883'
                ) RETURNING 1
            ),
            deleted_convos AS (
                DELETE FROM conversations WHERE lead_id IN (
                    SELECT id FROM leads WHERE phone = '918769448883'
                ) RETURNING 1
            ),
            deleted_billing AS (
                DELETE FROM billing_events WHERE lead_id IN (
                    SELECT id FROM leads WHERE phone = '918769448883'
                ) RETURNING 1
            ),
            deleted_consent AS (
                DELETE FROM consent_log WHERE lead_id IN (
                    SELECT id FROM leads WHERE phone = '918769448883'
                ) RETURNING 1
            ),
            deleted_leads AS (
                DELETE FROM leads WHERE phone = '918769448883' RETURNING phone
            )
            SELECT 
                (SELECT COUNT(*) FROM deleted_messages) AS messages,
                (SELECT COUNT(*) FROM deleted_convos) AS convos,
                (SELECT COUNT(*) FROM deleted_billing) AS billing,
                (SELECT COUNT(*) FROM deleted_leads) AS leads
        """))
        row = r.fetchone()
        print(f"918769448883: DELETE leads={row[3]} convos={row[1]} messages={row[0]} billing={row[2]}")
    await engine.dispose()

asyncio.run(reset())
