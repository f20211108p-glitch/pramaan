"""Reset Siddharth (8769) and Niranjan (9924) for fresh test."""
import asyncio
import asyncpg

PHONES = ["918769448883", "919924866488"]


async def reset():
    conn = await asyncpg.connect("postgresql://lead:leadpass@localhost:5432/leadengine")
    for phone in PHONES:
        await conn.execute(
            "DELETE FROM messages WHERE conversation_id IN "
            "(SELECT c.id FROM conversations c JOIN leads l ON c.lead_id = l.id WHERE l.phone = $1)",
            phone,
        )
        await conn.execute(
            "DELETE FROM conversations WHERE lead_id IN (SELECT id FROM leads WHERE phone = $1)",
            phone,
        )
        for tbl in ("consent_log", "billing_events"):
            try:
                await conn.execute(
                    f"DELETE FROM {tbl} WHERE lead_id IN (SELECT id FROM leads WHERE phone = $1)",
                    phone,
                )
            except Exception:
                pass
        r = await conn.execute("DELETE FROM leads WHERE phone = $1", phone)
        print(f"{phone}: {r}")
    print("Both leads cleared — fresh start!")
    await conn.close()


asyncio.run(reset())
