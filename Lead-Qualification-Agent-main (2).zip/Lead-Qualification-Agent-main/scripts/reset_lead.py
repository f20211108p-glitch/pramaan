"""Reset lead data for phone 918769448883 — fresh test start."""
import asyncio
import asyncpg


async def reset():
    conn = await asyncpg.connect("postgresql://lead:leadpass@localhost:5432/leadengine")

    r1 = await conn.execute(
        "DELETE FROM messages WHERE conversation_id IN "
        "(SELECT c.id FROM conversations c JOIN leads l ON c.lead_id = l.id WHERE l.phone = '918769448883')"
    )
    r2 = await conn.execute(
        "DELETE FROM conversations WHERE lead_id IN "
        "(SELECT id FROM leads WHERE phone = '918769448883')"
    )
    # Clean all FK-dependent tables
    for tbl in ("consents", "consent_log", "billing_events"):
        try:
            r = await conn.execute(
                f"DELETE FROM {tbl} WHERE lead_id IN "
                "(SELECT id FROM leads WHERE phone = '918769448883')"
            )
            print(f"{tbl}: {r}")
        except Exception as e:
            print(f"{tbl}: skipped ({e})")
    r3 = r4 = "see above"
    r5 = await conn.execute("DELETE FROM leads WHERE phone = '918769448883'")

    print(f"Messages: {r1}")
    print(f"Conversations: {r2}")
    print(f"Consents: {r3}")
    print(f"Billing: {r4}")
    print(f"Leads: {r5}")
    print("Fresh start ready!")

    await conn.close()


asyncio.run(reset())
