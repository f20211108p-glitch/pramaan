"""
Seed a test ClientConfig + ingest sample brochure into the database.

What this does:
  1. Connects to your local PostgreSQL (from .env or default)
  2. Creates all tables if they don't exist
  3. Upserts a "Prestige Group Test" client_config row
  4. If scripts/sample_brochure.pdf exists → ingests it via RAG pipeline
     (fastembed runs locally — no API key needed, no cost)
  5. Prints everything it created so you can verify

Run with: make seed
         or: python scripts/seed_client.py
"""
import asyncio
import sys
import uuid
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.pool import NullPool

# Add project root to path so imports work when running as script
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.db.engine import Base
from src.db.tables import ClientConfig, BrochureChunk
from src.config import get_settings

settings = get_settings()

# ── Seed data ────────────────────────────────────────────────────────────────

# Fixed UUIDs so re-running doesn't create duplicates
SEED_CLIENT_ID = uuid.UUID("aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee")
SEED_PROJECT_ID = uuid.UUID("11111111-2222-3333-4444-555555555555")

SEED_CLIENT = {
    "id": SEED_CLIENT_ID,
    "client_name": "Prestige Group Test",
    "waba_number": "+919820011111",
    "waba_phone_number_id": "TEST_PHONE_ID",
    "waba_token": "TEST_TOKEN",
    "project_ids": [SEED_PROJECT_ID],
    "prompt_overrides": {},
    "language_config": {
        "primary_language": "hinglish",
        "regional_languages": ["hindi", "english"],
        "formality_level": "formal",
        "hindi_pronoun": "aap",
    },
    "broker_wa_numbers": ["+919820099999"],
    "google_calendar_id": None,
    "active": True,
}

BROCHURE_PDF = Path(__file__).parent / "sample_brochure.pdf"


async def seed():
    print("=" * 60)
    print("  LeadEngine — Seed Script")
    print("=" * 60)
    print(f"\n📌 DB: {settings.database_url}")

    engine = create_async_engine(settings.database_url, poolclass=NullPool)

    # ── Step 1: Create all tables ────────────────────────────────────────
    print("\n[1/4] Creating tables (if they don't exist)...")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    print("  ✓ Tables ready")

    factory = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

    async with factory() as db:
        # ── Step 2: Upsert client ────────────────────────────────────────
        print("\n[2/4] Seeding client_config...")
        result = await db.execute(
            select(ClientConfig).where(ClientConfig.id == SEED_CLIENT_ID)
        )
        existing = result.scalar_one_or_none()

        if existing:
            print(f"  ⏭  Client already exists: {existing.client_name} (id={existing.id})")
            client = existing
        else:
            client = ClientConfig(**SEED_CLIENT)
            db.add(client)
            await db.commit()
            await db.refresh(client)
            print(f"  ✓ Created client: {client.client_name}")

        # Print client details
        print(f"\n  Client Details:")
        print(f"    id:                  {client.id}")
        print(f"    client_name:         {client.client_name}")
        print(f"    waba_number:         {client.waba_number}")
        print(f"    waba_phone_number_id:{client.waba_phone_number_id}")
        print(f"    waba_token:          {client.waba_token}")
        print(f"    language_config:     {client.language_config}")
        print(f"    broker_wa_numbers:   {client.broker_wa_numbers}")
        print(f"    active:              {client.active}")

        # ── Step 3: Ingest sample brochure ───────────────────────────────
        print(f"\n[3/4] Brochure ingestion...")
        if BROCHURE_PDF.exists():
            # Check if already ingested
            chunk_result = await db.execute(
                select(BrochureChunk).where(
                    BrochureChunk.client_id == SEED_CLIENT_ID,
                    BrochureChunk.project_id == SEED_PROJECT_ID,
                ).limit(1)
            )
            if chunk_result.scalar_one_or_none():
                # Count existing
                from sqlalchemy import func
                count_result = await db.execute(
                    select(func.count(BrochureChunk.id)).where(
                        BrochureChunk.client_id == SEED_CLIENT_ID,
                        BrochureChunk.project_id == SEED_PROJECT_ID,
                    )
                )
                count = count_result.scalar()
                print(f"  ⏭  Brochure already ingested ({count} chunks). Skipping.")
            else:
                print(f"  Ingesting {BROCHURE_PDF.name}...")
                from src.rag.ingest import ingest_brochure
                ingest_result = await ingest_brochure(
                    db=db,
                    pdf_path=str(BROCHURE_PDF),
                    client_id=str(SEED_CLIENT_ID),
                    project_id=str(SEED_PROJECT_ID),
                    project_name="Paradise Heights",
                )
                print(f"  ✓ Ingested: {ingest_result['pages_extracted']} pages → {ingest_result['chunks_ingested']} chunks")
        else:
            print(f"  ⚠  No brochure found at {BROCHURE_PDF}")
            print(f"     Run: python scripts/create_sample_pdf.py")

        # ── Step 4: Summary ──────────────────────────────────────────────
        print(f"\n[4/4] Summary")
        print(f"  Client ID: {SEED_CLIENT_ID}")
        print(f"  Project ID: {SEED_PROJECT_ID}")
        print(f"  WABA Phone Number ID: {client.waba_phone_number_id}")
        print(f"\n  Next steps:")
        print(f"    make simulate   → run a 4-turn Hinglish conversation")
        print(f"    make test-e2e   → run the integration test")

    await engine.dispose()
    print("\n" + "=" * 60)
    print("  Seed complete!")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(seed())
