"""Send a test message to 8769 via the WABA API."""
import asyncio
import asyncpg
import sys
sys.path.insert(0, "C:/Users/Hp/Desktop/Pramaan/leadengine")


async def send():
    conn = await asyncpg.connect("postgresql://lead:leadpass@localhost:5432/leadengine")
    row = await conn.fetchrow(
        "SELECT waba_phone_number_id, waba_token FROM client_config WHERE client_name = $1",
        "Pramaan Test",
    )
    await conn.close()

    from src.channels.whatsapp import WhatsAppChannel
    ok = await WhatsAppChannel.send_message(
        waba_phone_number_id=row["waba_phone_number_id"],
        waba_token=row["waba_token"],
        to="918769448883",
        content="Test message from LeadEngine — system is live!",
    )
    print("Sent:", ok)


asyncio.run(send())
