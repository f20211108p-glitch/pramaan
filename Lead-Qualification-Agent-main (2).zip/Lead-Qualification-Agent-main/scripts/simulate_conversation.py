"""
Simulate a full 4-turn Hinglish qualification conversation WITHOUT WhatsApp.

This is the Week 1 demo. It proves the entire pipeline works end-to-end:
  webhook payload → parse → dedup → tenant → lead → consent → conversation
  → save inbound → RAG search → LangGraph engine → persist → send reply

What happens:
  Turn 1: Lead says "Hi, mujhe 2BHK chahiye Whitefield mein"
    → language_detector → "hinglish"
    → greeter → welcome message
    → intent_detector → "buyer"
    → qualifier → extracts {locations: ["Whitefield"], property_type: "apartment"}
    → asks about budget

  Turn 2: "Budget 80 lakh ke aaspaas"
    → qualifier → extracts {budget_min: 7000000, budget_max: 9000000}
    → asks about timeline

  Turn 3: "2 mahine mein shift karna hai"
    → qualifier → extracts {timeline_months: 2, urgency: "1_3_months"}
    → asks about financing

  Turn 4: "SBI se pre-approval hai"
    → qualifier → extracts {financing_status: "loan_approved"}
    → scorer → score=90 (hot) → billing_event
    → scheduler (stub) → stage="scheduling"

Requires:
  - PostgreSQL running (docker-compose up -d postgres)
  - ANTHROPIC_API_KEY in .env
  - make seed (to create the test client)

Run: make simulate
     or: python scripts/simulate_conversation.py
"""
import asyncio
import sys
import uuid
from pathlib import Path

from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.pool import NullPool

# Add project root to path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.config import get_settings
from src.db.tables import Lead, Message, BillingEvent, ConsentLog, Conversation
from src.channels.router import MessageRouter

settings = get_settings()

# Must match seed_client.py
SEED_CLIENT_ID = uuid.UUID("aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee")
TEST_WABA_PHONE_ID = "TEST_PHONE_ID"
TEST_LEAD_PHONE = "+919999900000"

# 4-turn Hinglish conversation
CONVERSATION = [
    "Hi, mujhe 2BHK chahiye Whitefield mein",
    "Budget 80 lakh ke aaspaas",
    "2 mahine mein shift karna hai",
    "SBI se pre-approval hai",
]


def _make_webhook_payload(text: str, turn: int) -> dict:
    """
    Build a realistic WhatsApp Cloud API webhook payload.

    This is exactly what Meta sends to our webhook endpoint.
    In production, this comes from POST /webhooks/whatsapp.
    In simulation, we build it manually.
    """
    return {
        "object": "whatsapp_business_account",
        "entry": [{
            "id": "WHATSAPP_BUSINESS_ACCOUNT_ID",
            "changes": [{
                "value": {
                    "messaging_product": "whatsapp",
                    "metadata": {
                        "display_phone_number": "+919820011111",
                        "phone_number_id": TEST_WABA_PHONE_ID,
                    },
                    "messages": [{
                        "from": TEST_LEAD_PHONE.lstrip("+"),
                        "id": f"wamid.simulate_turn_{turn}_{uuid.uuid4().hex[:8]}",
                        "timestamp": "1716500000",
                        "text": {"body": text},
                        "type": "text",
                    }],
                    "contacts": [{
                        "profile": {"name": "Test Lead"},
                        "wa_id": TEST_LEAD_PHONE.lstrip("+"),
                    }],
                },
                "field": "messages",
            }],
        }],
    }


async def simulate():
    print("=" * 70)
    print("  LeadEngine — Conversation Simulator")
    print("  4-turn Hinglish qualification → scoring → billing")
    print("=" * 70)

    # Check API key
    if not settings.anthropic_api_key:
        print("\n❌ ANTHROPIC_API_KEY not set in .env")
        print("   This script calls real Claude API for language detection,")
        print("   extraction, and response generation.")
        print("   Get your key from: https://console.anthropic.com")
        sys.exit(1)

    engine = create_async_engine(settings.database_url, poolclass=NullPool)
    factory = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

    # Initialize the router (compiles the LangGraph graph)
    router = MessageRouter()

    print(f"\n📌 DB: {settings.database_url}")
    print(f"🔑 API Key: {settings.anthropic_api_key[:8]}...{settings.anthropic_api_key[-4:]}")
    print(f"📱 Lead phone: {TEST_LEAD_PHONE}")
    print()

    # ── Run each turn ────────────────────────────────────────────────────
    for i, msg in enumerate(CONVERSATION, 1):
        print(f"┌─ Turn {i}/4 {'─' * 50}")
        print(f"│ 👤 Lead: {msg}")

        # Build webhook payload (simulates what Meta sends)
        payload = _make_webhook_payload(msg, i)

        # Route through the full pipeline
        # This is the SAME code path that runs in production
        async with factory() as db:
            result = await router.route_inbound(payload, db)

        reply = result.get("response", "")
        print(f"│ 🤖 Bot:  {reply}")
        print(f"│ 📊 Result: lead_id={result.get('lead_id', '?')[:8]}... "
              f"conv_id={result.get('conversation_id', '?')[:8]}...")
        print(f"└{'─' * 60}\n")

    # ── Final state inspection ───────────────────────────────────────────
    print("=" * 70)
    print("  FINAL STATE — What's in the database")
    print("=" * 70)

    async with factory() as db:
        # Get lead
        lead_result = await db.execute(
            select(Lead).where(
                Lead.client_id == SEED_CLIENT_ID,
                Lead.phone == TEST_LEAD_PHONE,
            )
        )
        lead = lead_result.scalar_one_or_none()

        if lead:
            print(f"\n📋 Lead Profile:")
            print(f"  id:                  {lead.id}")
            print(f"  phone:               {lead.phone}")
            print(f"  language_pref:       {lead.language_pref}")
            print(f"  intent:              {lead.intent}")
            print(f"  stage:               {lead.stage}")
            print(f"  budget_min:          {lead.budget_min} ({_format_inr(lead.budget_min)})")
            print(f"  budget_max:          {lead.budget_max} ({_format_inr(lead.budget_max)})")
            print(f"  timeline_months:     {lead.timeline_months}")
            print(f"  urgency:             {lead.urgency}")
            print(f"  financing_status:    {lead.financing_status}")
            print(f"  location_preferences:{lead.location_preferences}")
            print(f"  property_type:       {lead.property_type}")
            print(f"  family_size:         {lead.family_size}")
            print(f"  score:               {lead.score}")
            print(f"  tier:                {lead.tier}")

            # Score validation
            if lead.score and lead.score >= 70:
                print(f"\n  🔥 HOT LEAD! Score {lead.score}/100 — ready for site visit")
            elif lead.score and lead.score >= 40:
                print(f"\n  🌤  Warm lead. Score {lead.score}/100 — needs nurturing")
            else:
                print(f"\n  ❄  Cold lead. Score {lead.score or 0}/100 — needs follow-up")
        else:
            print("\n  ⚠  No lead found in DB")

        # Messages
        msg_count = await db.execute(
            select(func.count(Message.id)).where(
                Message.client_id == SEED_CLIENT_ID,
            )
        )
        total_msgs = msg_count.scalar()
        print(f"\n💬 Messages: {total_msgs} total (inbound + outbound)")

        # Billing events
        billing_result = await db.execute(
            select(BillingEvent).where(
                BillingEvent.client_id == SEED_CLIENT_ID,
            )
        )
        events = billing_result.scalars().all()
        print(f"\n💰 Billing Events: {len(events)}")
        for ev in events:
            print(f"  - {ev.event_type} | lead={str(ev.lead_id)[:8]}... | {ev.extra_data}")

        # Consent
        consent_result = await db.execute(
            select(ConsentLog).where(
                ConsentLog.client_id == SEED_CLIENT_ID,
            )
        )
        consents = consent_result.scalars().all()
        print(f"\n✅ Consent Records: {len(consents)}")
        for c in consents:
            print(f"  - {c.consent_type} | source={c.source} | {c.granted_at}")

        # Conversation
        conv_result = await db.execute(
            select(Conversation).where(
                Conversation.client_id == SEED_CLIENT_ID,
            )
        )
        convs = conv_result.scalars().all()
        print(f"\n🗣  Conversations: {len(convs)}")
        for conv in convs:
            print(f"  - status={conv.status} | started={conv.started_at}")

    await engine.dispose()

    print("\n" + "=" * 70)
    print("  Simulation complete!")
    print("=" * 70)


def _format_inr(amount: int | None) -> str:
    """Format INR amount in lakhs/crores for readability."""
    if not amount:
        return "not set"
    if amount >= 10_000_000:
        return f"₹{amount / 10_000_000:.1f} Cr"
    if amount >= 100_000:
        return f"₹{amount / 100_000:.0f} L"
    return f"₹{amount:,}"


if __name__ == "__main__":
    asyncio.run(simulate())
