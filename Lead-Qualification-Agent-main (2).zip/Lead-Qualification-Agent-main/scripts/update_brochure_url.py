"""Update client_config with Supabase brochure URL."""
import asyncio
import json
import asyncpg


async def update():
    conn = await asyncpg.connect("postgresql://lead:leadpass@localhost:5432/leadengine")
    row = await conn.fetchrow("SELECT id, prompt_overrides FROM client_config LIMIT 1")
    if not row:
        print("No client_config found!")
        return
    raw = row["prompt_overrides"]
    if isinstance(raw, str):
        overrides = json.loads(raw) if raw else {}
    else:
        overrides = raw or {}
    overrides["brochure_url"] = (
        "https://zitynxbvmpsvnmegoiek.supabase.co/storage/v1/object/public/"
        "brochures/shreeji-greens/Shreeji_Greens_Vadodara_Brochure.pdf"
    )
    overrides["brochure_filename"] = "Shreeji_Greens_Brochure.pdf"
    overrides["site_address"] = (
        "Ground Floor, Shreeji Greens Site Office, Gotri Road, Vadodara 390021"
    )
    await conn.execute(
        "UPDATE client_config SET prompt_overrides = $1::jsonb WHERE id = $2",
        json.dumps(overrides), row["id"],
    )
    print(f"Updated client {row['id']}")
    print(f"prompt_overrides: {json.dumps(overrides, indent=2)}")
    await conn.close()


asyncio.run(update())
