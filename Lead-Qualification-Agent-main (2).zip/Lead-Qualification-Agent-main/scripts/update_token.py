﻿import asyncio, os, sys
os.environ["DATABASE_URL"] = "postgresql+asyncpg://lead:leadpass@localhost:5432/leadengine"
from sqlalchemy.ext.asyncio import create_async_engine
from sqlalchemy import text

NEW_TOKEN = sys.argv[1]

async def update():
    engine = create_async_engine(os.environ["DATABASE_URL"])
    async with engine.begin() as conn:
        result = await conn.execute(
            text("UPDATE client_config SET waba_token = :token, updated_at = NOW() WHERE waba_number = '919016188202' RETURNING id, client_name"),
            {"token": NEW_TOKEN}
        )
        row = result.fetchone()
        if row:
            print(f"Updated: {row[1]} ({row[0]})")
        else:
            print("No client matched")
    await engine.dispose()

asyncio.run(update())
