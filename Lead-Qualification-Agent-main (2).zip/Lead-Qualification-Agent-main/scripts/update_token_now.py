"""Update WABA token for all clients."""
import asyncio
import asyncpg

TOKEN = "EAASZAFTDOua4BRmAZBW62CYAAZAZCLqiHjRRZByOkF6hWRZCYjl8OODQO2lJKdLOtm06Q6lepCw8FpzG5zYuFDCBYBd0JjHa2urOhFP4v143Fa1MoIzSucbK0ox7AamniUX38ZBFCTYxwYdF6yk1Arhv7G1ZAnsVLYP9QUamHv5On4yJczKlhSkq80KdCXOaBZCw7e98tCzZBRb80dZB7n5ZCEZCRcdE5JPtUSPQeK6BTSxPn40L4LQ8rf4LNcnhMQA6ZB9WZAvgYiLAlV0TJkhRUZCb0NsENWWZBZBQLWrhzZBIP6ikG8ZD"


async def update():
    conn = await asyncpg.connect("postgresql://lead:leadpass@localhost:5432/leadengine")
    r = await conn.execute("UPDATE client_config SET waba_token = $1", TOKEN)
    print(f"Token updated: {r}")
    # Verify
    rows = await conn.fetch("SELECT client_name, substring(waba_token, 1, 20) as token_start FROM client_config")
    for row in rows:
        print(f"  {row['client_name']}: {row['token_start']}...")
    await conn.close()


asyncio.run(update())
