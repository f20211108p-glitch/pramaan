"""
Admin API — full REST endpoints for the broker dashboard.

Endpoints:
  Clients:       POST/GET/GET/{id}/PATCH/{id}
  Leads:         GET (list+filter) / GET/{id} / PATCH/{id}
  Conversations: GET (by lead) / GET/{id}/messages
  Billing:       GET (list)
  Stats:         GET (pipeline overview)
  Brochures:     POST /ingest / DELETE /chunks / GET /projects

All endpoints are protected by x-admin-key header.
All queries filter by client_id — multi-tenant boundary enforced.
"""
import os
import uuid
import logging
import tempfile
from datetime import datetime
from typing import Any

from fastapi import (
    APIRouter, UploadFile, File, Form, Header,
    Depends, HTTPException, BackgroundTasks, Query, Request,
)
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy.ext.asyncio import AsyncSession

from src.config import get_settings
from src.core.crypto import encrypt_token
from src.db.engine import get_db
from src.api.auth import get_current_user
from src.db.tables import User
from src.db.queries import (
    # Existing
    update_lead,
    # New — Chunk 7A
    list_clients, get_client, create_client, update_client,
    list_leads, get_lead,
    list_conversations, get_conversation_messages,
    list_billing_events,
    get_pipeline_stats,
)
from src.crm.sync import check_crm_health
from src.crm.registry import list_adapters
from src.rag.ingest import ingest_brochure, delete_project_chunks, list_projects
from src.rag.qa_ingest import ingest_qa_pairs, list_qa_pairs, delete_project_qa

logger = logging.getLogger(__name__)

# ── Rate limiting (Redis-backed, works across multiple workers) ─────────────
import time

from src.core.redis import get_redis

_RATE_LIMIT_WINDOW = 60  # seconds
_RATE_LIMIT_MAX = 60     # requests per window


async def _rate_limit(request: Request):
    """Redis sorted-set sliding-window rate limiter per IP. Multi-process safe."""
    client_ip = request.client.host if request.client else "unknown"
    now = time.time()
    window_start = now - _RATE_LIMIT_WINDOW
    key = f"rate:admin:{client_ip}"

    try:
        redis = get_redis()
        pipe = redis.pipeline()
        pipe.zremrangebyscore(key, 0, window_start)
        pipe.zcard(key)
        pipe.zadd(key, {f"{now}": now})
        pipe.expire(key, _RATE_LIMIT_WINDOW + 10)
        results = await pipe.execute()

        current_count = results[1]
        if current_count >= _RATE_LIMIT_MAX:
            raise HTTPException(
                status_code=429,
                detail=f"Rate limit exceeded. Max {_RATE_LIMIT_MAX} requests per {_RATE_LIMIT_WINDOW}s.",
            )
    except HTTPException:
        raise
    except Exception as e:
        # If Redis is down, allow the request (fail-open) but log
        logger.warning("[rate_limit] Redis error, failing open: %s", e)


router = APIRouter(prefix="/admin", tags=["admin"], dependencies=[Depends(_rate_limit)])


# ── Auth & multi-tenant authorization ────────────────────────────────────────

def _check_tenant(user: User, client_id: str) -> None:
    """
    Multi-tenant boundary: admins access any client; client-role users may
    only access their own client_id. Raises 403 otherwise.
    """
    if user.role == "admin":
        return
    if user.client_id and str(user.client_id) == str(client_id):
        return
    raise HTTPException(status_code=403, detail="Access denied for this client")


async def _admin_only(user: User = Depends(get_current_user)) -> User:
    """Dependency: authenticated user with admin role."""
    if user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    return user


async def _tenant_access(
    client_id: str,
    user: User = Depends(get_current_user),
) -> User:
    """
    Dependency: authenticated user with access to the client_id in the
    request path/query. Admins pass for any client; client users only
    for their own tenant.
    """
    _check_tenant(user, client_id)
    return user


# Kept for backward compatibility with modules importing the old name.
# Now performs FULL auth (DB-backed user, active check) instead of merely
# decoding the JWT. Tenant/role checks happen per-endpoint.
_verify_admin_key = get_current_user


# ── Response models ──────────────────────────────────────────────────────────

class ClientOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    client_name: str
    waba_number: str
    waba_phone_number_id: str
    broker_wa_numbers: list[str] | None = None
    google_calendar_id: str | None = None
    crm_type: str | None = None
    language_config: dict | None = None
    prompt_overrides: dict | None = None
    billing_model: str = "direct"  # "direct" | "per_visit" | "per_lead"
    scoring_config: dict | None = None
    active: bool
    created_at: datetime
    updated_at: datetime


class ClientCreate(BaseModel):
    client_name: str
    waba_number: str
    waba_phone_number_id: str
    waba_token: str
    broker_wa_numbers: list[str] = Field(default_factory=list)
    google_calendar_id: str | None = None
    crm_type: str | None = None
    crm_token: str | None = None
    language_config: dict | None = None
    prompt_overrides: dict | None = None
    billing_model: str = "direct"  # "direct" | "per_visit" | "per_lead"
    scoring_config: dict | None = None


class ClientUpdate(BaseModel):
    client_name: str | None = None
    waba_token: str | None = None
    waba_phone_number_id: str | None = None
    waba_number: str | None = None
    broker_wa_numbers: list[str] | None = None
    google_calendar_id: str | None = None
    crm_type: str | None = None
    crm_token: str | None = None
    language_config: dict | None = None
    prompt_overrides: dict | None = None
    billing_model: str | None = None  # "direct" | "per_visit" | "per_lead"
    scoring_config: dict | None = None
    active: bool | None = None


class LeadOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    client_id: str
    phone: str
    name: str | None = None
    email: str | None = None
    language_pref: str
    intent: str
    budget_min: int | None = None
    budget_max: int | None = None
    timeline_months: int | None = None
    urgency: str
    financing_status: str
    location_preferences: list | None = None
    property_type: str
    family_size: int | None = None
    score: int | None = None
    tier: str | None = None
    stage: str
    source_channel: str
    created_at: datetime
    updated_at: datetime


class LeadUpdate(BaseModel):
    name: str | None = None
    stage: str | None = None
    tier: str | None = None
    score: int | None = None
    assigned_agent_id: str | None = None


class ConversationOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    client_id: str
    lead_id: str
    channel: str
    status: str
    summary: str | None = None
    started_at: datetime
    last_message_at: datetime


class MessageOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    conversation_id: str
    direction: str
    content: str
    message_type: str
    channel_message_id: str | None = None
    timestamp: datetime


class BillingEventOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    client_id: str
    lead_id: str | None = None
    event_type: str
    amount_inr: int | None = None
    metadata: dict | None = None
    created_at: datetime


# Secrets that must never appear in API responses
_REDACTED_FIELDS = frozenset({"waba_token", "crm_token", "password_hash"})


def _to_str_id(obj: Any) -> dict:
    """
    Convert an ORM object to a JSON-safe dict.
    Uses Python attribute names (not DB column names) to avoid alias issues.
    Sensitive credential fields are always omitted.
    """
    d = {}
    # Use the mapper's column attributes (Python-side names)
    from sqlalchemy import inspect as sa_inspect
    mapper = sa_inspect(type(obj))
    for attr in mapper.column_attrs:
        key = attr.key  # Python attribute name (e.g. 'extra_data')
        if key in _REDACTED_FIELDS:
            continue
        val = getattr(obj, key)
        if isinstance(val, uuid.UUID):
            d[key] = str(val)
        elif isinstance(val, datetime):
            d[key] = val.isoformat()
        else:
            d[key] = val
    return d


# ═══════════════════════════════════════════════════════════════════════════════
# CLIENT ENDPOINTS
# ═══════════════════════════════════════════════════════════════════════════════

@router.post("/clients", status_code=201)
async def create_client_endpoint(
    body: ClientCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(_admin_only),
):
    """Create a new client (tenant)."""
    data = body.model_dump(exclude_none=True)
    # Encrypt sensitive tokens before storage
    if "waba_token" in data:
        data["waba_token"] = encrypt_token(data["waba_token"])
    if "crm_token" in data:
        data["crm_token"] = encrypt_token(data["crm_token"])
    client = await create_client(db, data)
    return _to_str_id(client)


@router.get("/clients")
async def list_clients_endpoint(
    active_only: bool = Query(True),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """List clients. Admins see all; client users see only their own."""
    clients = await list_clients(db, active_only=active_only)
    if user.role != "admin":
        clients = [c for c in clients if str(c.id) == str(user.client_id)]
    return {"clients": [_to_str_id(c) for c in clients]}


@router.get("/clients/{client_id}")
async def get_client_endpoint(
    client_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(_tenant_access),
):
    """Get a single client by ID."""
    client = await get_client(db, client_id)
    if not client:
        raise HTTPException(status_code=404, detail="Client not found")
    return _to_str_id(client)


@router.patch("/clients/{client_id}")
async def update_client_endpoint(
    client_id: str,
    body: ClientUpdate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(_admin_only),
):
    """Update a client's configuration."""
    # Check client exists
    existing = await get_client(db, client_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Client not found")

    fields = body.model_dump(exclude_none=True)
    if not fields:
        raise HTTPException(status_code=400, detail="No fields to update")

    # Encrypt sensitive tokens before storage
    if "waba_token" in fields:
        fields["waba_token"] = encrypt_token(fields["waba_token"])
    if "crm_token" in fields:
        fields["crm_token"] = encrypt_token(fields["crm_token"])

    client = await update_client(db, client_id, fields)
    return _to_str_id(client)


# ═══════════════════════════════════════════════════════════════════════════════
# LEAD ENDPOINTS
# ═══════════════════════════════════════════════════════════════════════════════

@router.get("/clients/{client_id}/leads")
async def list_leads_endpoint(
    client_id: str,
    tier: str | None = Query(None, description="Filter by tier: hot/warm/cold"),
    stage: str | None = Query(None, description="Filter by stage"),
    search: str | None = Query(None, description="Search by phone or name"),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(_tenant_access),
):
    """List leads for a client with optional filters and pagination."""
    leads, total = await list_leads(
        db, client_id,
        tier=tier, stage=stage, search=search,
        limit=limit, offset=offset,
    )
    return {
        "leads": [_to_str_id(l) for l in leads],
        "total": total,
        "limit": limit,
        "offset": offset,
    }


@router.get("/clients/{client_id}/leads/{lead_id}")
async def get_lead_endpoint(
    client_id: str,
    lead_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(_tenant_access),
):
    """Get a single lead with full details."""
    lead = await get_lead(db, client_id, lead_id)
    if not lead:
        raise HTTPException(status_code=404, detail="Lead not found")
    return _to_str_id(lead)


@router.patch("/clients/{client_id}/leads/{lead_id}")
async def update_lead_endpoint(
    client_id: str,
    lead_id: str,
    body: LeadUpdate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(_tenant_access),
):
    """
    Manually update a lead (broker override).
    Useful for: changing stage, assigning agent, manual score adjustment.
    """
    existing = await get_lead(db, client_id, lead_id)
    if not existing:
        raise HTTPException(status_code=404, detail="Lead not found")

    fields = body.model_dump(exclude_none=True)
    if not fields:
        raise HTTPException(status_code=400, detail="No fields to update")

    lead = await update_lead(db, client_id, lead_id, fields)
    return _to_str_id(lead)


# ═══════════════════════════════════════════════════════════════════════════════
# CONVERSATION + MESSAGE ENDPOINTS
# ═══════════════════════════════════════════════════════════════════════════════

@router.get("/clients/{client_id}/leads/{lead_id}/conversations")
async def list_conversations_endpoint(
    client_id: str,
    lead_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(_tenant_access),
):
    """List all conversations for a lead."""
    conversations = await list_conversations(db, client_id, lead_id)
    return {"conversations": [_to_str_id(c) for c in conversations]}


@router.get("/clients/{client_id}/conversations/{conversation_id}/messages")
async def get_messages_endpoint(
    client_id: str,
    conversation_id: str,
    limit: int = Query(100, ge=1, le=500),
    offset: int = Query(0, ge=0),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(_tenant_access),
):
    """Get messages for a conversation (chronological order)."""
    messages = await get_conversation_messages(
        db, client_id, conversation_id,
        limit=limit, offset=offset,
    )
    return {
        "messages": [_to_str_id(m) for m in messages],
        "limit": limit,
        "offset": offset,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# BILLING ENDPOINTS
# ═══════════════════════════════════════════════════════════════════════════════

@router.get("/clients/{client_id}/billing")
async def list_billing_endpoint(
    client_id: str,
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(_tenant_access),
):
    """List billing events for a client."""
    events, total = await list_billing_events(
        db, client_id, limit=limit, offset=offset,
    )
    return {
        "events": [_to_str_id(e) for e in events],
        "total": total,
        "limit": limit,
        "offset": offset,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# STATS ENDPOINT
# ═══════════════════════════════════════════════════════════════════════════════

@router.get("/clients/{client_id}/stats")
async def get_stats_endpoint(
    client_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(_tenant_access),
):
    """
    Pipeline overview stats for a client.
    Returns lead counts by tier + stage, conversation/message totals, billing count.
    """
    stats = await get_pipeline_stats(db, client_id)
    return {"client_id": client_id, **stats}


# ═══════════════════════════════════════════════════════════════════════════════
# CRM ENDPOINTS — Chunk 7B
# ═══════════════════════════════════════════════════════════════════════════════

@router.get("/crm/adapters")
async def list_crm_adapters(
    user: User = Depends(get_current_user),
):
    """List all available CRM adapter types."""
    return {"adapters": list_adapters()}


@router.get("/clients/{client_id}/crm/health")
async def crm_health_check(
    client_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(_tenant_access),
):
    """
    Check if the client's CRM connection is healthy.
    Returns connection status + CRM type.
    """
    client = await get_client(db, client_id)
    if not client:
        raise HTTPException(status_code=404, detail="Client not found")

    if not client.crm_type or not client.crm_token:
        return {
            "client_id": client_id,
            "crm_configured": False,
            "crm_type": client.crm_type,
            "status": "not_configured",
        }

    result = await check_crm_health(client)
    return {
        "client_id": client_id,
        "crm_configured": True,
        "crm_type": client.crm_type,
        "status": result.status.value if result else "unknown",
        "message": result.message if result else "",
    }


# ═══════════════════════════════════════════════════════════════════════════════
# RATE LIMIT + QUEUE MONITORING — Chunk 10A
# ═══════════════════════════════════════════════════════════════════════════════

@router.get("/clients/{client_id}/leads/{lead_phone}/rate-limit")
async def get_lead_rate_limit(
    client_id: str,
    lead_phone: str,
    user: User = Depends(_tenant_access),
):
    """Check rate limit status for a specific lead."""
    from src.core.rate_limit import get_rate_limit_info
    info = await get_rate_limit_info(client_id, lead_phone)
    return {"client_id": client_id, "lead_phone": lead_phone, **info}


@router.get("/queue/stats")
async def get_queue_stats(
    user: User = Depends(_admin_only),
):
    """Get message queue statistics."""
    from src.core.message_queue import get_pending_count, get_stream_length
    pending = await get_pending_count()
    stream_len = await get_stream_length()
    settings = get_settings()
    return {
        "webhook_mode": settings.webhook_mode,
        "stream_length": stream_len,
        "pending_messages": pending,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# BROCHURE INGESTION ENDPOINTS (existing — from earlier chunks)
# ═══════════════════════════════════════════════════════════════════════════════

@router.post("/ingest", status_code=202)
async def ingest_pdf(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    client_id: str = Form(...),
    project_name: str = Form(...),
    project_id: str = Form(None),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """
    Upload a PDF brochure and ingest it into pgvector.
    Returns the ingestion result.
    """
    _check_tenant(user, client_id)

    if not file.filename or not file.filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Only PDF files are supported")

    if not project_id:
        project_id = str(uuid.uuid4())

    content = await file.read()
    if len(content) > 50 * 1024 * 1024:  # 50 MB cap — brochures, not archives
        raise HTTPException(status_code=413, detail="PDF too large (max 50 MB)")

    with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
        tmp.write(content)
        tmp_path = tmp.name

    try:
        result = await ingest_brochure(
            db=db,
            pdf_path=tmp_path,
            client_id=client_id,
            project_id=project_id,
            project_name=project_name,
        )
        return {"status": "ingested", **result}
    except Exception as e:
        logger.error("Ingest failed: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=f"Ingestion failed: {str(e)}")
    finally:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass


@router.delete("/projects/{project_id}/chunks")
async def delete_chunks(
    project_id: str,
    client_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(_tenant_access),
):
    """Delete all chunks for a project (before re-ingestion)."""
    deleted = await delete_project_chunks(db, client_id, project_id)
    return {"deleted": deleted, "project_id": project_id}


@router.get("/projects")
async def get_projects(
    client_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(_tenant_access),
):
    """List all projects with chunk counts for a client."""
    projects = await list_projects(db, client_id)
    return {"client_id": client_id, "projects": projects}


# ═══════════════════════════════════════════════════════════════════════════════
# PROJECT Q&A — builder-supplied questionnaire ingestion
# ═══════════════════════════════════════════════════════════════════════════════

class QAPair(BaseModel):
    question: str
    answer: str
    category: str | None = None


class QAIngestRequest(BaseModel):
    client_id: str
    project_id: str
    project_name: str
    qa_pairs: list[QAPair]
    replace_existing: bool = True


@router.get("/qa-template")
async def get_qa_template(
    user: User = Depends(get_current_user),
):
    """
    Return the standard project Q&A questionnaire.
    Builders fill in the answers; the dashboard sends them to /projects/{id}/qa.
    """
    import json as _json
    from pathlib import Path
    path = Path(__file__).resolve().parent.parent / "prompts" / "project_qa_template.json"
    if not path.exists():
        raise HTTPException(status_code=500, detail="Template file not found")
    return _json.loads(path.read_text(encoding="utf-8"))


@router.post("/projects/qa")
async def ingest_project_qa(
    body: QAIngestRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """
    Ingest Q&A pairs for a project. Replaces existing Q&A (idempotent).
    The brochure RAG search picks them up automatically — no qualifier changes needed.
    """
    _check_tenant(user, body.client_id)
    result = await ingest_qa_pairs(
        db,
        client_id=body.client_id,
        project_id=body.project_id,
        project_name=body.project_name,
        qa_pairs=[p.model_dump() for p in body.qa_pairs],
        replace_existing=body.replace_existing,
    )
    return result


@router.get("/projects/{project_id}/qa")
async def list_project_qa(
    project_id: str,
    client_id: str = Query(..., description="Client (tenant) UUID"),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(_tenant_access),
):
    """List the stored Q&A pairs for a project."""
    pairs = await list_qa_pairs(db, client_id, project_id)
    return {"client_id": client_id, "project_id": project_id, "qa_pairs": pairs}


@router.delete("/projects/{project_id}/qa")
async def delete_project_qa_endpoint(
    project_id: str,
    client_id: str = Query(...),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(_tenant_access),
):
    """Delete all Q&A pairs for a project (leaves brochure chunks intact)."""
    deleted = await delete_project_qa(db, client_id, project_id)
    return {"deleted": deleted, "project_id": project_id}