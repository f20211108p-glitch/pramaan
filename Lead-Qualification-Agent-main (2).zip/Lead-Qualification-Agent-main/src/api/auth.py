"""
Auth API — JWT-based login for dashboard users.

Two roles:
  - admin: Pramaan team, can see all clients + onboard new ones
  - client: Developer team (Prestige, Lodha), sees only their own data

Endpoints:
  POST /auth/login        — email + password => JWT token
  GET  /auth/me           — current user info (requires token)
  POST /auth/users        — create user (admin-only)
  GET  /auth/users        — list users (admin-only)
"""
import asyncio
import uuid
import logging
from datetime import datetime, timedelta, timezone
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Header
from pydantic import BaseModel, EmailStr, field_validator
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
import jwt as pyjwt
from jwt.exceptions import PyJWTError
from passlib.context import CryptContext

from src.config import get_settings
from src.db.engine import get_db
from src.db.tables import User, ClientConfig

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/auth", tags=["auth"])

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# JWT settings
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_HOURS = 24


# ── Request / Response models ──────────────────────────────────────────────

class LoginRequest(BaseModel):
    email: str
    password: str


class LoginResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: dict


class CreateUserRequest(BaseModel):
    email: str
    password: str
    name: str
    role: str = "client"  # "admin" | "client"
    client_id: str | None = None  # required if role == "client"

    @field_validator("password")
    @classmethod
    def validate_password(cls, v: str) -> str:
        if len(v) < 12:
            raise ValueError("Password must be at least 12 characters")
        if not any(c.isupper() for c in v):
            raise ValueError("Password must contain at least one uppercase letter")
        if not any(c.isdigit() for c in v):
            raise ValueError("Password must contain at least one digit")
        return v


class UserOut(BaseModel):
    id: str
    email: str
    name: str
    role: str
    client_id: str | None
    client_name: str | None = None
    active: bool
    created_at: str


# ── Helpers ────────────────────────────────────────────────────────────────

def _create_access_token(data: dict) -> str:
    settings = get_settings()
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + timedelta(hours=ACCESS_TOKEN_EXPIRE_HOURS)
    to_encode.update({"exp": expire})
    return pyjwt.encode(to_encode, settings.secret_key, algorithm=ALGORITHM)


def _hash_password(password: str) -> str:
    return pwd_context.hash(password)


def _verify_password(plain: str, hashed: str) -> bool:
    return pwd_context.verify(plain, hashed)


# Pre-computed dummy hash so login timing is identical whether or not the
# email exists (prevents user-enumeration via response timing).
_DUMMY_HASH = pwd_context.hash("invalid-placeholder-password")


async def get_current_user(
    authorization: str = Header(..., alias="Authorization"),
    db: AsyncSession = Depends(get_db),
) -> User:
    """Extract and validate JWT from Authorization header."""
    settings = get_settings()

    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid authorization header")

    token = authorization[7:]  # strip "Bearer "

    try:
        payload = pyjwt.decode(token, settings.secret_key, algorithms=[ALGORITHM])
        user_id = payload.get("sub")
        if not user_id:
            raise HTTPException(status_code=401, detail="Invalid token")
    except (PyJWTError, Exception):
        raise HTTPException(status_code=401, detail="Invalid or expired token")

    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()

    if not user or not user.active:
        raise HTTPException(status_code=401, detail="User not found or inactive")

    return user


def require_admin(user: User = Depends(get_current_user)) -> User:
    """Dependency that requires admin role."""
    if user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    return user


# ── Endpoints ──────────────────────────────────────────────────────────────

@router.post("/login")
async def login(body: LoginRequest, db: AsyncSession = Depends(get_db)):
    """Authenticate user and return JWT token."""
    result = await db.execute(
        select(User).where(User.email == body.email.lower().strip())
    )
    user = result.scalar_one_or_none()

    # bcrypt is CPU-bound (~100ms+) — run off the event loop. Verify against a
    # dummy hash when the user doesn't exist so timing doesn't leak existence.
    hashed = user.password_hash if user else _DUMMY_HASH
    password_ok = await asyncio.to_thread(_verify_password, body.password, hashed)

    if not user or not password_ok:
        raise HTTPException(status_code=401, detail="Invalid email or password")

    if not user.active:
        raise HTTPException(status_code=403, detail="Account is disabled")

    # Get client name if client role
    client_name = None
    if user.client_id:
        cr = await db.execute(
            select(ClientConfig.client_name).where(ClientConfig.id == user.client_id)
        )
        client_name = cr.scalar_one_or_none()

    token = _create_access_token({"sub": str(user.id), "role": user.role})

    return LoginResponse(
        access_token=token,
        user={
            "id": str(user.id),
            "email": user.email,
            "name": user.name,
            "role": user.role,
            "client_id": str(user.client_id) if user.client_id else None,
            "client_name": client_name,
        },
    )


@router.get("/me")
async def get_me(user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    """Get current authenticated user info."""
    client_name = None
    if user.client_id:
        cr = await db.execute(
            select(ClientConfig.client_name).where(ClientConfig.id == user.client_id)
        )
        client_name = cr.scalar_one_or_none()

    return UserOut(
        id=str(user.id),
        email=user.email,
        name=user.name,
        role=user.role,
        client_id=str(user.client_id) if user.client_id else None,
        client_name=client_name,
        active=user.active,
        created_at=user.created_at.isoformat(),
    )


@router.post("/users", status_code=201)
async def create_user(
    body: CreateUserRequest,
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(require_admin),
):
    """Create a new dashboard user (admin-only)."""
    # Validate role
    if body.role not in ("admin", "client"):
        raise HTTPException(status_code=400, detail="Role must be 'admin' or 'client'")

    if body.role == "client" and not body.client_id:
        raise HTTPException(status_code=400, detail="client_id required for client role")

    # Check for duplicate email
    existing = await db.execute(
        select(User).where(User.email == body.email.lower().strip())
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=409, detail="Email already registered")

    # Validate client_id if provided
    client_name = None
    if body.client_id:
        cr = await db.execute(
            select(ClientConfig).where(ClientConfig.id == body.client_id)
        )
        client = cr.scalar_one_or_none()
        if not client:
            raise HTTPException(status_code=404, detail="Client not found")
        client_name = client.client_name

    user = User(
        email=body.email.lower().strip(),
        password_hash=await asyncio.to_thread(_hash_password, body.password),
        name=body.name,
        role=body.role,
        client_id=body.client_id if body.role == "client" else None,
    )
    db.add(user)
    await db.commit()
    await db.refresh(user)

    return UserOut(
        id=str(user.id),
        email=user.email,
        name=user.name,
        role=user.role,
        client_id=str(user.client_id) if user.client_id else None,
        client_name=client_name,
        active=user.active,
        created_at=user.created_at.isoformat(),
    )


@router.get("/users")
async def list_users(
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(require_admin),
):
    """List all dashboard users (admin-only)."""
    result = await db.execute(select(User).order_by(User.created_at.desc()))
    users = result.scalars().all()

    out = []
    for u in users:
        client_name = None
        if u.client_id:
            cr = await db.execute(
                select(ClientConfig.client_name).where(ClientConfig.id == u.client_id)
            )
            client_name = cr.scalar_one_or_none()
        out.append(UserOut(
            id=str(u.id),
            email=u.email,
            name=u.name,
            role=u.role,
            client_id=str(u.client_id) if u.client_id else None,
            client_name=client_name,
            active=u.active,
            created_at=u.created_at.isoformat(),
        ))

    return {"users": out}
