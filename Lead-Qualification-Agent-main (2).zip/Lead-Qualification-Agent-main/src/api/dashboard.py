"""
Dashboard API — composite endpoints optimized for the broker-facing Next.js dashboard.

These endpoints differ from the raw Admin CRUD (admin.py) in that they:
  1. Combine multiple queries into single responses (reduce round-trips)
  2. Return dashboard-shaped data (stats + recent leads in one call)
  3. Support bulk operations (batch stage updates)
  4. Provide activity feeds and timelines
  5. Include export functionality (CSV, conversation text)

All endpoints are protected by x-admin-key header.
All queries filter by client_id — multi-tenant boundary enforced.

Endpoint Map:
  GET  /dashboard/{client_id}/home                    — dashboard overview
  GET  /dashboard/{client_id}/leads/{lead_id}/detail   — full lead detail (1 call)
  GET  /dashboard/{client_id}/leads/{lead_id}/timeline — chronological activity
  POST /dashboard/{client_id}/leads/bulk-update        — batch stage/tier changes
  GET  /dashboard/{client_id}/activity                 — live activity feed
  GET  /dashboard/{client_id}/leads/export             — CSV export
  GET  /dashboard/{client_id}/conversations/{id}/export — conversation text export
"""
import csv
import io
import uuid
import logging
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

from src.db.engine import get_db
from src.db.queries import (
    get_client,
    get_lead,
    get_pipeline_stats,
    get_recent_leads,
    get_lead_detail,
    get_lead_timeline,
    get_recent_activity,
    bulk_update_leads,
    list_leads,
    get_conversation_export,
)
from src.api.admin import _tenant_access, _to_str_id
from src.db.tables import User
from src.insights.lead_insight import generate_lead_insight

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/dashboard", tags=["dashboard"])


# ── Request models ─────────────────────────────────────────────────────────

class BulkLeadUpdate(BaseModel):
    lead_ids: list[str] = Field(..., min_length=1, max_length=200)
    stage: str | None = None
    tier: str | None = None
    assigned_agent_id: str | None = None


# ── Helpers ────────────────────────────────────────────────────────────────

async def _ensure_client_exists(db: AsyncSession, client_id: str):
    """Check that the client exists. Raises 404 if not."""
    client = await get_client(db, client_id)
    if not client:
        raise HTTPException(status_code=404, detail="Client not found")
    return client


def _serialize_datetime(dt: datetime | None) -> str | None:
    if dt is None:
        return None
    return dt.isoformat()


# ═══════════════════════════════════════════════════════════════════════════════
# DASHBOARD HOME — combined overview for landing page
# ═══════════════════════════════════════════════════════════════════════════════

@router.get("/{client_id}/home")
async def dashboard_home(
    client_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(_tenant_access),
):
    """
    Dashboard landing page data — single API call for the entire home screen.

    Returns:
      - client info (name, CRM status)
      - pipeline stats (by tier, by stage, totals)
      - recent hot leads (top 5 hot, most recently updated)
      - recent activity (last 10 messages across all leads)
    """
    client = await _ensure_client_exists(db, client_id)

    # Run queries
    stats = await get_pipeline_stats(db, client_id)
    hot_leads = await get_recent_leads(db, client_id, tier="hot", limit=5)
    recent_leads = await get_recent_leads(db, client_id, limit=10)
    activity = await get_recent_activity(db, client_id, limit=10)

    return {
        "client": {
            "id": str(client.id),
            "client_name": client.client_name,
            "crm_type": client.crm_type,
            "crm_configured": bool(client.crm_type and client.crm_token),
            "billing_model": getattr(client, "billing_model", "direct"),
        },
        "stats": stats,
        "hot_leads": [_to_str_id(l) for l in hot_leads],
        "recent_leads": [_to_str_id(l) for l in recent_leads],
        "recent_activity": [
            {**a, "timestamp": _serialize_datetime(a["timestamp"])}
            for a in activity
        ],
    }


# ═══════════════════════════════════════════════════════════════════════════════
# LEAD INSIGHT — Haiku-generated sales analysis per lead
# ═══════════════════════════════════════════════════════════════════════════════

@router.get("/{client_id}/leads/{lead_id}/insight")
async def lead_insight(
    client_id: str,
    lead_id: str,
    refresh: bool = Query(False, description="Force regeneration, skip cache"),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(_tenant_access),
):
    """
    Generate a broker-facing insight for a lead:
      - Conversation summary
      - Close probability (0-100)
      - Buying signals
      - Concerns / objections
      - Recommended next action
      - Talking points
      - Urgency level

    Cached for 1 hour per lead. Pass ?refresh=true to force regenerate.
    """
    await _ensure_client_exists(db, client_id)
    try:
        result = await generate_lead_insight(db, client_id, lead_id, force_refresh=refresh)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    return result


# ═══════════════════════════════════════════════════════════════════════════════
# LEAD DETAIL — full lead info in one call
# ═══════════════════════════════════════════════════════════════════════════════

@router.get("/{client_id}/leads/{lead_id}/detail")
async def lead_detail(
    client_id: str,
    lead_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(_tenant_access),
):
    """
    Full lead detail view — one API call replaces 4 separate queries.

    Returns:
      - lead profile (all fields)
      - conversations list
      - messages for each conversation
      - billing events
      - consent records
    """
    await _ensure_client_exists(db, client_id)

    detail = await get_lead_detail(db, client_id, lead_id)
    if not detail:
        raise HTTPException(status_code=404, detail="Lead not found")

    lead = detail["lead"]
    conversations = detail["conversations"]
    messages_by_conv = detail["messages_by_conversation"]
    billing_events = detail["billing_events"]
    consents = detail["consents"]

    # Serialize conversations with their messages nested
    conv_list = []
    for conv in conversations:
        conv_data = _to_str_id(conv)
        conv_msgs = messages_by_conv.get(str(conv.id), [])
        conv_data["messages"] = [_to_str_id(m) for m in conv_msgs]
        conv_data["message_count"] = len(conv_msgs)
        conv_list.append(conv_data)

    return {
        "lead": _to_str_id(lead),
        "conversations": conv_list,
        "billing_events": [_to_str_id(e) for e in billing_events],
        "consents": [_to_str_id(c) for c in consents],
        "summary": {
            "total_conversations": len(conversations),
            "total_messages": sum(len(msgs) for msgs in messages_by_conv.values()),
            "total_billing_events": len(billing_events),
            "has_consent": len(consents) > 0,
        },
    }


# ═══════════════════════════════════════════════════════════════════════════════
# LEAD TIMELINE — chronological activity feed for one lead
# ═══════════════════════════════════════════════════════════════════════════════

@router.get("/{client_id}/leads/{lead_id}/timeline")
async def lead_timeline(
    client_id: str,
    lead_id: str,
    limit: int = Query(50, ge=1, le=500),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(_tenant_access),
):
    """
    Chronological activity timeline for a single lead.

    Returns a merged, sorted list of:
      - messages (inbound + outbound)
      - billing events (qualified_lead, etc.)

    Each event: {type: "message"|"billing", timestamp, data: {...}}
    """
    await _ensure_client_exists(db, client_id)

    # Verify lead exists
    lead = await get_lead(db, client_id, lead_id)
    if not lead:
        raise HTTPException(status_code=404, detail="Lead not found")

    events = await get_lead_timeline(db, client_id, lead_id, limit=limit)

    return {
        "lead_id": lead_id,
        "lead_phone": lead.phone,
        "lead_name": lead.name,
        "events": [
            {**e, "timestamp": _serialize_datetime(e["timestamp"])}
            for e in events
        ],
        "total_events": len(events),
    }


# ═══════════════════════════════════════════════════════════════════════════════
# BULK UPDATE — batch stage/tier changes
# ═══════════════════════════════════════════════════════════════════════════════

@router.post("/{client_id}/leads/bulk-update")
async def bulk_update(
    client_id: str,
    body: BulkLeadUpdate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(_tenant_access),
):
    """
    Batch-update multiple leads at once.

    Use cases:
      - Select all hot leads → mark as "handed_off"
      - Assign multiple leads to an agent
      - Bulk tier correction
    """
    await _ensure_client_exists(db, client_id)

    fields = body.model_dump(exclude={"lead_ids"}, exclude_none=True)
    if not fields:
        raise HTTPException(status_code=400, detail="No fields to update")

    # Validate stage if provided
    valid_stages = {
        "new", "qualifying", "qualified", "scheduling",
        "nurturing", "handed_off", "converted", "lost",
    }
    if body.stage and body.stage not in valid_stages:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid stage '{body.stage}'. Valid: {sorted(valid_stages)}",
        )

    valid_tiers = {"hot", "warm", "cold"}
    if body.tier and body.tier not in valid_tiers:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid tier '{body.tier}'. Valid: {sorted(valid_tiers)}",
        )

    count = await bulk_update_leads(db, client_id, body.lead_ids, fields)

    return {
        "updated": count,
        "lead_ids": body.lead_ids,
        "fields": fields,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# ACTIVITY FEED — recent activity across all leads
# ═══════════════════════════════════════════════════════════════════════════════

@router.get("/{client_id}/activity")
async def activity_feed(
    client_id: str,
    limit: int = Query(30, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(_tenant_access),
):
    """
    Recent activity across all leads for the dashboard live feed.

    Returns the most recent messages with lead info attached.
    Useful for: "what's happening right now" panel, notification feed.
    """
    await _ensure_client_exists(db, client_id)

    activity = await get_recent_activity(db, client_id, limit=limit)

    return {
        "client_id": client_id,
        "activity": [
            {**a, "timestamp": _serialize_datetime(a["timestamp"])}
            for a in activity
        ],
        "count": len(activity),
    }


# ═══════════════════════════════════════════════════════════════════════════════
# LEADS EXPORT — CSV download
# ═══════════════════════════════════════════════════════════════════════════════

@router.get("/{client_id}/leads/export")
async def export_leads_csv(
    client_id: str,
    tier: str | None = Query(None),
    stage: str | None = Query(None),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(_tenant_access),
):
    """
    Export leads as CSV download.

    Supports the same filters as the leads list (tier, stage).
    Returns a downloadable CSV file.
    """
    await _ensure_client_exists(db, client_id)

    leads, total = await list_leads(
        db, client_id,
        tier=tier, stage=stage,
        limit=10_000,  # practical max for CSV
        offset=0,
    )

    # Build CSV in memory
    output = io.StringIO()
    writer = csv.writer(output)

    # Header
    writer.writerow([
        "id", "phone", "name", "email", "intent", "stage", "tier", "score",
        "budget_min", "budget_max", "timeline_months", "urgency",
        "financing_status", "location_preferences", "property_type",
        "family_size", "language_pref", "source_channel",
        "created_at", "updated_at",
    ])

    # Data rows
    for lead in leads:
        locations = lead.location_preferences
        if isinstance(locations, list):
            locations = "; ".join(str(loc) for loc in locations)

        writer.writerow([
            str(lead.id),
            lead.phone,
            lead.name or "",
            lead.email or "",
            lead.intent,
            lead.stage,
            lead.tier or "",
            lead.score if lead.score is not None else "",
            lead.budget_min if lead.budget_min is not None else "",
            lead.budget_max if lead.budget_max is not None else "",
            lead.timeline_months if lead.timeline_months is not None else "",
            lead.urgency,
            lead.financing_status,
            locations or "",
            lead.property_type,
            lead.family_size if lead.family_size is not None else "",
            lead.language_pref,
            lead.source_channel,
            lead.created_at.isoformat() if lead.created_at else "",
            lead.updated_at.isoformat() if lead.updated_at else "",
        ])

    output.seek(0)

    filename = f"leads_{client_id[:8]}_{datetime.now(timezone.utc).strftime('%Y%m%d')}.csv"
    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )


# ═══════════════════════════════════════════════════════════════════════════════
# CONVERSATION EXPORT — full chat as text
# ═══════════════════════════════════════════════════════════════════════════════

@router.get("/{client_id}/conversations/{conversation_id}/export")
async def export_conversation(
    client_id: str,
    conversation_id: str,
    format: str = Query("text", description="Export format: text or json"),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(_tenant_access),
):
    """
    Export a full conversation.

    Formats:
      - text: WhatsApp-style chat format (for broker handoff, CRM notes)
      - json: structured JSON (for programmatic use)
    """
    await _ensure_client_exists(db, client_id)

    messages = await get_conversation_export(db, client_id, conversation_id)

    if not messages:
        raise HTTPException(status_code=404, detail="Conversation not found or empty")

    if format == "json":
        return {"conversation_id": conversation_id, "messages": messages}

    # Text format — WhatsApp-style chat export
    lines = []
    for msg in messages:
        ts = msg["timestamp"]
        direction = "Lead" if msg["direction"] == "inbound" else "Bot"
        content = msg["content"]
        lines.append(f"[{ts}] {direction}: {content}")

    text_output = "\n".join(lines)

    return StreamingResponse(
        iter([text_output]),
        media_type="text/plain",
        headers={
            "Content-Disposition": f"attachment; filename=conversation_{conversation_id[:8]}.txt",
        },
    )
