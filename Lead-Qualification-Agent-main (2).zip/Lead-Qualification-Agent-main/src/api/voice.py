"""
Voice call API — endpoints for triggering and managing outbound calls.
Tenant-scoped: client users can only act on their own client_id.

Endpoints:
  POST /admin/clients/{client_id}/calls/trigger     — trigger outbound calls for a client
  POST /admin/clients/{client_id}/calls/dial         — dial a specific lead
  GET  /admin/clients/{client_id}/calls/eligible     — list leads eligible for calling
  POST /admin/voice/sip-trunk                        — configure SIP trunk (via LiveKit API)
"""
import logging

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from src.config import get_settings
from src.db.engine import get_db
from src.db.queries import get_client, get_lead
from src.api.admin import _tenant_access, _admin_only, _rate_limit
from src.db.tables import User

# NOTE: src.voice.* is imported LAZILY inside each endpoint, not here.
# The voice stack depends on the LiveKit SDK whose API surface has shifted
# between major versions — an ImportError there must degrade the voice
# endpoints to 503, never prevent the whole API from booting (this module
# is included in main.py's router chain at startup).


def _voice_module():
    """Import the outbound-call module lazily; 503 if the voice stack is broken."""
    try:
        from src.voice import outbound
        return outbound
    except Exception as e:
        logger.error("[voice] Voice stack unavailable: %s", e)
        raise HTTPException(
            status_code=503,
            detail="Voice calling is not available in this deployment.",
        )

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/admin", tags=["voice"], dependencies=[Depends(_rate_limit)])


# ── Request/Response models ──────────────────────────────────────────────

class TriggerCallsRequest(BaseModel):
    max_calls: int = 5
    delay_hours: int | None = None  # Override silence threshold


class DialLeadRequest(BaseModel):
    lead_id: str
    override_language: str | None = None  # Override auto-detected language


class SIPTrunkConfig(BaseModel):
    """Provider-agnostic SIP trunk configuration."""
    provider: str  # "twilio", "exotel", "telnyx", "custom"
    outbound_uri: str  # SIP URI for outbound calls
    username: str | None = None
    password: str | None = None
    caller_id: str | None = None  # E.164 phone number


# ── Endpoints ────────────────────────────────────────────────────────────

@router.post("/clients/{client_id}/calls/trigger")
async def trigger_outbound_calls(
    client_id: str,
    body: TriggerCallsRequest = TriggerCallsRequest(),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(_tenant_access),
):
    """
    Trigger a batch of outbound calls for a client.

    Finds eligible leads (warm/hot, silent for X hours) and calls them.
    Returns the list of call results.
    """
    client = await get_client(db, client_id)
    if not client:
        raise HTTPException(status_code=404, detail="Client not found")

    settings = get_settings()
    if not settings.livekit_api_key:
        raise HTTPException(
            status_code=503,
            detail="LiveKit not configured. Set LIVEKIT_API_KEY and LIVEKIT_API_SECRET.",
        )

    if not settings.sip_trunk_id:
        raise HTTPException(
            status_code=503,
            detail="SIP trunk not configured. Create one via POST /admin/voice/sip-trunk.",
        )

    results = await _voice_module().run_outbound_batch(
        client_id=client_id,
        client_name=client.client_name,
        delay_hours=body.delay_hours,
        max_calls=body.max_calls,
    )

    return {
        "client_id": client_id,
        "calls_initiated": len(results),
        "results": results,
    }


@router.post("/clients/{client_id}/calls/dial")
async def dial_specific_lead(
    client_id: str,
    body: DialLeadRequest,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(_tenant_access),
):
    """
    Dial a specific lead immediately (manual trigger from dashboard).

    Useful for: broker wants to have the AI call a specific lead right now.
    """
    client = await get_client(db, client_id)
    if not client:
        raise HTTPException(status_code=404, detail="Client not found")

    lead = await get_lead(db, client_id, body.lead_id)
    if not lead:
        raise HTTPException(status_code=404, detail="Lead not found")

    settings = get_settings()
    if not settings.livekit_api_key or not settings.sip_trunk_id:
        raise HTTPException(status_code=503, detail="Voice calling not configured")

    # Build lead context dict
    language = body.override_language or lead.language_pref or "english"
    lead_dict = {
        "lead_id": str(lead.id),
        "client_id": client_id,
        "phone": lead.phone,
        "name": lead.name,
        "language_pref": language,
        "tier": lead.tier,
        "score": lead.score,
        "budget_min": lead.budget_min,
        "budget_max": lead.budget_max,
        "timeline_months": lead.timeline_months,
        "location_preferences": lead.location_preferences,
        "property_type": lead.property_type,
        "financing_status": lead.financing_status,
        "family_size": lead.family_size,
    }

    result = await _voice_module().call_lead(lead_dict, client.client_name)

    if result.get("status") == "error":
        raise HTTPException(status_code=500, detail=result.get("message", "Call failed"))

    return {
        "client_id": client_id,
        "lead_id": body.lead_id,
        **result,
    }


@router.get("/clients/{client_id}/calls/eligible")
async def list_eligible_leads(
    client_id: str,
    delay_hours: int | None = Query(None, description="Override silence threshold (hours)"),
    limit: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(_tenant_access),
):
    """
    List leads eligible for outbound calls (preview before triggering).

    Shows which leads would be called and why.
    """
    client = await get_client(db, client_id)
    if not client:
        raise HTTPException(status_code=404, detail="Client not found")

    leads = await _voice_module().find_leads_to_call(
        db, client_id,
        delay_hours=delay_hours,
        limit=limit,
    )

    return {
        "client_id": client_id,
        "eligible_count": len(leads),
        "leads": [
            {
                "lead_id": l["lead_id"],
                "phone": l["phone"],
                "name": l["name"],
                "tier": l["tier"],
                "score": l["score"],
                "language": l["language_pref"],
            }
            for l in leads
        ],
    }


@router.post("/voice/sip-trunk")
async def configure_sip_trunk(
    body: SIPTrunkConfig,
    user: User = Depends(_admin_only),
):
    """
    Configure a SIP trunk via LiveKit API.

    This creates an outbound SIP trunk in LiveKit that can be used
    for making calls. The trunk ID is returned and should be saved
    to SIP_TRUNK_ID in your environment.

    Supports: Twilio, Exotel, Telnyx, or any SIP provider.
    """
    settings = get_settings()

    if not settings.livekit_api_key or not settings.livekit_api_secret:
        raise HTTPException(status_code=503, detail="LiveKit not configured")

    try:
        from livekit import api as lk_api

        lk = lk_api.LiveKitAPI(
            url=settings.livekit_url,
            api_key=settings.livekit_api_key,
            api_secret=settings.livekit_api_secret,
        )

        # Create outbound trunk
        trunk_request = lk_api.CreateSIPOutboundTrunkRequest(
            trunk=lk_api.SIPOutboundTrunkInfo(
                name=f"leadengine-{body.provider}",
                address=body.outbound_uri,
                auth_username=body.username or "",
                auth_password=body.password or "",
            ),
        )

        trunk = await lk.sip.create_sip_outbound_trunk(trunk_request)
        trunk_id = trunk.sip_trunk_id if hasattr(trunk, 'sip_trunk_id') else str(trunk)

        logger.info("[voice] SIP trunk created: provider=%s trunk_id=%s", body.provider, trunk_id)

        return {
            "status": "created",
            "provider": body.provider,
            "trunk_id": trunk_id,
            "message": f"Trunk created. Set SIP_TRUNK_ID={trunk_id} in your .env file.",
        }

    except ImportError:
        raise HTTPException(status_code=503, detail="LiveKit SDK not installed")
    except Exception as e:
        logger.error("[voice] Failed to create SIP trunk: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to create trunk: {e}")
