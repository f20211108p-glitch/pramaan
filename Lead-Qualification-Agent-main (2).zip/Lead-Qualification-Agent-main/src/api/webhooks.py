"""
WhatsApp webhook endpoints — GET (verification) + POST (inbound messages).

Supports two processing modes:
  - sync (default in dev): process message inline, respond within webhook
  - async (production): enqueue to Redis stream, respond immediately,
    background worker processes and sends reply

Set WEBHOOK_MODE=async in .env to use async mode.

Security: when META_APP_SECRET is configured, every POST payload is verified
against the X-Hub-Signature-256 header (HMAC-SHA256). Unsigned/invalid
payloads are rejected with 403.
"""
import json
import logging

from fastapi import APIRouter, Request, Query, Response, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from src.channels.whatsapp import WhatsAppChannel
from src.channels.router import MessageRouter
from src.config import get_settings
from src.db.engine import get_db

logger = logging.getLogger(__name__)

router = APIRouter(tags=["webhooks"])

_message_router = MessageRouter()


@router.get("/webhook/whatsapp")
async def verify_webhook(
    response: Response,
    hub_mode: str = Query(None, alias="hub.mode"),
    hub_verify_token: str = Query(None, alias="hub.verify_token"),
    hub_challenge: str = Query(None, alias="hub.challenge"),
):
    """Meta webhook verification — returns the challenge if token matches."""
    if not hub_mode or not hub_verify_token or not hub_challenge:
        response.status_code = 400
        return {"error": "Missing verification parameters"}

    challenge = WhatsAppChannel.verify_webhook(hub_mode, hub_verify_token, hub_challenge)
    if challenge is not None:
        return Response(content=challenge, media_type="text/plain")

    response.status_code = 403
    return {"error": "Verification failed"}


@router.post("/webhook/whatsapp")
async def receive_webhook(
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    """
    Receive inbound WhatsApp messages from Meta.
    Returns 200 for all processable payloads — Meta retries aggressively
    on non-200 responses. Invalid signatures are the one exception (403).

    In async mode (WEBHOOK_MODE=async), messages are enqueued to Redis
    and processed by a background worker. This ensures the webhook
    responds within Meta's 20-second timeout even during traffic spikes.

    Deduplication happens exactly once, inside MessageRouter.route_inbound()
    (i.e. in the worker for async mode). Do NOT dedup here before enqueuing:
    is_duplicate() is a check-AND-mark operation, so checking here would make
    the worker see every message as a duplicate and drop it.
    """
    raw_body = await request.body()
    settings = get_settings()

    # ── Signature verification (Meta X-Hub-Signature-256) ───────────────
    if settings.meta_app_secret:
        signature = request.headers.get("X-Hub-Signature-256", "")
        if not WhatsAppChannel.verify_signature(raw_body, signature, settings.meta_app_secret):
            logger.warning("Webhook rejected: invalid X-Hub-Signature-256")
            return Response(status_code=403)
    elif settings.is_production:
        logger.warning(
            "META_APP_SECRET not set — webhook signatures are NOT verified. "
            "Set it in production."
        )

    try:
        payload = json.loads(raw_body)
    except Exception:
        logger.warning("Invalid JSON in webhook payload")
        return {"status": "ok"}

    webhook_mode = getattr(settings, "webhook_mode", "sync")

    if webhook_mode == "async":
        # Async mode: enqueue and return immediately
        try:
            from src.core.message_queue import enqueue_message
            # Quick-parse to get client_id for the stream key
            parsed = WhatsAppChannel.parse_webhook_payload(payload)
            if parsed is None:
                return {"status": "ok"}  # status update, skip

            entry_id = await enqueue_message(
                client_id=parsed.get("waba_phone_number_id", "unknown"),
                payload=payload,
            )
            logger.info("Webhook enqueued: entry_id=%s", entry_id)
        except Exception as e:
            logger.error("Failed to enqueue message: %s", e, exc_info=True)
            # Fall back to sync processing if queue fails
            try:
                result = await _message_router.route_inbound(payload, db)
                logger.info("Webhook processed (fallback sync): %s", result)
            except Exception as e2:
                logger.error("Fallback sync processing also failed: %s", e2, exc_info=True)
    else:
        # Sync mode (default): process inline
        try:
            result = await _message_router.route_inbound(payload, db)
            logger.info("Webhook processed: %s", result)
        except Exception as e:
            # Log but don't crash — always return 200 to Meta
            logger.error("Webhook processing error: %s", e, exc_info=True)

    return {"status": "ok"}
