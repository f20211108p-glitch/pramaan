"""
MessageRouter — the full inbound pipeline. Dedup happens HERE (only once).

Webhook payload → parse → dedup → resolve tenant → lead → consent → conversation
→ save inbound → LangGraph engine → send reply → save outbound
"""
import asyncio
import json
import logging
from datetime import datetime

from sqlalchemy.ext.asyncio import AsyncSession

from src.channels.whatsapp import WhatsAppChannel
from src.core.dedup import is_duplicate
from src.core.lead_lock import lead_lock
from src.core.rate_limit import check_rate_limit
from src.core.tenant import resolve_client
from src.db.queries import (
    get_or_create_lead,
    get_or_create_conversation,
    get_conversation_messages,
    save_message,
    update_lead,
    write_billing_event,
    write_consent,
    has_consent,
)
from src.engine.graph import compile_graph, make_state_key
from src.notifications.broker import notify_brokers, notify_visit_booked
from src.crm.sync import sync_lead_to_crm
from src.rag.search import should_trigger_rag, rag_search
from src.config import get_settings

logger = logging.getLogger(__name__)


# Phrases that indicate the lead is asking us to send the brochure.
_BROCHURE_KEYWORDS = (
    "brochure", "broucher", "brushur", "broushre", "braoushre",
    "brocher", "brosure", "broshure", "brochur",
    "bhej dijiye", "bhej do", "bhej dena", "bhejo", "bhejiye",
    "bhej sakte", "bhej sakti",
    "send pdf", "send the pdf", "send brochure", "send the brochure",
    "send floor plan", "share brochure", "share pdf",
    "ha bhej", "haan bhej", "yes send", "yes please send",
    "floor plan bhej", "pdf bhej",
)


def _is_brochure_request(text: str) -> bool:
    """Detect whether the user is asking for the brochure / floor plan PDF."""
    if not text:
        return False
    low = text.lower().strip()
    return any(kw in low for kw in _BROCHURE_KEYWORDS)


def _brochure_sent_ack(language: str) -> str:
    """Short acknowledgement that goes out AFTER the PDF is delivered."""
    if language == "hindi":
        return "*Brochure bhej diya hai.* ✅ Koi sawaal ho toh poochiye."
    if language == "hinglish":
        return "*Brochure bhej diya!* ✅ Koi sawaal ho toh batao."
    return "*Brochure sent!* ✅ Let me know if you have any questions."


def _brochure_unavailable_ack(language: str) -> str:
    if language == "hindi":
        return (
            "Brochure abhi share nahi kar pa raha. Main team se confirm karke "
            "thodi der mein bhej deta hoon."
        )
    if language == "hinglish":
        return (
            "Brochure abhi share nahi ho pa raha — main team se confirm karke "
            "thodi der mein bhej deta hoon."
        )
    return (
        "I can't share the brochure right now. I'll confirm with our team and "
        "send it across shortly."
    )


class MessageRouter:
    """Routes inbound WhatsApp messages through the full pipeline."""

    def __init__(self):
        self._graph = compile_graph()

    async def route_inbound(self, raw_payload: dict, db: AsyncSession) -> dict:
        """
        Process a raw WhatsApp webhook payload end-to-end.

        Returns:
            dict with {lead_id, conversation_id, response, next_action}
            or {skipped: True, reason: "..."} for ignored messages
        """
        # ── Step 1: Parse webhook payload ─────────────────────────────────
        parsed = WhatsAppChannel.parse_webhook_payload(raw_payload)
        if parsed is None:
            return {"skipped": True, "reason": "status_update_or_unparseable"}

        # Serialize processing per lead: two rapid messages (or a reclaimed
        # stale one) must never run the graph concurrently for the same lead.
        # Sync mode runs inside the webhook handler — Meta times out at 20s,
        # so cap the lock wait well below that. Async workers can wait long.
        wait = 60.0 if get_settings().webhook_mode == "async" else 10.0
        async with lead_lock(
            parsed["waba_phone_number_id"], parsed["sender_phone"], wait_timeout=wait,
        ):
            return await self._route_parsed(parsed, db)

    async def _route_parsed(self, parsed: dict, db: AsyncSession) -> dict:
        """Process an already-parsed inbound message (holds the lead lock)."""
        waba_phone_number_id = parsed["waba_phone_number_id"]
        sender_phone = parsed["sender_phone"]
        sender_name = parsed.get("sender_name")
        text = parsed["text"]
        message_type = parsed["message_type"]
        media_id = parsed.get("media_id")
        message_id = parsed["message_id"]

        # ── Step 2: Dedup ─────────────────────────────────────────────────
        if await is_duplicate(message_id):
            return {"skipped": True, "reason": "duplicate"}

        # ── Step 3: Resolve tenant ────────────────────────────────────────
        client_config = await resolve_client(db, waba_phone_number_id)
        if client_config is None:
            logger.warning("Unknown WABA number: %s — ignoring", waba_phone_number_id)
            return {"skipped": True, "reason": "unknown_waba"}

        client_id = str(client_config.id)

        # ── Step 4: Get or create lead ────────────────────────────────────
        lead = await get_or_create_lead(db, client_id, sender_phone)
        lead_id = str(lead.id)

        # Update lead name from WhatsApp profile if not already set
        if sender_name and not lead.name:
            await update_lead(db, client_id, lead_id, {"name": sender_name})
            lead.name = sender_name

        # ── Step 4b: Rate limit check ────────────────────────────────────
        is_allowed = await check_rate_limit(client_id, sender_phone)
        if not is_allowed:
            throttle_reply = "I'm processing your earlier messages. I'll respond shortly!"
            await WhatsAppChannel.send_message(
                waba_phone_number_id=client_config.waba_phone_number_id,
                waba_token=client_config.waba_token,
                to=sender_phone,
                content=throttle_reply,
            )
            await save_message(
                db, client_id, await self._ensure_conversation(db, client_id, lead.id),
                direction="outbound", content=throttle_reply, message_type="text",
            )
            return {
                "lead_id": lead_id,
                "conversation_id": "",
                "response": throttle_reply,
                "next_action": "rate_limited",
            }

        # ── Step 5: First-message consent ─────────────────────────────────
        if not await has_consent(db, client_id, lead.id):
            await write_consent(
                db, client_id, lead.id,
                consent_type="data_collection",
                source="first_message",
            )

        # ── Step 6: Get or create conversation ───────────────────────────
        conversation = await get_or_create_conversation(db, client_id, lead.id)
        conversation_id = str(conversation.id)

        # ── Step 7: Save inbound message ──────────────────────────────────
        # Voice notes are saved in Step 8 (with their transcript) — saving here
        # too would create a duplicate inbound row for the same message_id.
        is_voice_note = message_type == "audio" and media_id
        if not is_voice_note:
            await save_message(
                db, client_id, conversation.id,
                direction="inbound",
                content=text,
                message_type=message_type,
                channel_message_id=message_id,
            )

        # Invalidate the cached lead-insight so the dashboard sees fresh analysis
        from src.insights.lead_insight import invalidate_insight_cache
        await invalidate_insight_cache(str(lead.id))

        # ── Step 8: Voice note handling ─────────────────────────────────
        if message_type == "audio" and media_id:
            from src.core.transcription import transcribe_voice_note

            logger.info("[router] Voice note received (media_id=%s), transcribing...", media_id)
            transcript = await transcribe_voice_note(
                media_id=media_id,
                waba_token=client_config.waba_token,
                language_hint=lead.language_pref if lead else None,
            )

            if transcript:
                # Success — use the transcript as if the user typed it
                text = transcript
                logger.info("[router] Transcribed voice note: %.100s...", text)
                # Save the inbound voice note once, with its transcript
                await save_message(
                    db, client_id, conversation.id,
                    direction="inbound",
                    content=f"[voice note] {text}",
                    message_type="audio",
                    channel_message_id=message_id,
                )
            else:
                # Transcription failed — fallback to asking for text
                logger.warning("[router] Transcription failed for media_id=%s", media_id)
                await save_message(
                    db, client_id, conversation.id,
                    direction="inbound",
                    content="[voice note]",
                    message_type="audio",
                    channel_message_id=message_id,
                )
                fallback_reply = (
                    "Sorry, I couldn't process that voice note. "
                    "Could you type out what you'd like to say?"
                )
                await WhatsAppChannel.send_message(
                    waba_phone_number_id=client_config.waba_phone_number_id,
                    waba_token=client_config.waba_token,
                    to=sender_phone,
                    content=fallback_reply,
                )
                await save_message(
                    db, client_id, conversation.id,
                    direction="outbound", content=fallback_reply, message_type="text",
                )
                return {
                    "lead_id": lead_id,
                    "conversation_id": conversation_id,
                    "response": fallback_reply,
                    "next_action": "continue",
                }
            # If transcription succeeded, fall through to Step 9 (RAG) and the rest of the pipeline

        # ── Step 9: Load history, then RAG + intent classification ────────
        # History first (intent classification needs the previous assistant
        # message for context: "haan" only means "book it" if we just offered
        # slots).
        history_messages = await get_conversation_messages(
            db, client_id, conversation.id, limit=20,
        )
        # Build message list: previous turns + current (already saved in step 7)
        # The last message in history IS the current inbound — don't double-add
        conv_messages = []
        for m in history_messages:
            role = "user" if m.direction == "inbound" else "assistant"
            conv_messages.append({"role": role, "content": m.content})

        prev_assistant = next(
            (m["content"] for m in reversed(conv_messages) if m["role"] == "assistant"),
            "",
        )

        # Kick off intent classification (Haiku, in a thread) CONCURRENTLY
        # with the RAG search — it replaces the old regex heuristics for
        # brochure / slot-confirmation / question detection at no added
        # wall-clock latency.
        intent_task = None
        if text:
            from src.engine.intent import classify_turn_intent
            intent_task = asyncio.create_task(
                asyncio.to_thread(
                    classify_turn_intent, text, prev_assistant, lead.stage or "",
                )
            )

        # RAG: include brochure context when the lead has a known location
        # or the current message mentions property details, so the qualifier
        # can reference specific projects/pricing even on short messages.
        rag_context: list[str] = []
        has_location = bool(lead.location_preferences)
        trigger_rag = should_trigger_rag(text) if text else False
        if text and (trigger_rag or has_location):
            try:
                # Use the current message + lead context for a richer search
                search_query = text
                if has_location and not trigger_rag:
                    locs = lead.location_preferences
                    loc_str = ", ".join(locs) if isinstance(locs, list) else str(locs)
                    prop_type = lead.property_type or ""
                    search_query = f"{prop_type} property in {loc_str} {text}".strip()
                rag_context = await rag_search(db, search_query, client_id)
                logger.info("[router] RAG returned %d chunks for: %.50s...", len(rag_context), search_query)
            except Exception as e:
                logger.warning("[router] RAG search failed: %s", e)
                try:
                    await db.rollback()
                except Exception:
                    pass

        turn_intent = None
        if intent_task is not None:
            try:
                turn_intent = await intent_task
            except Exception as e:
                logger.warning("[router] Intent classification failed: %s", e)

        # ── Step 10: Run engine ────────────────────────────────────────────
        engine_result = await self._run_engine(
            client_id=client_id,
            client_config=client_config,
            lead=lead,
            text=text,
            sender_phone=sender_phone,
            message_type=message_type,
            media_id=media_id,
            rag_context=rag_context,
            conversation_history=conv_messages,
            turn_intent=turn_intent,
        )
        reply = engine_result.get("reply", "")

        # Capture the lead's stage BEFORE persistence refreshes the ORM
        # object — the booking side effects below must fire exactly once,
        # on the new→scheduled transition.
        prior_stage = lead.stage or "new"

        # ── Step 11: Persist scoring + billing after engine ────────────
        billing_written = await self._persist_engine_results(db, client_id, lead_id, engine_result)

        # ── Step 11b: Broker notification for HOT leads ──────────────────
        # Only notify when the billing event was ACTUALLY written — the DB
        # idempotency constraint is the source of truth for "first time hot",
        # so duplicate runs can neither double-bill nor double-notify.
        lead_data = engine_result.get("lead_data", {})
        if billing_written and lead_data.get("tier") == "hot":
            try:
                await notify_brokers(
                    client_config=client_config,
                    lead=lead_data,
                    scoring_reasoning=lead_data.get("scoring_reasoning"),
                )
            except Exception as e:
                logger.error("[router] Broker notification failed: %s", e)
                # Non-fatal — don't block the lead's reply

        # ── Step 11b-2: Site-visit booking side effects ─────────────────
        # The scheduler node confirmed a slot to the LEAD; this is where the
        # BUSINESS finds out. Fires only on the transition into 'scheduled'
        # so a repeated confirmation can't double-book or double-notify.
        booked_slot = engine_result.get("booked_slot")
        if (
            booked_slot
            and lead_data.get("stage") == "scheduled"
            and prior_stage != "scheduled"
        ):
            try:
                await self._handle_visit_booked(
                    db, client_config, client_id, lead_id, lead_data, booked_slot,
                )
            except Exception as e:
                logger.critical(
                    "[router] Visit-booked side effects FAILED for lead %s (slot: %s): %s "
                    "— broker may not know about this visit. Follow up manually.",
                    lead_id, booked_slot, e,
                )

        # ── Step 11c: CRM sync ──────────────────────────────────────────
        if lead_data:
            try:
                await sync_lead_to_crm(
                    client_config=client_config,
                    lead=lead_data,
                )
            except Exception as e:
                logger.error("[router] CRM sync failed: %s", e)
                # Non-fatal — don't block the lead's reply

        # ── Step 11d: Brochure delivery ─────────────────────────────────
        # If the lead asked for the brochure (and we haven't sent it yet
        # in this conversation), upload + send the PDF here, then craft a
        # short confirming reply instead of letting the LLM hallucinate.
        # Prefer the LLM intent classification; fall back to the keyword
        # heuristic only when the classifier was unavailable.
        if turn_intent is not None:
            brochure_requested = turn_intent.get("wants_brochure", False)
        else:
            brochure_requested = bool(text and _is_brochure_request(text))

        brochure_sent = False
        if brochure_requested:
            brochure_sent = await self._send_brochure(
                db=db,
                client_config=client_config,
                lead_id=lead_id,
                conversation_id=conversation.id,
                to_phone=sender_phone,
                language=(lead_data.get("language_pref") or lead.language_pref or "english"),
            )
            if brochure_sent:
                # Replace the LLM reply with a short acknowledgement so the
                # user sees the PDF + a one-line "sent!" instead of a
                # hallucinated re-confirmation.
                reply = _brochure_sent_ack(
                    language=(lead_data.get("language_pref") or lead.language_pref or "english"),
                )
            else:
                # Brochure requested but not deliverable (none configured, or
                # Meta rejected the send). Replace the LLM reply with an honest
                # "we'll get back to you" — never let the model claim it sent
                # (or will send) a document the system couldn't deliver.
                reply = _brochure_unavailable_ack(
                    language=(lead_data.get("language_pref") or lead.language_pref or "english"),
                )

        # ── Step 12: Send reply using CLIENT's WABA credentials ─────────
        if reply:
            await WhatsAppChannel.send_message(
                waba_phone_number_id=client_config.waba_phone_number_id,
                waba_token=client_config.waba_token,
                to=sender_phone,
                content=reply,
            )

            # Mark inbound as read
            if message_id:
                await WhatsAppChannel.mark_as_read(
                    waba_phone_number_id=client_config.waba_phone_number_id,
                    waba_token=client_config.waba_token,
                    message_id=message_id,
                )

        # ── Step 13: Save outbound message ───────────────────────────────
        if reply:
            await save_message(
                db, client_id, conversation.id,
                direction="outbound",
                content=reply,
                message_type="text",
            )

        # ── Step 14: Return result ───────────────────────────────────────
        return {
            "lead_id": lead_id,
            "conversation_id": conversation_id,
            "response": reply,
            "next_action": "continue",
        }

    async def _send_brochure(
        self,
        db: AsyncSession,
        client_config,
        lead_id: str,
        conversation_id,
        to_phone: str,
        language: str,
    ) -> bool:
        """
        Send the project brochure PDF to the lead.

        Resolution order:
          1. client_config.prompt_overrides["brochure_url"]  (public HTTPS)
          2. client_config.prompt_overrides["brochure_path"] (local file)
          3. settings.default_brochure_url                   (public HTTPS)
          4. settings.default_brochure_path                  (local file)

        Local files are uploaded once via Meta's /media endpoint.
        Returns True if Meta accepted the send.
        """
        raw_overrides = client_config.prompt_overrides
        if isinstance(raw_overrides, str):
            overrides = json.loads(raw_overrides) if raw_overrides else {}
        else:
            overrides = raw_overrides or {}
        settings = get_settings()

        brochure_url = (
            overrides.get("brochure_url")
            or settings.default_brochure_url
            or None
        )
        brochure_path = (
            overrides.get("brochure_path")
            or settings.default_brochure_path
            or None
        )
        filename = (
            overrides.get("brochure_filename")
            or settings.default_brochure_filename
            or "brochure.pdf"
        )

        client_id = str(client_config.id)

        # Prefer URL — simplest, no upload required
        if brochure_url:
            ok = await WhatsAppChannel.send_document(
                waba_phone_number_id=client_config.waba_phone_number_id,
                waba_token=client_config.waba_token,
                to=to_phone,
                document_url=brochure_url,
                filename=filename,
            )
            if ok:
                await save_message(
                    db, client_id, conversation_id,
                    direction="outbound",
                    content=f"[brochure: {filename}]",
                    message_type="document",
                )
            return ok

        # Fall back to local file via Meta media upload
        if brochure_path:
            from pathlib import Path
            if not Path(brochure_path).exists():
                logger.warning("Brochure path not found: %s", brochure_path)
                return False
            media_id = await WhatsAppChannel.upload_media(
                waba_phone_number_id=client_config.waba_phone_number_id,
                waba_token=client_config.waba_token,
                file_path=brochure_path,
            )
            if not media_id:
                return False
            ok = await WhatsAppChannel.send_document(
                waba_phone_number_id=client_config.waba_phone_number_id,
                waba_token=client_config.waba_token,
                to=to_phone,
                media_id=media_id,
                filename=filename,
            )
            if ok:
                await save_message(
                    db, client_id, conversation_id,
                    direction="outbound",
                    content=f"[brochure: {filename}]",
                    message_type="document",
                )
            return ok

        logger.info("No brochure configured for client %s", client_id)
        return False

    async def _ensure_conversation(self, db, client_id: str, lead_id) -> str:
        """Get or create a conversation and return its ID."""
        conversation = await get_or_create_conversation(db, client_id, lead_id)
        return conversation.id

    async def _run_engine(
        self,
        client_id: str,
        client_config,
        lead,
        text: str,
        sender_phone: str,
        message_type: str,
        media_id: str | None,
        rag_context: list[str] | None = None,
        conversation_history: list[dict] | None = None,
        turn_intent: dict | None = None,
    ) -> dict:
        """
        Run the LangGraph qualification engine and return results.
        Returns dict with: reply, lead_data, billing_event, next_action.
        """
        try:
            # Build messages: full conversation history so the qualifier
            # knows what was already asked/answered and doesn't repeat
            messages = conversation_history or [{"role": "user", "content": text}]

            state = {
                "messages": messages,
                "lead": {
                    # Identity
                    "phone": sender_phone,
                    "client_id": client_id,
                    "name": lead.name,
                    # Conversation state — persists across turns via DB
                    "intent": lead.intent or "unknown",
                    "stage": lead.stage or "new",
                    "language_pref": lead.language_pref or "english",
                    # Accumulated qualification data from previous turns
                    # Grows as lead provides more info across messages
                    "budget_min": lead.budget_min,
                    "budget_max": lead.budget_max,
                    "timeline_months": lead.timeline_months,
                    "urgency": lead.urgency or "unknown",
                    "financing_status": lead.financing_status or "unknown",
                    "location_preferences": lead.location_preferences or [],
                    "property_type": lead.property_type or "any",
                    "family_size": lead.family_size,
                    "score": lead.score,
                    "tier": lead.tier,
                },
                "client_config": {
                    "id": client_id,
                    "client_name": client_config.client_name,
                    "prompt_overrides": (
                        json.loads(client_config.prompt_overrides)
                        if isinstance(client_config.prompt_overrides, str)
                        else (client_config.prompt_overrides or {})
                    ),
                    "language_config": (
                        json.loads(client_config.language_config)
                        if isinstance(client_config.language_config, str)
                        else (client_config.language_config or {})
                    ),
                },
                "current_node": "",
                "turn_count": 0,
                "awaiting_info": [],
                "last_extraction": {},
                "should_handoff": False,
                "handoff_reason": None,
                "next_action": None,
                "language": lead.language_pref or "english",
                "rag_context": rag_context or [],
                "turn_intent": turn_intent,
                "billing_event": None,
                "errors": [],
            }

            config = make_state_key(client_id, sender_phone)
            result = await asyncio.to_thread(self._graph.invoke, state, config)

            # Extract bot reply from messages
            reply = ""
            messages = result.get("messages", [])
            for msg in reversed(messages):
                if msg.get("role") == "assistant":
                    reply = msg.get("content", "")
                    break
            if not reply:
                reply = "I'm here to help! What kind of property are you looking for?"

            return {
                "reply": reply,
                "lead_data": result.get("lead", {}),
                "billing_event": result.get("billing_event"),
                "next_action": result.get("next_action"),
                "booked_slot": result.get("booked_slot"),
            }

        except Exception as e:
            logger.error("Engine error for %s/%s: %s", client_id, sender_phone, e)
            return {
                "reply": "Sorry, something went wrong. Please try again in a moment.",
                "lead_data": {},
                "billing_event": None,
                "next_action": None,
                "booked_slot": None,
            }

    async def _handle_visit_booked(
        self,
        db: AsyncSession,
        client_config,
        client_id: str,
        lead_id: str,
        lead_data: dict,
        booked_slot: str,
    ) -> None:
        """
        Close the booking loop after a lead confirms a site visit:
          1. Write the site_visit_booked billing event (powers digests/metrics)
          2. Create the Google Calendar event (best-effort, only when the
             slot parses to an unambiguous datetime)
          3. Alert the brokers — the one step that must not silently fail
        """
        # 1. Billing/metrics event — the DB unique index is the source of
        # truth for "first booking". If this is a duplicate (e.g. the stage
        # write failed last turn and the lead confirmed again), skip ALL
        # side effects: brokers were already alerted the first time.
        try:
            written = await write_billing_event(
                db,
                client_id=client_id,
                lead_id=lead_id,
                event_type="site_visit_booked",
                metadata={"slot": booked_slot},
            )
            if written is None:
                logger.info(
                    "[router] site_visit_booked for lead %s is a duplicate — skipping side effects",
                    lead_id,
                )
                return
        except Exception as e:
            # Transient write failure: proceed with broker alert anyway —
            # a missing metric beats a lead nobody meets at the site office.
            logger.critical(
                "[router] site_visit_booked event write FAILED for %s: %s — "
                "metrics will undercount; proceeding with broker alert.",
                lead_id, e,
            )

        # 2. Calendar event (best-effort; never guess an ambiguous time)
        calendar_link = None
        calendar_id = getattr(client_config, "google_calendar_id", None)
        if calendar_id:
            try:
                from src.scheduler.calendar import parse_slot_to_datetime, create_site_visit
                visit_time = parse_slot_to_datetime(booked_slot)
                if visit_time:
                    created = await create_site_visit(
                        calendar_id=calendar_id,
                        lead=lead_data,
                        visit_time=visit_time,
                    )
                    if created:
                        calendar_link = created.get("html_link")
                else:
                    logger.info(
                        "[router] Slot '%s' too ambiguous for a calendar event — "
                        "broker alert carries the raw text instead", booked_slot,
                    )
            except Exception as e:
                logger.warning("[router] Calendar event creation failed: %s", e)

        # 3. Broker alert — the business-critical step
        await notify_visit_booked(
            client_config=client_config,
            lead=lead_data,
            slot_text=booked_slot,
            calendar_link=calendar_link,
        )
        logger.info(
            "[router] Booking loop closed for lead %s (slot: %s, calendar=%s)",
            lead_id, booked_slot, "yes" if calendar_link else "no",
        )

    async def _persist_engine_results(
        self,
        db: AsyncSession,
        client_id: str,
        lead_id: str,
        engine_result: dict,
    ) -> bool:
        """
        Persist lead scoring, stage updates, and billing events to DB.
        Called after graph.invoke() completes.

        Returns True if a billing event was actually written (i.e. this is
        genuinely the lead's first transition to HOT).
        """
        lead_data = engine_result.get("lead_data", {})

        # Update lead with any scoring data from the engine
        update_fields = {}
        for field in ("name", "score", "tier", "stage", "intent", "language_pref",
                      "budget_min", "budget_max", "timeline_months", "urgency",
                      "financing_status", "location_preferences", "property_type",
                      "family_size"):
            if field in lead_data and lead_data[field] is not None:
                update_fields[field] = lead_data[field]

        if update_fields:
            try:
                await update_lead(db, client_id, lead_id, update_fields)
                logger.info("[router] Updated lead %s with %d fields", lead_id, len(update_fields))
            except Exception as e:
                logger.error("[router] Failed to update lead %s: %s", lead_id, e)

        # Write billing event for HOT leads
        billing_event = engine_result.get("billing_event")
        if billing_event:
            try:
                written = await write_billing_event(
                    db,
                    client_id=client_id,
                    lead_id=lead_id,
                    event_type=billing_event["event_type"],
                    metadata=billing_event.get("metadata"),
                )
                if written is None:
                    logger.info(
                        "[router] Billing event for lead %s rejected as duplicate (already billed)",
                        lead_id,
                    )
                    return False
                logger.info("[router] Billing event written: %s for lead %s",
                           billing_event["event_type"], lead_id)
                return True
            except Exception as e:
                # Transient failure (NOT a duplicate): the lead's hot tier was
                # already persisted above, so the scorer will never re-fire this
                # event. Returning False here would also suppress the broker
                # notification forever. Notify anyway and scream for ops to
                # re-bill manually — losing revenue beats losing the lead.
                logger.critical(
                    "[router] BILLING EVENT LOST for lead %s (%s) — write failed: %s. "
                    "Bill manually and investigate.",
                    lead_id, billing_event.get("event_type"), e,
                )
                return True
        return False
