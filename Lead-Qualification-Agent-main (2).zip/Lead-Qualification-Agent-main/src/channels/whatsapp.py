"""
WhatsApp Cloud API channel — verify, receive, send.
Each client has their own WABA credentials. Never use a global token.
Tokens may arrive encrypted ("enc::...") — decrypted at point of use.
"""
import asyncio as _asyncio
import hashlib
import hmac
import logging
from datetime import datetime, timezone

import httpx

from src.config import get_settings
from src.core.crypto import decrypt_token
from src.models.message import UnifiedMessage

logger = logging.getLogger(__name__)


def _resolve_token(waba_token: str | None) -> str:
    """
    Tokens are stored encrypted ("enc::...") in the DB. Depending on the code
    path (DB read vs Redis cache vs cron), callers may pass either form.
    Decrypt here — single point of truth — so every API call uses plaintext.
    decrypt_token() is a no-op for already-plaintext tokens.
    """
    return decrypt_token(waba_token) or waba_token or ""

META_API_BASE = "https://graph.facebook.com/v21.0"
MAX_RETRIES = 3
RETRY_BASE_DELAY = 1  # seconds

_MAX_SEND_RETRIES = 3
_RETRY_BACKOFF_BASE = 1.0


async def _retry_request(coro_factory, max_retries=_MAX_SEND_RETRIES):
    """Retry an async HTTP request with exponential backoff on 429/5xx."""
    last_error = None
    for attempt in range(max_retries):
        try:
            resp = await coro_factory()
            if resp.status_code == 429 or resp.status_code >= 500:
                last_error = Exception(f"HTTP {resp.status_code}: {resp.text[:200]}")
                if attempt < max_retries - 1:
                    wait = _RETRY_BACKOFF_BASE * (2 ** attempt)
                    logger.warning("[whatsapp] Retrying send (attempt %d/%d, status=%d), wait %.1fs", attempt+1, max_retries, resp.status_code, wait)
                    await _asyncio.sleep(wait)
                    continue
            return resp
        except httpx.HTTPError as e:
            last_error = e
            if attempt < max_retries - 1:
                wait = _RETRY_BACKOFF_BASE * (2 ** attempt)
                logger.warning("[whatsapp] HTTP error, retrying (attempt %d/%d): %s", attempt+1, max_retries, e)
                await _asyncio.sleep(wait)
                continue
            raise
    raise last_error


class WhatsAppChannel:
    """WhatsApp Cloud API wrapper — multi-tenant (per-client tokens)."""

    # ── Webhook verification ──────────────────────────────────────────────

    @staticmethod
    def verify_webhook(mode: str, token: str, challenge: str) -> str | None:
        """
        GET /webhook/whatsapp — Meta sends this to verify the endpoint.
        Returns the challenge string if token matches, else None.
        """
        settings = get_settings()
        if mode == "subscribe" and token == settings.whatsapp_verify_token:
            logger.info("Webhook verified successfully")
            return challenge
        logger.warning("Webhook verification failed: mode=%s", mode)
        return None

    # ── Inbound message parsing ───────────────────────────────────────────

    @staticmethod
    def parse_webhook_payload(payload: dict) -> dict | None:
        """
        Parse Meta's webhook payload into structured data.

        Returns dict with keys:
            waba_phone_number_id, sender_phone, text, message_type,
            media_id, message_id, timestamp
        Or None if the payload is a status update (delivered/read) or unparseable.
        """
        try:
            entry = payload.get("entry", [])
            if not entry:
                return None

            changes = entry[0].get("changes", [])
            if not changes:
                return None

            value = changes[0].get("value", {})

            # Extract WABA phone number ID (the routing key)
            metadata = value.get("metadata", {})
            waba_phone_number_id = metadata.get("phone_number_id")
            if not waba_phone_number_id:
                logger.warning("No phone_number_id in webhook payload")
                return None

            # Check if this is a status update (delivered/read) — acknowledge but don't process
            if "statuses" in value:
                logger.debug("Status update received, skipping: %s", value["statuses"])
                return None

            # Extract contact name (WhatsApp profile name)
            contacts = value.get("contacts", [])
            sender_name = None
            if contacts:
                sender_name = contacts[0].get("profile", {}).get("name")

            # Extract the actual message
            messages = value.get("messages", [])
            if not messages:
                return None

            msg = messages[0]
            sender_phone = msg.get("from", "")
            message_id = msg.get("id", "")
            msg_timestamp = msg.get("timestamp", "")
            msg_type = msg.get("type", "text")

            # Parse text based on message type
            text = ""
            media_id = None
            message_type = "text"

            if msg_type == "text":
                text = msg.get("text", {}).get("body", "")
                message_type = "text"
            elif msg_type == "audio":
                media_id = msg.get("audio", {}).get("id")
                message_type = "audio"
                text = "[voice note]"
            elif msg_type == "image":
                media_id = msg.get("image", {}).get("id")
                message_type = "image"
                text = msg.get("image", {}).get("caption", "[image]")
            elif msg_type == "document":
                media_id = msg.get("document", {}).get("id")
                message_type = "document"
                text = msg.get("document", {}).get("caption", "[document]")
            elif msg_type == "interactive":
                # Button replies or list replies
                interactive = msg.get("interactive", {})
                if interactive.get("type") == "button_reply":
                    text = interactive.get("button_reply", {}).get("title", "")
                elif interactive.get("type") == "list_reply":
                    text = interactive.get("list_reply", {}).get("title", "")
                message_type = "text"
            else:
                logger.info("Unsupported message type: %s", msg_type)
                text = f"[{msg_type}]"
                message_type = "text"

            # Parse timestamp
            try:
                ts = datetime.fromtimestamp(int(msg_timestamp))
            except (ValueError, TypeError):
                ts = datetime.now(timezone.utc)

            return {
                "waba_phone_number_id": waba_phone_number_id,
                "sender_phone": sender_phone,
                "sender_name": sender_name,
                "text": text,
                "message_type": message_type,
                "media_id": media_id,
                "message_id": message_id,
                "timestamp": ts,
            }

        except (IndexError, KeyError, TypeError) as e:
            logger.error("Failed to parse webhook payload: %s", e)
            return None

    @staticmethod
    def to_unified_message(parsed: dict) -> UnifiedMessage:
        """Convert parsed webhook data to a UnifiedMessage."""
        return UnifiedMessage(
            channel="whatsapp",
            direction="inbound",
            sender_id=parsed["sender_phone"],
            content=parsed["text"],
            message_type=parsed["message_type"],
            channel_message_id=parsed["message_id"],
            timestamp=parsed["timestamp"],
            metadata={
                "waba_phone_number_id": parsed["waba_phone_number_id"],
                "media_id": parsed.get("media_id"),
            },
        )

    # ── Outbound messaging ────────────────────────────────────────────────

    @staticmethod
    async def send_message(
        waba_phone_number_id: str,
        waba_token: str,
        to: str,
        content: str,
    ) -> bool:
        """
        Send a text message via WhatsApp Cloud API.
        Uses the CLIENT's WABA credentials — NOT a global token.
        Retries on 5xx with exponential backoff (3 attempts).
        """
        url = f"{META_API_BASE}/{waba_phone_number_id}/messages"
        headers = {
            "Authorization": f"Bearer {_resolve_token(waba_token)}",
            "Content-Type": "application/json",
        }
        body = {
            "messaging_product": "whatsapp",
            "recipient_type": "individual",
            "to": to,
            "type": "text",
            "text": {"preview_url": False, "body": content},
        }

        try:
            async with httpx.AsyncClient(timeout=30) as client:
                resp = await _retry_request(lambda: client.post(url, json=body, headers=headers))

            if resp.status_code < 300:
                logger.info("Message sent to %s", to)
                return True

            logger.error(
                "Meta API error %d sending to %s: %s",
                resp.status_code, to, resp.text,
            )
            return False
        except (httpx.HTTPError, Exception) as e:
            logger.error("Failed to send message to %s after retries: %s", to, e)
            return False

    @staticmethod
    async def send_document(
        waba_phone_number_id: str,
        waba_token: str,
        to: str,
        document_url: str | None = None,
        media_id: str | None = None,
        filename: str = "brochure.pdf",
        caption: str | None = None,
    ) -> bool:
        """
        Send a PDF (or any document) via WhatsApp Cloud API.

        Provide EITHER document_url (publicly reachable HTTPS URL) OR media_id
        (returned from a prior /media upload).  URL is the simpler path.
        """
        if not document_url and not media_id:
            logger.error("send_document called without document_url or media_id")
            return False

        url = f"{META_API_BASE}/{waba_phone_number_id}/messages"
        headers = {
            "Authorization": f"Bearer {_resolve_token(waba_token)}",
            "Content-Type": "application/json",
        }
        doc_payload: dict = {"filename": filename}
        if document_url:
            doc_payload["link"] = document_url
        else:
            doc_payload["id"] = media_id
        if caption:
            doc_payload["caption"] = caption

        body = {
            "messaging_product": "whatsapp",
            "recipient_type": "individual",
            "to": to,
            "type": "document",
            "document": doc_payload,
        }

        try:
            async with httpx.AsyncClient(timeout=30) as client:
                resp = await _retry_request(lambda: client.post(url, json=body, headers=headers))
            if resp.status_code < 300:
                logger.info("Document sent to %s (filename=%s)", to, filename)
                return True
            logger.error(
                "Meta API error %d sending document to %s: %s",
                resp.status_code, to, resp.text,
            )
            return False
        except (httpx.HTTPError, Exception) as e:
            logger.error("HTTP error sending document: %s", e)
            return False

    @staticmethod
    async def send_image(
        waba_phone_number_id: str,
        waba_token: str,
        to: str,
        image_url: str | None = None,
        media_id: str | None = None,
        caption: str | None = None,
    ) -> bool:
        """
        Send an image via WhatsApp Cloud API.

        Provide EITHER image_url (publicly reachable HTTPS URL) OR media_id
        (returned from a prior /media upload).

        Use for: property photos, floor plans, site images.
        """
        if not image_url and not media_id:
            logger.error("send_image called without image_url or media_id")
            return False

        url = f"{META_API_BASE}/{waba_phone_number_id}/messages"
        headers = {
            "Authorization": f"Bearer {_resolve_token(waba_token)}",
            "Content-Type": "application/json",
        }
        image_payload: dict = {}
        if image_url:
            image_payload["link"] = image_url
        else:
            image_payload["id"] = media_id
        if caption:
            image_payload["caption"] = caption

        body = {
            "messaging_product": "whatsapp",
            "recipient_type": "individual",
            "to": to,
            "type": "image",
            "image": image_payload,
        }

        try:
            async with httpx.AsyncClient(timeout=30) as client:
                resp = await _retry_request(lambda: client.post(url, json=body, headers=headers))

            if resp.status_code < 300:
                logger.info("Image sent to %s", to)
                return True

            logger.error(
                "Meta API error %d sending image to %s: %s",
                resp.status_code, to, resp.text,
            )
            return False
        except (httpx.HTTPError, Exception) as e:
            logger.error("Failed to send image to %s after retries: %s", to, e)
            return False

    @staticmethod
    async def upload_media(
        waba_phone_number_id: str,
        waba_token: str,
        file_path: str,
        mime_type: str = "application/pdf",
    ) -> str | None:
        """
        Upload a local file to Meta's media endpoint.

        Returns the media_id on success — pass it to send_document(media_id=...).
        Use this when you don't have a public HTTPS URL for the file.
        """
        from pathlib import Path
        p = Path(file_path)
        if not p.exists():
            logger.error("upload_media: file not found: %s", file_path)
            return None

        url = f"{META_API_BASE}/{waba_phone_number_id}/media"
        headers = {"Authorization": f"Bearer {_resolve_token(waba_token)}"}
        try:
            async with httpx.AsyncClient(timeout=60) as client:
                with open(p, "rb") as f:
                    files = {
                        "file": (p.name, f, mime_type),
                        "type": (None, mime_type),
                        "messaging_product": (None, "whatsapp"),
                    }
                    resp = await client.post(url, headers=headers, files=files)
            if resp.status_code < 300:
                media_id = resp.json().get("id")
                logger.info("Media uploaded (id=%s, file=%s)", media_id, p.name)
                return media_id
            logger.error("Media upload failed %d: %s", resp.status_code, resp.text)
            return None
        except (httpx.HTTPError, OSError) as e:
            logger.error("upload_media error: %s", e)
            return None

    @staticmethod
    async def send_template_message(
        waba_phone_number_id: str,
        waba_token: str,
        to: str,
        template_name: str,
        language_code: str = "en",
        components: list[dict] | None = None,
    ) -> bool:
        """Send a template message (used for broker notifications)."""
        url = f"{META_API_BASE}/{waba_phone_number_id}/messages"
        headers = {
            "Authorization": f"Bearer {_resolve_token(waba_token)}",
            "Content-Type": "application/json",
        }
        template = {
            "name": template_name,
            "language": {"code": language_code},
        }
        if components:
            template["components"] = components

        body = {
            "messaging_product": "whatsapp",
            "to": to,
            "type": "template",
            "template": template,
        }

        try:
            async with httpx.AsyncClient(timeout=30) as client:
                resp = await _retry_request(lambda: client.post(url, json=body, headers=headers))
            if resp.status_code < 300:
                logger.info("Template '%s' sent to %s", template_name, to)
                return True
            logger.error("Template send failed %d: %s", resp.status_code, resp.text)
            return False
        except (httpx.HTTPError, Exception) as e:
            logger.error("HTTP error sending template: %s", e)
            return False

    @staticmethod
    async def mark_as_read(
        waba_phone_number_id: str,
        waba_token: str,
        message_id: str,
    ) -> bool:
        """Send a read receipt for the given message."""
        url = f"{META_API_BASE}/{waba_phone_number_id}/messages"
        headers = {
            "Authorization": f"Bearer {_resolve_token(waba_token)}",
            "Content-Type": "application/json",
        }
        body = {
            "messaging_product": "whatsapp",
            "status": "read",
            "message_id": message_id,
        }

        try:
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.post(url, json=body, headers=headers)
            return resp.status_code < 300
        except httpx.HTTPError:
            return False

    # ── Signature verification ────────────────────────────────────────────

    @staticmethod
    def verify_signature(payload_bytes: bytes, signature: str, app_secret: str) -> bool:
        """
        Validate X-Hub-Signature-256 header from Meta.
        Returns True if signature is valid.
        """
        if not signature or not signature.startswith("sha256="):
            return False
        expected = hmac.new(
            app_secret.encode(), payload_bytes, hashlib.sha256
        ).hexdigest()
        return hmac.compare_digest(f"sha256={expected}", signature)