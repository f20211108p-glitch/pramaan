from pydantic_settings import BaseSettings, SettingsConfigDict
from functools import lru_cache
from pathlib import Path

# Always resolve .env relative to this file's location (project root)
_ENV_FILE = Path(__file__).parent.parent / ".env"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=str(_ENV_FILE), extra="ignore", env_ignore_empty=True)

    # Database
    database_url: str = "postgresql+asyncpg://lead:leadpass@localhost:5432/leadengine"

    # Redis
    redis_url: str = "redis://localhost:6379/0"

    # LLM
    anthropic_api_key: str = ""
    openai_api_key: str = ""

    # WhatsApp
    whatsapp_verify_token: str = "leadengine_verify_2026"
    # Meta App Secret — used to verify X-Hub-Signature-256 on inbound webhooks.
    # REQUIRED in production. When empty, signature verification is skipped.
    meta_app_secret: str = ""

    # Langfuse
    langfuse_public_key: str = ""
    langfuse_secret_key: str = ""
    langfuse_host: str = "http://localhost:3001"

    # Google Calendar (optional — for site visit booking)
    google_calendar_credentials_path: str = ""

    # Observability
    sentry_dsn: str = ""  # optional — error tracking via Sentry when set

    # App
    app_env: str = "dev"
    log_level: str = "INFO"
    secret_key: str = "change_me_in_production"
    encryption_salt: str = ""  # PBKDF2 salt for token encryption (leave empty for default)

    # CORS
    cors_origins: str = ""  # comma-separated list of allowed origins (empty = use defaults)

    # Webhook processing mode: "async" (default, uses Redis worker) or "sync" (dev only)
    webhook_mode: str = "async"

    # Supabase (storage for brochures)
    supabase_url: str = ""
    supabase_service_key: str = ""

    # Default brochure fallback (used when client_config has no brochure configured)
    default_brochure_url: str = ""
    default_brochure_path: str = ""
    default_brochure_filename: str = "brochure.pdf"

    # Whisper STT (self-hosted via docker-whisper)
    whisper_url: str = "http://localhost:9000"

    # LiveKit (voice agent + outbound calls)
    livekit_url: str = "http://localhost:7880"
    livekit_api_key: str = ""
    livekit_api_secret: str = ""

    # SIP trunk (provider-agnostic — configure for Twilio, Exotel, etc.)
    sip_trunk_id: str = ""          # LiveKit SIP trunk ID (created via API)
    sip_trunk_outbound_uri: str = ""  # e.g., "sip:+911234567890@sip.exotel.com"
    sip_trunk_username: str = ""
    sip_trunk_password: str = ""

    # Voice agent
    voice_agent_caller_id: str = ""   # Outbound caller ID (your DID number)
    voice_followup_delay_hours: int = 4  # Hours without WhatsApp reply before auto-call

    @property
    def is_production(self) -> bool:
        return self.app_env == "production"


@lru_cache
def get_settings() -> Settings:
    return Settings()
