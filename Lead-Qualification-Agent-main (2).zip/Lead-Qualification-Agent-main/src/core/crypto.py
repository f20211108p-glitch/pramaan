"""
Token encryption for sensitive fields stored in the database.

Uses Fernet symmetric encryption (AES-128-CBC + HMAC-SHA256).
The encryption key is derived from SECRET_KEY via PBKDF2.

Fields encrypted: client_config.waba_token, client_config.crm_token
"""
import base64
import hashlib
import logging
from functools import lru_cache

from cryptography.fernet import Fernet, InvalidToken

from src.config import get_settings

logger = logging.getLogger(__name__)

# Prefix to identify encrypted values (so we don't double-encrypt)
_ENCRYPTED_PREFIX = "enc::"


@lru_cache
def _get_fernet() -> Fernet:
    """Derive a Fernet key from SECRET_KEY using PBKDF2."""
    settings = get_settings()
    # PBKDF2 with SHA256 to derive a 32-byte key, then base64-encode for Fernet
    # Salt from env (ENCRYPTION_SALT) or fallback for backward compat
    salt = getattr(settings, "encryption_salt", None) or "leadengine_token_encryption_salt"
    key = hashlib.pbkdf2_hmac(
        "sha256",
        settings.secret_key.encode("utf-8"),
        salt.encode("utf-8"),
        iterations=100_000,
    )
    # Fernet needs a 32-byte key, base64url-encoded
    fernet_key = base64.urlsafe_b64encode(key[:32])
    return Fernet(fernet_key)


def encrypt_token(plaintext: str | None) -> str | None:
    """Encrypt a token for storage. Returns None if input is None/empty."""
    if not plaintext:
        return plaintext
    if plaintext.startswith(_ENCRYPTED_PREFIX):
        return plaintext  # Already encrypted
    f = _get_fernet()
    encrypted = f.encrypt(plaintext.encode("utf-8"))
    return _ENCRYPTED_PREFIX + encrypted.decode("utf-8")


def decrypt_token(ciphertext: str | None) -> str | None:
    """Decrypt a stored token. Returns the original if not encrypted (migration-safe)."""
    if not ciphertext:
        return ciphertext
    if not ciphertext.startswith(_ENCRYPTED_PREFIX):
        # Not encrypted — return as-is (backward compat with existing plaintext tokens)
        return ciphertext
    f = _get_fernet()
    try:
        encrypted_bytes = ciphertext[len(_ENCRYPTED_PREFIX):].encode("utf-8")
        return f.decrypt(encrypted_bytes).decode("utf-8")
    except InvalidToken:
        logger.error("[crypto] Failed to decrypt token — key may have changed")
        return None
