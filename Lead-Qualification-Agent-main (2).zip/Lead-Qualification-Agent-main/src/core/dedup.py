"""
Redis-based message deduplication.
WhatsApp may deliver the same webhook multiple times — this prevents double-processing.
"""
import logging

from src.core.redis import get_redis

logger = logging.getLogger(__name__)

DEDUP_TTL = 86400  # 24 hours


async def is_duplicate(message_id: str) -> bool:
    """
    Check if a message has already been processed.

    Uses Redis SET NX EX:
    - If the key does NOT exist → sets it with 24h TTL → returns False (new message)
    - If the key DOES exist → returns True (duplicate, skip)
    """
    if not message_id:
        return False  # no message_id = can't dedup, process it

    redis = get_redis()
    key = f"dedup:{message_id}"

    # SET NX returns True if key was set (new), False if already exists (duplicate)
    was_set = await redis.set(key, "1", nx=True, ex=DEDUP_TTL)

    if not was_set:
        logger.info("Duplicate message detected: %s", message_id)
        return True

    return False
