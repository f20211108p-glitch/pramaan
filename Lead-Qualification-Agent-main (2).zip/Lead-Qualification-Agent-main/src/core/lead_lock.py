"""
Per-lead processing lock — serializes message processing for a single lead.

Why this exists:
  Two rapid messages from the same lead (or a reclaimed stale message)
  can be processed by two workers concurrently. Both read the same lead
  row, both run the graph, both write back → lost field updates, two
  contradictory replies, and a race in the hot-tier billing dedup.

Implementation:
  Redis SET NX EX with a unique token, released via a compare-and-delete
  Lua script (so a worker can never release a lock it no longer owns
  after expiry). Waiters poll with backoff up to `wait_timeout`; if the
  lock can't be acquired in time we proceed anyway (fail-open) — an
  occasional race beats dropping a lead's message.
"""
import asyncio
import logging
import uuid
from contextlib import asynccontextmanager

from src.core.redis import get_redis

logger = logging.getLogger(__name__)

# Lock auto-expires after this long even if the holder crashes mid-graph.
LOCK_TTL_SECONDS = 90
# How long a second message waits for the first to finish processing.
# Workers (async mode) can afford a long wait; sync-mode webhooks must stay
# well under Meta's 20s timeout — callers pass wait_timeout accordingly.
WAIT_TIMEOUT_SECONDS = 60
POLL_INTERVAL_SECONDS = 0.5

# Compare-and-delete: only release if we still own the lock.
_RELEASE_LUA = """
if redis.call("get", KEYS[1]) == ARGV[1] then
    return redis.call("del", KEYS[1])
else
    return 0
end
"""


@asynccontextmanager
async def lead_lock(client_key: str, lead_phone: str, wait_timeout: float | None = None):
    """
    Async context manager serializing processing per (client, lead).

    Usage:
        async with lead_lock(waba_phone_number_id, sender_phone):
            ... process message ...

    Never raises on Redis failure — degrades to unlocked processing.
    """
    key = f"lock:lead:{client_key}:{lead_phone}"
    token = uuid.uuid4().hex
    acquired = False
    timeout = WAIT_TIMEOUT_SECONDS if wait_timeout is None else wait_timeout

    try:
        redis = get_redis()
        deadline = asyncio.get_running_loop().time() + timeout
        while True:
            acquired = bool(await redis.set(key, token, nx=True, ex=LOCK_TTL_SECONDS))
            if acquired:
                break
            if asyncio.get_running_loop().time() >= deadline:
                logger.warning(
                    "[lead_lock] Timed out waiting for %s — proceeding WITHOUT lock",
                    key,
                )
                break
            await asyncio.sleep(POLL_INTERVAL_SECONDS)
    except Exception as e:
        logger.warning("[lead_lock] Redis unavailable (%s) — proceeding without lock", e)

    try:
        yield
    finally:
        if acquired:
            try:
                redis = get_redis()
                await redis.eval(_RELEASE_LUA, 1, key, token)
            except Exception as e:
                logger.warning("[lead_lock] Release failed for %s: %s (TTL will expire it)", key, e)
