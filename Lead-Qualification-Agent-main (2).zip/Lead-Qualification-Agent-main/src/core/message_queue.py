"""
Redis Streams-based message queue for async message processing.

Instead of processing messages synchronously inside the webhook handler
(which risks Meta's 20-second timeout), we:

1. Webhook receives message → validates → pushes to Redis stream → returns 200 immediately
2. Background worker pulls from stream → processes through LangGraph → sends reply

Uses Redis Streams (XADD/XREADGROUP) for reliable at-least-once delivery:
- Stream key: "mq:{client_id}" (per-client streams)
- Consumer group: "engine_workers"
- Each worker: unique consumer name
- Failed messages can be reclaimed via XPENDING + XCLAIM

Architecture:
  ┌──────────┐   XADD    ┌──────────┐   XREADGROUP   ┌──────────┐
  │ Webhook  │ ────────→ │  Redis   │ ──────────────→ │  Worker  │
  │ (fast)   │           │  Stream  │                 │ (async)  │
  └──────────┘           └──────────┘                 └──────────┘
       ↓                                                   ↓
    200 OK                                            LangGraph +
   (< 1 sec)                                         send reply
"""
import json
import logging
import time
from typing import Any

import redis.asyncio as aioredis

from src.core.redis import get_redis

logger = logging.getLogger(__name__)

# Stream configuration
STREAM_PREFIX = "mq:messages"  # single stream for all clients
CONSUMER_GROUP = "engine_workers"
MAX_STREAM_LEN = 10_000  # cap stream length (auto-trim oldest)
CLAIM_TIMEOUT_MS = 300_000  # 5 minutes — reclaim stuck messages after this


async def ensure_consumer_group() -> None:
    """
    Create the consumer group if it doesn't exist.
    Call once at startup.
    """
    redis = get_redis()
    try:
        await redis.xgroup_create(
            STREAM_PREFIX, CONSUMER_GROUP,
            id="0",        # start from beginning
            mkstream=True,  # create stream if it doesn't exist
        )
        logger.info("[mq] Consumer group '%s' created on stream '%s'", CONSUMER_GROUP, STREAM_PREFIX)
    except aioredis.ResponseError as e:
        if "BUSYGROUP" in str(e):
            # Group already exists — that's fine
            pass
        else:
            raise


async def enqueue_message(
    client_id: str,
    payload: dict,
) -> str:
    """
    Push a message onto the Redis stream for async processing.

    Args:
        client_id: tenant ID (included in the stream entry for routing)
        payload: the raw WhatsApp webhook payload (already parsed)

    Returns:
        The Redis stream entry ID (e.g., "1234567890-0")
    """
    redis = get_redis()

    entry = {
        "client_id": client_id,
        "payload": json.dumps(payload),
        "enqueued_at": str(time.time()),
    }

    entry_id = await redis.xadd(
        STREAM_PREFIX,
        entry,
        maxlen=MAX_STREAM_LEN,
        approximate=True,  # ~ is faster than exact maxlen
    )

    logger.info("[mq] Enqueued message for client %s, entry_id=%s", client_id[:8], entry_id)
    return entry_id


async def dequeue_messages(
    consumer_name: str,
    count: int = 10,
    block_ms: int = 5000,
) -> list[dict[str, Any]]:
    """
    Pull messages from the stream as a consumer in the group.

    Args:
        consumer_name: unique name for this worker (e.g., "worker-1")
        count: max messages to read at once
        block_ms: how long to block waiting for new messages (milliseconds)

    Returns:
        List of {entry_id, client_id, payload, enqueued_at}
    """
    redis = get_redis()

    try:
        results = await redis.xreadgroup(
            CONSUMER_GROUP,
            consumer_name,
            {STREAM_PREFIX: ">"},  # ">" = only new, undelivered messages
            count=count,
            block=block_ms,
        )
    except aioredis.ResponseError as e:
        if "NOGROUP" in str(e):
            await ensure_consumer_group()
            return []
        raise

    if not results:
        return []

    messages = []
    for stream_name, entries in results:
        for entry_id, data in entries:
            try:
                messages.append({
                    "entry_id": entry_id,
                    "client_id": data.get("client_id", ""),
                    "payload": json.loads(data.get("payload", "{}")),
                    "enqueued_at": float(data.get("enqueued_at", 0)),
                })
            except (json.JSONDecodeError, ValueError) as e:
                logger.error("[mq] Failed to parse entry %s: %s", entry_id, e)
                # Ack the bad message so it doesn't block the queue
                await ack_message(entry_id)

    return messages


async def ack_message(entry_id: str) -> None:
    """
    Acknowledge a message as successfully processed.
    This removes it from the pending entries list (PEL).
    """
    redis = get_redis()
    await redis.xack(STREAM_PREFIX, CONSUMER_GROUP, entry_id)
    logger.debug("[mq] Acked entry %s", entry_id)


async def get_pending_count() -> int:
    """Get the number of messages pending (delivered but not acked)."""
    redis = get_redis()
    try:
        info = await redis.xpending(STREAM_PREFIX, CONSUMER_GROUP)
        return info.get("pending", 0) if isinstance(info, dict) else 0
    except aioredis.ResponseError:
        return 0


async def get_stream_length() -> int:
    """Get the total number of entries in the stream."""
    redis = get_redis()
    try:
        return await redis.xlen(STREAM_PREFIX)
    except aioredis.ResponseError:
        return 0


async def reclaim_stale_messages(
    consumer_name: str,
    max_count: int = 10,
) -> list[dict[str, Any]]:
    """
    Reclaim messages that have been pending too long (consumer crashed).

    Uses XAUTOCLAIM to atomically find and reassign stale messages.

    Args:
        consumer_name: the worker claiming the messages
        max_count: max messages to reclaim

    Returns:
        List of reclaimed messages (same format as dequeue_messages)
    """
    redis = get_redis()
    try:
        # XAUTOCLAIM: find pending msgs idle > CLAIM_TIMEOUT_MS and assign to us
        result = await redis.xautoclaim(
            STREAM_PREFIX,
            CONSUMER_GROUP,
            consumer_name,
            min_idle_time=CLAIM_TIMEOUT_MS,
            start_id="0-0",
            count=max_count,
        )

        # result format: [next_start_id, [(id, data), ...], [deleted_ids]]
        if not result or len(result) < 2:
            return []

        entries = result[1]
        messages = []
        for entry_id, data in entries:
            try:
                messages.append({
                    "entry_id": entry_id,
                    "client_id": data.get("client_id", ""),
                    "payload": json.loads(data.get("payload", "{}")),
                    "enqueued_at": float(data.get("enqueued_at", 0)),
                })
            except (json.JSONDecodeError, ValueError):
                await ack_message(entry_id)

        if messages:
            logger.info("[mq] Reclaimed %d stale messages", len(messages))
        return messages

    except aioredis.ResponseError as e:
        logger.warning("[mq] XAUTOCLAIM failed: %s", e)
        return []


# ── Dead-Letter Queue ─────────────────────────────────────────────────────────

DLQ_STREAM = "mq:dlq"
DLQ_MAX_LEN = 5_000


async def send_to_dlq(
    entry_id: str,
    client_id: str,
    payload: dict,
    error: str,
    worker_name: str = "unknown",
) -> str | None:
    """
    Move a failed message to the dead-letter queue for inspection/replay.

    Args:
        entry_id: original stream entry ID
        client_id: tenant ID
        payload: the original webhook payload
        error: the error message/traceback
        worker_name: which worker failed

    Returns:
        DLQ entry ID, or None on failure.
    """
    redis = get_redis()
    try:
        dlq_entry = {
            "original_entry_id": entry_id,
            "client_id": client_id,
            "payload": json.dumps(payload),
            "error": error[:2000],  # cap error string
            "worker": worker_name,
            "failed_at": str(time.time()),
        }
        dlq_id = await redis.xadd(DLQ_STREAM, dlq_entry, maxlen=DLQ_MAX_LEN, approximate=True)
        logger.warning("[mq] Sent entry %s to DLQ as %s (error: %.100s)", entry_id, dlq_id, error)
        return dlq_id
    except Exception as e:
        logger.error("[mq] Failed to send to DLQ: %s", e)
        return None


async def get_dlq_messages(count: int = 50) -> list[dict]:
    """Read recent DLQ entries (for admin API inspection)."""
    redis = get_redis()
    try:
        entries = await redis.xrevrange(DLQ_STREAM, count=count)
        return [
            {
                "dlq_id": entry_id,
                "original_entry_id": data.get("original_entry_id", ""),
                "client_id": data.get("client_id", ""),
                "error": data.get("error", ""),
                "worker": data.get("worker", ""),
                "failed_at": data.get("failed_at", ""),
            }
            for entry_id, data in entries
        ]
    except Exception:
        return []


async def replay_dlq_message(dlq_id: str) -> dict | None:
    """
    Re-enqueue a DLQ message back onto the main stream for retry.
    Returns the re-enqueued entry or None.
    """
    redis = get_redis()
    try:
        entries = await redis.xrange(DLQ_STREAM, min=dlq_id, max=dlq_id, count=1)
        if not entries:
            return None

        _, data = entries[0]
        payload = json.loads(data.get("payload", "{}"))
        client_id = data.get("client_id", "unknown")

        # Re-enqueue on the main stream
        new_id = await enqueue_message(client_id, payload)

        # Remove from DLQ
        await redis.xdel(DLQ_STREAM, dlq_id)

        logger.info("[mq] Replayed DLQ %s → main stream %s", dlq_id, new_id)
        return {"dlq_id": dlq_id, "new_entry_id": new_id, "client_id": client_id}
    except Exception as e:
        logger.error("[mq] Failed to replay DLQ message %s: %s", dlq_id, e)
        return None


async def get_dlq_count() -> int:
    """Get the number of messages in the DLQ."""
    redis = get_redis()
    try:
        return await redis.xlen(DLQ_STREAM)
    except Exception:
        return 0
