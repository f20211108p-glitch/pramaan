"""
Per-lead rate limiting using Redis sliding window.

Prevents a single aggressive lead from costing ₹50 in 10 minutes
by capping messages per lead per time window.

Also provides per-client rate limiting to protect against
property-launch-day traffic spikes (500+ msgs/hour).
"""
import logging
import time

from src.core.redis import get_redis

logger = logging.getLogger(__name__)

# ── Configuration ─────────────────────────────────────────────────────────────

# Per-lead: max N messages in WINDOW seconds
LEAD_MAX_MESSAGES = 10
LEAD_WINDOW_SECONDS = 60  # 1 minute

# Per-client: max N messages total in WINDOW seconds (across all leads)
CLIENT_MAX_MESSAGES = 200
CLIENT_WINDOW_SECONDS = 300  # 5 minutes


async def check_rate_limit(
    client_id: str,
    lead_phone: str,
    max_messages: int = LEAD_MAX_MESSAGES,
    window_seconds: int = LEAD_WINDOW_SECONDS,
) -> bool:
    """
    Check if a lead has exceeded the message rate limit.

    Uses a Redis sorted set as a sliding window counter.
    Each message is scored by its timestamp. We remove entries
    older than the window, then count remaining.

    Args:
        client_id: tenant ID
        lead_phone: lead's phone number
        max_messages: max messages allowed in window (default 3)
        window_seconds: window size in seconds (default 300 = 5 min)

    Returns:
        True if the message is allowed (under limit).
        False if the rate limit is exceeded (should throttle).
    """
    redis = get_redis()
    key = f"rate:lead:{client_id}:{lead_phone}"
    now = time.time()
    window_start = now - window_seconds

    pipe = redis.pipeline()
    # Remove entries older than the window
    pipe.zremrangebyscore(key, 0, window_start)
    # Count current entries in window
    pipe.zcard(key)
    # Add current message
    pipe.zadd(key, {f"{now}": now})
    # Set TTL so keys auto-expire
    pipe.expire(key, window_seconds + 60)
    results = await pipe.execute()

    current_count = results[1]  # zcard result

    if current_count >= max_messages:
        logger.warning(
            "[rate_limit] Lead %s:%s exceeded limit (%d/%d in %ds)",
            client_id[:8], lead_phone, current_count, max_messages, window_seconds,
        )
        return False

    return True


async def check_client_rate_limit(
    client_id: str,
    max_messages: int = CLIENT_MAX_MESSAGES,
    window_seconds: int = CLIENT_WINDOW_SECONDS,
) -> bool:
    """
    Check if a client has exceeded the overall message rate limit.

    This protects against property-launch-day traffic spikes.
    When exceeded, messages are queued instead of dropped.

    Returns:
        True if allowed, False if exceeded.
    """
    redis = get_redis()
    key = f"rate:client:{client_id}"
    now = time.time()
    window_start = now - window_seconds

    pipe = redis.pipeline()
    pipe.zremrangebyscore(key, 0, window_start)
    pipe.zcard(key)
    pipe.zadd(key, {f"{now}": now})
    pipe.expire(key, window_seconds + 60)
    results = await pipe.execute()

    current_count = results[1]

    if current_count >= max_messages:
        logger.warning(
            "[rate_limit] Client %s exceeded limit (%d/%d in %ds)",
            client_id[:8], current_count, max_messages, window_seconds,
        )
        return False

    return True


async def get_rate_limit_info(client_id: str, lead_phone: str) -> dict:
    """
    Get current rate limit status for a lead. Useful for debugging / admin API.

    Returns:
        {remaining: int, total: int, window_seconds: int, reset_in: float}
    """
    redis = get_redis()
    key = f"rate:lead:{client_id}:{lead_phone}"
    now = time.time()
    window_start = now - LEAD_WINDOW_SECONDS

    # Remove stale + count
    pipe = redis.pipeline()
    pipe.zremrangebyscore(key, 0, window_start)
    pipe.zcard(key)
    pipe.zrangebyscore(key, window_start, now, start=0, num=1, withscores=True)
    results = await pipe.execute()

    current_count = results[1]
    oldest_entries = results[2]

    reset_in = 0.0
    if oldest_entries:
        oldest_score = oldest_entries[0][1]
        reset_in = max(0.0, (oldest_score + LEAD_WINDOW_SECONDS) - now)

    return {
        "remaining": max(0, LEAD_MAX_MESSAGES - current_count),
        "total": LEAD_MAX_MESSAGES,
        "window_seconds": LEAD_WINDOW_SECONDS,
        "reset_in": round(reset_in, 1),
    }
