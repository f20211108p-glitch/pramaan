"""
Shared Redis connection pool — single pool for all modules.

Replaces the per-module _redis_client globals in dedup, rate_limit,
message_queue, and tenant. One connection pool, one health check.
"""
import logging
from datetime import datetime, timezone

import redis.asyncio as aioredis

from src.config import get_settings

logger = logging.getLogger(__name__)

_pool: aioredis.Redis | None = None


def get_redis() -> aioredis.Redis:
    """Return the shared async Redis client (lazy-initialized)."""
    global _pool
    if _pool is None:
        settings = get_settings()
        _pool = aioredis.from_url(
            settings.redis_url,
            decode_responses=True,
            max_connections=20,
        )
    return _pool


async def check_redis_health() -> dict:
    """
    Verify Redis connectivity. Returns {ok: bool, latency_ms: float, error: str|None}.
    """
    try:
        r = get_redis()
        start = datetime.now(timezone.utc)
        await r.ping()
        latency = (datetime.now(timezone.utc) - start).total_seconds() * 1000
        return {"ok": True, "latency_ms": round(latency, 1), "error": None}
    except Exception as e:
        logger.error("[redis] Health check failed: %s", e)
        return {"ok": False, "latency_ms": -1, "error": str(e)}


async def close_redis() -> None:
    """Close the connection pool (call on shutdown)."""
    global _pool
    if _pool is not None:
        await _pool.aclose()
        _pool = None
        logger.info("[redis] Connection pool closed")
