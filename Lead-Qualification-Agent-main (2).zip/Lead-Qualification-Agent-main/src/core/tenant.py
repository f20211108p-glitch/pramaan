"""
Tenant resolution: maps a WABA phone_number_id to a ClientConfig.
Results are cached in Redis for 5 minutes to avoid DB hit on every message.
"""
import json
import logging
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.core.crypto import decrypt_token, encrypt_token
from src.core.redis import get_redis
from src.db.tables import ClientConfig

logger = logging.getLogger(__name__)

_CLIENT_CACHE_TTL = 300  # 5 minutes


def _cache_key(waba_number: str) -> str:
    return f"client_config:{waba_number}"


async def resolve_client(db: AsyncSession, waba_number: str) -> ClientConfig | None:
    """
    Returns ClientConfig for the given WABA phone_number_id.
    Checks Redis cache first; falls back to DB and repopulates cache.
    'waba_number' here is actually the waba_phone_number_id sent by Meta in every webhook.
    """
    redis = get_redis()
    cached = await redis.get(_cache_key(waba_number))
    if cached:
        data = json.loads(cached)
        # Reconstruct a lightweight ClientConfig-like dict (not ORM object from cache)
        return _dict_to_client_config(data)

    result = await db.execute(
        select(ClientConfig).where(
            ClientConfig.waba_phone_number_id == waba_number,
            ClientConfig.active.is_(True),
        )
    )
    client = result.scalar_one_or_none()
    if client is None:
        logger.warning("Unknown WABA number: %s", waba_number)
        return None

    await redis.setex(
        _cache_key(waba_number),
        _CLIENT_CACHE_TTL,
        json.dumps(_client_config_to_dict(client)),
    )
    return client


async def get_client_prompt(
    db: AsyncSession,
    client_id: str | UUID,
    node_name: str,
    default_prompt: str,
) -> str:
    """
    Returns the per-client override prompt for a node, or the default.
    Checks DB once; callers should cache the ClientConfig upstream.
    """
    result = await db.execute(
        select(ClientConfig.prompt_overrides).where(
            ClientConfig.id == client_id,
            ClientConfig.active.is_(True),
        )
    )
    overrides: dict | None = result.scalar_one_or_none()
    if overrides and node_name in overrides:
        return overrides[node_name]
    return default_prompt


async def invalidate_client_cache(waba_number: str) -> None:
    redis = get_redis()
    await redis.delete(_cache_key(waba_number))


def _client_config_to_dict(client: ClientConfig) -> dict:
    return {
        "id": str(client.id),
        "client_name": client.client_name,
        "waba_number": client.waba_number,
        "waba_phone_number_id": client.waba_phone_number_id,
        "waba_token": encrypt_token(client.waba_token) if client.waba_token else None,
        "project_ids": [str(p) for p in (client.project_ids or [])],
        "prompt_overrides": client.prompt_overrides or {},
        "crm_type": client.crm_type,
        "crm_token": encrypt_token(client.crm_token) if client.crm_token else None,
        "language_config": client.language_config or {},
        "broker_wa_numbers": client.broker_wa_numbers or [],
        "google_calendar_id": client.google_calendar_id,
        "scoring_config": client.scoring_config or {},
        "active": client.active,
    }


def _dict_to_client_config(data: dict) -> ClientConfig:
    # Returns a detached ClientConfig (not bound to a session) from cached dict
    client = ClientConfig()
    client.id = UUID(data["id"])
    client.client_name = data["client_name"]
    client.waba_number = data["waba_number"]
    client.waba_phone_number_id = data["waba_phone_number_id"]
    client.waba_token = decrypt_token(data.get("waba_token"))
    client.project_ids = [UUID(p) for p in data.get("project_ids", [])]
    client.prompt_overrides = data.get("prompt_overrides", {})
    client.crm_type = data.get("crm_type")
    client.crm_token = decrypt_token(data.get("crm_token"))
    client.language_config = data.get("language_config", {})
    client.broker_wa_numbers = data.get("broker_wa_numbers", [])
    client.google_calendar_id = data.get("google_calendar_id")
    client.scoring_config = data.get("scoring_config", {})
    client.active = data.get("active", True)
    return client
