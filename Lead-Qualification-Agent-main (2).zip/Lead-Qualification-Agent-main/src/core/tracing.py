"""
Langfuse observability — decorators for LangGraph nodes and LLM calls.

Provides @trace_node and @trace_llm decorators that log:
  - Node: input/output state, latency, tags (client_id, lead_id, language)
  - LLM: model, tokens (in/out/cache), latency, estimated INR cost

Cost estimates (as of 2026, INR per million tokens):
  - Sonnet: input ₹291, output ₹1455
  - Haiku:  input ₹97,  output ₹485

If Langfuse keys are not set, decorators become transparent no-ops.
"""
import logging
import time
import functools
from typing import Any, Callable

from src.config import get_settings

logger = logging.getLogger(__name__)

# ── Langfuse client singleton ─────────────────────────────────────────────────

_langfuse_client = None
_langfuse_enabled = False


def _get_langfuse():
    """Lazy-init Langfuse client. Returns None if keys not configured."""
    global _langfuse_client, _langfuse_enabled
    if _langfuse_client is not None:
        return _langfuse_client

    settings = get_settings()
    if not settings.langfuse_public_key or not settings.langfuse_secret_key:
        _langfuse_enabled = False
        logger.debug("[tracing] Langfuse keys not set — tracing disabled")
        return None

    try:
        from langfuse import Langfuse
        _langfuse_client = Langfuse(
            public_key=settings.langfuse_public_key,
            secret_key=settings.langfuse_secret_key,
            host=settings.langfuse_host,
        )
        _langfuse_enabled = True
        logger.info("[tracing] Langfuse initialized (host=%s)", settings.langfuse_host)
        return _langfuse_client
    except Exception as e:
        logger.warning("[tracing] Failed to initialize Langfuse: %s", e)
        _langfuse_enabled = False
        return None


# ── Cost estimation ───────────────────────────────────────────────────────────

# INR per million tokens
COST_TABLE = {
    "claude-sonnet-4-5":       {"input": 291, "output": 1455},
    "claude-sonnet-4-5-20250929": {"input": 291, "output": 1455},
    "claude-haiku-4-5":        {"input": 97,  "output": 485},
    "claude-haiku-4-5-20251001":  {"input": 97,  "output": 485},
}


def estimate_cost_inr(model: str, input_tokens: int, output_tokens: int) -> float:
    """Estimate cost in INR for a given LLM call."""
    costs = COST_TABLE.get(model)
    if not costs:
        # Fallback: try prefix match
        for key, val in COST_TABLE.items():
            if key in model or model in key:
                costs = val
                break
    if not costs:
        costs = {"input": 291, "output": 1455}  # default to Sonnet pricing
    return (input_tokens * costs["input"] + output_tokens * costs["output"]) / 1_000_000


# ── @trace_node decorator ────────────────────────────────────────────────────

def trace_node(name: str) -> Callable:
    """
    Decorator for LangGraph node functions.
    Logs: node name, input/output state summary, latency, tags.

    Usage:
        @trace_node("greeter")
        def greeter_node(state: QualificationState) -> dict:
            ...
    """
    def decorator(fn: Callable) -> Callable:
        @functools.wraps(fn)
        def wrapper(state: dict, *args: Any, **kwargs: Any) -> Any:
            lf = _get_langfuse()
            start = time.time()

            # Extract tags from state
            lead = state.get("lead", {})
            client_config = state.get("client_config", {})
            tags = {
                "node_name": name,
                "client_id": str(client_config.get("id", "")),
                "lead_id": str(lead.get("id", "")),
                "language": state.get("language", "unknown"),
                "turn_count": str(state.get("turn_count", 0)),
            }

            trace = None
            span = None
            if lf:
                try:
                    trace = lf.trace(
                        name=f"node:{name}",
                        metadata=tags,
                        tags=[name, state.get("language", "unknown")],
                    )
                    span = trace.span(
                        name=name,
                        input=_summarize_state(state, max_len=500),
                    )
                except Exception as e:
                    logger.debug("[tracing] Failed to create trace: %s", e)

            try:
                result = fn(state, *args, **kwargs)
                latency = time.time() - start

                if span:
                    try:
                        span.end(
                            output=_summarize_state(result, max_len=500) if isinstance(result, dict) else str(result)[:500],
                            metadata={"latency_ms": round(latency * 1000)},
                        )
                    except Exception:
                        pass

                logger.debug(
                    "[trace:%s] latency=%.0fms client=%s",
                    name, latency * 1000, tags["client_id"][:8],
                )
                return result

            except Exception as e:
                if span:
                    try:
                        span.end(level="ERROR", status_message=str(e))
                    except Exception:
                        pass
                raise

        return wrapper
    return decorator


# ── @trace_llm decorator ─────────────────────────────────────────────────────

def trace_llm(name: str) -> Callable:
    """
    Decorator for LLM call functions (classify, generate, extract_structured).
    Logs: model, tokens, cache stats, latency, cost estimate.

    Usage:
        @trace_llm("classify")
        def classify(system_prompt, user_text, valid_values, cache=True):
            ...
    """
    def decorator(fn: Callable) -> Callable:
        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            lf = _get_langfuse()
            start = time.time()

            generation = None
            if lf:
                try:
                    generation = lf.generation(
                        name=f"llm:{name}",
                        metadata={"call_type": name},
                    )
                except Exception as e:
                    logger.debug("[tracing] Failed to create generation: %s", e)

            try:
                result = fn(*args, **kwargs)
                latency = time.time() - start

                # Try to extract usage from the result if it's a response object
                # For our LLM functions, usage is logged via _log_usage already
                if generation:
                    try:
                        generation.end(
                            output=str(result)[:500] if result else "",
                            metadata={
                                "latency_ms": round(latency * 1000),
                                "call_type": name,
                            },
                        )
                    except Exception:
                        pass

                return result

            except Exception as e:
                if generation:
                    try:
                        generation.end(level="ERROR", status_message=str(e))
                    except Exception:
                        pass
                raise

        return wrapper
    return decorator


# ── Helpers ───────────────────────────────────────────────────────────────────

def _summarize_state(state: dict, max_len: int = 500) -> dict:
    """Create a JSON-safe summary of a state dict for logging."""
    summary = {}
    for key, val in state.items():
        if key == "messages":
            summary[key] = f"[{len(val)} messages]" if isinstance(val, list) else str(val)[:100]
        elif key == "rag_context":
            summary[key] = f"[{len(val)} chunks]" if isinstance(val, list) else str(val)[:100]
        elif isinstance(val, dict):
            summary[key] = {k: str(v)[:80] for k, v in val.items()}
        elif isinstance(val, (list, tuple)):
            summary[key] = str(val)[:200]
        else:
            summary[key] = str(val)[:200]
    return summary


def flush_traces() -> None:
    """Flush any pending Langfuse traces. Call on shutdown."""
    lf = _get_langfuse()
    if lf:
        try:
            lf.flush()
        except Exception as e:
            logger.debug("[tracing] Flush failed: %s", e)
