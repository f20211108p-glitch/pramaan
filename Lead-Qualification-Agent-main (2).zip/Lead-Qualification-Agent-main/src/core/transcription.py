"""
Voice note transcription — downloads WhatsApp audio and transcribes via self-hosted Whisper.

Production-grade with multi-language support for Indian real estate:
  - Primary: Hindi, English, Hinglish (code-mixed)
  - Regional: Marathi, Gujarati, Tamil, Telugu, Kannada, Bengali, Punjabi
  - Language hint from lead profile to improve accuracy
  - Retry with exponential backoff on transient failures
  - Audio format validation and size limits
  - Graceful fallback: retry without language hint if first attempt fails

Flow:
  1. WhatsApp sends a media_id for the voice note (OGG/Opus format)
  2. We fetch the media URL from Meta's Graph API
  3. Download the actual audio bytes
  4. Validate audio (format, size)
  5. POST to self-hosted Whisper with language hint + prompt priming
  6. Return transcribed text with detected language
"""
import asyncio
import logging
import tempfile
from pathlib import Path
from typing import NamedTuple

import httpx

from src.config import get_settings
from src.core.crypto import decrypt_token

logger = logging.getLogger(__name__)

META_API_BASE = "https://graph.facebook.com/v21.0"

# ── Timeouts ─────────────────────────────────────────────────────────────────
TRANSCRIBE_TIMEOUT = 60  # bumped for larger/regional-language audio
DOWNLOAD_TIMEOUT = 15

# ── Audio validation ─────────────────────────────────────────────────────────
MAX_AUDIO_SIZE_MB = 25  # WhatsApp caps at 16MB, but allow headroom
MIN_AUDIO_SIZE_BYTES = 512  # below this is likely empty/corrupt
MAX_AUDIO_SIZE_BYTES = MAX_AUDIO_SIZE_MB * 1024 * 1024

# ── Retry config ─────────────────────────────────────────────────────────────
MAX_RETRIES = 3
RETRY_BACKOFF_BASE = 1.0  # seconds — 1s, 2s, 4s

# ── Language mapping ─────────────────────────────────────────────────────────
# Maps lead language_pref values → Whisper ISO 639-1 codes
LANGUAGE_HINT_MAP: dict[str, str] = {
    "english": "en",
    "hindi": "hi",
    "hinglish": "hi",  # Whisper handles code-mixing well with Hindi hint
    "marathi": "mr",
    "gujarati": "gu",
    "tamil": "ta",
    "telugu": "te",
    "kannada": "kn",
    "bengali": "bn",
    "punjabi": "pa",
    "malayalam": "ml",
    "odia": "or",
    "urdu": "ur",
    "assamese": "as",
}

# Prompt priming — helps Whisper with real-estate domain vocabulary
# and common Indian English/Hindi terms. Kept short to avoid biasing output.
DOMAIN_PROMPTS: dict[str, str] = {
    "hi": (
        "रियल एस्टेट, फ्लैट, BHK, EMI, बजट, लोकेशन, पज़ेशन, "
        "RERA, बुकिंग, साइट विज़िट, ब्रोशर, फ्लोर प्लान"
    ),
    "en": (
        "real estate, flat, BHK, EMI, budget, location, possession, "
        "RERA, booking, site visit, brochure, floor plan, carpet area"
    ),
    "mr": (
        "रिअल इस्टेट, फ्लॅट, BHK, EMI, बजेट, लोकेशन, पझेशन, "
        "RERA, बुकिंग, साइट व्हिजिट"
    ),
    "gu": (
        "રિયલ એસ્ટેટ, ફ્લેટ, BHK, EMI, બજેટ, લોકેશન, "
        "RERA, બુકિંગ, સાઇટ વિઝિટ"
    ),
}


class TranscriptionResult(NamedTuple):
    """Structured result from transcription."""
    text: str
    language: str  # detected or hinted ISO 639-1 code
    duration_hint: float | None  # estimated duration in seconds if available


async def transcribe_voice_note(
    media_id: str,
    waba_token: str,
    language_hint: str | None = None,
) -> str | None:
    """
    Download a WhatsApp voice note and transcribe it.

    Args:
        media_id: WhatsApp media ID from the webhook payload
        waba_token: The client's WABA token (may be encrypted)
        language_hint: Lead's language_pref (e.g. "hindi", "english", "marathi")
                       Used to prime Whisper for better accuracy.

    Returns:
        Transcribed text string, or None on failure.
        NEVER raises — all errors are caught and logged.
    """
    try:
        token = decrypt_token(waba_token) or waba_token

        media_url = await _get_media_url(media_id, token)
        if not media_url:
            return None

        audio_bytes = await _download_media(media_url, token)
        if not audio_bytes:
            return None

        # Validate audio before sending to Whisper
        validation_error = _validate_audio(audio_bytes)
        if validation_error:
            logger.warning("[transcription] Audio validation failed: %s", validation_error)
            return None

        # Resolve language hint to Whisper code
        whisper_lang = LANGUAGE_HINT_MAP.get(language_hint or "", None)

        # Attempt transcription with language hint
        result = await _transcribe_with_retry(audio_bytes, whisper_lang)

        # Fallback: if hinted transcription failed or returned empty,
        # retry without hint (let Whisper auto-detect)
        if result is None and whisper_lang is not None:
            logger.info(
                "[transcription] Retrying without language hint (was: %s)",
                whisper_lang,
            )
            result = await _transcribe_with_retry(audio_bytes, language_code=None)

        if result:
            logger.info(
                "[transcription] Success (media_id=%s, lang=%s, length=%d chars): %.80s...",
                media_id, result.language, len(result.text), result.text,
            )
            return result.text

        return None

    except Exception as e:
        logger.error(
            "[transcription] Unexpected error for media_id=%s: %s",
            media_id, e, exc_info=True,
        )
        return None


async def transcribe_voice_note_detailed(
    media_id: str,
    waba_token: str,
    language_hint: str | None = None,
) -> TranscriptionResult | None:
    """
    Same as transcribe_voice_note but returns structured result
    with detected language. Used by voice agent for language-aware responses.
    """
    try:
        token = decrypt_token(waba_token) or waba_token
        media_url = await _get_media_url(media_id, token)
        if not media_url:
            return None

        audio_bytes = await _download_media(media_url, token)
        if not audio_bytes:
            return None

        validation_error = _validate_audio(audio_bytes)
        if validation_error:
            return None

        whisper_lang = LANGUAGE_HINT_MAP.get(language_hint or "", None)
        result = await _transcribe_with_retry(audio_bytes, whisper_lang)

        if result is None and whisper_lang is not None:
            result = await _transcribe_with_retry(audio_bytes, language_code=None)

        return result

    except Exception as e:
        logger.error("[transcription] Detailed transcription error: %s", e, exc_info=True)
        return None


# ── Audio validation ─────────────────────────────────────────────────────────

def _validate_audio(audio_bytes: bytes) -> str | None:
    """
    Validate audio before sending to Whisper.
    Returns error string if invalid, None if OK.
    """
    size = len(audio_bytes)

    if size < MIN_AUDIO_SIZE_BYTES:
        return f"Audio too small ({size} bytes), likely empty or corrupt"

    if size > MAX_AUDIO_SIZE_BYTES:
        return f"Audio too large ({size / 1024 / 1024:.1f} MB, max {MAX_AUDIO_SIZE_MB} MB)"

    # Check OGG magic bytes (WhatsApp voice notes are OGG/Opus)
    # OGG files start with "OggS" (0x4F676753)
    if audio_bytes[:4] != b"OggS":
        # Could be other format (MP4, WAV) — Whisper handles many formats,
        # so just warn but don't reject
        logger.info(
            "[transcription] Non-OGG audio detected (magic: %s), proceeding anyway",
            audio_bytes[:4].hex(),
        )

    return None


# ── Media download ───────────────────────────────────────────────────────────

async def _get_media_url(media_id: str, token: str) -> str | None:
    """Fetch the download URL for a media object from Meta's Graph API."""
    url = f"{META_API_BASE}/{media_id}"
    headers = {"Authorization": f"Bearer {token}"}

    try:
        async with httpx.AsyncClient(timeout=DOWNLOAD_TIMEOUT) as client:
            resp = await client.get(url, headers=headers)

        if resp.status_code != 200:
            logger.error(
                "[transcription] Failed to get media URL (status=%d): %s",
                resp.status_code, resp.text[:200],
            )
            return None

        media_url = resp.json().get("url")
        if not media_url:
            logger.error("[transcription] No URL in media response")
            return None

        return media_url

    except httpx.HTTPError as e:
        logger.error("[transcription] HTTP error fetching media URL: %s", e)
        return None


async def _download_media(media_url: str, token: str) -> bytes | None:
    """Download audio bytes from Meta's CDN."""
    headers = {"Authorization": f"Bearer {token}"}

    try:
        async with httpx.AsyncClient(timeout=DOWNLOAD_TIMEOUT) as client:
            resp = await client.get(media_url, headers=headers)

        if resp.status_code != 200:
            logger.error(
                "[transcription] Failed to download media (status=%d)",
                resp.status_code,
            )
            return None

        audio_bytes = resp.content
        size_kb = len(audio_bytes) / 1024
        logger.info("[transcription] Downloaded %.1f KB audio", size_kb)
        return audio_bytes

    except httpx.HTTPError as e:
        logger.error("[transcription] HTTP error downloading media: %s", e)
        return None


# ── Whisper transcription with retry ─────────────────────────────────────────

async def _transcribe_with_retry(
    audio_bytes: bytes,
    language_code: str | None,
) -> TranscriptionResult | None:
    """
    Send audio to Whisper with exponential backoff retry.
    Retries on transient errors (timeouts, 5xx). Does NOT retry on 4xx.
    """
    last_error: Exception | None = None

    for attempt in range(MAX_RETRIES):
        try:
            result = await _transcribe(audio_bytes, language_code)
            return result
        except _TransientError as e:
            last_error = e
            if attempt < MAX_RETRIES - 1:
                wait = RETRY_BACKOFF_BASE * (2 ** attempt)
                logger.warning(
                    "[transcription] Transient error (attempt %d/%d), retrying in %.1fs: %s",
                    attempt + 1, MAX_RETRIES, wait, e,
                )
                await asyncio.sleep(wait)
            else:
                logger.error(
                    "[transcription] All %d attempts failed: %s",
                    MAX_RETRIES, e,
                )
        except _PermanentError as e:
            logger.error("[transcription] Permanent error, not retrying: %s", e)
            return None

    return None


class _TransientError(Exception):
    """Retryable error (timeout, 5xx, connection error)."""
    pass


class _PermanentError(Exception):
    """Non-retryable error (4xx, bad response format)."""
    pass


async def _transcribe(
    audio_bytes: bytes,
    language_code: str | None,
) -> TranscriptionResult | None:
    """
    Single transcription attempt against self-hosted Whisper.

    Raises _TransientError or _PermanentError on failure.
    Returns None if Whisper returns empty text (not an error — just silence).
    """
    settings = get_settings()
    whisper_url = f"{settings.whisper_url}/v1/audio/transcriptions"

    try:
        async with httpx.AsyncClient(timeout=TRANSCRIBE_TIMEOUT) as client:
            files = {
                "file": ("voice_note.ogg", audio_bytes, "audio/ogg"),
            }
            data: dict[str, str] = {
                "model": "whisper-1",
                "response_format": "verbose_json",  # gives us language + segments
            }

            # Add language hint if provided
            if language_code:
                data["language"] = language_code

            # Add domain prompt priming for better vocabulary recognition
            prompt = DOMAIN_PROMPTS.get(
                language_code or "", DOMAIN_PROMPTS.get("en", "")
            )
            if prompt:
                data["prompt"] = prompt

            resp = await client.post(whisper_url, files=files, data=data)

    except httpx.ConnectError:
        raise _TransientError(
            f"Cannot connect to Whisper at {settings.whisper_url}"
        )
    except httpx.TimeoutException:
        raise _TransientError(
            f"Whisper timed out after {TRANSCRIBE_TIMEOUT}s"
        )
    except httpx.HTTPError as e:
        raise _TransientError(f"HTTP error: {e}")

    # Handle response status
    if resp.status_code >= 500:
        raise _TransientError(f"Whisper 5xx (status={resp.status_code}): {resp.text[:200]}")

    if resp.status_code >= 400:
        raise _PermanentError(f"Whisper 4xx (status={resp.status_code}): {resp.text[:200]}")

    if resp.status_code != 200:
        raise _PermanentError(f"Unexpected status {resp.status_code}")

    # Parse response
    try:
        result = resp.json()
    except Exception:
        raise _PermanentError(f"Invalid JSON from Whisper: {resp.text[:200]}")

    text = result.get("text", "").strip()
    if not text:
        logger.info("[transcription] Whisper returned empty text (silence or noise)")
        return None

    # Extract detected language (verbose_json includes this)
    detected_lang = result.get("language", language_code or "unknown")

    # Extract duration if available
    duration = result.get("duration", None)

    return TranscriptionResult(
        text=text,
        language=detected_lang,
        duration_hint=duration,
    )
