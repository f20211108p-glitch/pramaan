"""
Background message worker — pulls from Redis stream and processes messages.

This is the async counterpart to the webhook handler. Instead of processing
messages synchronously (risking Meta's 20-second timeout), the webhook
enqueues to Redis and this worker processes them at its own pace.

Run with: python -m src.core.worker
Or via Makefile: make worker

Architecture:
  1. Worker starts → creates consumer group if needed
  2. Main loop: XREADGROUP (block 5s) → process each message → XACK
  3. Every 60 seconds: reclaim stale messages from crashed workers
  4. Graceful shutdown on SIGINT/SIGTERM
"""
import asyncio
import logging
import os
import signal
import time

from src.config import get_settings
from src.core.message_queue import (
    ensure_consumer_group,
    dequeue_messages,
    ack_message,
    reclaim_stale_messages,
    get_pending_count,
    get_stream_length,
    send_to_dlq,
    get_dlq_count,
)
from src.channels.router import MessageRouter
from src.db.engine import AsyncSessionFactory

logger = logging.getLogger(__name__)

# Worker identity — unique per process
WORKER_NAME = f"worker-{os.getpid()}"

# How often to reclaim stale messages (seconds)
RECLAIM_INTERVAL = 60

# How often to log stats (seconds)
STATS_INTERVAL = 120


class MessageWorker:
    """
    Background worker that processes messages from the Redis stream.

    Usage:
        worker = MessageWorker()
        await worker.run()
    """

    def __init__(self, worker_name: str | None = None):
        self.worker_name = worker_name or WORKER_NAME
        self._router = MessageRouter()
        self._running = False
        self._processed = 0
        self._errors = 0
        self._last_reclaim = 0.0
        self._last_stats = 0.0
        self._start_time = 0.0

    async def run(self) -> None:
        """
        Main worker loop. Runs until shutdown signal received.
        """
        self._running = True
        self._start_time = time.time()
        self._last_reclaim = time.time()
        self._last_stats = time.time()

        logger.info("[worker:%s] Starting message worker", self.worker_name)

        # Ensure consumer group exists
        await ensure_consumer_group()

        while self._running:
            try:
                # Pull new messages (blocks up to 5s if none available)
                messages = await dequeue_messages(
                    consumer_name=self.worker_name,
                    count=10,
                    block_ms=5000,
                )

                # Process each message
                for msg in messages:
                    await self._process_message(msg)

                # Periodically reclaim stale messages from crashed workers
                if time.time() - self._last_reclaim > RECLAIM_INTERVAL:
                    await self._reclaim_stale()
                    self._last_reclaim = time.time()

                # Periodically log stats
                if time.time() - self._last_stats > STATS_INTERVAL:
                    await self._log_stats()
                    self._last_stats = time.time()

            except asyncio.CancelledError:
                logger.info("[worker:%s] Received cancel signal", self.worker_name)
                break
            except Exception as e:
                logger.error("[worker:%s] Loop error: %s", self.worker_name, e, exc_info=True)
                # Brief pause before retrying to avoid tight error loops
                await asyncio.sleep(1)

        logger.info(
            "[worker:%s] Shut down. Processed=%d, Errors=%d, Uptime=%.0fs",
            self.worker_name, self._processed, self._errors,
            time.time() - self._start_time,
        )

    async def _process_message(self, msg: dict) -> None:
        """
        Process a single message from the queue.

        Steps:
          1. Create a fresh DB session
          2. Route through MessageRouter (same logic as sync path)
          3. Ack the message on success
          4. On failure: log error, ack anyway (dead-letter in future)
        """
        entry_id = msg["entry_id"]
        client_id = msg["client_id"]
        payload = msg["payload"]
        enqueued_at = msg.get("enqueued_at", 0)

        # Track queue latency
        latency = time.time() - enqueued_at if enqueued_at else 0
        if latency > 10:
            logger.warning(
                "[worker:%s] High queue latency: %.1fs for entry %s",
                self.worker_name, latency, entry_id,
            )

        try:
            async with AsyncSessionFactory() as db:
                result = await self._router.route_inbound(payload, db)
                logger.info(
                    "[worker:%s] Processed %s → %s (latency=%.1fs)",
                    self.worker_name, entry_id,
                    "ok" if "response" in result else result.get("reason", "?"),
                    latency,
                )

            self._processed += 1

        except Exception as e:
            logger.error(
                "[worker:%s] Failed to process %s: %s",
                self.worker_name, entry_id, e, exc_info=True,
            )
            self._errors += 1
            # Send to dead-letter queue for inspection / replay
            await send_to_dlq(
                entry_id=entry_id,
                client_id=client_id,
                payload=payload,
                error=f"{type(e).__name__}: {e}",
                worker_name=self.worker_name,
            )

        # Always ack — prevents infinite retry. Failures are in DLQ.
        await ack_message(entry_id)

    async def _reclaim_stale(self) -> None:
        """Reclaim messages from crashed workers."""
        stale = await reclaim_stale_messages(self.worker_name, max_count=5)
        for msg in stale:
            await self._process_message(msg)

    async def _log_stats(self) -> None:
        """Log worker statistics."""
        pending = await get_pending_count()
        stream_len = await get_stream_length()
        dlq_len = await get_dlq_count()
        uptime = time.time() - self._start_time
        rate = self._processed / max(uptime, 1) * 60  # msgs/min

        logger.info(
            "[worker:%s] Stats: processed=%d, errors=%d, pending=%d, stream=%d, dlq=%d, rate=%.1f/min",
            self.worker_name, self._processed, self._errors,
            pending, stream_len, dlq_len, rate,
        )

    def stop(self) -> None:
        """Signal the worker to stop after the current iteration."""
        self._running = False


async def main():
    """Entry point for running the worker as a standalone process."""
    settings = get_settings()
    logging.basicConfig(
        level=settings.log_level,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    worker = MessageWorker()

    # Graceful shutdown on SIGINT/SIGTERM
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, worker.stop)
        except NotImplementedError:
            # Windows doesn't support add_signal_handler
            pass

    await worker.run()


if __name__ == "__main__":  # pragma: no cover
    asyncio.run(main())
