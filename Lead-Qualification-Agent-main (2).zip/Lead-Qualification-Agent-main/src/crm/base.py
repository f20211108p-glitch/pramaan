"""
CRM adapter base — abstract interface for all CRM integrations.

Every CRM adapter must implement these methods:
  - push_lead()       — create or update a lead/contact in the external CRM
  - update_lead()     — push field updates to an existing CRM record
  - push_note()       — attach a conversation summary / note to the lead
  - check_health()    — verify the CRM token is valid (used by admin API)

Design principles:
  1. Multi-tenant: every call receives client_config (contains crm_token)
  2. Non-blocking: CRM sync failures NEVER block the lead's WhatsApp reply
  3. Idempotent: push_lead() with same phone should upsert, not create duplicates
  4. Minimal payload: only send fields the CRM cares about
"""
from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any
from enum import Enum

logger = logging.getLogger(__name__)


class CRMSyncStatus(str, Enum):
    """Result status for CRM sync operations."""
    SUCCESS = "success"
    CREATED = "created"
    UPDATED = "updated"
    SKIPPED = "skipped"      # e.g. CRM not configured
    FAILED = "failed"
    AUTH_ERROR = "auth_error"


@dataclass
class CRMSyncResult:
    """Standardized result from any CRM operation."""
    status: CRMSyncStatus
    crm_type: str
    external_id: str | None = None     # CRM's ID for the lead (for future lookups)
    message: str = ""
    raw_response: dict[str, Any] = field(default_factory=dict)
    synced_at: datetime = field(default_factory=datetime.utcnow)

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status.value,
            "crm_type": self.crm_type,
            "external_id": self.external_id,
            "message": self.message,
            "synced_at": self.synced_at.isoformat(),
        }


@dataclass
class CRMLeadPayload:
    """
    Normalized lead data sent to CRM adapters.

    Adapters map these fields to their CRM's schema.
    Built from LeadEngine's internal lead dict + client_config.
    """
    # Identity
    phone: str
    name: str | None = None
    email: str | None = None

    # Qualification
    intent: str = "unknown"
    budget_min: int | None = None
    budget_max: int | None = None
    timeline_months: int | None = None
    urgency: str = "unknown"
    financing_status: str = "unknown"
    location_preferences: list[str] = field(default_factory=list)
    property_type: str = "any"
    family_size: int | None = None

    # Scoring
    score: int | None = None
    tier: str | None = None
    stage: str = "new"

    # Source
    source_channel: str = "whatsapp"
    language_pref: str = "english"

    # Internal IDs (for mapping back)
    leadengine_lead_id: str | None = None
    leadengine_client_id: str | None = None

    @classmethod
    def from_lead_dict(cls, lead: dict[str, Any], client_id: str | None = None) -> CRMLeadPayload:
        """Build payload from the engine's lead dict."""
        return cls(
            phone=lead.get("phone", ""),
            name=lead.get("name"),
            email=lead.get("email"),
            intent=lead.get("intent", "unknown"),
            budget_min=lead.get("budget_min"),
            budget_max=lead.get("budget_max"),
            timeline_months=lead.get("timeline_months"),
            urgency=lead.get("urgency", "unknown"),
            financing_status=lead.get("financing_status", "unknown"),
            location_preferences=lead.get("location_preferences", []),
            property_type=lead.get("property_type", "any"),
            family_size=lead.get("family_size"),
            score=lead.get("score"),
            tier=lead.get("tier"),
            stage=lead.get("stage", "new"),
            source_channel=lead.get("source_channel", "whatsapp"),
            language_pref=lead.get("language_pref", "english"),
            leadengine_lead_id=str(lead["id"]) if "id" in lead else None,
            leadengine_client_id=client_id,
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to plain dict (for JSON serialization to CRM APIs)."""
        return {
            "phone": self.phone,
            "name": self.name,
            "email": self.email,
            "intent": self.intent,
            "budget_min": self.budget_min,
            "budget_max": self.budget_max,
            "timeline_months": self.timeline_months,
            "urgency": self.urgency,
            "financing_status": self.financing_status,
            "location_preferences": self.location_preferences,
            "property_type": self.property_type,
            "family_size": self.family_size,
            "score": self.score,
            "tier": self.tier,
            "stage": self.stage,
            "source_channel": self.source_channel,
            "language_pref": self.language_pref,
            "leadengine_lead_id": self.leadengine_lead_id,
            "leadengine_client_id": self.leadengine_client_id,
        }


class BaseCRMAdapter(ABC):
    """
    Abstract CRM adapter. Subclass for each CRM integration.

    Usage:
        adapter = SellDoCRMAdapter()
        result = await adapter.push_lead(crm_token="xxx", payload=payload)
    """

    @property
    @abstractmethod
    def crm_type(self) -> str:
        """Unique identifier for this CRM (matches ClientConfig.crm_type)."""
        ...

    @abstractmethod
    async def push_lead(
        self,
        crm_token: str,
        payload: CRMLeadPayload,
        **kwargs: Any,
    ) -> CRMSyncResult:
        """
        Create or update (upsert) a lead in the external CRM.

        Must be idempotent — same phone number should update, not duplicate.
        """
        ...

    @abstractmethod
    async def update_lead(
        self,
        crm_token: str,
        payload: CRMLeadPayload,
        external_id: str | None = None,
        fields: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> CRMSyncResult:
        """
        Push field updates to an existing CRM record.

        If external_id is known, use it directly. Otherwise fall back to
        phone-based lookup + update.
        """
        ...

    @abstractmethod
    async def push_note(
        self,
        crm_token: str,
        external_id: str | None = None,
        phone: str | None = None,
        note: str = "",
        **kwargs: Any,
    ) -> CRMSyncResult:
        """Attach a note/comment to a lead in the CRM."""
        ...

    @abstractmethod
    async def check_health(self, crm_token: str) -> CRMSyncResult:
        """
        Verify the CRM credentials are valid.

        Used by admin API to show connection status.
        Returns SUCCESS if auth works, AUTH_ERROR otherwise.
        """
        ...

    def _make_result(
        self,
        status: CRMSyncStatus,
        external_id: str | None = None,
        message: str = "",
        raw_response: dict | None = None,
    ) -> CRMSyncResult:
        """Helper to build a result with correct crm_type."""
        return CRMSyncResult(
            status=status,
            crm_type=self.crm_type,
            external_id=external_id,
            message=message,
            raw_response=raw_response or {},
        )
