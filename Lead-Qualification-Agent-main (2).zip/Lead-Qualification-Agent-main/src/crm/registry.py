"""
CRM adapter registry — maps crm_type string → adapter instance.

Usage:
    adapter = get_adapter("selldo")
    adapter = get_adapter("webhook")
    adapter = get_adapter(None)  # returns None — CRM not configured

Adding a new CRM:
  1. Create src/crm/mycrm_adapter.py subclassing BaseCRMAdapter
  2. Register it in _ADAPTERS below
  3. That's it — the sync module picks it up automatically
"""
from __future__ import annotations

import logging
from typing import Any

from src.crm.base import BaseCRMAdapter

logger = logging.getLogger(__name__)

# Lazy registry — adapters are instantiated once on first lookup
_ADAPTERS: dict[str, BaseCRMAdapter] = {}
_INITIALIZED = False


def _init_registry() -> None:
    """
    Populate the registry with all known adapters.
    Called lazily on first get_adapter() call.
    """
    global _INITIALIZED

    from src.crm.selldo_adapter import SellDoCRMAdapter
    from src.crm.webhook_adapter import WebhookCRMAdapter

    _ADAPTERS["selldo"] = SellDoCRMAdapter()
    _ADAPTERS["webhook"] = WebhookCRMAdapter()

    _INITIALIZED = True
    logger.info("[crm_registry] Registered adapters: %s", list(_ADAPTERS.keys()))


def get_adapter(crm_type: str | None) -> BaseCRMAdapter | None:
    """
    Get a CRM adapter by type string.

    Returns None if:
      - crm_type is None/empty (client has no CRM configured)
      - crm_type is unknown (log a warning, don't crash)
    """
    if not crm_type:
        return None

    global _INITIALIZED
    if not _INITIALIZED:
        _init_registry()

    crm_type_lower = crm_type.strip().lower()
    adapter = _ADAPTERS.get(crm_type_lower)

    if adapter is None:
        logger.warning("[crm_registry] Unknown crm_type '%s'. Available: %s",
                       crm_type, list(_ADAPTERS.keys()))

    return adapter


def list_adapters() -> list[str]:
    """Return list of registered CRM type names."""
    global _INITIALIZED
    if not _INITIALIZED:
        _init_registry()
    return list(_ADAPTERS.keys())


def register_adapter(adapter: BaseCRMAdapter) -> None:
    """
    Register a custom CRM adapter at runtime.
    Useful for plugins or test overrides.
    """
    global _INITIALIZED
    if not _INITIALIZED:
        _init_registry()
    _ADAPTERS[adapter.crm_type] = adapter
    logger.info("[crm_registry] Registered custom adapter: %s", adapter.crm_type)
