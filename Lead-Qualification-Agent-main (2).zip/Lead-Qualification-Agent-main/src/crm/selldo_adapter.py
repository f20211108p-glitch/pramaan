"""
Sell.Do CRM adapter — popular CRM for Indian real estate developers.

Sell.Do API reference: https://www.sell.do/developer
Key endpoints:
  - POST /api/leads/create   — create or update lead (upserts by phone)
  - POST /api/leads/update   — update existing lead by ID
  - POST /api/leads/notes    — attach note to a lead
  - GET  /api/leads/search   — search leads by phone

Token format: Sell.Do API key (from client's Sell.Do account settings)
"""
import logging
from typing import Any

import httpx

from src.crm.base import (
    BaseCRMAdapter, CRMLeadPayload, CRMSyncResult, CRMSyncStatus,
)

logger = logging.getLogger(__name__)

SELLDO_BASE_URL = "https://app.sell.do/api"
TIMEOUT = httpx.Timeout(connect=10.0, read=20.0, write=10.0, pool=5.0)


def _map_stage_to_selldo(stage: str) -> str:
    """Map LeadEngine stage to Sell.Do pipeline stage."""
    mapping = {
        "new": "New",
        "qualifying": "Contacted",
        "qualified": "Qualified",
        "scheduling": "Site Visit Scheduled",
        "nurturing": "Follow Up",
        "handed_off": "Negotiation",
        "converted": "Won",
        "lost": "Lost",
    }
    return mapping.get(stage, "New")


def _map_tier_to_selldo_rating(tier: str | None) -> str:
    """Map LeadEngine tier to Sell.Do rating."""
    mapping = {
        "hot": "A",
        "warm": "B",
        "cold": "C",
    }
    return mapping.get(tier or "", "C")


def _format_budget_lakhs(amount: int | None) -> str | None:
    """Format INR amount as lakhs string for Sell.Do."""
    if amount is None:
        return None
    lakhs = amount / 100_000
    if lakhs >= 100:
        crores = lakhs / 100
        return f"{crores:.1f} Cr"
    return f"{lakhs:.0f} L"


def _build_selldo_payload(payload: CRMLeadPayload) -> dict[str, Any]:
    """
    Map CRMLeadPayload fields to Sell.Do's expected format.

    Sell.Do uses flat form-encoded params:
      lead[name], lead[email], lead[phone], lead[stage], etc.
    """
    data: dict[str, Any] = {
        "lead[phone]": payload.phone,
        "lead[source]": "WhatsApp - LeadEngine",
        "lead[stage]": _map_stage_to_selldo(payload.stage),
        "lead[rating]": _map_tier_to_selldo_rating(payload.tier),
    }

    if payload.name:
        data["lead[name]"] = payload.name
    if payload.email:
        data["lead[email]"] = payload.email
    if payload.budget_min:
        data["lead[budget_min]"] = _format_budget_lakhs(payload.budget_min)
    if payload.budget_max:
        data["lead[budget_max]"] = _format_budget_lakhs(payload.budget_max)
    if payload.location_preferences:
        data["lead[location]"] = ", ".join(payload.location_preferences)
    if payload.property_type and payload.property_type != "any":
        data["lead[property_type]"] = payload.property_type.capitalize()

    # Custom fields — Sell.Do supports custom_field[key]=value
    if payload.timeline_months is not None:
        data["lead[custom_field][timeline_months]"] = str(payload.timeline_months)
    if payload.financing_status != "unknown":
        data["lead[custom_field][financing_status]"] = payload.financing_status
    if payload.urgency != "unknown":
        data["lead[custom_field][urgency]"] = payload.urgency
    if payload.score is not None:
        data["lead[custom_field][leadengine_score]"] = str(payload.score)
    if payload.family_size is not None:
        data["lead[custom_field][family_size]"] = str(payload.family_size)
    if payload.language_pref != "english":
        data["lead[custom_field][language]"] = payload.language_pref
    if payload.leadengine_lead_id:
        data["lead[custom_field][leadengine_id]"] = payload.leadengine_lead_id

    return data


class SellDoCRMAdapter(BaseCRMAdapter):
    """
    Sell.Do CRM integration.

    Sell.Do is the most popular CRM for Indian real estate.
    Their API uses form-encoded POST with API key auth.
    Leads are upserted by phone number (no duplicates).
    """

    def __init__(self, base_url: str = SELLDO_BASE_URL):
        self._base_url = base_url

    @property
    def crm_type(self) -> str:
        return "selldo"

    async def push_lead(
        self,
        crm_token: str,
        payload: CRMLeadPayload,
        **kwargs: Any,
    ) -> CRMSyncResult:
        """Create or update a lead in Sell.Do (upserts by phone)."""
        if not crm_token:
            return self._make_result(CRMSyncStatus.SKIPPED, message="No Sell.Do API key")

        data = _build_selldo_payload(payload)
        data["api_key"] = crm_token

        url = f"{self._base_url}/leads/create"

        try:
            async with httpx.AsyncClient(timeout=TIMEOUT) as client:
                resp = await client.post(url, data=data)

            resp_json = {}
            try:
                resp_json = resp.json()
            except Exception:
                pass

            if resp.status_code in (200, 201):
                external_id = str(resp_json.get("id", resp_json.get("lead", {}).get("id", ""))) or None
                status = CRMSyncStatus.CREATED if resp.status_code == 201 else CRMSyncStatus.UPDATED
                return self._make_result(
                    status,
                    external_id=external_id,
                    message=f"Lead synced to Sell.Do",
                    raw_response=resp_json,
                )

            if resp.status_code in (401, 403):
                return self._make_result(
                    CRMSyncStatus.AUTH_ERROR,
                    message=f"Sell.Do auth failed: {resp.status_code}",
                    raw_response=resp_json,
                )

            return self._make_result(
                CRMSyncStatus.FAILED,
                message=f"Sell.Do returned {resp.status_code}: {resp_json.get('message', '')}",
                raw_response=resp_json,
            )

        except httpx.TimeoutException as e:
            logger.warning("[selldo] Timeout: %s", e)
            return self._make_result(CRMSyncStatus.FAILED, message=f"Timeout: {e}")
        except httpx.RequestError as e:
            logger.warning("[selldo] Request error: %s", e)
            return self._make_result(CRMSyncStatus.FAILED, message=f"Request error: {e}")

    async def update_lead(
        self,
        crm_token: str,
        payload: CRMLeadPayload,
        external_id: str | None = None,
        fields: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> CRMSyncResult:
        """
        Update an existing lead in Sell.Do.

        If external_id is known, update directly. Otherwise, Sell.Do's
        create endpoint handles upsert by phone.
        """
        if not crm_token:
            return self._make_result(CRMSyncStatus.SKIPPED, message="No Sell.Do API key")

        # Sell.Do's create endpoint upserts by phone, so we can reuse push_lead
        # for updates when we don't have an external_id
        if not external_id:
            return await self.push_lead(crm_token, payload, **kwargs)

        data = _build_selldo_payload(payload)
        data["api_key"] = crm_token
        data["lead[id]"] = external_id

        url = f"{self._base_url}/leads/update"

        try:
            async with httpx.AsyncClient(timeout=TIMEOUT) as client:
                resp = await client.post(url, data=data)

            if resp.status_code in (200, 201):
                return self._make_result(
                    CRMSyncStatus.UPDATED,
                    external_id=external_id,
                    message="Lead updated in Sell.Do",
                )

            # Fallback to create (upsert) if update fails
            logger.info("[selldo] Update by ID failed (%d), falling back to upsert", resp.status_code)
            return await self.push_lead(crm_token, payload, **kwargs)

        except (httpx.TimeoutException, httpx.RequestError) as e:
            logger.warning("[selldo] Update failed: %s", e)
            return self._make_result(CRMSyncStatus.FAILED, message=str(e))

    async def push_note(
        self,
        crm_token: str,
        external_id: str | None = None,
        phone: str | None = None,
        note: str = "",
        **kwargs: Any,
    ) -> CRMSyncResult:
        """Attach a note to a lead in Sell.Do."""
        if not crm_token:
            return self._make_result(CRMSyncStatus.SKIPPED, message="No Sell.Do API key")

        if not external_id and not phone:
            return self._make_result(CRMSyncStatus.FAILED, message="Need external_id or phone for note")

        data: dict[str, Any] = {
            "api_key": crm_token,
            "note[content]": note,
        }
        if external_id:
            data["note[lead_id]"] = external_id
        elif phone:
            data["note[phone]"] = phone

        url = f"{self._base_url}/leads/notes"

        try:
            async with httpx.AsyncClient(timeout=TIMEOUT) as client:
                resp = await client.post(url, data=data)

            if resp.status_code in (200, 201):
                return self._make_result(CRMSyncStatus.SUCCESS, message="Note added to Sell.Do")

            return self._make_result(
                CRMSyncStatus.FAILED,
                message=f"Sell.Do notes returned {resp.status_code}",
            )

        except (httpx.TimeoutException, httpx.RequestError) as e:
            logger.warning("[selldo] Note push failed: %s", e)
            return self._make_result(CRMSyncStatus.FAILED, message=str(e))

    async def check_health(self, crm_token: str) -> CRMSyncResult:
        """Verify Sell.Do API key by hitting a lightweight endpoint."""
        if not crm_token:
            return self._make_result(CRMSyncStatus.SKIPPED, message="No Sell.Do API key")

        url = f"{self._base_url}/leads/search"

        try:
            async with httpx.AsyncClient(timeout=TIMEOUT) as client:
                resp = await client.get(url, params={"api_key": crm_token, "phone": "0000000000"})

            if resp.status_code in (200, 404):
                # 200 = key valid, 404 = key valid but no lead found
                return self._make_result(CRMSyncStatus.SUCCESS, message="Sell.Do connection OK")

            if resp.status_code in (401, 403):
                return self._make_result(CRMSyncStatus.AUTH_ERROR, message="Invalid Sell.Do API key")

            return self._make_result(
                CRMSyncStatus.FAILED,
                message=f"Sell.Do returned {resp.status_code}",
            )

        except (httpx.TimeoutException, httpx.RequestError) as e:
            return self._make_result(CRMSyncStatus.FAILED, message=f"Unreachable: {e}")
