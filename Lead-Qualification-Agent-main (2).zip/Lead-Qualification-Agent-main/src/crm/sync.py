"""
CRM sync orchestrator — called from the router after lead updates.

This module is the single entry point for CRM operations:
  - sync_lead_to_crm()   — push lead data to the client's configured CRM
  - sync_note_to_crm()   — push a conversation summary / note

Design:
  - Non-blocking: failures are logged, never bubble up to the lead's reply
  - Multi-tenant: each client has their own CRM type + token
  - Idempotent: safe to call multiple times for the same lead

Integration point (router.py):
  After _persist_engine_results() and before/after broker notifications:
    await sync_lead_to_crm(client_config, lead_data)
"""
import logging
from typing import Any

from src.core.crypto import decrypt_token
from src.crm.base import CRMLeadPayload, CRMSyncResult, CRMSyncStatus
from src.crm.registry import get_adapter

logger = logging.getLogger(__name__)


async def sync_lead_to_crm(
    client_config: Any,
    lead: dict[str, Any],
    fields_updated: dict[str, Any] | None = None,
) -> CRMSyncResult | None:
    """
    Push lead data to the client's configured CRM.

    Args:
        client_config: ClientConfig ORM object (has .crm_type, .crm_token)
        lead: Lead data dict from engine result or DB
        fields_updated: Optional dict of specific fields that changed this turn
                       (used for incremental updates vs full push)

    Returns:
        CRMSyncResult or None if no CRM configured.
        NEVER raises — all exceptions are caught and logged.
    """
    crm_type = getattr(client_config, "crm_type", None)
    crm_token = decrypt_token(getattr(client_config, "crm_token", None))

    if not crm_type or not crm_token:
        logger.debug("[crm_sync] No CRM configured for client %s", getattr(client_config, "id", "?"))
        return None

    adapter = get_adapter(crm_type)
    if adapter is None:
        logger.warning("[crm_sync] No adapter for crm_type='%s'", crm_type)
        return CRMSyncResult(
            status=CRMSyncStatus.FAILED,
            crm_type=crm_type,
            message=f"Unknown CRM type: {crm_type}",
        )

    try:
        payload = CRMLeadPayload.from_lead_dict(
            lead,
            client_id=str(getattr(client_config, "id", "")),
        )

        # If we have specific fields that changed, use update_lead
        # Otherwise, push the full lead (upsert)
        if fields_updated:
            result = await adapter.update_lead(
                crm_token=crm_token,
                payload=payload,
                fields=fields_updated,
            )
        else:
            result = await adapter.push_lead(
                crm_token=crm_token,
                payload=payload,
            )

        if result.status in (CRMSyncStatus.SUCCESS, CRMSyncStatus.CREATED, CRMSyncStatus.UPDATED):
            logger.info("[crm_sync] Lead synced to %s (status=%s, external_id=%s)",
                       crm_type, result.status.value, result.external_id)
        else:
            logger.warning("[crm_sync] CRM sync to %s returned %s: %s",
                          crm_type, result.status.value, result.message)

        return result

    except Exception as e:
        logger.error("[crm_sync] Unexpected error syncing to %s: %s", crm_type, e, exc_info=True)
        return CRMSyncResult(
            status=CRMSyncStatus.FAILED,
            crm_type=crm_type,
            message=f"Unexpected error: {e}",
        )


async def sync_note_to_crm(
    client_config: Any,
    phone: str,
    note: str,
    external_id: str | None = None,
) -> CRMSyncResult | None:
    """
    Push a note/summary to the lead's CRM record.

    Useful for: conversation summaries, handoff notes, scoring rationale.

    Returns:
        CRMSyncResult or None if no CRM configured.
        NEVER raises.
    """
    crm_type = getattr(client_config, "crm_type", None)
    crm_token = decrypt_token(getattr(client_config, "crm_token", None))

    if not crm_type or not crm_token:
        return None

    adapter = get_adapter(crm_type)
    if adapter is None:
        return CRMSyncResult(
            status=CRMSyncStatus.FAILED,
            crm_type=crm_type,
            message=f"Unknown CRM type: {crm_type}",
        )

    try:
        result = await adapter.push_note(
            crm_token=crm_token,
            external_id=external_id,
            phone=phone,
            note=note,
        )

        if result.status == CRMSyncStatus.SUCCESS:
            logger.info("[crm_sync] Note pushed to %s for phone=%s", crm_type, phone[-4:])
        else:
            logger.warning("[crm_sync] Note push to %s failed: %s", crm_type, result.message)

        return result

    except Exception as e:
        logger.error("[crm_sync] Note push error: %s", e, exc_info=True)
        return CRMSyncResult(
            status=CRMSyncStatus.FAILED,
            crm_type=crm_type,
            message=f"Unexpected error: {e}",
        )


async def check_crm_health(
    client_config: Any,
) -> CRMSyncResult | None:
    """
    Check if the client's CRM connection is healthy.
    Used by the admin API to show connection status.

    Returns None if no CRM configured.
    """
    crm_type = getattr(client_config, "crm_type", None)
    crm_token = decrypt_token(getattr(client_config, "crm_token", None))

    if not crm_type or not crm_token:
        return None

    adapter = get_adapter(crm_type)
    if adapter is None:
        return CRMSyncResult(
            status=CRMSyncStatus.FAILED,
            crm_type=crm_type,
            message=f"Unknown CRM type: {crm_type}",
        )

    try:
        return await adapter.check_health(crm_token)
    except Exception as e:
        return CRMSyncResult(
            status=CRMSyncStatus.FAILED,
            crm_type=crm_type,
            message=f"Health check error: {e}",
        )
