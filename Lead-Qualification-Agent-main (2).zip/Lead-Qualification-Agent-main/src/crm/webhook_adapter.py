"""
Generic Webhook CRM adapter — posts lead data to any URL.

This is the universal adapter: if a client's CRM supports inbound webhooks
(Salesforce, HubSpot, Zoho, or a custom system), they configure a webhook URL
as the crm_token and we POST lead data to it.

Token format: the full webhook URL (e.g. "https://hooks.salesforce.com/xxx")
"""
import logging
from typing import Any

import httpx

from src.crm.base import (
    BaseCRMAdapter, CRMLeadPayload, CRMSyncResult, CRMSyncStatus,
)

logger = logging.getLogger(__name__)

# 10s connect + 15s total — CRM webhooks can be slow
TIMEOUT = httpx.Timeout(connect=10.0, read=15.0, write=10.0, pool=5.0)


class WebhookCRMAdapter(BaseCRMAdapter):
    """
    Posts lead data to a client-configured webhook URL.

    The crm_token IS the webhook URL. The payload is JSON-posted as-is.
    Suitable for: Zapier, Make, Salesforce Web-to-Lead, HubSpot forms, custom endpoints.
    """

    @property
    def crm_type(self) -> str:
        return "webhook"

    async def push_lead(
        self,
        crm_token: str,
        payload: CRMLeadPayload,
        **kwargs: Any,
    ) -> CRMSyncResult:
        """POST lead data to the webhook URL."""
        webhook_url = crm_token.strip()
        if not webhook_url:
            return self._make_result(CRMSyncStatus.SKIPPED, message="No webhook URL configured")

        body = {
            "event": "lead_created_or_updated",
            "source": "leadengine",
            **payload.to_dict(),
        }

        try:
            async with httpx.AsyncClient(timeout=TIMEOUT) as client:
                resp = await client.post(webhook_url, json=body)

            if resp.status_code in (200, 201, 202):
                # Try to extract an ID from the response
                external_id = None
                try:
                    resp_json = resp.json()
                    external_id = str(
                        resp_json.get("id")
                        or resp_json.get("lead_id")
                        or resp_json.get("contact_id")
                        or ""
                    ) or None
                except Exception:
                    pass

                return self._make_result(
                    CRMSyncStatus.SUCCESS,
                    external_id=external_id,
                    message=f"HTTP {resp.status_code}",
                    raw_response={"status_code": resp.status_code},
                )

            if resp.status_code in (401, 403):
                return self._make_result(
                    CRMSyncStatus.AUTH_ERROR,
                    message=f"Webhook returned {resp.status_code}",
                    raw_response={"status_code": resp.status_code, "body": resp.text[:500]},
                )

            return self._make_result(
                CRMSyncStatus.FAILED,
                message=f"Webhook returned {resp.status_code}",
                raw_response={"status_code": resp.status_code, "body": resp.text[:500]},
            )

        except httpx.TimeoutException as e:
            logger.warning("[webhook_crm] Timeout posting to %s: %s", webhook_url[:60], e)
            return self._make_result(CRMSyncStatus.FAILED, message=f"Timeout: {e}")
        except httpx.RequestError as e:
            logger.warning("[webhook_crm] Request error for %s: %s", webhook_url[:60], e)
            return self._make_result(CRMSyncStatus.FAILED, message=f"Request error: {e}")

    async def update_lead(
        self,
        crm_token: str,
        payload: CRMLeadPayload,
        external_id: str | None = None,
        fields: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> CRMSyncResult:
        """
        For webhook adapter, update = re-push with event type changed.
        Most webhook consumers handle upsert by phone number.
        """
        webhook_url = crm_token.strip()
        if not webhook_url:
            return self._make_result(CRMSyncStatus.SKIPPED, message="No webhook URL configured")

        body = {
            "event": "lead_updated",
            "source": "leadengine",
            "external_id": external_id,
            "updated_fields": fields or {},
            **payload.to_dict(),
        }

        try:
            async with httpx.AsyncClient(timeout=TIMEOUT) as client:
                resp = await client.post(webhook_url, json=body)

            if resp.status_code in (200, 201, 202):
                return self._make_result(
                    CRMSyncStatus.UPDATED,
                    external_id=external_id,
                    message=f"HTTP {resp.status_code}",
                )

            return self._make_result(
                CRMSyncStatus.FAILED,
                message=f"Webhook returned {resp.status_code}",
            )

        except (httpx.TimeoutException, httpx.RequestError) as e:
            logger.warning("[webhook_crm] Update failed for %s: %s", webhook_url[:60], e)
            return self._make_result(CRMSyncStatus.FAILED, message=str(e))

    async def push_note(
        self,
        crm_token: str,
        external_id: str | None = None,
        phone: str | None = None,
        note: str = "",
        **kwargs: Any,
    ) -> CRMSyncResult:
        """POST a note event to the webhook."""
        webhook_url = crm_token.strip()
        if not webhook_url:
            return self._make_result(CRMSyncStatus.SKIPPED, message="No webhook URL configured")

        body = {
            "event": "lead_note",
            "source": "leadengine",
            "external_id": external_id,
            "phone": phone,
            "note": note,
        }

        try:
            async with httpx.AsyncClient(timeout=TIMEOUT) as client:
                resp = await client.post(webhook_url, json=body)

            if resp.status_code in (200, 201, 202):
                return self._make_result(CRMSyncStatus.SUCCESS, message="Note posted")

            return self._make_result(
                CRMSyncStatus.FAILED,
                message=f"Webhook returned {resp.status_code}",
            )

        except (httpx.TimeoutException, httpx.RequestError) as e:
            logger.warning("[webhook_crm] Note push failed: %s", e)
            return self._make_result(CRMSyncStatus.FAILED, message=str(e))

    async def check_health(self, crm_token: str) -> CRMSyncResult:
        """
        Verify the webhook URL is reachable with a GET request.
        Many webhook endpoints accept GET for health checks.
        """
        webhook_url = crm_token.strip()
        if not webhook_url:
            return self._make_result(CRMSyncStatus.SKIPPED, message="No webhook URL configured")

        try:
            async with httpx.AsyncClient(timeout=TIMEOUT) as client:
                resp = await client.get(webhook_url)

            if resp.status_code < 500:
                return self._make_result(
                    CRMSyncStatus.SUCCESS,
                    message=f"Webhook reachable (HTTP {resp.status_code})",
                )

            return self._make_result(
                CRMSyncStatus.FAILED,
                message=f"Webhook returned {resp.status_code}",
            )

        except (httpx.TimeoutException, httpx.RequestError) as e:
            return self._make_result(CRMSyncStatus.FAILED, message=f"Unreachable: {e}")
