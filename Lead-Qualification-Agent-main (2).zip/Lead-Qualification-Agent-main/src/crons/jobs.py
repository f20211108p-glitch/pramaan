"""
Scheduled jobs — replaces all n8n workflows with APScheduler inside FastAPI.

Jobs:
  1. daily_digest()          — 8:00 AM IST, summarise yesterday's leads to brokers
  2. stale_reengagement()    — 10:00 AM IST, re-engage nurturing leads (7+ days stale)
  3. warm_lead_digest()      — 6:00 PM IST, evening WARM-only digest to primary broker

All jobs are multi-tenant: they iterate over every active client and use that
client's WABA credentials to send template messages.

Cost notes (outside-24h-window WhatsApp pricing):
  - Utility template:   ~₹0.17/msg
  - Marketing template:  ~₹1.02/msg
"""
import logging
from datetime import datetime, timedelta, timezone

from sqlalchemy import select, func, and_
from sqlalchemy.ext.asyncio import AsyncSession

from src.db.engine import AsyncSessionFactory
from src.db.tables import ClientConfig, Lead, Conversation, BillingEvent
from src.db.queries import get_or_create_conversation, save_message
from src.channels.whatsapp import WhatsAppChannel

logger = logging.getLogger(__name__)

# ── Timezone ──────────────────────────────────────────────────────────────────
IST = timezone(timedelta(hours=5, minutes=30))


def _template_param(text: str) -> str:
    """
    Sanitize text for a WhatsApp template BODY parameter.
    Meta rejects params containing newlines/tabs (#132000) — every digest
    was failing at the API. Collapse to a single line.
    """
    return " | ".join(part.strip() for part in text.splitlines() if part.strip())


# ═══════════════════════════════════════════════════════════════════════════════
# JOB 1: Daily Digest — 8:00 AM IST
# ═══════════════════════════════════════════════════════════════════════════════

def _format_digest(
    client_name: str,
    date_str: str,
    leads_by_tier: dict[str, int],
    total_new: int,
    appointments_booked: int,
    avg_response_min: float | None,
) -> str:
    """Format the daily digest message text for WhatsApp."""
    hot = leads_by_tier.get("hot", 0)
    warm = leads_by_tier.get("warm", 0)
    cold = leads_by_tier.get("cold", 0)

    lines = [
        f"*{client_name} — Daily Lead Report*",
        f"Date: {date_str}",
        "",
        f"New Leads: {total_new}",
        f"  Hot: {hot}  |  Warm: {warm}  |  Cold: {cold}",
        f"Appointments Booked: {appointments_booked}",
    ]
    if avg_response_min is not None:
        lines.append(f"Avg Response Time: {avg_response_min:.0f} min")
    else:
        lines.append("Avg Response Time: N/A")

    lines.append("")
    lines.append("Check your dashboard for full details.")
    return "\n".join(lines)


async def _build_digest_for_client(
    db: AsyncSession,
    client: ClientConfig,
    target_date: datetime,
) -> str | None:
    """
    Query yesterday's data for a single client and return formatted digest text.
    Returns None if there's nothing to report.
    """
    client_id = str(client.id)
    day_start = target_date.replace(hour=0, minute=0, second=0, microsecond=0)
    day_end = day_start + timedelta(days=1)

    # Count new leads grouped by tier
    tier_rows = (await db.execute(
        select(Lead.tier, func.count(Lead.id))
        .where(
            Lead.client_id == client.id,
            Lead.created_at >= day_start,
            Lead.created_at < day_end,
        )
        .group_by(Lead.tier)
    )).all()

    leads_by_tier: dict[str, int] = {}
    total_new = 0
    for tier_val, cnt in tier_rows:
        key = (tier_val or "unscored").lower()
        leads_by_tier[key] = cnt
        total_new += cnt

    # Count appointments booked (billing events with event_type = "site_visit_booked")
    appt_count = (await db.execute(
        select(func.count(BillingEvent.id)).where(
            BillingEvent.client_id == client.id,
            BillingEvent.event_type == "site_visit_booked",
            BillingEvent.created_at >= day_start,
            BillingEvent.created_at < day_end,
        )
    )).scalar() or 0

    # Average response time: time between first inbound and first outbound per conversation
    # This is a simplified metric — avg of (first_outbound - conversation.started_at)
    # For a lightweight approach, skip if no leads
    avg_response_min = None  # future: compute from message timestamps

    if total_new == 0 and appt_count == 0:
        return None

    date_str = day_start.strftime("%d %b %Y")
    return _format_digest(
        client_name=client.client_name,
        date_str=date_str,
        leads_by_tier=leads_by_tier,
        total_new=total_new,
        appointments_booked=appt_count,
        avg_response_min=avg_response_min,
    )


async def daily_digest() -> dict:
    """
    Job 1: Send daily lead summary to all broker numbers for each active client.
    Runs at 8:00 AM IST.

    Returns summary dict for logging/testing.
    """
    logger.info("[cron:daily_digest] Starting daily digest run")
    results: dict[str, dict] = {}

    async with AsyncSessionFactory() as db:
        clients = (await db.execute(
            select(ClientConfig).where(ClientConfig.active.is_(True))
        )).scalars().all()

        yesterday = datetime.now(IST) - timedelta(days=1)

        for client in clients:
            client_id = str(client.id)
            broker_numbers = client.broker_wa_numbers or []
            if not broker_numbers:
                results[client_id] = {"skipped": True, "reason": "no_brokers"}
                continue

            digest_text = await _build_digest_for_client(db, client, yesterday)
            if digest_text is None:
                results[client_id] = {"skipped": True, "reason": "no_activity"}
                continue

            # Send to each broker via template message
            sent = 0
            for broker_phone in broker_numbers:
                try:
                    ok = await WhatsAppChannel.send_template_message(
                        waba_phone_number_id=client.waba_phone_number_id,
                        waba_token=client.waba_token,
                        to=broker_phone,
                        template_name="daily_digest",
                        language_code="en",
                        components=[{
                            "type": "body",
                            "parameters": [{"type": "text", "text": _template_param(digest_text)}],
                        }],
                    )
                    if ok:
                        sent += 1
                except Exception as e:
                    logger.error(
                        "[cron:daily_digest] Failed sending to %s: %s",
                        broker_phone, e,
                    )

            results[client_id] = {"sent": sent, "total_brokers": len(broker_numbers)}

    logger.info("[cron:daily_digest] Completed: %s", results)
    return results


# ═══════════════════════════════════════════════════════════════════════════════
# JOB 2: Stale Re-engagement — 10:00 AM IST
# ═══════════════════════════════════════════════════════════════════════════════

MAX_REENGAGEMENTS_PER_CLIENT = 50  # cost control


def _build_reengagement_message(lead: Lead) -> str:
    """Build a personalized re-engagement message (no LLM, template-based)."""
    name = lead.name or "there"
    prop_type = lead.property_type or "property"
    locs = lead.location_preferences or []
    if isinstance(locs, list) and locs:
        location = locs[0] if isinstance(locs[0], str) else str(locs[0])
    else:
        location = "your preferred area"

    return (
        f"Hi {name}, we noticed you were interested in a {prop_type} "
        f"in {location}. Prices have been updated recently — "
        f"would you like to know more? Reply to continue the conversation!"
    )


async def stale_reengagement() -> dict:
    """
    Job 2: Re-engage leads in 'nurturing' stage with no activity for 7+ days.
    Max 50 per client per run (cost control — marketing templates cost ~₹1.02/msg).
    Runs at 10:00 AM IST.
    """
    logger.info("[cron:stale_reengagement] Starting re-engagement run")
    results: dict[str, dict] = {}

    cutoff = datetime.now(IST) - timedelta(days=7)

    async with AsyncSessionFactory() as db:
        clients = (await db.execute(
            select(ClientConfig).where(ClientConfig.active.is_(True))
        )).scalars().all()

        for client in clients:
            client_id = str(client.id)

            # Find stale nurturing leads
            stale_leads = (await db.execute(
                select(Lead).where(
                    Lead.client_id == client.id,
                    Lead.stage == "nurturing",
                    Lead.updated_at < cutoff,
                ).limit(MAX_REENGAGEMENTS_PER_CLIENT)
            )).scalars().all()

            if not stale_leads:
                results[client_id] = {"skipped": True, "reason": "no_stale_leads"}
                continue

            sent = 0
            for lead in stale_leads:
                msg = _build_reengagement_message(lead)
                try:
                    ok = await WhatsAppChannel.send_template_message(
                        waba_phone_number_id=client.waba_phone_number_id,
                        waba_token=client.waba_token,
                        to=lead.phone,
                        template_name="stale_reengagement",
                        language_code="en",
                        components=[{
                            "type": "body",
                            "parameters": [{"type": "text", "text": _template_param(msg)}],
                        }],
                    )
                    if ok:
                        sent += 1
                        # Update the lead so it's not picked up again tomorrow
                        lead.updated_at = datetime.now(timezone.utc)
                        await db.commit()
                        # Persist into conversation history — otherwise the
                        # qualifier never sees the question the lead answers next
                        conv = await get_or_create_conversation(db, str(client.id), lead.id)
                        await save_message(
                            db, str(client.id), conv.id,
                            direction="outbound", content=msg,
                        )
                except Exception as e:
                    logger.error(
                        "[cron:stale_reengagement] Failed for lead %s: %s",
                        lead.phone, e,
                    )

            results[client_id] = {
                "stale_found": len(stale_leads),
                "sent": sent,
            }

    logger.info("[cron:stale_reengagement] Completed: %s", results)
    return results


# ═══════════════════════════════════════════════════════════════════════════════
# JOB 3: Warm Lead Digest — 6:00 PM IST
# ═══════════════════════════════════════════════════════════════════════════════

async def warm_lead_digest() -> dict:
    """
    Job 3: Evening digest of WARM leads only, sent to primary broker (first number).
    Runs at 6:00 PM IST.
    """
    logger.info("[cron:warm_lead_digest] Starting warm lead digest")
    results: dict[str, dict] = {}

    async with AsyncSessionFactory() as db:
        clients = (await db.execute(
            select(ClientConfig).where(ClientConfig.active.is_(True))
        )).scalars().all()

        today_start = datetime.now(IST).replace(hour=0, minute=0, second=0, microsecond=0)
        today_end = today_start + timedelta(days=1)

        for client in clients:
            client_id = str(client.id)
            broker_numbers = client.broker_wa_numbers or []
            if not broker_numbers:
                results[client_id] = {"skipped": True, "reason": "no_brokers"}
                continue

            # Only primary broker (first number) gets the warm digest
            primary_broker = broker_numbers[0]

            # Count today's warm leads
            warm_leads = (await db.execute(
                select(Lead).where(
                    Lead.client_id == client.id,
                    Lead.tier == "warm",
                    Lead.created_at >= today_start,
                    Lead.created_at < today_end,
                )
            )).scalars().all()

            if not warm_leads:
                results[client_id] = {"skipped": True, "reason": "no_warm_leads"}
                continue

            # Build summary
            lead_lines = []
            for lead in warm_leads[:10]:  # cap at 10 to keep message short
                name = lead.name or "Unknown"
                prop = lead.property_type or "N/A"
                score = lead.score or 0
                lead_lines.append(f"  - {name} ({prop}, score {score})")

            text = (
                f"*{client.client_name} — Warm Leads Today*\n"
                f"Total: {len(warm_leads)}\n\n"
                + "\n".join(lead_lines)
                + "\n\nThese leads are actively exploring. Follow up soon!"
            )

            try:
                ok = await WhatsAppChannel.send_template_message(
                    waba_phone_number_id=client.waba_phone_number_id,
                    waba_token=client.waba_token,
                    to=primary_broker,
                    template_name="warm_lead_digest",
                    language_code="en",
                    components=[{
                        "type": "body",
                        "parameters": [{"type": "text", "text": _template_param(text)}],
                    }],
                )
                results[client_id] = {"sent": 1 if ok else 0, "warm_count": len(warm_leads)}
            except Exception as e:
                logger.error(
                    "[cron:warm_lead_digest] Failed for client %s: %s",
                    client_id, e,
                )
                results[client_id] = {"sent": 0, "error": str(e)}

    logger.info("[cron:warm_lead_digest] Completed: %s", results)
    return results


# ═══════════════════════════════════════════════════════════════════════════════
# JOB 4: HOT Lead Follow-up — every 4 hours
# ═══════════════════════════════════════════════════════════════════════════════

MAX_HOT_FOLLOWUPS_PER_CLIENT = 20  # cost control


def _build_hot_followup(lead: Lead, language: str) -> str:
    """Template for HOT leads who haven't confirmed a site visit slot."""
    name = lead.name or "there"
    if language in ("hindi", "hinglish"):
        return (
            f"Hi {name}, aapne abhi tak site visit ka time confirm nahi kiya. "
            f"Koi bhi din aur time batao — hum aapke liye arrange kar denge! 🏠"
        )
    return (
        f"Hi {name}, just following up on your site visit! "
        f"Let me know which day and time works best for you. 🏠"
    )


def _build_warm_followup(lead: Lead, language: str) -> str:
    """Template for WARM leads who went quiet during qualification."""
    name = lead.name or "there"
    prop_type = lead.property_type or "property"
    locs = lead.location_preferences or []
    location = locs[0] if isinstance(locs, list) and locs else "your preferred area"

    if language in ("hindi", "hinglish"):
        return (
            f"Hi {name}, {location} mein {prop_type} ke baare mein aapki enquiry "
            f"incomplete reh gayi thi. Kuch aur jaanna chahte ho? Main help kar sakta hu! 😊"
        )
    return (
        f"Hi {name}, we noticed your enquiry about a {prop_type} in {location} "
        f"is still open. Would you like to continue? I'm here to help! 😊"
    )


async def followup_hot_leads() -> dict:
    """
    Job 4: Follow up with HOT leads in 'scheduling' stage who haven't
    confirmed a slot within 24 hours.

    Only follows up within the WhatsApp 24h conversation window (free text).
    Leads idle 12-24h get a nudge. Beyond 24h needs a template (skipped).

    Respects per-client `prompt_overrides.followup_enabled` toggle.
    Runs every 4 hours.
    """
    logger.info("[cron:followup_hot] Starting HOT lead follow-up run")
    results: dict[str, dict] = {}

    now = datetime.now(IST)
    # Target: leads updated 12-24h ago (within WhatsApp free window, not too soon)
    window_start = now - timedelta(hours=24)
    window_end = now - timedelta(hours=12)

    async with AsyncSessionFactory() as db:
        clients = (await db.execute(
            select(ClientConfig).where(ClientConfig.active.is_(True))
        )).scalars().all()

        for client in clients:
            client_id = str(client.id)

            # Check followup toggle (default: enabled)
            overrides = client.prompt_overrides or {}
            if overrides.get("followup_enabled") is False:
                results[client_id] = {"skipped": True, "reason": "followup_disabled"}
                continue

            # Find HOT leads in scheduling stage, idle 12-24h
            hot_leads = (await db.execute(
                select(Lead).where(
                    Lead.client_id == client.id,
                    Lead.tier == "hot",
                    Lead.stage == "scheduling",
                    Lead.updated_at >= window_start,
                    Lead.updated_at <= window_end,
                ).limit(MAX_HOT_FOLLOWUPS_PER_CLIENT)
            )).scalars().all()

            if not hot_leads:
                results[client_id] = {"skipped": True, "reason": "no_hot_idle_leads"}
                continue

            sent = 0
            for lead in hot_leads:
                language = lead.language_pref or "english"
                msg = _build_hot_followup(lead, language)
                try:
                    ok = await WhatsAppChannel.send_message(
                        waba_phone_number_id=client.waba_phone_number_id,
                        waba_token=client.waba_token,
                        to=lead.phone,
                        content=msg,
                    )
                    if ok:
                        sent += 1
                        # Bump updated_at so we don't re-send next run
                        lead.updated_at = datetime.now(timezone.utc)
                        await db.commit()
                        # Persist into conversation history for the qualifier/dashboard
                        conv = await get_or_create_conversation(db, str(client.id), lead.id)
                        await save_message(
                            db, str(client.id), conv.id,
                            direction="outbound", content=msg,
                        )
                except Exception as e:
                    logger.error(
                        "[cron:followup_hot] Failed for lead %s: %s",
                        lead.phone, e,
                    )

            results[client_id] = {"hot_idle": len(hot_leads), "sent": sent}

    logger.info("[cron:followup_hot] Completed: %s", results)
    return results


# ═══════════════════════════════════════════════════════════════════════════════
# JOB 5: WARM Lead Follow-up — every 6 hours
# ═══════════════════════════════════════════════════════════════════════════════

MAX_WARM_FOLLOWUPS_PER_CLIENT = 30  # cost control


async def followup_warm_leads() -> dict:
    """
    Job 5: Follow up with WARM leads who went quiet during qualification.

    Target: WARM leads idle 24-48h. Within 24h window → free text.
    Beyond 24h → still attempt send_message (Meta may reject outside window,
    but many conversations stay open due to recent bot replies).

    Respects per-client `prompt_overrides.followup_enabled` toggle.
    Runs every 6 hours.
    """
    logger.info("[cron:followup_warm] Starting WARM lead follow-up run")
    results: dict[str, dict] = {}

    now = datetime.now(IST)
    window_start = now - timedelta(hours=48)
    window_end = now - timedelta(hours=24)

    async with AsyncSessionFactory() as db:
        clients = (await db.execute(
            select(ClientConfig).where(ClientConfig.active.is_(True))
        )).scalars().all()

        for client in clients:
            client_id = str(client.id)

            # Check followup toggle (default: enabled)
            overrides = client.prompt_overrides or {}
            if overrides.get("followup_enabled") is False:
                results[client_id] = {"skipped": True, "reason": "followup_disabled"}
                continue

            # Find WARM leads idle 24-48h (qualifying or nurturing stage)
            warm_leads = (await db.execute(
                select(Lead).where(
                    Lead.client_id == client.id,
                    Lead.tier == "warm",
                    Lead.stage.in_(["qualifying", "qualified", "nurturing"]),
                    Lead.updated_at >= window_start,
                    Lead.updated_at <= window_end,
                ).limit(MAX_WARM_FOLLOWUPS_PER_CLIENT)
            )).scalars().all()

            if not warm_leads:
                results[client_id] = {"skipped": True, "reason": "no_warm_idle_leads"}
                continue

            sent = 0
            for lead in warm_leads:
                language = lead.language_pref or "english"
                msg = _build_warm_followup(lead, language)
                try:
                    ok = await WhatsAppChannel.send_message(
                        waba_phone_number_id=client.waba_phone_number_id,
                        waba_token=client.waba_token,
                        to=lead.phone,
                        content=msg,
                    )
                    if ok:
                        sent += 1
                        lead.updated_at = datetime.now(timezone.utc)
                        await db.commit()
                        # Persist into conversation history for the qualifier/dashboard
                        conv = await get_or_create_conversation(db, str(client.id), lead.id)
                        await save_message(
                            db, str(client.id), conv.id,
                            direction="outbound", content=msg,
                        )
                except Exception as e:
                    logger.error(
                        "[cron:followup_warm] Failed for lead %s: %s",
                        lead.phone, e,
                    )

            results[client_id] = {"warm_idle": len(warm_leads), "sent": sent}

    logger.info("[cron:followup_warm] Completed: %s", results)
    return results
