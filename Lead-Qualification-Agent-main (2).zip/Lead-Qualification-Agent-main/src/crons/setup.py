"""
APScheduler integration — wire cron jobs into FastAPI's lifespan.

Uses Redis distributed locking so that even with multiple uvicorn workers,
each cron job executes exactly once per scheduled trigger.

Usage in main.py:
    from src.crons.setup import start_scheduler, stop_scheduler

    @asynccontextmanager
    async def lifespan(app):
        ...
        start_scheduler()
        yield
        stop_scheduler()
"""
import functools
import logging

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger

from src.crons.jobs import (
    daily_digest, stale_reengagement, warm_lead_digest,
    followup_hot_leads, followup_warm_leads,
)
from src.config import get_settings
from src.core.redis import get_redis

logger = logging.getLogger(__name__)

_scheduler: AsyncIOScheduler | None = None

# Lock TTL — if a job takes longer than this, another worker can pick it up.
# Set conservatively high; most jobs finish in <60s.
_LOCK_TTL_SECONDS = 300


def _with_redis_lock(job_id: str, ttl: int = _LOCK_TTL_SECONDS):
    """
    Decorator that wraps an async cron job with a Redis SETNX lock.
    If another worker already holds the lock, this invocation skips silently.
    Prevents duplicate execution across multiple uvicorn workers.
    """
    def decorator(func):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            redis = get_redis()
            lock_key = f"cron_lock:{job_id}"

            # Try to acquire lock (SET NX EX = atomic set-if-not-exists with TTL)
            acquired = await redis.set(lock_key, "1", nx=True, ex=ttl)
            if not acquired:
                logger.debug("[scheduler] Job '%s' skipped — another worker holds the lock", job_id)
                return None

            try:
                logger.info("[scheduler] Job '%s' acquired lock, executing", job_id)
                return await func(*args, **kwargs)
            finally:
                # Release lock when done (even on error)
                await redis.delete(lock_key)

        return wrapper
    return decorator


# Wrap each job with the distributed lock
_daily_digest = _with_redis_lock("daily_digest")(daily_digest)
_stale_reengagement = _with_redis_lock("stale_reengagement")(stale_reengagement)
_warm_lead_digest = _with_redis_lock("warm_lead_digest")(warm_lead_digest)
_followup_hot_leads = _with_redis_lock("followup_hot_leads")(followup_hot_leads)
_followup_warm_leads = _with_redis_lock("followup_warm_leads")(followup_warm_leads)


def start_scheduler() -> AsyncIOScheduler:
    """Create and start the APScheduler. Safe to call in dev and production."""
    global _scheduler

    settings = get_settings()
    _scheduler = AsyncIOScheduler()

    # All times in IST (Asia/Kolkata)
    tz = "Asia/Kolkata"

    _scheduler.add_job(
        _daily_digest,
        CronTrigger(hour=8, minute=0, timezone=tz),
        id="daily_digest",
        name="Daily lead digest to brokers",
        replace_existing=True,
    )

    _scheduler.add_job(
        _stale_reengagement,
        CronTrigger(hour=10, minute=0, timezone=tz),
        id="stale_reengagement",
        name="Re-engage stale nurturing leads",
        replace_existing=True,
    )

    _scheduler.add_job(
        _warm_lead_digest,
        CronTrigger(hour=18, minute=0, timezone=tz),
        id="warm_lead_digest",
        name="Warm lead evening digest",
        replace_existing=True,
    )

    # ── Follow-up jobs (HOT 24h, WARM 48h) ──────────────────────────
    _scheduler.add_job(
        _followup_hot_leads,
        CronTrigger(hour="8,12,16,20", minute=30, timezone=tz),  # every 4h
        id="followup_hot_leads",
        name="Follow up HOT leads (scheduling, idle 12-24h)",
        replace_existing=True,
    )

    _scheduler.add_job(
        _followup_warm_leads,
        CronTrigger(hour="9,15,21", minute=30, timezone=tz),  # every 6h
        id="followup_warm_leads",
        name="Follow up WARM leads (idle 24-48h)",
        replace_existing=True,
    )

    _scheduler.start()
    logger.info(
        "[scheduler] Started APScheduler with %d jobs (env=%s)",
        len(_scheduler.get_jobs()),
        settings.app_env,
    )
    return _scheduler


def stop_scheduler() -> None:
    """Gracefully shut down the scheduler."""
    global _scheduler
    if _scheduler and _scheduler.running:
        _scheduler.shutdown(wait=False)
        logger.info("[scheduler] APScheduler shut down")
    _scheduler = None


def get_scheduler() -> AsyncIOScheduler | None:
    """Return the running scheduler instance (for admin endpoints / testing)."""
    return _scheduler
