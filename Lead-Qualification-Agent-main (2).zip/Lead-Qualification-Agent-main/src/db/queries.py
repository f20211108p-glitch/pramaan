"""
Common DB queries. EVERY query filters by client_id — this is the multi-tenant boundary.
"""
from datetime import datetime, timezone
from typing import Any
from uuid import UUID

from sqlalchemy import select, update, func, case, and_
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from src.db.tables import (
    ClientConfig, Lead, Conversation, Message, BillingEvent, ConsentLog,
)


async def get_or_create_lead(
    db: AsyncSession,
    client_id: str | UUID,
    phone: str,
) -> Lead:
    result = await db.execute(
        select(Lead).where(
            Lead.client_id == client_id,
            Lead.phone == phone,
        )
    )
    lead = result.scalar_one_or_none()
    if lead:
        return lead

    lead = Lead(client_id=client_id, phone=phone)
    db.add(lead)
    await db.commit()
    await db.refresh(lead)
    return lead


async def get_or_create_conversation(
    db: AsyncSession,
    client_id: str | UUID,
    lead_id: str | UUID,
    channel: str = "whatsapp",
) -> Conversation:
    result = await db.execute(
        select(Conversation).where(
            Conversation.client_id == client_id,
            Conversation.lead_id == lead_id,
            Conversation.status == "active",
        )
    )
    conversation = result.scalar_one_or_none()
    if conversation:
        return conversation

    conversation = Conversation(
        client_id=client_id,
        lead_id=lead_id,
        channel=channel,
    )
    db.add(conversation)
    await db.commit()
    await db.refresh(conversation)
    return conversation


async def save_message(
    db: AsyncSession,
    client_id: str | UUID,
    conversation_id: str | UUID,
    direction: str,
    content: str,
    message_type: str = "text",
    channel_message_id: str | None = None,
) -> Message:
    msg = Message(
        client_id=client_id,
        conversation_id=conversation_id,
        direction=direction,
        content=content,
        message_type=message_type,
        channel_message_id=channel_message_id,
        timestamp=datetime.now(timezone.utc),
    )
    db.add(msg)
    await db.flush()
    await db.refresh(msg)

    # bump last_message_at on the conversation
    await db.execute(
        update(Conversation)
        .where(
            Conversation.id == conversation_id,
            Conversation.client_id == client_id,
        )
        .values(last_message_at=datetime.now(timezone.utc))
    )
    await db.commit()
    return msg


async def update_lead(
    db: AsyncSession,
    client_id: str | UUID,
    lead_id: str | UUID,
    fields: dict[str, Any],
) -> Lead:
    fields["updated_at"] = datetime.now(timezone.utc)
    await db.execute(
        update(Lead)
        .where(Lead.id == lead_id, Lead.client_id == client_id)
        .values(**fields)
    )
    await db.commit()

    # Re-read with a fresh SELECT to get updated values
    # (don't use expire_all — it invalidates other loaded objects like client_config)
    result = await db.execute(
        select(Lead).where(Lead.id == lead_id, Lead.client_id == client_id)
        .execution_options(populate_existing=True)
    )
    return result.scalar_one()


async def write_billing_event(
    db: AsyncSession,
    client_id: str | UUID,
    lead_id: str | UUID | None,
    event_type: str,
    metadata: dict | None = None,
    amount_inr: int | None = None,
) -> BillingEvent | None:
    """
    Write a billing event. Returns None (instead of raising) when the
    DB-level idempotency constraint rejects a duplicate qualified_lead
    event — concurrent runs and DLQ replays must not double-bill.
    """
    from sqlalchemy.exc import IntegrityError

    event = BillingEvent(
        client_id=client_id,
        lead_id=lead_id,
        event_type=event_type,
        amount_inr=amount_inr,
        extra_data=metadata,
    )
    db.add(event)
    try:
        await db.commit()
    except IntegrityError:
        await db.rollback()
        return None
    await db.refresh(event)
    return event


async def write_consent(
    db: AsyncSession,
    client_id: str | UUID,
    lead_id: str | UUID,
    consent_type: str,
    source: str,
    metadata: dict | None = None,
) -> ConsentLog:
    consent = ConsentLog(
        client_id=client_id,
        lead_id=lead_id,
        consent_type=consent_type,
        source=source,
        extra_data=metadata,
    )
    db.add(consent)
    await db.commit()
    await db.refresh(consent)
    return consent


async def has_consent(
    db: AsyncSession,
    client_id: str | UUID,
    lead_id: str | UUID,
) -> bool:
    result = await db.execute(
        select(ConsentLog).where(
            ConsentLog.client_id == client_id,
            ConsentLog.lead_id == lead_id,
            ConsentLog.consent_type == "data_collection",
        )
    )
    return result.scalar_one_or_none() is not None


# ═══════════════════════════════════════════════════════════════════════════════
# Admin API queries — Chunk 7A
# ═══════════════════════════════════════════════════════════════════════════════


# ── Client queries ────────────────────────────────────────────────────────────

async def list_clients(db: AsyncSession, active_only: bool = True) -> list[ClientConfig]:
    """List all clients, optionally filtered by active status."""
    q = select(ClientConfig)
    if active_only:
        q = q.where(ClientConfig.active == True)
    q = q.order_by(ClientConfig.created_at.desc())
    result = await db.execute(q)
    return list(result.scalars().all())


async def get_client(db: AsyncSession, client_id: str | UUID) -> ClientConfig | None:
    """Get a single client by ID."""
    result = await db.execute(
        select(ClientConfig).where(ClientConfig.id == client_id)
    )
    return result.scalar_one_or_none()


async def create_client(db: AsyncSession, fields: dict[str, Any]) -> ClientConfig:
    """Create a new client config."""
    client = ClientConfig(**fields)
    db.add(client)
    await db.commit()
    await db.refresh(client)
    return client


async def update_client(
    db: AsyncSession,
    client_id: str | UUID,
    fields: dict[str, Any],
) -> ClientConfig | None:
    """Update a client config. Returns None if not found."""
    fields["updated_at"] = datetime.now(timezone.utc)
    await db.execute(
        update(ClientConfig)
        .where(ClientConfig.id == client_id)
        .values(**fields)
    )
    await db.commit()
    # Re-read with populate_existing to get updated values
    # (don't use expire_all — it invalidates other loaded objects)
    result = await db.execute(
        select(ClientConfig).where(ClientConfig.id == client_id)
        .execution_options(populate_existing=True)
    )
    return result.scalar_one_or_none()


# ── Lead queries ──────────────────────────────────────────────────────────────

async def list_leads(
    db: AsyncSession,
    client_id: str | UUID,
    tier: str | None = None,
    stage: str | None = None,
    search: str | None = None,
    limit: int = 50,
    offset: int = 0,
) -> tuple[list[Lead], int]:
    """
    List leads for a client with optional filters.
    Returns (leads, total_count) for pagination.
    """
    base = select(Lead).where(Lead.client_id == client_id)
    count_q = select(func.count(Lead.id)).where(Lead.client_id == client_id)

    if tier:
        base = base.where(Lead.tier == tier)
        count_q = count_q.where(Lead.tier == tier)
    if stage:
        base = base.where(Lead.stage == stage)
        count_q = count_q.where(Lead.stage == stage)
    if search:
        # Search by phone or name (case-insensitive)
        search_filter = Lead.phone.ilike(f"%{search}%") | Lead.name.ilike(f"%{search}%")
        base = base.where(search_filter)
        count_q = count_q.where(search_filter)

    total = (await db.execute(count_q)).scalar() or 0

    base = base.order_by(Lead.updated_at.desc()).limit(limit).offset(offset)
    result = await db.execute(base)
    leads = list(result.scalars().all())

    return leads, total


async def get_lead(
    db: AsyncSession,
    client_id: str | UUID,
    lead_id: str | UUID,
) -> Lead | None:
    """Get a single lead by ID (tenant-scoped)."""
    result = await db.execute(
        select(Lead).where(Lead.client_id == client_id, Lead.id == lead_id)
    )
    return result.scalar_one_or_none()


# ── Conversation queries ──────────────────────────────────────────────────────

async def list_conversations(
    db: AsyncSession,
    client_id: str | UUID,
    lead_id: str | UUID,
) -> list[Conversation]:
    """List all conversations for a lead."""
    result = await db.execute(
        select(Conversation)
        .where(Conversation.client_id == client_id, Conversation.lead_id == lead_id)
        .order_by(Conversation.started_at.desc())
    )
    return list(result.scalars().all())


async def get_conversation_messages(
    db: AsyncSession,
    client_id: str | UUID,
    conversation_id: str | UUID,
    limit: int = 100,
    offset: int = 0,
) -> list[Message]:
    """Get messages for a conversation (tenant-scoped, chronological order).

    IMPORTANT: We fetch the N most-recent messages (DESC) and then reverse
    to chronological order.  Using ASC + LIMIT would return the N *oldest*
    messages, cutting off the current inbound on long conversations — the
    nodes would then see the wrong "latest user message" as their context.
    """
    result = await db.execute(
        select(Message)
        .where(
            Message.client_id == client_id,
            Message.conversation_id == conversation_id,
        )
        .order_by(Message.timestamp.desc())   # newest first
        .limit(limit)
        .offset(offset)
    )
    # Reverse to restore chronological (oldest → newest) order for the LLM
    messages = list(result.scalars().all())
    messages.reverse()
    return messages


# ── Billing queries ──────────────────────────────────────────────────────────

async def list_billing_events(
    db: AsyncSession,
    client_id: str | UUID,
    limit: int = 50,
    offset: int = 0,
) -> tuple[list[BillingEvent], int]:
    """List billing events for a client with pagination."""
    count_q = select(func.count(BillingEvent.id)).where(
        BillingEvent.client_id == client_id,
    )
    total = (await db.execute(count_q)).scalar() or 0

    result = await db.execute(
        select(BillingEvent)
        .where(BillingEvent.client_id == client_id)
        .order_by(BillingEvent.created_at.desc())
        .limit(limit)
        .offset(offset)
    )
    events = list(result.scalars().all())
    return events, total


# ── Stats queries ─────────────────────────────────────────────────────────────

async def get_pipeline_stats(
    db: AsyncSession,
    client_id: str | UUID,
) -> dict[str, Any]:
    """
    Get pipeline overview stats for a client.
    Returns counts by tier, stage, and totals.
    """
    # Total leads
    total_q = select(func.count(Lead.id)).where(Lead.client_id == client_id)
    total = (await db.execute(total_q)).scalar() or 0

    # By tier
    tier_q = (
        select(Lead.tier, func.count(Lead.id))
        .where(Lead.client_id == client_id)
        .group_by(Lead.tier)
    )
    tier_rows = (await db.execute(tier_q)).all()
    by_tier = {(row[0] or "unscored"): row[1] for row in tier_rows}

    # By stage
    stage_q = (
        select(Lead.stage, func.count(Lead.id))
        .where(Lead.client_id == client_id)
        .group_by(Lead.stage)
    )
    stage_rows = (await db.execute(stage_q)).all()
    by_stage = {row[0]: row[1] for row in stage_rows}

    # Billing totals
    billing_count_q = select(func.count(BillingEvent.id)).where(
        BillingEvent.client_id == client_id,
    )
    billing_count = (await db.execute(billing_count_q)).scalar() or 0

    # Conversations count
    conv_count_q = select(func.count(Conversation.id)).where(
        Conversation.client_id == client_id,
    )
    conv_count = (await db.execute(conv_count_q)).scalar() or 0

    # Messages count
    msg_count_q = select(func.count(Message.id)).where(
        Message.client_id == client_id,
    )
    msg_count = (await db.execute(msg_count_q)).scalar() or 0

    return {
        "total_leads": total,
        "by_tier": by_tier,
        "by_stage": by_stage,
        "total_conversations": conv_count,
        "total_messages": msg_count,
        "total_billing_events": billing_count,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# Dashboard queries — Chunk 8
# ═══════════════════════════════════════════════════════════════════════════════


async def get_recent_leads(
    db: AsyncSession,
    client_id: str | UUID,
    tier: str | None = None,
    limit: int = 10,
) -> list[Lead]:
    """
    Get most recently updated leads for a client.
    Optionally filter by tier (e.g. only hot leads for dashboard priority list).
    """
    q = (
        select(Lead)
        .where(Lead.client_id == client_id)
        .order_by(Lead.updated_at.desc())
        .limit(limit)
    )
    if tier:
        q = q.where(Lead.tier == tier)
    result = await db.execute(q)
    return list(result.scalars().all())


async def get_lead_detail(
    db: AsyncSession,
    client_id: str | UUID,
    lead_id: str | UUID,
) -> dict[str, Any] | None:
    """
    Get a lead with all related data in one call:
      - lead profile
      - conversations list
      - messages for each conversation
      - billing events

    Returns None if lead not found. Used by dashboard lead detail view.
    """
    # Lead
    lead_result = await db.execute(
        select(Lead).where(Lead.client_id == client_id, Lead.id == lead_id)
    )
    lead = lead_result.scalar_one_or_none()
    if not lead:
        return None

    # Conversations
    conv_result = await db.execute(
        select(Conversation)
        .where(Conversation.client_id == client_id, Conversation.lead_id == lead_id)
        .order_by(Conversation.started_at.desc())
    )
    conversations = list(conv_result.scalars().all())

    # Messages for all conversations (batch — one query)
    conv_ids = [c.id for c in conversations]
    messages_by_conv: dict[str, list[Message]] = {str(c.id): [] for c in conversations}
    if conv_ids:
        msg_result = await db.execute(
            select(Message)
            .where(
                Message.client_id == client_id,
                Message.conversation_id.in_(conv_ids),
            )
            .order_by(Message.timestamp.asc())
        )
        for msg in msg_result.scalars().all():
            messages_by_conv[str(msg.conversation_id)].append(msg)

    # Billing events for this lead
    billing_result = await db.execute(
        select(BillingEvent)
        .where(BillingEvent.client_id == client_id, BillingEvent.lead_id == lead_id)
        .order_by(BillingEvent.created_at.desc())
    )
    billing_events = list(billing_result.scalars().all())

    # Consent
    consent_result = await db.execute(
        select(ConsentLog)
        .where(ConsentLog.client_id == client_id, ConsentLog.lead_id == lead_id)
    )
    consents = list(consent_result.scalars().all())

    return {
        "lead": lead,
        "conversations": conversations,
        "messages_by_conversation": messages_by_conv,
        "billing_events": billing_events,
        "consents": consents,
    }


async def get_lead_timeline(
    db: AsyncSession,
    client_id: str | UUID,
    lead_id: str | UUID,
    limit: int = 50,
) -> list[dict[str, Any]]:
    """
    Build a chronological activity timeline for a lead.
    Merges messages and billing events into a single sorted list.

    Each event: {type, timestamp, data}
    """
    events: list[dict[str, Any]] = []

    # Messages across all conversations for this lead
    conv_result = await db.execute(
        select(Conversation.id)
        .where(Conversation.client_id == client_id, Conversation.lead_id == lead_id)
    )
    conv_ids = [row[0] for row in conv_result.all()]

    if conv_ids:
        msg_result = await db.execute(
            select(Message)
            .where(
                Message.client_id == client_id,
                Message.conversation_id.in_(conv_ids),
            )
            .order_by(Message.timestamp.asc())
        )
        for msg in msg_result.scalars().all():
            events.append({
                "type": "message",
                "timestamp": msg.timestamp,
                "data": {
                    "direction": msg.direction,
                    "content": msg.content,
                    "message_type": msg.message_type,
                    "conversation_id": str(msg.conversation_id),
                },
            })

    # Billing events
    billing_result = await db.execute(
        select(BillingEvent)
        .where(BillingEvent.client_id == client_id, BillingEvent.lead_id == lead_id)
        .order_by(BillingEvent.created_at.asc())
    )
    for ev in billing_result.scalars().all():
        events.append({
            "type": "billing",
            "timestamp": ev.created_at,
            "data": {
                "event_type": ev.event_type,
                "amount_inr": ev.amount_inr,
                "extra_data": ev.extra_data,
            },
        })

    # Sort everything chronologically
    events.sort(key=lambda e: e["timestamp"])

    return events[-limit:]


async def get_recent_activity(
    db: AsyncSession,
    client_id: str | UUID,
    limit: int = 30,
) -> list[dict[str, Any]]:
    """
    Recent activity across ALL leads for a client.
    Used for the dashboard live feed / activity panel.

    Returns most recent messages with lead phone/name attached.
    """
    # Join messages → conversations → leads to get lead info
    result = await db.execute(
        select(
            Message.direction,
            Message.content,
            Message.message_type,
            Message.timestamp,
            Message.conversation_id,
            Lead.id.label("lead_id"),
            Lead.phone.label("lead_phone"),
            Lead.name.label("lead_name"),
            Lead.tier.label("lead_tier"),
        )
        .join(Conversation, Message.conversation_id == Conversation.id)
        .join(Lead, Conversation.lead_id == Lead.id)
        .where(Message.client_id == client_id)
        .order_by(Message.timestamp.desc())
        .limit(limit)
    )

    rows = result.all()
    return [
        {
            "direction": row.direction,
            "content": row.content[:200],  # truncate for feed
            "message_type": row.message_type,
            "timestamp": row.timestamp,
            "conversation_id": str(row.conversation_id),
            "lead_id": str(row.lead_id),
            "lead_phone": row.lead_phone,
            "lead_name": row.lead_name,
            "lead_tier": row.lead_tier,
        }
        for row in rows
    ]


async def bulk_update_leads(
    db: AsyncSession,
    client_id: str | UUID,
    lead_ids: list[str | UUID],
    fields: dict[str, Any],
) -> int:
    """
    Batch-update multiple leads at once.
    Used for: "select all → mark as handed_off", bulk stage changes.
    Returns the number of leads updated.
    """
    fields["updated_at"] = datetime.now(timezone.utc)
    result = await db.execute(
        update(Lead)
        .where(Lead.client_id == client_id, Lead.id.in_(lead_ids))
        .values(**fields)
    )
    await db.commit()
    return result.rowcount


async def get_conversation_export(
    db: AsyncSession,
    client_id: str | UUID,
    conversation_id: str | UUID,
) -> list[dict[str, Any]]:
    """
    Export a full conversation as a flat list of messages.
    Used for: CRM note generation, broker handoff, conversation review.
    """
    result = await db.execute(
        select(Message)
        .where(
            Message.client_id == client_id,
            Message.conversation_id == conversation_id,
        )
        .order_by(Message.timestamp.asc())
    )
    messages = result.scalars().all()

    return [
        {
            "direction": m.direction,
            "content": m.content,
            "message_type": m.message_type,
            "timestamp": m.timestamp.isoformat(),
        }
        for m in messages
    ]
