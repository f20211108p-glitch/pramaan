import uuid
from datetime import datetime, timezone
from sqlalchemy import (
    Column, String, Boolean, Integer, BigInteger, Text,
    DateTime, ForeignKey, UniqueConstraint, ARRAY, Index,
    text as sa_text,
)
from sqlalchemy.dialects.postgresql import UUID, JSONB
from pgvector.sqlalchemy import Vector
from src.db.engine import Base


def _uuid():
    return str(uuid.uuid4())


def _now():
    return datetime.now(timezone.utc)


class ClientConfig(Base):
    __tablename__ = "client_config"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    client_name = Column(String, nullable=False)
    waba_number = Column(String, nullable=False, unique=True)
    waba_phone_number_id = Column(String, nullable=False)
    waba_token = Column(String, nullable=False)
    project_ids = Column(ARRAY(UUID(as_uuid=True)), default=list)
    prompt_overrides = Column(JSONB, default=dict)
    crm_type = Column(String, nullable=True)
    crm_token = Column(String, nullable=True)
    language_config = Column(JSONB, default=lambda: {
        "primary_language": "english",
        "regional_languages": [],
        "formality_level": "formal",
        "hindi_pronoun": "aap",
    })
    broker_wa_numbers = Column(ARRAY(String), default=list)
    google_calendar_id = Column(String, nullable=True)
    billing_model = Column(String, default="direct", nullable=False)  # "direct" | "per_visit" | "per_lead"
    scoring_config = Column(JSONB, default=lambda: {}, nullable=False)
    active = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime, default=_now, nullable=False)
    updated_at = Column(DateTime, default=_now, onupdate=_now, nullable=False)


class Lead(Base):
    __tablename__ = "leads"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    client_id = Column(UUID(as_uuid=True), ForeignKey("client_config.id"), nullable=False, index=True)
    phone = Column(String, nullable=False)
    name = Column(String, nullable=True)
    email = Column(String, nullable=True)
    language_pref = Column(String, default="english", nullable=False)
    intent = Column(String, default="unknown", nullable=False)
    budget_min = Column(BigInteger, nullable=True)
    budget_max = Column(BigInteger, nullable=True)
    timeline_months = Column(Integer, nullable=True)
    urgency = Column(String, default="unknown", nullable=False)
    financing_status = Column(String, default="unknown", nullable=False)
    location_preferences = Column(JSONB, default=list)
    property_type = Column(String, default="any", nullable=False)
    family_size = Column(Integer, nullable=True)
    score = Column(Integer, nullable=True)
    tier = Column(String, nullable=True)
    stage = Column(String, default="new", nullable=False)
    source_channel = Column(String, default="whatsapp", nullable=False)
    assigned_agent_id = Column(UUID(as_uuid=True), nullable=True)
    created_at = Column(DateTime, default=_now, nullable=False)
    updated_at = Column(DateTime, default=_now, onupdate=_now, nullable=False)

    __table_args__ = (
        UniqueConstraint("client_id", "phone", name="uq_lead_client_phone"),
        Index("ix_lead_client_stage", "client_id", "stage"),
        Index("ix_lead_client_tier_stage", "client_id", "tier", "stage"),
        Index("ix_lead_client_updated", "client_id", "updated_at"),
    )


class Conversation(Base):
    __tablename__ = "conversations"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    client_id = Column(UUID(as_uuid=True), ForeignKey("client_config.id"), nullable=False, index=True)
    lead_id = Column(UUID(as_uuid=True), ForeignKey("leads.id"), nullable=False)
    channel = Column(String, default="whatsapp", nullable=False)
    status = Column(String, default="active", nullable=False)
    summary = Column(Text, nullable=True)
    started_at = Column(DateTime, default=_now, nullable=False)
    last_message_at = Column(DateTime, default=_now, nullable=False)


class Message(Base):
    __tablename__ = "messages"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    client_id = Column(UUID(as_uuid=True), ForeignKey("client_config.id"), nullable=False, index=True)
    conversation_id = Column(UUID(as_uuid=True), ForeignKey("conversations.id"), nullable=False)
    direction = Column(String, nullable=False)
    content = Column(Text, nullable=False)
    message_type = Column(String, default="text", nullable=False)
    channel_message_id = Column(String, nullable=True)
    timestamp = Column(DateTime, default=_now, nullable=False)

    __table_args__ = (
        Index("ix_message_conversation", "conversation_id", "timestamp"),
        Index("ix_message_client_direction", "client_id", "direction"),
    )


class ConsentLog(Base):
    __tablename__ = "consent_log"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    client_id = Column(UUID(as_uuid=True), ForeignKey("client_config.id"), nullable=False, index=True)
    lead_id = Column(UUID(as_uuid=True), ForeignKey("leads.id"), nullable=False)
    consent_type = Column(String, nullable=False)
    source = Column(String, nullable=False)
    granted_at = Column(DateTime, default=_now, nullable=False)
    extra_data = Column("metadata", JSONB, nullable=True)  # 'metadata' is reserved by SQLAlchemy Base


class BillingEvent(Base):
    __tablename__ = "billing_events"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    client_id = Column(UUID(as_uuid=True), ForeignKey("client_config.id"), nullable=False, index=True)
    lead_id = Column(UUID(as_uuid=True), ForeignKey("leads.id"), nullable=True)
    event_type = Column(String, nullable=False)
    amount_inr = Column(Integer, nullable=True)
    extra_data = Column("metadata", JSONB, nullable=True)  # 'metadata' is reserved by SQLAlchemy Base
    created_at = Column(DateTime, default=_now, nullable=False)

    __table_args__ = (
        # A lead gets ONE qualified_lead and ONE site_visit_booked event, ever —
        # enforced at the DB level so concurrent graph runs, DLQ replays, and
        # repeated confirmations can't double-bill or double-notify.
        Index(
            "uq_billing_once_per_type",
            "client_id", "lead_id", "event_type",
            unique=True,
            postgresql_where=sa_text(
                "event_type IN ('qualified_lead', 'site_visit_booked')"
            ),
        ),
    )


class BrochureChunk(Base):
    __tablename__ = "brochure_chunks"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    client_id = Column(UUID(as_uuid=True), ForeignKey("client_config.id"), nullable=False, index=True)
    project_id = Column(UUID(as_uuid=True), nullable=False, index=True)
    project_name = Column(String, nullable=False)
    chunk_type = Column(String, nullable=False)
    text = Column(Text, nullable=False)
    embedding = Column(Vector(384), nullable=True)   # fastembed paraphrase-multilingual-MiniLM-L12-v2
    page_number = Column(Integer, nullable=True)
    created_at = Column(DateTime, default=_now, nullable=False)

    __table_args__ = (
        Index(
            "ix_brochure_embedding_cosine",
            "embedding",
            postgresql_using="ivfflat",
            postgresql_ops={"embedding": "vector_cosine_ops"},
            postgresql_with={"lists": 100},
        ),
    )


class User(Base):
    """Dashboard users — admin (Pramaan team) or client (developer like Prestige/Lodha)."""
    __tablename__ = "users"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email = Column(String, nullable=False, unique=True)
    password_hash = Column(String, nullable=False)
    name = Column(String, nullable=False)
    role = Column(String, nullable=False, default="client")  # "admin" | "client"
    client_id = Column(UUID(as_uuid=True), ForeignKey("client_config.id"), nullable=True)  # NULL for admin
    active = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime, default=_now, nullable=False)
    updated_at = Column(DateTime, default=_now, onupdate=_now, nullable=False)


class EvalResult(Base):
    __tablename__ = "eval_results"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    client_id = Column(UUID(as_uuid=True), ForeignKey("client_config.id"), nullable=True)
    conversation_id = Column(UUID(as_uuid=True), ForeignKey("conversations.id"), nullable=True)
    eval_name = Column(String, nullable=False)
    score = Column(String, nullable=False)  # float stored as string for flexibility
    details = Column(JSONB, nullable=True)
    created_at = Column(DateTime, default=_now, nullable=False)
