"""
LangGraph qualification engine — the conversation brain.

Nodes: language_detector → greeter → intent_detector → qualifier → scorer → (scheduler|nurturer|handoff)
State key: (client_id, lead_phone) — NOT just lead_phone. Multi-tenant isolation.
"""
import logging
from typing import Literal

from langgraph.graph import StateGraph, END

from src.engine.state import QualificationState
from src.engine.nodes.language_detector import language_detector
from src.engine.nodes.greeter import greeter
from src.engine.nodes.intent_detector import intent_detector
from src.engine.nodes.qualifier import qualifier
from src.engine.nodes.scorer import scorer
from src.engine.nodes.scheduler import scheduler
from src.engine.nodes.nurturer import nurturer
from src.engine.nodes.handoff import handoff

logger = logging.getLogger(__name__)



# ── Conditional edge functions ────────────────────────────────────────────────

def after_language_detector(state: QualificationState) -> Literal["greeter", "qualifier"]:
    """
    First message (stage='new') → greeter.
    Returning lead with unknown intent → greeter (to re-run intent detection).
    Subsequent messages with known intent → qualifier directly.
    """
    lead = state.get("lead", {})
    stage = lead.get("stage", "new")
    intent = lead.get("intent", "unknown")
    if stage == "new" or intent == "unknown":
        return "greeter"
    return "qualifier"


def after_intent_detector(state: QualificationState) -> Literal["qualifier", "handoff"]:
    """Buyers/investors/renters → qualify. Sellers → handoff (v2 flow)."""
    lead = state.get("lead", {})
    intent = lead.get("intent", "unknown")
    if intent == "seller":
        return "handoff"
    return "qualifier"


def after_qualifier(state: QualificationState) -> Literal["qualifier", "scorer"]:
    """
    Always go to scorer after ONE qualifier pass.

    Why not loop? Each graph.invoke() = one WhatsApp message from the lead.
    The qualifier runs once, extracts what it can, generates ONE response.
    Lead data accumulates across invokes via DB (loaded by router each turn).
    Scorer re-runs each turn — score increases as more fields are filled.
    """
    return "scorer"


def after_scorer(state: QualificationState) -> Literal["scheduler", "nurturer", "handoff"]:
    """Hot → schedule. Warm → nurture. Cold buyer → nurture. Cold non-buyer → handoff."""
    if state.get("should_handoff"):
        return "handoff"
    lead = state.get("lead", {})
    tier = lead.get("tier")
    if tier == "hot":
        return "scheduler"
    if tier == "warm":
        return "nurturer"
    # Cold leads: buyers/investors/renters just haven't provided enough info yet —
    # keep them in the nurturing loop so qualifier can ask about budget/timeline.
    # Only hand off sellers and truly unknown intent.
    intent = lead.get("intent", "unknown")
    if intent in ("buyer", "investor", "renter"):
        return "nurturer"
    # Unknown intent cold leads — keep nurturing, don't dismiss them
    # Only sellers get explicit handoff (handled by should_handoff above)
    return "nurturer"


# ── Build the graph ───────────────────────────────────────────────────────────

def build_graph() -> StateGraph:
    """Construct and return the compiled qualification graph."""

    graph = StateGraph(QualificationState)

    # Add all nodes
    graph.add_node("language_detector", language_detector)
    graph.add_node("greeter", greeter)
    graph.add_node("intent_detector", intent_detector)
    graph.add_node("qualifier", qualifier)
    graph.add_node("scorer", scorer)
    graph.add_node("scheduler", scheduler)
    graph.add_node("nurturer", nurturer)
    graph.add_node("handoff", handoff)

    # Entry point
    graph.set_entry_point("language_detector")

    # Edges
    graph.add_conditional_edges("language_detector", after_language_detector)
    graph.add_edge("greeter", "intent_detector")
    graph.add_conditional_edges("intent_detector", after_intent_detector)
    graph.add_conditional_edges("qualifier", after_qualifier)
    graph.add_conditional_edges("scorer", after_scorer)

    # Terminal nodes
    graph.add_edge("scheduler", END)
    graph.add_edge("nurturer", END)
    graph.add_edge("handoff", END)

    return graph


def compile_graph(checkpointer=None):
    """Build and compile the graph, optionally with a checkpointer."""
    graph = build_graph()
    return graph.compile(checkpointer=checkpointer)


def make_state_key(client_id: str, lead_phone: str) -> dict:
    """Generate the thread config for LangGraph checkpointing. Multi-tenant key."""
    return {"configurable": {"thread_id": f"{client_id}:{lead_phone}"}}
