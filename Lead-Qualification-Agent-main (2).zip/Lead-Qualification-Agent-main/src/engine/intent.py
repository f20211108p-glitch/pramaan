"""
Per-turn intent classification — ONE Haiku tool-use call replaces the
regex/keyword heuristics that previously decided:

  - "is the lead asking for the brochure?"        (router keyword list)
  - "is the lead confirming a site-visit slot?"   (scheduler regex)
  - "is the lead asking a property question?"     (scheduler regex)
  - "which day/time did they pick?"               (scheduler regex extraction)

Keyword lists cannot survive Hinglish ("Sunday dekhta hu, but pehle price
batao" defeats every regex here). A single structured-extraction call is
robust across English/Hindi/Hinglish, costs ~₹0.02, and runs concurrently
with the RAG search so it adds no wall-clock latency.

Callers MUST treat a None return as "LLM unavailable" and fall back to
their local heuristics — the pipeline never hard-depends on this call.
"""
import logging
from typing import TypedDict

from src.engine.llm import extract_structured

logger = logging.getLogger(__name__)


class TurnIntent(TypedDict):
    wants_brochure: bool
    confirming_slot: bool
    asking_question: bool
    slot_text: str | None


INTENT_TOOL_SCHEMA = {
    "description": "Classify the intent of a WhatsApp message from a real estate lead",
    "properties": {
        "wants_brochure": {
            "type": "boolean",
            "description": (
                "True if the lead is asking to be sent the brochure / PDF / "
                "floor plan document (in any language or spelling), or clearly "
                "agreeing to receive it after the assistant offered it."
            ),
        },
        "confirming_slot": {
            "type": "boolean",
            "description": (
                "True if the lead is picking or agreeing to a site-visit "
                "day/time (e.g. 'Sunday 10 baje', 'thursday works', 'haan "
                "pakka', 'option 2'). False if they are only asking a question."
            ),
        },
        "slot_text": {
            "type": ["string", "null"],
            "description": (
                "If confirming_slot, the day/time portion only, cleaned up "
                "(e.g. 'Sunday, 10 baje', 'Thursday 11am'). Null otherwise."
            ),
        },
        "asking_question": {
            "type": "boolean",
            "description": (
                "True if the message contains a question about the property, "
                "project, pricing, financing, location, or process — even if "
                "combined with a slot confirmation."
            ),
        },
    },
    "required": ["wants_brochure", "confirming_slot", "asking_question"],
}

_SYSTEM_PROMPT = """You classify one WhatsApp message from a real estate lead in India.
Messages may be English, Hindi (Devanagari), or Hinglish (Roman-script Hindi), often mixed.

Context you receive:
- The assistant's previous message (what the lead is replying to)
- The lead's current pipeline stage ('scheduling' means time slots were already offered)

Classification rules:
- A message can be BOTH a slot confirmation AND a question ("Sunday 10 baje, lekin down payment kitna lagega?" → confirming_slot=true, slot_text='Sunday, 10 baje', asking_question=true).
- Short agreements ('haan', 'ok', 'theek hai', 'chalega') count as confirming_slot ONLY when stage is 'scheduling' or the previous assistant message offered time slots.
- 'brochure bhej do', 'send pdf', 'floor plan share karo', misspellings like 'broucher' → wants_brochure=true.
- A bare 'yes'/'haan' right after the assistant OFFERED the brochure → wants_brochure=true.
- General property interest is NOT a question; an actual ask (price, amenities, RERA, possession, loan, location, schools, safety...) IS."""


def classify_turn_intent(
    user_text: str,
    prev_assistant: str = "",
    stage: str = "",
) -> TurnIntent | None:
    """
    Classify the current turn's intent. SYNC (blocking) — call via
    asyncio.to_thread from async code.

    Returns None on any failure; callers fall back to local heuristics.
    """
    if not user_text or not user_text.strip():
        return None

    context_parts = []
    if prev_assistant:
        context_parts.append(f"Assistant's previous message: {prev_assistant[:500]}")
    context_parts.append(f"Lead's pipeline stage: {stage or 'unknown'}")
    context_parts.append(f"Lead's message: {user_text}")

    try:
        result = extract_structured(
            system_prompt=_SYSTEM_PROMPT,
            user_text="\n".join(context_parts),
            tool_name="classify_intent",
            tool_schema=INTENT_TOOL_SCHEMA,
        )
        if not result:
            return None
        intent: TurnIntent = {
            "wants_brochure": bool(result.get("wants_brochure", False)),
            "confirming_slot": bool(result.get("confirming_slot", False)),
            "asking_question": bool(result.get("asking_question", False)),
            "slot_text": result.get("slot_text") or None,
        }
        logger.info("[intent] %s | %.60s", intent, user_text)
        return intent
    except Exception as e:
        logger.warning("[intent] Classification failed (falling back to heuristics): %s", e)
        return None
