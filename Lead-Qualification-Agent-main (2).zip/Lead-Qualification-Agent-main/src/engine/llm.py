"""
Shared Anthropic client for LangGraph nodes — with prompt caching.

Uses Claude Haiku for cheap/fast classification tasks (language, intent, extraction).
Uses Claude Sonnet for generation tasks (greeting, qualifier responses).

Prompt caching strategy:
  - A shared base_context.txt (~1100 tokens) is cached across ALL node calls.
  - Per-node instructions are appended as a second (non-cached) text block.
  - First call: cache miss → creates cache (5-min TTL).
  - Subsequent calls within 5 min: cache hit → 90% cheaper on the base tokens.

Anthropic caching requires the cached block to be >= 1024 tokens.
Individual node prompts (~150-250 tokens) are too small alone.
The base context provides shared real estate domain knowledge that every node needs.
"""
import json
import logging
from pathlib import Path
from functools import lru_cache
from typing import Any

import anthropic

from src.config import get_settings
from src.core.tracing import trace_llm

logger = logging.getLogger(__name__)

PROMPTS_DIR = Path(__file__).resolve().parent.parent / "prompts"

# Model constants — single source of truth
# Haiku: cheapest + fastest — use for classify() calls (language, intent)
# Sonnet: best quality — use for generate() calls (greetings, qualifier responses)
HAIKU_MODEL = "claude-haiku-4-5"
SONNET_MODEL = "claude-sonnet-4-5"


@lru_cache
def get_anthropic_client() -> anthropic.Anthropic:
    """Return a shared sync Anthropic client (LangGraph nodes are sync)."""
    settings = get_settings()
    if not settings.anthropic_api_key:
        raise RuntimeError("ANTHROPIC_API_KEY not set — cannot run engine nodes")
    return anthropic.Anthropic(api_key=settings.anthropic_api_key)


@lru_cache
def _load_base_context() -> str:
    """Load the shared base context prompt (cached across all LLM calls)."""
    path = PROMPTS_DIR / "base_context.txt"
    if not path.exists():
        logger.warning("[llm] base_context.txt not found — caching will not work")
        return ""
    return path.read_text(encoding="utf-8")


def load_prompt(filename: str) -> str:
    """Load a prompt template from src/prompts/."""
    path = PROMPTS_DIR / filename
    if not path.exists():
        raise FileNotFoundError(f"Prompt file not found: {path}")
    return path.read_text(encoding="utf-8")


def _build_system_with_cache(node_prompt: str, cache: bool) -> str | list[dict]:
    """
    Build a two-block system prompt for Anthropic prompt caching.

    Block 1 (CACHED): base_context.txt — shared domain knowledge (~1100 tokens)
                       Marked with cache_control: ephemeral (5-min TTL)
    Block 2 (NOT cached): per-node instructions (changes every call)

    This ensures Block 1 is >= 1024 tokens (the minimum for cache eligibility).
    On cache hit, you pay ~10% of the original cost for Block 1 tokens.

    Without caching, returns a plain concatenated string.
    """
    base_context = _load_base_context()

    if not cache or not base_context:
        # No caching — just concatenate
        if base_context:
            return base_context + node_prompt
        return node_prompt

    # Two-block system: base (cached) + node instructions (not cached)
    return [
        {
            "type": "text",
            "text": base_context,
            "cache_control": {"type": "ephemeral"},
        },
        {
            "type": "text",
            "text": node_prompt,
        },
    ]


def _log_usage(response, call_type: str) -> None:
    """Log token usage including cache stats for cost tracking."""
    try:
        usage = response.usage
        input_tokens = getattr(usage, "input_tokens", 0) or 0
        output_tokens = getattr(usage, "output_tokens", 0) or 0
        cache_creation = getattr(usage, "cache_creation_input_tokens", 0) or 0
        cache_read = getattr(usage, "cache_read_input_tokens", 0) or 0
        logger.info(
            "[llm:%s] model=%s input=%d output=%d cache_create=%d cache_read=%d",
            call_type, response.model,
            int(input_tokens), int(output_tokens),
            int(cache_creation), int(cache_read),
        )
        if isinstance(cache_read, int) and cache_read > 0:
            logger.info("[llm:%s] CACHE HIT — saved ~%d tokens", call_type, cache_read)
    except Exception:
        logger.debug("[llm:%s] Could not log usage stats", call_type)


@trace_llm("classify")
def classify(
    system_prompt: str,
    user_text: str,
    valid_values: list[str],
    cache: bool = True,
) -> str:
    """
    Run a cheap Haiku classification call.
    Returns one of valid_values, or the first value as fallback.
    """
    client = get_anthropic_client()
    try:
        response = client.messages.create(
            model=HAIKU_MODEL,
            max_tokens=10,
            temperature=0.0,
            system=_build_system_with_cache(system_prompt, cache),
            messages=[{"role": "user", "content": user_text}],
        )
        _log_usage(response, "classify")
        raw = response.content[0].text.strip().lower()
        # Exact match
        if raw in valid_values:
            return raw
        # Fuzzy: check if any valid value is contained in the response
        for v in valid_values:
            if v in raw:
                return v
        logger.warning("Unexpected classification '%s', falling back to '%s'", raw, valid_values[0])
        return valid_values[0]
    except Exception as e:
        logger.error("Classification call failed: %s", e)
        return valid_values[0]


@trace_llm("generate")
def generate(
    system_prompt: str,
    user_text: str,
    max_tokens: int = 300,
    cache: bool = True,
    model: str | None = None,
    temperature: float = 0.7,
    conversation: list[dict] | None = None,
) -> str:
    """
    Run a generation call (Sonnet by default, Haiku if model override passed).

    If `conversation` is provided, it is used as the messages array (multi-turn).
    Otherwise falls back to a single user message from `user_text`.
    Returns the generated text, or empty string on error.
    """
    client = get_anthropic_client()
    use_model = model or SONNET_MODEL
    msgs = conversation if conversation else [{"role": "user", "content": user_text}]
    # Sanitize: Claude API requires strict user/assistant alternation.
    # Merge consecutive same-role messages and ensure conversation starts with user.
    if len(msgs) > 1:
        cleaned = []
        for m in msgs:
            if cleaned and cleaned[-1]["role"] == m["role"]:
                cleaned[-1]["content"] += "\n" + m["content"]
            else:
                cleaned.append(dict(m))
        if cleaned and cleaned[0]["role"] != "user":
            cleaned = cleaned[1:]
        if cleaned and cleaned[-1]["role"] != "user":
            cleaned.append({"role": "user", "content": user_text})
        msgs = cleaned or [{"role": "user", "content": user_text}]
    try:
        response = client.messages.create(
            model=use_model,
            max_tokens=max_tokens,
            temperature=temperature,
            system=_build_system_with_cache(system_prompt, cache),
            messages=msgs,
        )
        _log_usage(response, "generate")
        return response.content[0].text.strip()
    except Exception as e:
        logger.error("Generation call failed: %s", e)
        return ""


@trace_llm("extract_structured")
def extract_structured(
    system_prompt: str,
    user_text: str,
    tool_name: str,
    tool_schema: dict,
    cache: bool = True,
) -> dict[str, Any]:
    """
    Use Claude tool_use to extract structured data from text.
    Forces Claude to return valid JSON matching the schema — NEVER parse free text.

    Args:
        system_prompt: context / instructions for extraction
        user_text: the user message to extract from
        tool_name: name of the tool (e.g. "extract_lead_info")
        tool_schema: JSON Schema dict describing the fields to extract
        cache: enable prompt caching on system prompt

    Returns:
        dict of extracted fields, or empty dict on failure
    """
    client = get_anthropic_client()
    tools = [{
        "name": tool_name,
        "description": tool_schema.get("description", "Extract structured information"),
        "input_schema": {
            "type": "object",
            "properties": tool_schema["properties"],
            "required": tool_schema.get("required", []),
        },
    }]

    try:
        response = client.messages.create(
            model=HAIKU_MODEL,  # Haiku is fast+cheap for extraction
            max_tokens=512,
            temperature=0.0,
            system=_build_system_with_cache(system_prompt, cache),
            tools=tools,
            tool_choice={"type": "tool", "name": tool_name},
            messages=[{"role": "user", "content": user_text}],
        )
        _log_usage(response, "extract_structured")
        # Find the tool_use block
        for block in response.content:
            if block.type == "tool_use" and block.name == tool_name:
                return block.input or {}
        logger.warning("[extract_structured] No tool_use block in response")
        return {}
    except Exception as e:
        logger.error("[extract_structured] Extraction failed: %s", e)
        return {}
