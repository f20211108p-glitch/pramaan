"""
Greeter node — first-message-only welcome.

Loads the right prompt template based on detected language + client config.
Priority: client_config.prompt_overrides["greeter"] > greeter_{lang}.txt
Respects formality level (aap/tum) from client's language_config.
"""
import logging

from src.engine.state import QualificationState
from src.engine.llm import generate, load_prompt
from src.core.tracing import trace_node

logger = logging.getLogger(__name__)

# Fallback greetings when Claude is unavailable
FALLBACK_GREETINGS = {
    "english": "Hello! Welcome to {client_name}. How can I help you find your ideal property today?",
    "hindi": "नमस्ते! {client_name} में आपका स्वागत है। आज मैं आपकी कैसे मदद कर सकता हूँ?",
    "hinglish": "Hi! {client_name} mein aapka swagat hai 🙏 Aap kis tarah ki property dhundh rahe hain?",
    "regional": "Hello! Welcome to {client_name}. How can I help you find your ideal property today?",
}


def _get_formality(client_config: dict) -> tuple[str, str]:
    """Extract formality level and pronoun from client's language config."""
    lang_config = client_config.get("language_config", {})
    formality = lang_config.get("formality_level", "formal")
    pronoun = lang_config.get("hindi_pronoun", "aap")
    return formality, pronoun


def _load_greeter_prompt(language: str, client_config: dict) -> str:
    """
    Load greeting prompt. Priority:
    1. client_config.prompt_overrides["greeter"] (per-tenant custom)
    2. greeter_{language}.txt (language-specific template)
    3. greeter_en.txt (ultimate fallback)
    """
    overrides = client_config.get("prompt_overrides", {})
    if "greeter" in overrides:
        return overrides["greeter"]

    # Map language to prompt file
    lang_map = {
        "english": "greeter_en.txt",
        "hindi": "greeter_hi.txt",
        "hinglish": "greeter_hinglish.txt",
        "regional": "greeter_en.txt",  # fallback to English for regional
    }
    filename = lang_map.get(language, "greeter_en.txt")

    try:
        return load_prompt(filename)
    except FileNotFoundError:
        logger.warning("[greeter] Prompt file %s not found, using greeter_en.txt", filename)
        return load_prompt("greeter_en.txt")


@trace_node("greeter")
def greeter(state: QualificationState) -> dict:
    """Welcome the lead in their detected language. First message only."""

    language = state.get("language", "english")
    client_config = state.get("client_config", {})
    client_name = client_config.get("client_name", "our team")

    # Get user's first message
    messages = list(state.get("messages", []))
    user_text = ""
    for msg in messages:
        if msg.get("role") == "user":
            user_text = msg.get("content", "")
            break

    # Load and format prompt
    formality, pronoun = _get_formality(client_config)
    prompt_template = _load_greeter_prompt(language, client_config)
    system_prompt = prompt_template.format(
        client_name=client_name,
        user_message=user_text,
        formality=formality,
        pronoun=pronoun,
    )

    # Generate greeting via Claude Sonnet
    greeting = generate(system_prompt, user_text, max_tokens=200)

    if not greeting:
        # Fallback if Claude call fails
        fallback = FALLBACK_GREETINGS.get(language, FALLBACK_GREETINGS["english"])
        greeting = fallback.format(client_name=client_name)
        logger.warning("[greeter] Claude call failed, using fallback greeting")

    # Append bot message to conversation
    messages.append({"role": "assistant", "content": greeting})

    logger.info("[greeter] Language=%s, greeting: %.80s...", language, greeting)
    return {
        "messages": messages,
        "current_node": "greeter",
        "turn_count": 1,
    }
