"""
Handoff node — transfer conversation to human agent.

Called when:
  1. Lead is a seller (v2 flow — not yet automated)
  2. Lead is cold (score < 40) — polite close
  3. should_handoff flag is set (e.g., lead explicitly asks for human)

Generates a closing/transition message appropriate to the handoff reason.
"""
import logging

from src.engine.state import QualificationState
from src.core.tracing import trace_node

logger = logging.getLogger(__name__)


def _generate_handoff_message(lead: dict, handoff_reason: str | None, language: str) -> str:
    """
    Generate an appropriate handoff message based on the reason.
    Hardcoded (no LLM call) — handoff messages should be predictable.
    """
    name = lead.get("name") or ""
    name_greeting = f" {name}" if name else ""

    if handoff_reason == "seller":
        if language in ("hindi", "hinglish"):
            return (
                f"Namaste{name_greeting}! Aapki property sell karne mein hum zaroor madad karenge. "
                f"Humari team se koi aapko jald hi call karega. Dhanyavaad!"
            )
        return (
            f"Hi{name_greeting}! We'd love to help you sell your property. "
            f"One of our property specialists will reach out to you shortly. "
            f"Thank you for contacting us!"
        )

    if handoff_reason == "human_requested":
        if language in ("hindi", "hinglish"):
            return (
                f"Bilkul{name_greeting}! Main aapko humari team se connect kar raha hoon. "
                f"Koi jald hi aapse baat karega. Thoda wait kijiye."
            )
        return (
            f"Of course{name_greeting}! Let me connect you with our team. "
            f"Someone will reach out to you shortly."
        )

    # Default: cold lead / generic handoff — polite close
    if language in ("hindi", "hinglish"):
        return (
            f"Dhanyavaad{name_greeting}! Jab bhi aap property explore karna chahe, "
            f"toh hum yahan hain aapki madad ke liye. Bas message kar dijiye!"
        )
    return (
        f"Thank you{name_greeting}! Whenever you're ready to explore properties, "
        f"we're here to help. Just send us a message anytime!"
    )


@trace_node("handoff")
def handoff(state: QualificationState) -> dict:
    """
    Generate a handoff/closing message and mark lead as handed off.
    """
    lead = dict(state.get("lead", {}))
    language = state.get("language", lead.get("language_pref", "english"))
    handoff_reason = state.get("handoff_reason")

    # Determine reason if not explicitly set
    if not handoff_reason:
        intent = lead.get("intent", "unknown")
        if intent == "seller":
            handoff_reason = "seller"
        else:
            handoff_reason = "cold_lead"

    reply = _generate_handoff_message(lead, handoff_reason, language)

    lead["stage"] = "handed_off"

    messages = list(state.get("messages", []))
    messages.append({"role": "assistant", "content": reply})

    logger.info(
        "[handoff] Lead %s handed off (reason=%s, language=%s)",
        lead.get("phone"), handoff_reason, language,
    )

    return {
        "lead": lead,
        "messages": messages,
        "should_handoff": True,
        "handoff_reason": handoff_reason,
        "current_node": "handoff",
        "next_action": "handoff",
    }
