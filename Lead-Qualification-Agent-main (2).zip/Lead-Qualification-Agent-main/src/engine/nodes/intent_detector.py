"""
Intent detector node — classifies lead intent after greeting.

Uses Claude Haiku for fast, cheap classification.
Seller intent triggers immediate handoff (seller flow is v2).
"""
import logging

from src.engine.state import QualificationState
from src.engine.llm import classify, load_prompt
from src.core.tracing import trace_node

logger = logging.getLogger(__name__)

VALID_INTENTS = ["buyer", "seller", "investor", "renter", "unknown"]


@trace_node("intent_detector")
def intent_detector(state: QualificationState) -> dict:
    """Classify lead intent: buyer/seller/investor/renter/unknown."""

    lead = dict(state.get("lead", {}))

    # If intent is already known (from a prior turn), preserve it
    if lead.get("intent", "unknown") != "unknown":
        logger.info("[intent_detector] Intent already set: '%s', skipping", lead["intent"])
        return {"lead": lead, "current_node": "intent_detector"}

    # Get the latest user message
    messages = state.get("messages", [])
    user_text = ""
    for msg in reversed(messages):
        if msg.get("role") == "user":
            user_text = msg.get("content", "")
            break

    if not user_text:
        logger.warning("[intent_detector] No user message, defaulting to 'unknown'")
        return {"lead": lead, "current_node": "intent_detector"}

    # Classify intent
    system_prompt = load_prompt("intent_detect.txt")
    intent = classify(system_prompt, user_text, VALID_INTENTS)
    lead["intent"] = intent

    # Seller → immediate handoff.
    # NOTE: handoff_reason is a machine-readable KEY ("seller"), not prose —
    # the handoff node switches on it to pick the right closing message.
    should_handoff = intent == "seller"
    handoff_reason = "seller" if should_handoff else None

    logger.info("[intent_detector] Classified intent='%s' for: %.60s...", intent, user_text)
    return {
        "lead": lead,
        "current_node": "intent_detector",
        "should_handoff": should_handoff,
        "handoff_reason": handoff_reason,
    }
