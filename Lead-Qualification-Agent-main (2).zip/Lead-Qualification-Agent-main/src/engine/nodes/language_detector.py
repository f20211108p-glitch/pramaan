"""
Language detection node — runs on EVERY inbound message.

Uses Claude Haiku (not langdetect/langid) because those libraries
fail on Roman-script Hindi ("mujhe 2BHK chahiye" → misclassified as Italian/Portuguese).
"""
import logging

from src.engine.state import QualificationState
from src.engine.llm import classify, load_prompt
from src.core.tracing import trace_node

logger = logging.getLogger(__name__)

VALID_LANGUAGES = ["english", "hindi", "hinglish", "regional"]

# Roman-script Hindi/Urdu markers — used both for the english→hinglish
# flip guard and for the no-LLM fast path below.
HINDI_MARKERS = frozenset({
    "mein", "hai", "hain", "kya", "kaise", "kitna", "kitne",
    "chahiye", "chahte", "aap", "tum", "mujhe", "humko",
    "accha", "theek", "nahi", "bhai", "yaar", "batao",
    "bata", "dekho", "karo", "karenge", "karke", "wala",
    "abhi", "bahut", "bohot", "sab", "aur", "lekin", "pehle",
    "baad", "agar", "toh", "bhi", "ke", "ka", "ki", "ko",
    "ji", "haan", "chalega", "lagega", "milega", "dena",
    "lena", "aana", "jaana", "ghar", "paisa", "rupay",
    "lakh", "crore",
})


def _has_hindi_signal(text: str) -> bool:
    """True if the text contains Devanagari or Roman-script Hindi markers."""
    if any("ऀ" <= ch <= "ॿ" for ch in text):
        return True
    import re
    text_lower = text.lower()
    return any(
        re.search(r"\b" + re.escape(w) + r"\b", text_lower)
        for w in HINDI_MARKERS
    )


@trace_node("language_detector")
def language_detector(state: QualificationState) -> dict:
    """Classify language using Claude Haiku. Runs on EVERY message — lead may switch languages."""

    # Get the latest user message
    messages = state.get("messages", [])
    user_text = ""
    for msg in reversed(messages):
        if msg.get("role") == "user":
            user_text = msg.get("content", "")
            break

    if not user_text:
        logger.warning("[language_detector] No user message found, defaulting to 'english'")
        return {"language": "english", "current_node": "language_detector"}

    lead = dict(state.get("lead", {}))
    existing_lang = lead.get("language_pref")

    # Short messages (under 5 words) can't reliably detect language —
    # keep the existing language preference if one is already set
    if existing_lang and existing_lang != "english" and len(user_text.split()) < 5:
        logger.info("[language_detector] Short message, keeping existing '%s'", existing_lang)
        return {
            "language": existing_lang,
            "lead": lead,
            "current_node": "language_detector",
        }

    # ── No-LLM fast path ────────────────────────────────────────────────
    # An established English speaker writing a message with zero Hindi
    # signal (no Devanagari, no Roman-Hindi markers) is English. Skipping
    # the Haiku call here removes one LLM round-trip from the majority of
    # English conversations.
    if existing_lang == "english" and not _has_hindi_signal(user_text):
        logger.info("[language_detector] Fast path: kept 'english' (no Hindi signal)")
        lead["language_pref"] = "english"
        return {
            "language": "english",
            "lead": lead,
            "current_node": "language_detector",
        }

    # Load prompt and classify
    system_prompt = load_prompt("language_detect.txt")
    detected = classify(system_prompt, user_text, VALID_LANGUAGES)

    # ── Language-flip guard ──────────────────────────────────────────────
    # Haiku sometimes misclassifies pure English as "hinglish" (or vice versa).
    # Only allow a language SWITCH if the message contains clear evidence.
    # If the lead has been speaking english and the new detect says hinglish,
    # verify with a quick heuristic: does the message contain actual Hindi words?
    if existing_lang and detected != existing_lang:
        if existing_lang == "english" and detected == "hinglish":
            # Check for actual Hindi/Urdu words in the message
            if not _has_hindi_signal(user_text):
                logger.info(
                    "[language_detector] Blocked flip english→hinglish — no Hindi words found in: %.60s...",
                    user_text,
                )
                detected = existing_lang  # keep english
        elif existing_lang == "hinglish" and detected == "english":
            # More lenient flip back to english — if they're writing clean English, allow it
            pass  # allow the flip

    # Also update the lead's language_pref so it persists to DB
    lead["language_pref"] = detected

    logger.info("[language_detector] Detected '%s' for: %.60s...", detected, user_text)
    return {
        "language": detected,
        "lead": lead,
        "current_node": "language_detector",
    }
