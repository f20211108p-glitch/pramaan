"""
Nurturer node — warm lead follow-up to keep engagement alive.

Called when scorer determines tier=warm (40 <= score < 70).
Generates a friendly message that:
  1. Acknowledges what the lead has shared
  2. Shares a property insight
  3. Gently asks about ONE missing field
  4. Keeps the conversation going without being pushy
"""
import logging

from src.engine.state import QualificationState
from src.engine.llm import generate, load_prompt
from src.core.tracing import trace_node

logger = logging.getLogger(__name__)

# Fields we care about for qualification
ALL_QUALIFICATION_FIELDS = {
    "budget_min": "budget",
    "budget_max": "budget",
    "timeline_months": "timeline",
    "financing_status": "financing status",
    "location_preferences": "preferred location",
    "property_type": "property type",
    "family_size": "family size",
}


def _find_missing_fields(lead: dict) -> list[str]:
    """Identify which qualification fields are still missing."""
    missing = []
    seen_labels = set()

    for field, label in ALL_QUALIFICATION_FIELDS.items():
        if label in seen_labels:
            continue

        value = lead.get(field)
        is_missing = (
            value is None
            or value == "unknown"
            or value == "any"
            or (isinstance(value, list) and len(value) == 0)
        )
        if is_missing:
            missing.append(label)
        # Always mark label as seen — so budget_max doesn't re-add "budget"
        # when budget_min is already filled
        seen_labels.add(label)

    return missing


def _format_budget(lead: dict) -> str:
    b_min = lead.get("budget_min")
    b_max = lead.get("budget_max")
    if not b_min and not b_max:
        return "not discussed"
    parts = []
    if b_min:
        parts.append(f"{b_min // 100_000}L")
    if b_max:
        parts.append(f"{b_max // 100_000}L")
    return " - ".join(parts)


@trace_node("nurturer")
def nurturer(state: QualificationState) -> dict:
    """
    Generate a nurturing response for WARM leads.

    Keeps the conversation going by sharing insights and
    gently collecting missing qualification data.
    """
    lead = dict(state.get("lead", {}))
    client_config = state.get("client_config", {})
    language = state.get("language", lead.get("language_pref", "english"))
    messages = list(state.get("messages", []))

    # If qualifier already generated a reply this turn, use it — don't overwrite
    # (qualifier appends an assistant message before nurturer runs)
    existing_reply = next(
        (m.get("content") for m in reversed(messages) if m.get("role") == "assistant"),
        None
    )
    if existing_reply:
        lead["stage"] = "nurturing"
        return {"lead": lead, "messages": messages, "current_node": "nurturer", "next_action": "nurture"}

    # Identify what we still need
    missing = _find_missing_fields(lead)

    # Format lead data for prompt
    locs = lead.get("location_preferences", [])
    loc_str = ", ".join(locs) if isinstance(locs, list) and locs else "not discussed"

    try:
        prompt = load_prompt("nurturer.txt").format(
            client_name=client_config.get("client_name", "our team"),
            score=lead.get("score", 0),
            lead_name=lead.get("name") or "there",
            intent=lead.get("intent", "unknown"),
            budget_summary=_format_budget(lead),
            location_summary=loc_str,
            timeline_summary=f"{lead.get('timeline_months', '?')} months" if lead.get("timeline_months") else "not discussed",
            financing_status=lead.get("financing_status", "not discussed"),
            property_type=lead.get("property_type", "not specified"),
            missing_fields="- " + "\n- ".join(missing) if missing else "All key fields collected!",
            language=language,
        )

        # Get the last USER message (not assistant) to avoid passing our own reply back
        last_user_msg = next(
            (m.get("content", "") for m in reversed(state.get("messages", [])) if m.get("role") == "user"),
            ""
        )
        reply = generate(
            system_prompt=prompt,
            user_text=last_user_msg,
            max_tokens=250,
            temperature=0.7,
        )
    except Exception as e:
        logger.error("[nurturer] Response generation failed: %s", e)
        reply = ""

    if not reply:
        # Fallback — simple but functional
        if missing:
            reply = (
                f"Thanks for sharing! I'd love to help you find the perfect property. "
                f"Could you tell me more about your {missing[0]}?"
            )
        else:
            reply = (
                "You've given me great details! Let me check what's available "
                "that matches your requirements. I'll get back to you shortly."
            )

    # Update lead stage
    lead["stage"] = "nurturing"

    # Add messages
    messages = list(state.get("messages", []))
    messages.append({"role": "assistant", "content": reply})

    logger.info(
        "[nurturer] Warm lead %s — missing %d fields: %s",
        lead.get("phone"), len(missing), missing,
    )

    return {
        "lead": lead,
        "messages": messages,
        "current_node": "nurturer",
        "next_action": "nurture",
    }
