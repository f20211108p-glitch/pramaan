"""
Qualifier node — the core conversation loop.

Extracts structured lead data over multiple turns via Claude tool_use.
Loops until all key fields are collected OR turn_count >= 15.

Pipeline per turn:
  1. Get latest user message
  2. Extract structured fields (Claude Haiku tool_use)
  3. Merge into lead dict
  4. Update awaiting_info (remove filled fields)
  5. Generate next response (Claude Sonnet, language-aware)
  6. Append reply, increment turn_count
"""
import logging

from src.engine.state import QualificationState
from src.engine.llm import load_prompt, extract_structured, generate
from src.core.tracing import trace_node

logger = logging.getLogger(__name__)

# Priority order for collecting missing fields (default; overridable via client scoring_config)
DEFAULT_REQUIRED_FIELDS = ["budget", "timeline", "location", "property_type", "financing", "family_size"]

# Tool schema for structured extraction via Claude tool_use
EXTRACTION_TOOL_SCHEMA = {
    "description": "Extract property search requirements from the user message",
    "properties": {
        "budget_min": {
            "type": ["integer", "null"],
            "description": "Minimum budget in INR (e.g. 7000000 for 70 lakh)",
        },
        "budget_max": {
            "type": ["integer", "null"],
            "description": "Maximum budget in INR (e.g. 15000000 for 1.5 crore)",
        },
        "timeline_months": {
            "type": ["integer", "null"],
            "description": "How many months until they need the property",
        },
        "urgency": {
            "type": ["string", "null"],
            "enum": ["immediate", "1_3_months", "3_6_months", "6_12_months", "12_plus_months", None],
        },
        "locations": {
            "type": ["array", "null"],
            "items": {"type": "string"},
            "description": "List of preferred area/location names",
        },
        "property_type": {
            "type": ["string", "null"],
            "enum": ["apartment", "villa", "plot", "commercial", "any", None],
        },
        "financing_status": {
            "type": ["string", "null"],
            "enum": ["self_funded", "loan_approved", "loan_needed", "not_sure", None],
        },
        "family_size": {
            "type": ["integer", "null"],
            "description": "Number of people in household",
        },
        "extracted_confidence": {
            "type": "number",
            "description": "Confidence 0.0-1.0 in the extractions",
        },
    },
    "required": ["extracted_confidence"],
}


def _get_user_text(state: QualificationState) -> str:
    """Get the most recent user message from state."""
    messages = state.get("messages", [])
    for msg in reversed(messages):
        if msg.get("role") == "user":
            return msg.get("content", "")
    return ""


def _compute_awaiting_info(lead: dict, required_fields: list[str] | None = None) -> list[str]:
    """
    Determine which key fields are still missing.
    Returns them in required_fields priority order.
    """
    if required_fields is None:
        required_fields = DEFAULT_REQUIRED_FIELDS

    # Map field names to their "filled" check
    field_checks = {
        "budget": lambda: lead.get("budget_min") or lead.get("budget_max"),
        "timeline": lambda: lead.get("timeline_months"),
        "location": lambda: lead.get("location_preferences"),
        "property_type": lambda: lead.get("property_type") and lead.get("property_type") != "any",
        "financing": lambda: lead.get("financing_status") and lead.get("financing_status") != "unknown",
        "family_size": lambda: lead.get("family_size"),
    }

    missing = []
    for field in required_fields:
        check = field_checks.get(field)
        if check and not check():
            missing.append(field)
        elif not check:
            # Unknown field — treat as missing if not present in lead
            if not lead.get(field):
                missing.append(field)
    return missing


def _merge_extraction(lead: dict, extraction: dict, confidence: float) -> dict:
    """
    Merge extracted fields into lead dict.
    Only overwrites if value is not None and confidence > 0.5.
    """
    if confidence <= 0.5:
        return lead

    lead = dict(lead)
    if extraction.get("budget_min") is not None:
        lead["budget_min"] = extraction["budget_min"]
    if extraction.get("budget_max") is not None:
        lead["budget_max"] = extraction["budget_max"]
    if extraction.get("timeline_months") is not None:
        lead["timeline_months"] = extraction["timeline_months"]
    if extraction.get("urgency") is not None:
        lead["urgency"] = extraction["urgency"]
    if extraction.get("locations"):
        lead["location_preferences"] = extraction["locations"]
    if extraction.get("property_type") is not None:
        lead["property_type"] = extraction["property_type"]
    if extraction.get("financing_status") is not None:
        lead["financing_status"] = extraction["financing_status"]
    if extraction.get("family_size") is not None:
        lead["family_size"] = extraction["family_size"]
    return lead


def _format_filled_summary(lead: dict) -> str:
    """Human-readable summary of collected lead info for the prompt."""
    parts = []
    if lead.get("budget_min") or lead.get("budget_max"):
        b_min = f"₹{lead['budget_min'] // 100000}L" if lead.get("budget_min") else "?"
        b_max = f"₹{lead['budget_max'] // 100000}L" if lead.get("budget_max") else "?"
        parts.append(f"Budget: {b_min} – {b_max}")
    if lead.get("timeline_months"):
        parts.append(f"Timeline: {lead['timeline_months']} months")
    if lead.get("location_preferences"):
        locs = lead["location_preferences"]
        parts.append(f"Location: {', '.join(locs) if isinstance(locs, list) else locs}")
    if lead.get("property_type") and lead["property_type"] != "any":
        parts.append(f"Property type: {lead['property_type']}")
    if lead.get("financing_status") and lead["financing_status"] != "unknown":
        parts.append(f"Financing: {lead['financing_status']}")
    if lead.get("family_size"):
        parts.append(f"Family size: {lead['family_size']}")
    return "\n".join(f"- {p}" for p in parts) if parts else "- Nothing collected yet"


def _build_post_booking_prompt(
    client_name: str,
    language: str,
    rag_context_str: str,
    lead_name: str,
) -> str:
    """
    Dedicated prompt for after the site visit is booked.

    The qualifier becomes a focused Q&A assistant. It must NEVER:
      - re-confirm the booking
      - mention the time slot or address again
      - offer to send brochures (a separate handler decides that)
      - push pickup arrangements / "save my number" lines
      - ask new qualification questions

    It must answer the user's question concisely from BROCHURE CONTEXT,
    or say it will get back to them if context is missing.
    """
    lang_line = {
        "english": "Reply in English.",
        "hindi": "Reply in Hindi (Devanagari script).",
        "hinglish": "Reply in Hinglish (Roman-script Hindi + English mix, natural WhatsApp style).",
        "regional": "Reply in English.",
    }.get(language, "Reply in English.")

    rag_block = rag_context_str if rag_context_str else (
        "BROCHURE CONTEXT: (none available for this question)"
    )

    return (
        f"You are a helpful real estate assistant for {client_name}. "
        f"The lead ({lead_name}) has ALREADY confirmed a site visit. "
        f"They are now asking a follow-up question.\n\n"
        f"{rag_block}\n\n"
        f"YOUR JOB — answer ONLY the user's current question.\n\n"
        f"STRICT RULES:\n"
        f"1. NEVER re-confirm the site visit, mention the time, or repeat the address.\n"
        f"2. NEVER offer to send the brochure / floor plans / PDFs. A separate system handles that.\n"
        f"3. NEVER mention 'pickup', 'save my number', 'consultant will meet you'.\n"
        f"4. NEVER ask new qualification questions (budget, family size, financing, etc.).\n"
        f"5. Answer ONLY from BROCHURE CONTEXT above. Do NOT invent facts.\n"
        f"6. If BROCHURE CONTEXT has no relevant info, say briefly: "
        f"   'Main yeh detail confirm karke aapko bhej deta hoon' (or English equivalent).\n"
        f"7. Maximum 3 short sentences. No emojis except one tick / smile if natural.\n"
        f"8. {lang_line}\n"
        f"9. End with a soft open question like 'Aur kuch jaanna hai?' / 'Anything else?' — "
        f"   NEVER a booking-related CTA."
    )


def _load_qualifier_prompt(language: str, client_config: dict) -> str:
    """Load qualifier prompt, respecting per-client overrides."""
    overrides = client_config.get("prompt_overrides", {})
    if "qualifier" in overrides:
        return overrides["qualifier"]
    lang_map = {
        "english": "qualifier_en.txt",
        "hindi": "qualifier_hi.txt",
        "hinglish": "qualifier_hinglish.txt",
        "regional": "qualifier_en.txt",
    }
    return load_prompt(lang_map.get(language, "qualifier_en.txt"))


@trace_node("qualifier")
def qualifier(state: QualificationState) -> dict:
    """Core qualification loop — extracts lead data and generates next question."""
    lead = dict(state.get("lead", {}))
    client_config = state.get("client_config", {})
    language = state.get("language", "english")
    rag_context = state.get("rag_context", [])
    turn_count = state.get("turn_count", 0) + 1
    messages = list(state.get("messages", []))

    user_text = _get_user_text(state)
    client_name = client_config.get("client_name", "our team")
    lang_config = client_config.get("language_config", {})
    pronoun = lang_config.get("hindi_pronoun", "aap")
    formality = lang_config.get("formality_level", "formal")

    last_extraction = {}

    # ── Step 1: Extract structured data ───────────────────────────────────
    if user_text:
        extraction_system = load_prompt("qualifier_extract.txt")
        # Include the previous assistant message for context so short answers
        # like "home loan" or "this year" get correctly interpreted
        prev_assistant = next(
            (m.get("content", "") for m in reversed(messages) if m.get("role") == "assistant"),
            ""
        )
        extraction_input = user_text
        if prev_assistant:
            extraction_input = f"Assistant asked: {prev_assistant}\nUser replied: {user_text}"
        extraction = extract_structured(
            system_prompt=extraction_system,
            user_text=extraction_input,
            tool_name="extract_lead_info",
            tool_schema=EXTRACTION_TOOL_SCHEMA,
        )
        confidence = float(extraction.pop("extracted_confidence", 0.5))
        last_extraction = dict(extraction)
        lead = _merge_extraction(lead, extraction, confidence)
        logger.info("[qualifier] Turn %d extracted (conf=%.2f): %s", turn_count, confidence, extraction)

    # ── Step 2: Update awaiting_info ──────────────────────────────────────
    scoring_config = client_config.get("scoring_config", {})
    required_fields = scoring_config.get("required_fields", DEFAULT_REQUIRED_FIELDS)
    awaiting_info = _compute_awaiting_info(lead, required_fields)

    # ── Step 3: Build generation prompt ──────────────────────────────────
    filled_summary = _format_filled_summary(lead)
    awaiting_str = "\n".join(f"- {f}" for f in awaiting_info) if awaiting_info else "- All key fields collected!"

    rag_context_str = ""
    if rag_context:
        rag_context_str = "BROCHURE CONTEXT (answer property questions from this):\n"
        rag_context_str += "\n---\n".join(rag_context)

    formality_instruction = f"Use {formality} tone with '{pronoun}' pronoun." if language != "english" else ""

    # ── Post-booking Q&A mode ──────────────────────────────────────────
    # Once the visit is booked, the qualifier becomes a focused Q&A bot:
    # answer the user's question from brochure context, NEVER re-confirm,
    # NEVER offer brochures (separate handler does that), NEVER push CTAs.
    # Truncate conversation history aggressively — old confirmations in
    # history mislead the LLM into echoing them.
    if lead.get("stage") in ("scheduling", "scheduled"):
        system_prompt = _build_post_booking_prompt(
            client_name=client_name,
            language=language,
            rag_context_str=rag_context_str,
            lead_name=lead.get("name") or "there",
        )
        # Only send the LATEST user turn — no contaminating history
        response = generate(
            system_prompt,
            user_text,
            max_tokens=180,
            conversation=None,
            temperature=0.3,
        )
    else:
        prompt_template = _load_qualifier_prompt(language, client_config)
        system_prompt = prompt_template.format(
            client_name=client_name,
            filled_fields_summary=filled_summary,
            awaiting_info=awaiting_str,
            rag_context=rag_context_str,
            formality_instruction=formality_instruction,
            turn_count=turn_count,
        )
        # Pass full conversation history so Claude knows what was already discussed
        # and doesn't re-ask questions that were already answered
        conv_for_llm = [m for m in messages if m.get("content")]
        response = generate(system_prompt, user_text, max_tokens=250, conversation=conv_for_llm or None)

    if not response:
        fallbacks = {
            "budget": "What budget range are you working with?",
            "timeline": "When are you looking to move in?",
            "location": "Which areas are you considering?",
            "property_type": "Are you looking for an apartment, villa, or plot?",
            "financing": "Will you be self-funding or taking a home loan?",
            "family_size": "How many people will be living there?",
        }
        response = fallbacks.get(awaiting_info[0], "Tell me more about what you're looking for.") if awaiting_info \
            else "I have a good picture of what you need. Let me find the best options for you!"

    messages.append({"role": "assistant", "content": response})
    if lead.get("stage") not in ("scheduling", "scheduled"):
        lead["stage"] = "qualifying"

    logger.info("[qualifier] Turn %d | awaiting=%s | %.80s...", turn_count, awaiting_info, response)

    return {
        "lead": lead,
        "messages": messages,
        "turn_count": turn_count,
        "awaiting_info": awaiting_info,
        "last_extraction": last_extraction,
        "current_node": "qualifier",
    }
