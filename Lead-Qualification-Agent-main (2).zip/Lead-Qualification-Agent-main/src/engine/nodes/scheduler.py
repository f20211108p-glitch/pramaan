"""
Scheduler node — site visit booking for HOT leads.

Called when scorer determines tier=hot (score >= 70).
Generates a response offering available time slots.

Calendar integration:
  - If Google Calendar is configured → checks real availability
  - If not → generates fallback slots (morning/afternoon for next 3 days)
  - Actual event creation happens when lead confirms (future turn)

Important: The qualifier always runs before the scheduler and may have
already answered a property question (amenities, pricing, etc.) from
brochure data.  If the user asked a question this turn, pass through
the qualifier's answer instead of overwriting it with a scheduling offer.
"""
import logging

from src.engine.state import QualificationState
from src.engine.llm import generate, load_prompt
from src.core.tracing import trace_node

logger = logging.getLogger(__name__)


def _is_user_confirming_slot(text: str, stage: str) -> bool:
    """Detect if the lead is confirming a time slot (already in scheduling stage)."""
    import re
    if stage != "scheduling":
        return False
    if not text:
        return False
    # If the user is asking a question, it's NOT a slot confirmation
    if _is_user_asking_question(text):
        return False
    text_lower = text.lower().strip()
    # Multi-word / unambiguous indicators — safe for substring match
    time_phrases = [
        "monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday",
        "10 am", "10am", "3 pm", "3pm", "morning", "afternoon", "evening",
        "tomorrow", "today", "parso",
        "slot 1", "slot 2", "slot 3", "option 1", "option 2", "option 3",
        "1st", "2nd", "3rd",
        "confirm", "book", "chalega", "pakka",
    ]
    for phrase in time_phrases:
        if phrase in text_lower:
            return True
    # Short words need word-boundary matching to avoid false positives
    # ("ha" inside "hain", "ok" inside "booking", etc.)
    # IMPORTANT: only treat short-word matches as slot confirmations when the
    # message is short (≤ 5 words).  "Ha bhai, down payment kitna lagega" is
    # 7 words — clearly a question, not a confirmation, even though "ha" matches.
    word_count = len(text_lower.split())
    short_words = [
        "ok", "done", "yes", "haan", "ha", "theek", "sure", "fine",
        "sahi", "mon", "tue", "wed", "thu", "fri", "sat", "sun",
        "kal", "aaj", "first", "second", "third",
    ]
    if word_count <= 5:
        for word in short_words:
            if re.search(r'\b' + re.escape(word) + r'\b', text_lower):
                return True
    return False


def _is_slot_confirmation_with_question_mark(text: str) -> bool:
    """
    Detect messages like "Thursday 11am?" or "Monday 10 baje?" where the
    lead is softly confirming a slot (Indian chat style) rather than asking
    a question.  Returns True if the message is clearly a slot pick.
    """
    import re
    text_lower = text.lower().strip()
    days = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday",
            "mon", "tue", "wed", "thu", "fri", "sat", "sun", "kal", "aaj"]
    has_day = any(re.search(r'\b' + d + r'\b', text_lower) for d in days)
    has_time = bool(re.search(
        r'\b(\d{1,2}\s*(am|pm|baje)|morning|afternoon|evening|subah|shaam|dopahar)\b',
        text_lower
    ))
    return has_day or has_time


def _is_user_asking_question(text: str) -> bool:
    """Detect if the user's message is a question about the project/property."""
    if not text:
        return False
    text_lower = text.lower().strip()
    # Direct question marks — but NOT if the message is clearly a slot pick
    # (e.g. "Thursday 11am?" is a soft confirmation, not a property question)
    if "?" in text_lower:
        if _is_slot_confirmation_with_question_mark(text_lower):
            return False
        return True
    # Starts with a question word or phrase
    question_starts = [
        "what", "which", "how", "where", "when", "who", "why",
        "tell me", "can you", "do you", "is there", "are there",
        "does", "any", "show me", "give me",
        "before that", "share", "send me", "please share",
        "could you", "would you", "will you",
        "i want to know", "i need to know",
        "batao", "bata do", "bata", "kya",
    ]
    for qs in question_starts:
        if text_lower.startswith(qs):
            return True
    # Contains property-specific keywords that imply a query
    question_keywords = [
        "amenities", "amenity", "aminities", "aminiti", "price", "pricing", "cost", "floor plan",
        "specification", "specs", "location", "nearby", "facilities",
        "parking", "possession", "rera", "payment plan", "emi",
        "brochure", "layout", "map", "features", "swimming", "gym",
        "club", "school", "hospital", "connectivity",
        # Construction / timeline / delivery queries
        "construction", "timeline", "time line", "delivery", "handover",
        "completion", "status", "progress", "ready", "move in",
        # Finance queries (multi-word to avoid false-positive on "yes home loan")
        "home loan process", "loan process", "loan eligibility",
        "down payment", "downpayment", "emi calcul", "interest rate",
        "bank tie", "subsidy", "subvention",
        # Area / community queries
        "mandir", "temple", "mosque", "school", "safe", "clean",
    ]
    for kw in question_keywords:
        if kw in text_lower:
            return True
    return False


def _extract_time_from_message(text: str) -> str:
    """
    Extract only the day/time portion from a user message.

    Handles cases like "Sunday ko 10 baje avilable hu lekin down payment kitna lagega"
    → returns "Sunday, 10 baje"

    Strips question words and everything after "lekin", "but", "aur", "?", etc.
    """
    import re
    if not text:
        return "the time you chose"

    # Split on common conjunctions that signal a question follows
    split_on = [" lekin ", " but ", " aur bhi ", " par ", " however ", " also "]
    lower = text.lower()
    for sep in split_on:
        idx = lower.find(sep)
        if idx != -1:
            text = text[:idx]
            break

    # Also cut at question mark
    if "?" in text:
        text = text[:text.index("?")]

    # Now extract the time-related tokens: day names + time expressions
    day_map = {
        "monday": "Monday", "tuesday": "Tuesday", "wednesday": "Wednesday",
        "thursday": "Thursday", "friday": "Friday", "saturday": "Saturday",
        "sunday": "Sunday", "mon": "Monday", "tue": "Tuesday", "wed": "Wednesday",
        "thu": "Thursday", "fri": "Friday", "sat": "Saturday", "sun": "Sunday",
        "kal": "kal", "aaj": "aaj", "tomorrow": "tomorrow", "today": "today",
    }
    time_pattern = re.compile(
        r'\b(\d{1,2}\s*(?:am|pm|baje|:00|:\d{2})|\d{1,2}\s*o\'?clock'
        r'|morning|afternoon|evening|subah|shaam|dopahar'
        r'|10\s*am|3\s*pm|10\s*baje|3\s*baje)\b',
        re.IGNORECASE,
    )

    parts = []
    text_lower = text.lower()
    for word, display in day_map.items():
        if re.search(r'\b' + word + r'\b', text_lower):
            parts.append(display)
            break

    time_match = time_pattern.search(text)
    if time_match:
        parts.append(time_match.group(0).strip())

    if parts:
        return ", ".join(parts)

    # Fallback: return cleaned text (already stripped of question portion)
    cleaned = text.strip().rstrip(".")
    return cleaned if cleaned else "the time you chose"


_SLOT_LINE_RE = None  # compiled lazily below


def _resolve_slot_pick(slot_text: str | None, user_text: str, messages: list[dict]) -> str:
    """
    Turn the lead's confirmation into a usable slot string.

    "Sunday 10 baje"   → used as-is (has day/time content)
    "option 2" / "2nd" → resolved against the numbered slots we offered
                          in the most recent assistant message
    bare "haan pakka"  → resolved only if exactly ONE slot was offered;
                          otherwise returned as-is (the lead-facing
                          confirmation falls back to 'the time you chose',
                          and the broker alert carries the raw text)
    """
    import re
    global _SLOT_LINE_RE
    if _SLOT_LINE_RE is None:
        _SLOT_LINE_RE = re.compile(r"^\s*([1-6])[.)]\s*(.+)$", re.MULTILINE)

    candidate = (slot_text or user_text or "").strip()
    low = candidate.lower()

    # Already contains temporal content — good enough
    if re.search(
        r"\b(monday|tuesday|wednesday|thursday|friday|saturday|sunday|today|tomorrow|aaj|kal|parso)\b",
        low,
    ) or re.search(r"\d{1,2}\s*(am|pm|baje|:\d{2})", low):
        return candidate

    # Find the most recent assistant message that offered numbered slots
    offered: list[tuple[str, str]] = []
    for m in reversed(messages):
        if m.get("role") == "assistant":
            found = _SLOT_LINE_RE.findall(m.get("content", "") or "")
            if found:
                offered = found
                break

    if offered:
        mnum = re.search(r"\b(?:option|slot)\s*([1-6])\b", low) or re.search(
            r"\b([1-6])(?:st|nd|rd|th)?\b", low
        )
        if mnum:
            num = mnum.group(1)
            for n, line in offered:
                if n == num:
                    return line.strip()
        if len(offered) == 1:
            # Bare agreement with a single offered slot is unambiguous
            return offered[0][1].strip()

    return candidate


def _build_confirmation_message(lead: dict, client_config: dict, user_pick: str, language: str) -> str:
    """
    Deterministic booking-confirmation template.

    We do NOT use an LLM here — past attempts hallucinated CTAs like
    "Kya brochure bhej du?" or "Pickup arrange karu?" that the system
    couldn't actually fulfill.  A fixed template removes that whole class
    of bugs.

    Address comes ONLY from client_config.prompt_overrides.site_address.
    There is deliberately NO default address: this is a multi-tenant system,
    and a hardcoded fallback would direct one client's leads to another
    client's site office. If no address is configured, the confirmation
    says the exact location will be shared shortly (and logs a warning so
    ops can fix the client config).

    Google Maps link: uses prompt_overrides.site_map_url (exact URL) or
    auto-generates from site_address.  Zero cost — just a link.
    """
    from urllib.parse import quote_plus

    overrides = client_config.get("prompt_overrides", {}) or {}
    address = overrides.get("site_address")

    name = lead.get("name") or ""
    name_prefix = f"{name}, " if name else ""
    # Extract just the day/time portion — user may have combined slot + question
    pick = _extract_time_from_message(user_pick)

    if address:
        map_url = overrides.get("site_map_url") or f"https://maps.google.com/?q={quote_plus(address)}"
        location_block = f"📍 *Address:* {address}\n🗺️ *Map:* {map_url}\n\n"
        location_line_hi = location_block
        location_line_en = location_block
    else:
        logger.warning(
            "[scheduler] No site_address configured for client '%s' — "
            "confirmation sent WITHOUT address. Set prompt_overrides.site_address.",
            client_config.get("client_name", "?"),
        )
        location_line_hi = "📍 Exact location aapko thodi der mein bhej di jayegi.\n\n"
        location_line_en = "📍 We'll share the exact location with you shortly.\n\n"

    if language == "hindi":
        return (
            f"{name_prefix}*site visit confirm ho gaya hai!* ✅\n\n"
            f"📅 *Time:* {pick}\n"
            f"{location_line_hi}"
            f"Koi sawaal ho toh yahan message kar dena."
        )
    if language == "hinglish":
        return (
            f"{name_prefix}*site visit confirm ho gaya!* ✅\n\n"
            f"📅 *Time:* {pick}\n"
            f"{location_line_hi}"
            f"Koi sawaal ho toh yahin message kar dena."
        )
    return (
        f"{name_prefix}*your site visit is confirmed!* ✅\n\n"
        f"📅 *Time:* {pick}\n"
        f"{location_line_en}"
        f"Message me here if you have any questions."
    )


def _format_budget(lead: dict) -> str:
    b_min = lead.get("budget_min")
    b_max = lead.get("budget_max")
    if not b_min and not b_max:
        return "not discussed"
    parts = []
    if b_min:
        parts.append(f"{b_min // 100_000}L")
    if b_max:
        parts.append(f"{b_max // 100_000}L")
    return " - ".join(parts)


def _format_slots(slots: list[dict]) -> str:
    """Format slot list for the prompt."""
    if not slots:
        return "No specific slots available — ask the lead for their preferred time."
    lines = []
    for i, slot in enumerate(slots[:4], 1):
        lines.append(f"{i}. {slot['display']}")
    return "\n".join(lines)


@trace_node("scheduler")
def scheduler(state: QualificationState) -> dict:
    """
    Generate a site-visit scheduling response for HOT leads.

    If the user asked a property question this turn (amenities, pricing,
    floor plan, etc.), the qualifier already answered it from brochure data.
    In that case we pass through the qualifier's answer so the user isn't
    ignored.  A scheduling nudge will be offered on the NEXT turn.
    """
    lead = dict(state.get("lead", {}))
    client_config = state.get("client_config", {})
    language = state.get("language", lead.get("language_pref", "english"))
    messages = list(state.get("messages", []))

    # LLM-classified intent for this turn (router sets it). When present it
    # supersedes the regex heuristics below — keyword lists don't survive
    # Hinglish. Heuristics remain as the no-LLM fallback.
    turn_intent = state.get("turn_intent") or None

    # ── Guard: don't overwrite qualifier's answer to a user question ────
    user_text = next(
        (m.get("content", "") for m in reversed(messages) if m.get("role") == "user"),
        ""
    )
    qualifier_reply = next(
        (m.get("content") for m in reversed(messages) if m.get("role") == "assistant"),
        None
    )

    def _asking_question() -> bool:
        if turn_intent is not None:
            return bool(turn_intent.get("asking_question"))
        return _is_user_asking_question(user_text)

    def _confirming_slot(stage: str) -> bool:
        if turn_intent is not None:
            # Slot confirmation only makes sense once slots were offered
            return bool(turn_intent.get("confirming_slot")) and stage == "scheduling"
        return _is_user_confirming_slot(user_text, stage)

    # Once visit is booked, always pass through qualifier's answer
    if lead.get("stage") == "scheduled" and qualifier_reply:
        logger.info("[scheduler] Visit already booked — passing through qualifier reply for lead %s", lead.get("phone"))
        return {
            "lead": lead,
            "messages": messages,
            "current_node": "scheduler",
            "next_action": "scheduled",
        }

    current_stage = lead.get("stage", "")

    if qualifier_reply and _asking_question() and not _confirming_slot(current_stage):
        logger.info(
            "[scheduler] User asked a question — passing through qualifier's answer for lead %s",
            lead.get("phone"),
        )
        lead["stage"] = "scheduling"
        return {
            "lead": lead,
            "messages": messages,
            "current_node": "scheduler",
            "next_action": "schedule",
        }

    # ── Slot confirmation: lead picked a time → confirm the booking ────
    if _confirming_slot(current_stage):
        logger.info("[scheduler] Lead %s confirming slot: %s", lead.get("phone"), user_text)
        # Prefer the LLM-extracted slot text; resolve ordinal/bare picks
        # ("option 2", "haan pakka") against the slots we actually offered.
        slot_pick = _resolve_slot_pick(
            (turn_intent or {}).get("slot_text"), user_text, messages,
        )
        confirmation = _build_confirmation_message(lead, client_config, slot_pick, language)
        lead["stage"] = "scheduled"

        # If they also asked a question in the same message (e.g. "Sunday 10 baje,
        # lekin down payment kitna lagega?"), append the qualifier's answer after
        # the confirmation instead of discarding it.
        has_question = _asking_question()
        if qualifier_reply and has_question:
            # Confirmation first, then qualifier's answer to the question
            combined = confirmation + "\n\n" + qualifier_reply
            for i in range(len(messages) - 1, -1, -1):
                if messages[i].get("role") == "assistant":
                    messages.pop(i)
                    break
            messages.append({"role": "assistant", "content": combined})
        else:
            if qualifier_reply:
                for i in range(len(messages) - 1, -1, -1):
                    if messages[i].get("role") == "assistant":
                        messages.pop(i)
                        break
            messages.append({"role": "assistant", "content": confirmation})
        return {
            "lead": lead,
            "messages": messages,
            "current_node": "scheduler",
            "next_action": "scheduled",
            # Surface the confirmed slot so the router can close the loop:
            # write the site_visit_booked event, alert brokers, create the
            # calendar event. Without this, confirmations were cosmetic.
            "booked_slot": slot_pick,
        }

    # ── Generate scheduling response ────────────────────────────────────
    slots = _get_slots_sync(client_config)

    locs = lead.get("location_preferences", [])
    loc_str = ", ".join(locs) if isinstance(locs, list) and locs else "not specified"

    try:
        prompt = load_prompt("scheduler.txt").format(
            client_name=client_config.get("client_name", "our team"),
            score=lead.get("score", 0),
            tier=lead.get("tier", "hot"),
            lead_name=lead.get("name") or "there",
            budget_summary=_format_budget(lead),
            location_summary=loc_str,
            timeline_summary=f"{lead.get('timeline_months', '?')} months",
            property_type=lead.get("property_type", "any"),
            available_slots=_format_slots(slots),
            language=language,
        )

        reply = generate(
            system_prompt=prompt,
            user_text="Generate the scheduling message with available time slots.",
            max_tokens=200,
            temperature=0.7,
        )
    except Exception as e:
        logger.error("[scheduler] Response generation failed: %s", e)
        reply = ""

    if not reply:
        if slots:
            slot_lines = "\n".join(f"  {i}. {s['display']}" for i, s in enumerate(slots[:3], 1))
            reply = (
                f"Great news! Based on your requirements, I'd love to arrange a site visit.\n\n"
                f"Here are some available times:\n{slot_lines}\n\n"
                f"Which time works best for you?"
            )
        else:
            reply = (
                "Great news! You're a strong match for our properties. "
                "I'd love to arrange a site visit for you. "
                "What day and time works best?"
            )

    lead["stage"] = "scheduling"

    # Replace qualifier's generic reply (if any) with scheduler's response
    # instead of appending a second assistant message
    if qualifier_reply:
        # Remove qualifier's assistant message — scheduler's is more relevant here
        for i in range(len(messages) - 1, -1, -1):
            if messages[i].get("role") == "assistant":
                messages.pop(i)
                break

    messages.append({"role": "assistant", "content": reply})

    logger.info("[scheduler] Generated scheduling response for lead %s", lead.get("phone"))

    return {
        "lead": lead,
        "messages": messages,
        "current_node": "scheduler",
        "next_action": "schedule",
    }


def _get_slots_sync(client_config: dict) -> list[dict]:
    """
    Get available slots. Synchronous wrapper for the calendar module.

    If Google Calendar is not configured, returns fallback slots.
    This is called from a sync LangGraph node — cannot await directly.
    """
    calendar_id = client_config.get("google_calendar_id")

    if not calendar_id:
        # No calendar configured — use fallback slots
        from src.scheduler.calendar import _generate_fallback_slots
        return _generate_fallback_slots()

    # Google Calendar is configured — try to get real slots
    # Since this is a sync node, we use fallback slots and let the
    # router handle async calendar calls after the graph completes
    from src.scheduler.calendar import _generate_fallback_slots
    logger.info("[scheduler] Calendar ID configured (%s) — using fallback slots in node, "
                "real calendar check happens in router", calendar_id)
    return _generate_fallback_slots()
