"""
Scorer node — rules-based lead scoring + optional Haiku reasoning.

Scoring rubric (deterministic — NOT LLM-dependent):
  - Budget provided        → +30
  - Timeline <= 6 months   → +25 | 7-12m → +15 | >12m → +5
  - Location specified     → +20
  - Financing confirmed    → +15 | loan_needed → +8 | not_sure → +5
  - Family size known      → +10

Score → tier:  >=70 hot | 40-69 warm | <40 cold
Tier  → action: hot → schedule | warm → nurture | cold → handoff

After scoring:
  - Optional Haiku call generates a one-sentence reasoning string
  - HOT leads trigger a billing event (written by the router, not the node)
"""
import logging

from src.engine.state import QualificationState
from src.core.tracing import trace_node

logger = logging.getLogger(__name__)

DEFAULT_SCORING_CONFIG = {
    "weights": {
        "budget": 30,
        "timeline_urgent": 25,
        "timeline_medium": 15,
        "timeline_long": 5,
        "location": 20,
        "financing_confirmed": 15,
        "financing_needed": 8,
        "financing_unsure": 5,
        "family_size": 10,
    },
    "thresholds": {
        "hot": 70,
        "warm": 40,
    },
    "min_fields_for_hot": 5,
}


def _score_lead(lead: dict, config: dict | None = None) -> tuple[int, str, list[str]]:
    """Returns (score 0-100, tier, list of scoring reasons)."""
    # Merge provided config with defaults (top-level and nested dicts)
    effective = dict(DEFAULT_SCORING_CONFIG)
    if config:
        for key, val in config.items():
            if isinstance(val, dict) and isinstance(effective.get(key), dict):
                effective[key] = {**effective[key], **val}
            else:
                effective[key] = val

    weights = effective["weights"]
    thresholds = effective["thresholds"]
    min_fields_for_hot = effective["min_fields_for_hot"]

    score = 0
    reasons = []

    # Budget
    if lead.get("budget_min") or lead.get("budget_max"):
        score += weights.get("budget", 30)
        reasons.append("budget provided")

    # Timeline
    timeline = lead.get("timeline_months")
    if timeline:
        if timeline <= 6:
            score += weights.get("timeline_urgent", 25)
            reasons.append(f"urgent timeline ({timeline}m)")
        elif timeline <= 12:
            score += weights.get("timeline_medium", 15)
            reasons.append(f"medium timeline ({timeline}m)")
        else:
            score += weights.get("timeline_long", 5)
            reasons.append(f"long timeline ({timeline}m)")

    # Location
    locs = lead.get("location_preferences")
    if locs and (isinstance(locs, list) and len(locs) > 0 or isinstance(locs, str)):
        score += weights.get("location", 20)
        reasons.append("location specified")

    # Financing
    financing = lead.get("financing_status", "unknown")
    if financing in ("self_funded", "loan_approved"):
        score += weights.get("financing_confirmed", 15)
        reasons.append(f"financing confirmed ({financing})")
    elif financing == "loan_needed":
        score += weights.get("financing_needed", 8)
        reasons.append("loan needed")
    elif financing == "not_sure":
        score += weights.get("financing_unsure", 5)

    # Family size
    if lead.get("family_size"):
        score += weights.get("family_size", 10)
        reasons.append(f"family size={lead['family_size']}")

    score = min(score, 100)

    # ── Minimum-qualification gate ──────────────────────────────────────
    filled_count = sum([
        bool(lead.get("budget_min") or lead.get("budget_max")),
        bool(lead.get("timeline_months")),
        bool(locs and (isinstance(locs, list) and len(locs) > 0 or isinstance(locs, str))),
        bool(financing not in ("unknown", None, "")),
        bool(lead.get("family_size")),
        bool(lead.get("property_type") and lead.get("property_type") not in ("any", None)),
    ])

    critical_fields_filled = sum([
        bool(lead.get("budget_min") or lead.get("budget_max")),
        bool(lead.get("timeline_months")),
        bool(locs and (isinstance(locs, list) and len(locs) > 0 or isinstance(locs, str))),
        bool(financing not in ("unknown", None, "")),
        bool(lead.get("property_type") and lead.get("property_type") not in ("any", None)),
    ])
    only_family_size_missing = (filled_count == (min_fields_for_hot) and not lead.get("family_size")
                                and critical_fields_filled == min_fields_for_hot)

    hot_threshold = thresholds.get("hot", 70)
    warm_threshold = thresholds.get("warm", 40)
    total_fields = min_fields_for_hot + 1  # +1 for the optional family_size field

    if score >= hot_threshold and (filled_count >= total_fields or only_family_size_missing):
        tier = "hot"
        if only_family_size_missing:
            reasons.append("promoted to hot — only family_size missing")
    elif score >= hot_threshold and filled_count < total_fields:
        tier = "warm"
        reasons.append(f"capped to warm — only {filled_count}/{total_fields} fields collected")
    elif score >= warm_threshold:
        tier = "warm"
    else:
        tier = "cold"

    return score, tier, reasons


def _generate_reasoning(lead: dict, score: int, tier: str, reasons: list[str]) -> str:
    """
    Generate a one-sentence scoring explanation using Haiku.
    Fails gracefully — returns a rules-based summary on error.
    """
    try:
        from src.engine.llm import generate, load_prompt, HAIKU_MODEL

        b_min = f"₹{lead.get('budget_min', 0) // 100000}L" if lead.get("budget_min") else "not specified"
        b_max = f"₹{lead.get('budget_max', 0) // 100000}L" if lead.get("budget_max") else "not specified"
        locs = lead.get("location_preferences", [])
        loc_str = ", ".join(locs) if isinstance(locs, list) and locs else "not specified"

        prompt = load_prompt("scorer.txt").format(
            score=score,
            tier=tier,
            budget_summary=f"{b_min} – {b_max}",
            timeline_summary=f"{lead.get('timeline_months', '?')} months",
            financing_status=lead.get("financing_status", "unknown"),
            location_summary=loc_str,
            property_type=lead.get("property_type", "any"),
            family_size=lead.get("family_size", "unknown"),
            reasons=", ".join(reasons) if reasons else "minimal info",
        )

        reasoning = generate(
            system_prompt=prompt,
            user_text="Generate the scoring explanation.",
            max_tokens=100,
            model=HAIKU_MODEL,  # Use Haiku for cost — reasoning is short
            temperature=0.3,
        )
        if reasoning:
            return reasoning
    except Exception as e:
        logger.warning("[scorer] Reasoning generation failed: %s", e)

    # Fallback: build from rules
    return f"Scored {score}/100 ({tier}) — {', '.join(reasons) if reasons else 'insufficient information'}."


@trace_node("scorer")
def scorer(state: QualificationState) -> dict:
    """
    Rules-based scoring. Determines hot/warm/cold without LLM calls.
    Optionally generates a Haiku reasoning string.
    Returns billing_event metadata for HOT leads (router writes to DB).
    """
    lead = dict(state.get("lead", {}))
    client_config = state.get("client_config", {})
    scoring_config = client_config.get("scoring_config", {})

    # Capture the OLD tier BEFORE scoring overwrites it — needed for billing dedup.
    previous_tier = lead.get("tier")  # value from DB (previous turn's tier)

    score, tier, reasons = _score_lead(lead, scoring_config)

    lead["score"] = score
    lead["tier"] = tier
    if lead.get("stage") not in ("scheduling", "scheduled"):
        lead["stage"] = "qualified"

    # Generate human-readable reasoning.
    # LLM reasoning ONLY on tier transitions — that's the only moment it is
    # shown to a human (broker notification). Generating it on every turn
    # was one extra Haiku round-trip per message for text nobody read.
    if tier != previous_tier:
        reasoning = _generate_reasoning(lead, score, tier, reasons)
    else:
        reasoning = (
            f"Scored {score}/100 ({tier}) — "
            f"{', '.join(reasons) if reasons else 'insufficient information'}."
        )
    lead["scoring_reasoning"] = reasoning

    next_action = {"hot": "schedule", "warm": "nurture", "cold": "handoff"}[tier]

    # Billing event: only fire when the lead TRANSITIONS to HOT for the first time.
    billing_event = None
    if tier == "hot" and previous_tier != "hot":
        billing_event = {
            "event_type": "qualified_lead",
            "metadata": {
                "score": score,
                "tier": tier,
                "reasoning": reasoning,
                "reasons": reasons,
            },
        }

    logger.info(
        "[scorer] score=%d tier=%s next=%s reasons=%s",
        score, tier, next_action, reasons,
    )

    return {
        "lead": lead,
        "next_action": next_action,
        "current_node": "scorer",
        "billing_event": billing_event,
    }
