from __future__ import annotations

from typing import Literal, TypedDict


class QualificationState(TypedDict, total=False):
    """
    LangGraph state for the qualification conversation.
    Uses dict, not Pydantic — LangGraph needs plain dicts for checkpointing.
    """
    # Conversation history for LLM context
    messages: list[dict]

    # Lead data as dict (mirrors LeadProfile fields)
    lead: dict

    # Client configuration as dict (mirrors ClientConfig)
    client_config: dict

    # Current graph position
    current_node: str

    # Turn counter (incremented each inbound message)
    turn_count: int

    # Fields still needed from the lead
    awaiting_info: list[str]

    # What we extracted from the last message
    last_extraction: dict

    # Human handoff signals
    should_handoff: bool
    handoff_reason: str | None

    # What the graph should do next
    next_action: Literal["continue", "schedule", "nurture", "handoff", "complete"] | None

    # Detected language (updated every turn — lead may switch)
    language: str

    # Retrieved brochure chunks for current turn
    rag_context: list[str]

    # LLM-classified intent for the current turn (set by router):
    # {wants_brochure, confirming_slot, asking_question, slot_text}
    # None when the classifier was unavailable — nodes fall back to heuristics.
    turn_intent: dict | None

    # Billing event to write (set by scorer for HOT leads)
    billing_event: dict | None

    # Confirmed site-visit slot text (set by scheduler when the lead books).
    # Router uses it to write site_visit_booked, notify brokers, and create
    # the calendar event.
    booked_slot: str | None

    # Error accumulator
    errors: list[str]
