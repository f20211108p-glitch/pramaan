"""
LLM-as-judge evaluators for qualification engine.

Each judge scores a conversation result on a 0.0-1.0 scale using Claude Haiku.
These are used by the eval runner to gate deployments and track quality regressions.

Judges:
  1. IntentAccuracyJudge      — is the classified intent correct?
  2. BudgetExtractionJudge    — is the extracted budget accurate?
  3. QualificationCompletenessJudge — were all important fields captured?
  4. ConversationNaturalnessJudge   — does the bot sound natural?
  5. HandoffTimingJudge       — was the scoring/handoff appropriate?
"""
import json
import logging
from abc import ABC, abstractmethod
from typing import Any

from src.engine.llm import classify, generate, HAIKU_MODEL

logger = logging.getLogger(__name__)


class BaseJudge(ABC):
    """Abstract base class for all eval judges."""

    name: str = "base_judge"

    @abstractmethod
    def evaluate(self, test_case: dict, result: dict) -> float:
        """
        Evaluate a conversation result against the expected test case.

        Args:
            test_case: the test definition (expected intent, budget, etc.)
            result: the engine output (detected intent, extracted fields, reply, etc.)

        Returns:
            float between 0.0 (completely wrong) and 1.0 (perfect)
        """
        ...

    def _llm_score(self, rubric: str, context: str) -> float:
        """
        Ask Claude Haiku to score on a rubric. Returns 0.0-1.0.
        Extracts a float from the response.
        """
        system = (
            "You are an evaluation judge. Score the following on a scale from 0.0 to 1.0.\n"
            "Respond with ONLY a decimal number between 0.0 and 1.0, nothing else.\n\n"
            f"Rubric:\n{rubric}"
        )
        raw = ""
        # One retry on parse failure, then FAIL CLOSED (0.0). The old 0.5
        # "neutral" fallback equalled the pass threshold — a judge that
        # failed to parse on every case still passed the gate.
        for attempt in range(2):
            try:
                raw = generate(
                    system_prompt=system,
                    user_text=context,
                    max_tokens=10,
                    cache=False,
                    model=HAIKU_MODEL,
                    temperature=0.0,
                )
                score = float(raw.strip())
                return max(0.0, min(1.0, score))
            except (ValueError, TypeError):
                logger.warning(
                    "[%s] Could not parse score (attempt %d) from: %r",
                    self.name, attempt + 1, raw,
                )
            except Exception as e:
                logger.error("[%s] Judge LLM call failed: %s", self.name, e)
        return 0.0  # fail closed — an unjudgeable case is a failing case


# ═══════════════════════════════════════════════════════════════════════════════
# Judge 1: Intent Accuracy
# ═══════════════════════════════════════════════════════════════════════════════

class IntentAccuracyJudge(BaseJudge):
    """Is the classified intent correct?"""
    name = "intent_accuracy"

    def evaluate(self, test_case: dict, result: dict) -> float:
        expected = test_case.get("expected_intent", "")
        detected = result.get("intent", "")

        if not expected:
            return 1.0  # no expectation = pass

        # Exact match = 1.0
        if detected.lower() == expected.lower():
            return 1.0

        # Use LLM for fuzzy matching (buyer vs interested, seller vs listing)
        rubric = (
            "Score how well the detected intent matches the expected intent.\n"
            "1.0 = exact match or semantically equivalent\n"
            "0.5 = partially correct (e.g., 'buyer' when 'investor' expected)\n"
            "0.0 = completely wrong (e.g., 'buyer' when 'seller' expected)"
        )
        context = f"Expected intent: {expected}\nDetected intent: {detected}"
        return self._llm_score(rubric, context)


# ═══════════════════════════════════════════════════════════════════════════════
# Judge 2: Budget Extraction
# ═══════════════════════════════════════════════════════════════════════════════

class BudgetExtractionJudge(BaseJudge):
    """Is the extracted budget accurate?"""
    name = "budget_extraction"

    def evaluate(self, test_case: dict, result: dict) -> float:
        expected_min = test_case.get("expected_budget_min")
        expected_max = test_case.get("expected_budget_max")
        actual_min = result.get("budget_min")
        actual_max = result.get("budget_max")

        # No budget expected = auto-pass
        if expected_min is None and expected_max is None:
            return 1.0

        # Budget expected but not extracted
        if actual_min is None and actual_max is None:
            return 0.0

        # Score based on percentage accuracy
        scores = []
        if expected_min is not None and actual_min is not None:
            ratio = min(actual_min, expected_min) / max(actual_min, expected_min) if max(actual_min, expected_min) > 0 else 1.0
            scores.append(ratio)
        if expected_max is not None and actual_max is not None:
            ratio = min(actual_max, expected_max) / max(actual_max, expected_max) if max(actual_max, expected_max) > 0 else 1.0
            scores.append(ratio)

        if scores:
            return sum(scores) / len(scores)

        # Partial: one expected, other extracted
        return 0.5


# ═══════════════════════════════════════════════════════════════════════════════
# Judge 3: Qualification Completeness
# ═══════════════════════════════════════════════════════════════════════════════

class QualificationCompletenessJudge(BaseJudge):
    """Were all important fields captured?"""
    name = "qualification_completeness"

    IMPORTANT_FIELDS = [
        "intent", "property_type", "location_preferences",
        "budget_min", "budget_max", "timeline_months",
        "financing_status", "family_size",
    ]

    def evaluate(self, test_case: dict, result: dict) -> float:
        expected_fields = test_case.get("expected_fields", self.IMPORTANT_FIELDS)
        filled = 0
        for field in expected_fields:
            val = result.get(field)
            if val is not None and val != "" and val != "unknown" and val != "any" and val != []:
                filled += 1
        return filled / len(expected_fields) if expected_fields else 1.0


# ═══════════════════════════════════════════════════════════════════════════════
# Judge 4: Conversation Naturalness
# ═══════════════════════════════════════════════════════════════════════════════

class ConversationNaturalnessJudge(BaseJudge):
    """Does the bot sound natural in the detected language?"""
    name = "conversation_naturalness"

    def evaluate(self, test_case: dict, result: dict) -> float:
        reply = result.get("reply", "")
        language = result.get("language", "english")

        if not reply:
            return 0.0

        rubric = (
            "Score how natural and appropriate this chatbot reply sounds.\n"
            f"The conversation is in {language}.\n"
            "1.0 = sounds like a helpful, professional human agent\n"
            "0.7 = good but slightly robotic\n"
            "0.5 = understandable but clearly a bot\n"
            "0.3 = awkward, unnatural phrasing\n"
            "0.0 = incomprehensible or wrong language"
        )
        context = f"Language: {language}\nBot reply: {reply}"
        return self._llm_score(rubric, context)


# ═══════════════════════════════════════════════════════════════════════════════
# Judge 5: Handoff Timing
# ═══════════════════════════════════════════════════════════════════════════════

class HandoffTimingJudge(BaseJudge):
    """Was the scoring/handoff decision appropriate?"""
    name = "handoff_timing"

    def evaluate(self, test_case: dict, result: dict) -> float:
        expected_tier = test_case.get("expected_tier", "")
        actual_tier = result.get("tier", "")
        expected_score_range = test_case.get("expected_score_range")  # [min, max]
        actual_score = result.get("score")

        scores = []

        # Tier match
        if expected_tier:
            if actual_tier.lower() == expected_tier.lower():
                scores.append(1.0)
            else:
                # Adjacent tier = 0.5 (hot→warm is less wrong than hot→cold)
                tier_order = ["cold", "warm", "hot"]
                if actual_tier.lower() in tier_order and expected_tier.lower() in tier_order:
                    diff = abs(tier_order.index(actual_tier.lower()) - tier_order.index(expected_tier.lower()))
                    scores.append(1.0 - (diff * 0.5))
                else:
                    scores.append(0.0)

        # Score range check
        if expected_score_range and actual_score is not None:
            lo, hi = expected_score_range
            if lo <= actual_score <= hi:
                scores.append(1.0)
            else:
                # How far outside the range
                dist = min(abs(actual_score - lo), abs(actual_score - hi))
                scores.append(max(0.0, 1.0 - (dist / 50)))  # 50 points off = 0

        return sum(scores) / len(scores) if scores else 1.0


# ═══════════════════════════════════════════════════════════════════════════════
# Registry
# ═══════════════════════════════════════════════════════════════════════════════

ALL_JUDGES = [
    IntentAccuracyJudge(),
    BudgetExtractionJudge(),
    QualificationCompletenessJudge(),
    ConversationNaturalnessJudge(),
    HandoffTimingJudge(),
]


def get_judge(name: str) -> BaseJudge | None:
    """Look up a judge by name."""
    for j in ALL_JUDGES:
        if j.name == name:
            return j
    return None
