"""
Eval runner — the CI quality gate for the qualification engine.

Modes:
  ONLINE (default): each test case's user messages are fed turn-by-turn
    through the REAL LangGraph engine (real LLM calls), exactly as the
    router would. The accumulated lead state + final reply are then judged.
    This is the only mode that can catch a regression in src/engine.

  OFFLINE (--offline): judges the pre-recorded 'result' fixtures in the
    dataset. Useful for testing the judges themselves — it can NEVER catch
    an engine regression and must not be used as the CI gate.

Gate semantics (fail-closed):
  - Missing ANTHROPIC_API_KEY → exit 1. A quality gate that silently
    passes when unconfigured is theater.
  - Every judge aggregate must be >= PASS_THRESHOLD.
  - No single case may score below CASE_FLOOR on average.

CLI: python -m src.evals.runner --dataset src/evals/datasets/qualification_v1.json
"""
import argparse
import json
import logging
import os
import sys
from pathlib import Path
from typing import Any

from src.evals.judges import ALL_JUDGES, BaseJudge

logger = logging.getLogger(__name__)

PASS_THRESHOLD = 0.6   # minimum aggregate per judge
CASE_FLOOR = 0.35      # minimum mean score for any single case


def load_dataset(path: str | Path) -> list[dict]:
    """Load a test dataset JSON file."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Dataset not found: {p}")
    with open(p, encoding="utf-8") as f:
        data = json.load(f)
    if isinstance(data, dict) and "test_cases" in data:
        return data["test_cases"]
    if isinstance(data, list):
        return data
    raise ValueError(f"Invalid dataset format in {p}")


# ── Online engine execution ───────────────────────────────────────────────────

_EVAL_CLIENT_CONFIG = {
    "id": "00000000-0000-0000-0000-00000000e7a1",
    "client_name": "Eval Realty",
    "prompt_overrides": {},
    "language_config": {},
    "scoring_config": {},
}

_FRESH_LEAD = {
    "phone": "+919999900000",
    "client_id": _EVAL_CLIENT_CONFIG["id"],
    "name": None,
    "intent": "unknown",
    "stage": "new",
    "language_pref": "english",
    "budget_min": None,
    "budget_max": None,
    "timeline_months": None,
    "urgency": "unknown",
    "financing_status": "unknown",
    "location_preferences": [],
    "property_type": "any",
    "family_size": None,
    "score": None,
    "tier": None,
}


def run_case_through_engine(case: dict) -> dict:
    """
    Feed a test case's user messages through the REAL engine, turn by turn,
    mirroring how the router accumulates lead state across webhook deliveries.

    Returns the final lead dict (+ 'reply' and 'messages' for the judges).
    """
    from src.engine.graph import compile_graph

    graph = compile_graph()
    lead = dict(_FRESH_LEAD)
    conversation: list[dict] = []
    last_reply = ""

    for turn in case.get("messages", []):
        user_text = turn.get("text") or turn.get("content") or ""
        if not user_text:
            continue
        conversation.append({"role": "user", "content": user_text})

        state = {
            "messages": list(conversation),
            "lead": dict(lead),
            "client_config": dict(_EVAL_CLIENT_CONFIG),
            "current_node": "",
            "turn_count": 0,
            "awaiting_info": [],
            "last_extraction": {},
            "should_handoff": False,
            "handoff_reason": None,
            "next_action": None,
            "language": lead.get("language_pref") or "english",
            "rag_context": [],
            "turn_intent": None,
            "billing_event": None,
            "errors": [],
        }

        result = graph.invoke(state)

        # Accumulate lead fields across turns (router does this via the DB)
        for k, v in (result.get("lead") or {}).items():
            if v is not None:
                lead[k] = v

        # Append the engine's reply so the next turn has real history
        for msg in reversed(result.get("messages") or []):
            if msg.get("role") == "assistant":
                last_reply = msg.get("content", "")
                break
        if last_reply:
            conversation.append({"role": "assistant", "content": last_reply})

    out = dict(lead)
    out["reply"] = last_reply
    out["messages"] = conversation
    return out


# ── Judging ───────────────────────────────────────────────────────────────────

def evaluate_case(
    test_case: dict,
    result: dict,
    judges: list[BaseJudge] | None = None,
) -> dict[str, float]:
    """Run all judges on a single (case, result) pair. Judge errors score 0."""
    judges = judges or ALL_JUDGES
    scores: dict[str, float] = {}
    for judge in judges:
        try:
            score = judge.evaluate(test_case, result)
            scores[judge.name] = round(score, 3)
        except Exception as e:
            logger.error("[eval] Judge %s failed: %s", judge.name, e)
            scores[judge.name] = 0.0
    return scores


def run_eval(
    dataset: list[dict],
    online: bool,
    judges: list[BaseJudge] | None = None,
) -> dict[str, Any]:
    """
    Run the full eval. In online mode the engine is executed per case;
    in offline mode the dataset's pre-recorded fixtures are judged.
    """
    judges = judges or ALL_JUDGES
    per_case: list[dict] = []
    totals: dict[str, list[float]] = {j.name: [] for j in judges}

    for case in dataset:
        case_name = case.get("name", "unnamed")

        if online:
            try:
                result = run_case_through_engine(case)
            except Exception as e:
                logger.error("[eval] Engine run failed for '%s': %s", case_name, e)
                per_case.append({
                    "name": case_name,
                    "scores": {j.name: 0.0 for j in judges},
                    "error": str(e),
                })
                for j in judges:
                    totals[j.name].append(0.0)
                continue
        else:
            result = case.get("result", {})
            if not result:
                logger.warning("[eval] '%s' has no fixture — skipping (offline)", case_name)
                continue

        scores = evaluate_case(case, result, judges)
        per_case.append({"name": case_name, "scores": scores})
        for jname, score in scores.items():
            totals[jname].append(score)

    aggregate = {
        jname: (round(sum(s) / len(s), 3) if s else 0.0)
        for jname, s in totals.items()
    }

    # Pass criteria: every judge aggregate above threshold AND no case
    # catastrophically bad on average.
    judges_pass = all(v >= PASS_THRESHOLD for v in aggregate.values())
    weak_cases = [
        c["name"] for c in per_case
        if c["scores"] and (sum(c["scores"].values()) / len(c["scores"])) < CASE_FLOOR
    ]

    return {
        "mode": "online" if online else "offline",
        "aggregate": aggregate,
        "per_case": per_case,
        "weak_cases": weak_cases,
        "pass": judges_pass and not weak_cases and len(per_case) > 0,
        "total_cases": len(per_case),
    }


def print_report(report: dict) -> None:
    """Pretty-print an eval report to stdout."""
    print("\n" + "=" * 60)
    print(f"  EVAL REPORT  (mode: {report['mode']})")
    print("=" * 60)

    print(f"\nTotal cases evaluated: {report['total_cases']}")
    print(f"Overall: {'PASS' if report['pass'] else 'FAIL'}")

    print(f"\nAggregate scores (threshold {PASS_THRESHOLD}):")
    for jname, score in report["aggregate"].items():
        status = "PASS" if score >= PASS_THRESHOLD else "FAIL"
        bar = "#" * int(score * 20)
        print(f"  {jname:35s} {score:.3f}  [{bar:20s}]  {status}")

    if report["weak_cases"]:
        print(f"\nCases below the {CASE_FLOOR} floor:")
        for name in report["weak_cases"]:
            print(f"  !! {name}")

    print("\nPer-case breakdown:")
    for case in report["per_case"]:
        print(f"\n  {case['name']}:")
        for jname, score in case["scores"].items():
            print(f"    {jname:33s} {score:.3f}")
        if case.get("error"):
            print(f"    ENGINE ERROR: {case['error'][:120]}")

    print("\n" + "=" * 60)


# ── CLI ───────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Run LeadEngine evals")
    parser.add_argument(
        "--dataset",
        type=str,
        default="src/evals/datasets/qualification_v1.json",
        help="Path to test dataset JSON",
    )
    parser.add_argument(
        "--offline",
        action="store_true",
        default=False,
        help="Judge pre-recorded fixtures instead of running the engine "
             "(for testing the judges — NOT a regression gate)",
    )
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO)

    # FAIL CLOSED: a quality gate that silently passes when the API key is
    # missing protects nothing. If you genuinely want to skip evals, remove
    # the CI step — don't let it lie.
    if not os.environ.get("ANTHROPIC_API_KEY"):
        print(
            "\n[EVAL FAILED] ANTHROPIC_API_KEY is not set. The eval gate "
            "requires it (engine + judges are LLM-based). Set the secret "
            "in CI or remove the eval step explicitly.",
            file=sys.stderr,
        )
        sys.exit(1)

    dataset = load_dataset(args.dataset)
    logger.info("[eval] Loaded %d test cases from %s", len(dataset), args.dataset)

    report = run_eval(dataset, online=not args.offline)
    print_report(report)

    sys.exit(0 if report["pass"] else 1)


if __name__ == "__main__":
    main()
