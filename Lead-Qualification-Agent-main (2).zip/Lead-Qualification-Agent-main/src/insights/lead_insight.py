"""
Lead Insight generator — per-lead conversational analysis for the broker dashboard.

Given a lead profile + their conversation history, produces:
  - One-line conversation summary
  - Estimated close probability (0-100)
  - Buying signals (what's working in our favor)
  - Concerns / objections (what's blocking the deal)
  - Recommended next action for the broker
  - Talking points to emphasize on the next call

Uses Haiku (~₹0.05/call). Cached on the lead row for 1 hour so opening the
detail page repeatedly doesn't trigger a fresh LLM call.

NOTE: This is a READ-ONLY analysis layer.  It never modifies the lead itself —
the broker uses the insight to inform manual follow-up, not the bot.
"""
import asyncio
import json
import logging
from datetime import datetime, timezone
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from src.engine.llm import generate, HAIKU_MODEL
from src.db.queries import get_lead, get_conversation_messages, list_conversations
from src.core.redis import get_redis

logger = logging.getLogger(__name__)

# Cache insights in Redis for 1 hour — shared across all uvicorn workers.
_INSIGHT_CACHE_PREFIX = "insight:"
_INSIGHT_CACHE_TTL_SECONDS = 3600  # 1 hour


def _budget_summary(lead: dict) -> str:
    b_min = lead.get("budget_min")
    b_max = lead.get("budget_max")
    if not b_min and not b_max:
        return "not discussed"
    if b_min and b_max:
        return f"Rs.{b_min // 100000}L - Rs.{b_max // 100000}L"
    return f"Rs.{(b_min or b_max) // 100000}L"


def _tier_baseline_prob(tier: str | None, stage: str | None) -> int:
    """Deterministic baseline close probability before LLM refinement."""
    if stage == "scheduled":
        return 70
    if tier == "hot" and stage == "scheduling":
        return 55
    if tier == "hot":
        return 40
    if tier == "warm":
        return 20
    if tier == "cold":
        return 5
    return 10


def _format_messages_for_prompt(messages: list, max_msgs: int = 30) -> str:
    """Compact conversation history for the LLM."""
    recent = messages[-max_msgs:]
    lines = []
    for m in recent:
        role = "Lead" if m.get("direction") == "inbound" or m.get("role") == "user" else "Bot"
        content = (m.get("content") or "").strip().replace("\n", " ")
        if len(content) > 200:
            content = content[:200] + "..."
        lines.append(f"{role}: {content}")
    return "\n".join(lines)


INSIGHT_PROMPT = """You are a senior real-estate sales coach analysing a WhatsApp lead.

LEAD PROFILE:
- Name: {name}
- Tier: {tier} | Stage: {stage} | Score: {score}/100
- Budget: {budget}
- Timeline: {timeline}
- Location preferences: {locations}
- Property type: {property_type}
- Financing: {financing}
- Family size: {family_size}

CONVERSATION (most recent first below):
{conversation}

SCORING REASONING: {scoring_reasoning}

Produce a JSON object with EXACTLY these keys (no markdown, no commentary):
{{
  "summary": "<2-3 sentence summary of the conversation - what they want and where they are emotionally>",
  "close_probability": <integer 0-100, your estimate of how likely this deal closes within 30 days>,
  "buying_signals": ["<short signal 1>", "<short signal 2>", "<short signal 3>"],
  "concerns": ["<objection 1 or empty>", "<objection 2 or empty>"],
  "next_action": "<one specific action the broker should take next>",
  "talking_points": ["<emphasise X>", "<address Y>", "<offer Z>"],
  "urgency_level": "<low|medium|high>"
}}

Rules:
- buying_signals: 2-4 items. Concrete things the lead said or revealed.
- concerns: 0-3 items. Empty list if no objections detected.
- talking_points: 2-4 items. Specific things broker should emphasise on next contact.
- close_probability: anchored on tier ({tier_baseline} baseline) but adjusted for conversation signals.
- urgency_level: "high" if they've asked for visit/decision, "low" if browsing, "medium" otherwise.
- Be DIRECT and BROKER-FACING. No fluff. Sound like a sales coach, not a chatbot."""


async def generate_lead_insight(
    db: AsyncSession,
    client_id: str,
    lead_id: str,
    force_refresh: bool = False,
) -> dict[str, Any]:
    """
    Generate or retrieve a cached insight for a lead.

    Returns dict with keys:
      summary, close_probability, buying_signals, concerns,
      next_action, talking_points, urgency_level, generated_at, cached
    """
    cache_key = str(lead_id)

    # Cache check (Redis-backed, shared across workers)
    if not force_refresh:
        try:
            redis = get_redis()
            cached_raw = await redis.get(f"{_INSIGHT_CACHE_PREFIX}{cache_key}")
            if cached_raw:
                cached_data = json.loads(cached_raw)
                return {**cached_data, "cached": True}
        except Exception:
            pass  # Redis down — proceed without cache

    # Fetch lead
    lead_row = await get_lead(db, client_id, lead_id)
    if not lead_row:
        raise ValueError(f"Lead not found: {lead_id}")

    lead = {
        "name": lead_row.name,
        "phone": lead_row.phone,
        "tier": lead_row.tier,
        "stage": lead_row.stage,
        "score": lead_row.score,
        "budget_min": lead_row.budget_min,
        "budget_max": lead_row.budget_max,
        "timeline_months": lead_row.timeline_months,
        "location_preferences": lead_row.location_preferences,
        "property_type": lead_row.property_type,
        "financing_status": lead_row.financing_status,
        "family_size": lead_row.family_size,
    }

    # Fetch latest conversation messages
    convos = await list_conversations(db, client_id, lead_id)
    messages = []
    if convos:
        # Use the most recent conversation
        msgs = await get_conversation_messages(db, client_id, convos[0].id, limit=30)
        messages = [{"direction": m.direction, "content": m.content} for m in msgs]

    if not messages:
        # No conversation yet → return a minimal insight
        result = {
            "summary": "Lead just arrived - no conversation history yet.",
            "close_probability": _tier_baseline_prob(lead.get("tier"), lead.get("stage")),
            "buying_signals": [],
            "concerns": ["Has not engaged in conversation yet"],
            "next_action": "Wait for first reply, or send a personalised opening message.",
            "talking_points": ["Introduce yourself", "Ask about their requirements"],
            "urgency_level": "low",
            "generated_at": datetime.now(timezone.utc).isoformat() + "Z",
            "cached": False,
        }
        try:
            redis = get_redis()
            await redis.setex(
                f"{_INSIGHT_CACHE_PREFIX}{cache_key}",
                _INSIGHT_CACHE_TTL_SECONDS,
                json.dumps(result, default=str),
            )
        except Exception:
            pass  # Redis down — result still returned, just not cached
        return result

    # Build LLM prompt
    locs = lead.get("location_preferences", [])
    loc_str = ", ".join(locs) if isinstance(locs, list) and locs else "not specified"

    prompt = INSIGHT_PROMPT.format(
        name=lead.get("name") or "(unknown)",
        tier=lead.get("tier") or "unscored",
        stage=lead.get("stage") or "new",
        score=lead.get("score") or 0,
        budget=_budget_summary(lead),
        timeline=f"{lead.get('timeline_months') or '?'} months",
        locations=loc_str,
        property_type=lead.get("property_type") or "any",
        financing=lead.get("financing_status") or "unknown",
        family_size=lead.get("family_size") or "unknown",
        conversation=_format_messages_for_prompt(messages),
        scoring_reasoning=lead_row.__dict__.get("scoring_reasoning")
            or getattr(lead_row, "scoring_reasoning", None)
            or "n/a",
        tier_baseline=_tier_baseline_prob(lead.get("tier"), lead.get("stage")),
    )

    try:
        # generate() is a blocking (sync) Anthropic call — run it off the event loop
        raw = await asyncio.to_thread(
            generate,
            system_prompt=prompt,
            user_text="Produce the JSON insight now.",
            max_tokens=600,
            model=HAIKU_MODEL,
            temperature=0.4,
        )
        # Strip code-fence if Haiku wraps it
        cleaned = raw.strip()
        if cleaned.startswith("```"):
            cleaned = cleaned.strip("`")
            if cleaned.lower().startswith("json"):
                cleaned = cleaned[4:]
            cleaned = cleaned.strip()
        parsed = json.loads(cleaned)
    except Exception as e:
        logger.warning("[lead_insight] LLM failed for lead %s: %s", lead_id, e)
        parsed = {
            "summary": "Could not generate insight — try refreshing.",
            "close_probability": _tier_baseline_prob(lead.get("tier"), lead.get("stage")),
            "buying_signals": [],
            "concerns": ["Insight generation failed"],
            "next_action": "Review the conversation manually.",
            "talking_points": [],
            "urgency_level": "medium",
        }

    # Clamp probability into [0, 100]
    cp = parsed.get("close_probability", 0)
    try:
        cp = max(0, min(100, int(cp)))
    except (TypeError, ValueError):
        cp = _tier_baseline_prob(lead.get("tier"), lead.get("stage"))
    parsed["close_probability"] = cp

    parsed["generated_at"] = datetime.now(timezone.utc).isoformat() + "Z"
    parsed["cached"] = False

    # Write to Redis cache (best-effort)
    try:
        redis = get_redis()
        await redis.setex(
            f"{_INSIGHT_CACHE_PREFIX}{cache_key}",
            _INSIGHT_CACHE_TTL_SECONDS,
            json.dumps(parsed, default=str),
        )
    except Exception:
        pass  # Redis down — result still returned, just not cached

    return parsed


async def invalidate_insight_cache(lead_id: str) -> None:
    """
    Drop the cached insight for a lead (called when a new message arrives
    so the dashboard regenerates a fresh analysis). Best-effort, never raises.
    """
    try:
        redis = get_redis()
        await redis.delete(f"{_INSIGHT_CACHE_PREFIX}{lead_id}")
    except Exception:
        logger.debug("[lead_insight] Cache invalidation failed for lead %s", lead_id)
