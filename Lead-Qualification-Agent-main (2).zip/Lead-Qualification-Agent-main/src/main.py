import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from src.config import get_settings
from src.db.engine import engine, Base
from src.api.webhooks import router as webhook_router
from src.api.admin import router as admin_router
from src.api.dashboard import router as dashboard_router
from src.api.auth import router as auth_router
from src.api.voice import router as voice_router
from src.crons.setup import start_scheduler, stop_scheduler
from src.core.tracing import flush_traces
from src.core.redis import check_redis_health, close_redis

logger = logging.getLogger(__name__)
settings = get_settings()

logging.basicConfig(
    level=settings.log_level,
    force=True,
    handlers=[logging.StreamHandler(__import__("sys").stdout)],
)
# Force UTF-8 on the stream handler so ₹, emoji, etc. don't crash on Windows
for _h in logging.root.handlers:
    if hasattr(_h, "stream") and hasattr(_h.stream, "reconfigure"):
        try:
            _h.stream.reconfigure(encoding="utf-8")
        except Exception:
            pass


def _init_sentry() -> None:
    """Optional error tracking — enabled by setting SENTRY_DSN."""
    if not settings.sentry_dsn:
        return
    try:
        import sentry_sdk
        sentry_sdk.init(
            dsn=settings.sentry_dsn,
            environment=settings.app_env,
            traces_sample_rate=0.1,
        )
        logger.info("Sentry initialized (env=%s)", settings.app_env)
    except ImportError:
        logger.warning("SENTRY_DSN is set but sentry-sdk is not installed — `pip install sentry-sdk`")


async def _disable_default_admin() -> None:
    """
    Migration 0004 seeds admin@getpramaan.com with a known default password.
    In production that is a backdoor: if the password was never changed,
    disable the account and demand a real admin be created.
    """
    from sqlalchemy import select
    from passlib.context import CryptContext
    import asyncio

    from src.db.engine import AsyncSessionFactory
    from src.db.tables import User

    pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")
    try:
        async with AsyncSessionFactory() as db:
            res = await db.execute(
                select(User).where(
                    User.email == "admin@getpramaan.com",
                    User.active.is_(True),
                )
            )
            user = res.scalar_one_or_none()
            if user and await asyncio.to_thread(pwd.verify, "pramaan2026", user.password_hash):
                user.active = False
                await db.commit()
                logger.critical(
                    "SECURITY: seeded default admin (admin@getpramaan.com) still had "
                    "the default password — account DISABLED. Create a real admin user."
                )
    except Exception as e:
        logger.warning("Default-admin safety check failed: %s", e)


def _enforce_production_safety() -> None:
    """Refuse to boot production with default/missing secrets."""
    if not settings.is_production:
        return
    if settings.secret_key in ("", "change_me_in_production"):
        raise RuntimeError(
            "SECRET_KEY is unset/default — JWTs and token encryption would be "
            "forgeable. Set a strong SECRET_KEY before running in production."
        )
    if not settings.meta_app_secret:
        logger.warning(
            "META_APP_SECRET not set — WhatsApp webhook signatures will not be verified."
        )
    if not settings.cors_origins:
        logger.warning("CORS_ORIGINS not set — browser dashboards will be blocked by CORS.")


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("LeadEngine starting up (env=%s)", settings.app_env)
    _enforce_production_safety()
    _init_sentry()
    async with engine.begin() as conn:
        # In dev, tables are created by Alembic. This is a safety net.
        await conn.run_sync(Base.metadata.create_all)
    if settings.is_production:
        await _disable_default_admin()
    # Start APScheduler cron jobs (daily digest, re-engagement, warm digest)
    start_scheduler()
    yield
    stop_scheduler()
    flush_traces()
    await close_redis()
    await engine.dispose()
    logger.info("LeadEngine shut down")


app = FastAPI(
    title="LeadEngine",
    description="Multi-tenant real estate lead qualification SaaS",
    version="0.1.0",
    lifespan=lifespan,
)

def _get_cors_origins() -> list[str]:
    """Parse CORS origins from config. Falls back to sensible defaults."""
    if settings.cors_origins:
        return [o.strip() for o in settings.cors_origins.split(",") if o.strip()]
    if settings.is_production:
        return []  # Must be configured explicitly in production
    return ["*"]  # Allow all in dev

app.add_middleware(
    CORSMiddleware,
    allow_origins=_get_cors_origins(),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Routes ────────────────────────────────────────────────────────────────────
app.include_router(auth_router)
app.include_router(webhook_router)
app.include_router(admin_router)
app.include_router(dashboard_router)
app.include_router(voice_router)


@app.get("/health")
async def health():
    """
    Health check — verifies DB and Redis connectivity.
    Returns 200 with status=ok if all dependencies are healthy,
    200 with status=degraded if optional services are down,
    503 if critical services (DB/Redis) are unreachable.
    """
    from sqlalchemy import text as sa_text

    checks = {"env": settings.app_env, "version": "0.1.0"}

    # Check PostgreSQL — never leak exception details to unauthenticated callers
    try:
        async with engine.connect() as conn:
            await conn.execute(sa_text("SELECT 1"))
        checks["postgres"] = "ok"
    except Exception as e:
        logger.error("[health] Postgres check failed: %s", e)
        checks["postgres"] = "error"

    # Check Redis
    redis_health = await check_redis_health()
    if redis_health["ok"]:
        checks["redis"] = "ok"
    else:
        logger.error("[health] Redis check failed: %s", redis_health["error"])
        checks["redis"] = "error"
    checks["redis_latency_ms"] = redis_health["latency_ms"]

    # Determine overall status
    critical_ok = checks["postgres"] == "ok" and checks["redis"] == "ok"
    checks["status"] = "ok" if critical_ok else "degraded"

    from fastapi.responses import JSONResponse
    status_code = 200 if critical_ok else 503
    return JSONResponse(content=checks, status_code=status_code)
