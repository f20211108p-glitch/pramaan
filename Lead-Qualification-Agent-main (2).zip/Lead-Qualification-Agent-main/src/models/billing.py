from __future__ import annotations

from datetime import datetime
from typing import Literal
from pydantic import BaseModel, Field


BillingEventType = Literal["qualified_lead", "appointment_booked", "conversation_completed"]


class BillingEvent(BaseModel):
    id: str
    client_id: str
    lead_id: str | None = None
    event_type: BillingEventType
    amount_inr: int | None = None
    metadata: dict = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=datetime.utcnow)
