from __future__ import annotations

from typing import Literal
from pydantic import BaseModel, Field

from src.models.lead import LanguagePref


class LanguageConfig(BaseModel):
    primary_language: LanguagePref = "english"
    regional_languages: list[str] = Field(default_factory=list)
    formality_level: Literal["formal", "casual"] = "formal"
    hindi_pronoun: Literal["aap", "tum"] = "aap"


class ClientConfig(BaseModel):
    id: str
    client_name: str
    waba_number: str
    waba_phone_number_id: str
    waba_token: str
    project_ids: list[str] = Field(default_factory=list)
    prompt_overrides: dict[str, str] = Field(default_factory=dict)
    crm_type: str | None = None
    language_config: LanguageConfig = Field(default_factory=LanguageConfig)
    broker_wa_numbers: list[str] = Field(default_factory=list)
    google_calendar_id: str | None = None
    active: bool = True
