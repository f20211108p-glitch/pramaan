from __future__ import annotations

from datetime import datetime
from typing import Literal
from pydantic import BaseModel, Field

from src.models.message import UnifiedMessage


ConversationStatus = Literal["active", "paused", "handed_off", "completed", "abandoned"]


class Conversation(BaseModel):
    id: str
    client_id: str
    lead_id: str
    channel: str = "whatsapp"
    status: ConversationStatus = "active"
    messages: list[UnifiedMessage] = Field(default_factory=list)
    summary: str | None = None
    started_at: datetime = Field(default_factory=datetime.utcnow)
    last_message_at: datetime = Field(default_factory=datetime.utcnow)
