"""
Lead domain models — field names locked in DECISIONS.md Section 4.
Do NOT rename any field without updating DECISIONS.md and coordinating with both devs.
"""
from __future__ import annotations

from typing import Literal
from pydantic import BaseModel, Field, field_validator


# ── Type aliases (reused across modules) ─────────────────────────────────────

Intent = Literal["buyer", "seller", "investor", "renter", "unknown"]
LeadStage = Literal[
    "new", "qualifying", "qualified", "scheduling",
    "nurturing", "handed_off", "converted", "lost",
]
FinancingStatus = Literal["pre_approved", "exploring", "cash", "unknown"]
PropertyType = Literal["apartment", "villa", "plot", "commercial", "any"]
LanguagePref = Literal["english", "hindi", "hinglish", "regional"]
Urgency = Literal["immediate", "1_3_months", "3_6_months", "6_plus", "unknown"]
Tier = Literal["hot", "warm", "cold"]


# ── Value objects ─────────────────────────────────────────────────────────────

class Budget(BaseModel):
    min_amount: int | None = None
    max_amount: int | None = None
    currency: str = "INR"


class Timeline(BaseModel):
    months: int | None = None
    urgency: Urgency = "unknown"


class LeadScore(BaseModel):
    score: int = Field(ge=0, le=100)
    tier: Tier
    reasoning: str = ""

    @field_validator("tier")
    @classmethod
    def tier_matches_score(cls, v: str, info) -> str:
        score = info.data.get("score")
        if score is None:
            return v
        expected = "hot" if score >= 70 else ("warm" if score >= 40 else "cold")
        if v != expected:
            raise ValueError(
                f"Tier '{v}' does not match score {score}. Expected '{expected}'. "
                f"Rules: hot >= 70, warm 40-69, cold < 40."
            )
        return v


# ── LeadProfile — the main domain object ─────────────────────────────────────

class LeadProfile(BaseModel):
    """
    Central lead model. Created with just (phone, client_id) on first message,
    then progressively filled by the qualification engine.
    """
    phone: str
    client_id: str

    name: str | None = None
    email: str | None = None

    language_pref: LanguagePref = "english"
    intent: Intent = "unknown"

    budget_min: int | None = None   # INR — e.g. 7000000 = 70 lakh
    budget_max: int | None = None   # INR
    timeline_months: int | None = None
    urgency: Urgency = "unknown"
    financing_status: FinancingStatus = "unknown"
    location_preferences: list[str] = Field(default_factory=list)
    property_type: PropertyType = "any"
    family_size: int | None = None

    score: int | None = None        # 0-100
    tier: Tier | None = None
    stage: LeadStage = "new"

    def compute_tier(self) -> Tier | None:
        """Derive tier from score. Does NOT mutate self."""
        if self.score is None:
            return None
        if self.score >= 70:
            return "hot"
        if self.score >= 40:
            return "warm"
        return "cold"

    def missing_fields(self) -> list[str]:
        """Return list of key qualification fields still empty."""
        missing = []
        if self.budget_min is None and self.budget_max is None:
            missing.append("budget")
        if self.timeline_months is None:
            missing.append("timeline")
        if not self.location_preferences:
            missing.append("location")
        if self.property_type == "any":
            missing.append("property_type")
        if self.financing_status == "unknown":
            missing.append("financing")
        if self.intent == "unknown":
            missing.append("intent")
        return missing
