"""
Message models — the unified envelope for all inbound/outbound messages.
"""
from __future__ import annotations

from datetime import datetime
from typing import Literal
from pydantic import BaseModel, Field


ChannelType = Literal["whatsapp", "web"]
MessageDirection = Literal["inbound", "outbound"]
MediaType = Literal["text", "audio", "image", "document"]


class UnifiedMessage(BaseModel):
    """
    Channel-agnostic message representation.
    WhatsApp webhook → parsed into this → fed to the engine.
    """
    channel: ChannelType = "whatsapp"
    direction: MessageDirection
    sender_id: str                          # phone number or user ID
    content: str                            # text body (or transcription for audio)
    message_type: MediaType = "text"
    channel_message_id: str | None = None   # WhatsApp's wamid for dedup
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    metadata: dict = Field(default_factory=dict)  # extra channel-specific data
