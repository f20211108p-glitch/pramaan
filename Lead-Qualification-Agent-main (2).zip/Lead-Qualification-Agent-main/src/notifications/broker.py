"""
Broker notification — WhatsApp alert when a lead is scored HOT.

Flow:
  1. Scorer marks lead as hot (score >= 70)
  2. Router calls notify_brokers() after persisting results
  3. This module sends a formatted lead summary to each broker_wa_number
  4. Uses the CLIENT's WABA credentials (multi-tenant)

The notification includes:
  - Lead name / phone
  - Score + tier + reasoning
  - Budget, location, timeline, financing
  - A "call to action" line for the broker to follow up
"""
import logging
from typing import Any

from src.channels.whatsapp import WhatsAppChannel
from src.core.crypto import decrypt_token

logger = logging.getLogger(__name__)


def _format_currency_lakhs(amount: int | None) -> str:
    """Convert INR amount to lakhs/crores display string."""
    if amount is None:
        return "not specified"
    if amount >= 10_000_000:  # 1 crore+
        crores = amount / 10_000_000
        return f"₹{crores:.1f} Cr"
    lakhs = amount / 100_000
    return f"₹{lakhs:.0f}L"


def _format_lead_summary(lead: dict, scoring_reasoning: str | None = None) -> str:
    """
    Build a WhatsApp-friendly lead summary for the broker.

    Example output:
        *New HOT Lead*
        Name: Raj Sharma
        Phone: +919820011111
        Score: 85/100 (HOT)

        Budget: 70L - 90L
        Location: Whitefield, Sarjapur Road
        Timeline: 2 months
        Financing: SBI pre-approved
        Property: apartment (family of 4)

        AI Assessment: High-intent buyer with confirmed financing...

        Reply to this message to start follow-up.
    """
    name = lead.get("name") or "Unknown"
    phone = lead.get("phone", "")
    score = lead.get("score", 0)
    tier = (lead.get("tier") or "unknown").upper()

    # Budget range
    b_min = _format_currency_lakhs(lead.get("budget_min"))
    b_max = _format_currency_lakhs(lead.get("budget_max"))
    if lead.get("budget_min") or lead.get("budget_max"):
        budget_str = f"{b_min} - {b_max}"
    else:
        budget_str = "not specified"

    # Location
    locs = lead.get("location_preferences", [])
    if isinstance(locs, list) and locs:
        location_str = ", ".join(locs)
    elif isinstance(locs, str) and locs:
        location_str = locs
    else:
        location_str = "not specified"

    # Timeline
    timeline = lead.get("timeline_months")
    timeline_str = f"{timeline} months" if timeline else "not specified"

    # Financing
    financing = lead.get("financing_status", "unknown")
    financing_display = {
        "pre_approved": "Pre-approved",
        "exploring": "Exploring options",
        "cash": "Cash buyer",
        "unknown": "Not discussed",
    }.get(financing, financing)

    # Property + family
    prop_type = lead.get("property_type", "any")
    family = lead.get("family_size")
    prop_str = prop_type
    if family:
        prop_str += f" (family of {family})"

    # Intent
    intent = lead.get("intent", "unknown")

    lines = [
        f"*New {tier} Lead* \U0001f525",
        f"Name: {name}",
        f"Phone: {phone}",
        f"Score: {score}/100 ({tier})",
        f"Intent: {intent}",
        "",
        f"Budget: {budget_str}",
        f"Location: {location_str}",
        f"Timeline: {timeline_str}",
        f"Financing: {financing_display}",
        f"Property: {prop_str}",
    ]

    if scoring_reasoning:
        lines.append("")
        lines.append(f"AI Assessment: {scoring_reasoning}")

    lines.append("")
    lines.append("Reply to this message to start follow-up.")

    return "\n".join(lines)


async def notify_visit_booked(
    client_config: Any,
    lead: dict,
    slot_text: str,
    calendar_link: str | None = None,
) -> list[dict]:
    """
    Alert every broker that a lead CONFIRMED a site visit.

    This is the moment a human must take over logistics — without this
    notification, the AI's booking confirmation is theater: the lead shows
    up and nobody knows they're coming.
    """
    broker_numbers = client_config.broker_wa_numbers or []
    if not broker_numbers:
        logger.warning(
            "[broker_notify] SITE VISIT BOOKED for lead %s but NO broker numbers "
            "configured for client %s — nobody will be told!",
            lead.get("phone"), client_config.id,
        )
        return []

    lines = [
        "*Site Visit CONFIRMED* 📅",
        f"Name: {lead.get('name') or 'Unknown'}",
        f"Phone: {lead.get('phone', '')}",
        f"Requested time: {slot_text}",
    ]
    locs = lead.get("location_preferences", [])
    if isinstance(locs, list) and locs:
        lines.append(f"Interested in: {', '.join(locs)}")
    if calendar_link:
        lines.append(f"Calendar: {calendar_link}")
    lines.append("")
    lines.append("Please call the lead to confirm logistics and be at the site office.")
    summary = "\n".join(lines)

    results = []
    for broker_phone in broker_numbers:
        try:
            success = await WhatsAppChannel.send_message(
                waba_phone_number_id=client_config.waba_phone_number_id,
                waba_token=client_config.waba_token,
                to=broker_phone,
                content=summary,
            )
            results.append({"broker_number": broker_phone, "success": success})
        except Exception as e:
            logger.error("[broker_notify] Visit alert to %s failed: %s", broker_phone, e)
            results.append({"broker_number": broker_phone, "success": False})

    if not any(r["success"] for r in results):
        logger.critical(
            "[broker_notify] Site visit for lead %s could NOT be delivered to any broker — "
            "manual follow-up required (slot: %s)",
            lead.get("phone"), slot_text,
        )
    return results


async def notify_brokers(
    client_config: Any,
    lead: dict,
    scoring_reasoning: str | None = None,
) -> list[dict]:
    """
    Send WhatsApp notification to all broker numbers configured for this client.

    Args:
        client_config: ClientConfig ORM object (has waba_phone_number_id, waba_token, broker_wa_numbers)
        lead: dict of lead fields (from engine result or DB)
        scoring_reasoning: optional AI-generated scoring explanation

    Returns:
        list of {broker_number, success: bool} dicts
    """
    broker_numbers = client_config.broker_wa_numbers or []
    if not broker_numbers:
        logger.info("[broker_notify] No broker numbers configured for client %s", client_config.id)
        return []

    summary = _format_lead_summary(lead, scoring_reasoning)
    results = []

    for broker_phone in broker_numbers:
        try:
            success = await WhatsAppChannel.send_message(
                waba_phone_number_id=client_config.waba_phone_number_id,
                waba_token=decrypt_token(client_config.waba_token),
                to=broker_phone,
                content=summary,
            )
            results.append({"broker_number": broker_phone, "success": success})
            if success:
                logger.info("[broker_notify] Notified broker %s for lead %s", broker_phone, lead.get("phone"))
            else:
                logger.warning("[broker_notify] Failed to notify broker %s", broker_phone)
        except Exception as e:
            logger.error("[broker_notify] Error notifying broker %s: %s", broker_phone, e)
            results.append({"broker_number": broker_phone, "success": False})

    return results
