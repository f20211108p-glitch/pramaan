"""
Text chunking and chunk-type classification for brochure RAG.

Chunks are ~400 tokens (~300 words) with 50-token overlap for context continuity.
Chunk types are classified by keyword heuristics (no LLM needed — save cost).
"""
import re
import logging
from typing import Literal

logger = logging.getLogger(__name__)

ChunkType = Literal[
    "pricing_table", "amenities", "location",
    "floor_plan", "specifications", "general",
]

# Average tokens per word ≈ 1.3 for English. 400 tokens ≈ 300 words.
DEFAULT_CHUNK_SIZE = 300  # words
DEFAULT_OVERLAP = 40      # words


def chunk_text(
    text: str,
    chunk_size: int = DEFAULT_CHUNK_SIZE,
    overlap: int = DEFAULT_OVERLAP,
) -> list[dict]:
    """
    Split text into overlapping chunks of ~chunk_size words.

    Returns:
        list of {"text": str, "start_char": int, "end_char": int, "chunk_index": int}
    """
    if not text or not text.strip():
        return []

    # Normalize whitespace but preserve paragraph structure
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = text.strip()

    words = text.split()
    if not words:
        return []

    chunks = []
    word_idx = 0
    chunk_index = 0

    while word_idx < len(words):
        end_idx = min(word_idx + chunk_size, len(words))
        chunk_words = words[word_idx:end_idx]
        chunk_text_str = " ".join(chunk_words)

        # Calculate character positions
        # Find the start/end in original text for metadata
        start_char = text.find(chunk_words[0], 0 if not chunks else chunks[-1].get("_search_from", 0))
        if start_char == -1:
            start_char = 0
        end_char = start_char + len(chunk_text_str)

        chunks.append({
            "text": chunk_text_str,
            "start_char": start_char,
            "end_char": min(end_char, len(text)),
            "chunk_index": chunk_index,
            "_search_from": start_char + 1,  # internal: for next search start
        })

        chunk_index += 1

        # Advance by chunk_size - overlap
        step = max(chunk_size - overlap, 1)
        word_idx += step

        # If the remaining text is smaller than overlap, include it in the last chunk
        if word_idx < len(words) and len(words) - word_idx < overlap:
            break

    # Clean internal keys
    for c in chunks:
        c.pop("_search_from", None)

    logger.info("Chunked %d words into %d chunks (size=%d, overlap=%d)",
                len(words), len(chunks), chunk_size, overlap)
    return chunks


def classify_chunk_type(text: str) -> ChunkType:
    """
    Classify a chunk's content type using keyword heuristics.
    No LLM call needed — fast and free.
    """
    lower = text.lower()

    # Pricing keywords
    pricing_kw = ["₹", "lakh", "crore", "price", "cost", "emi", "per sq", "rate",
                  "booking amount", "gst", "stamp duty", "registration"]
    if sum(1 for kw in pricing_kw if kw in lower) >= 2:
        return "pricing_table"

    # Floor plan keywords
    floor_kw = ["floor plan", "bhk", "carpet", "built-up", "sqft", "sq.ft",
                "super built", "rera carpet", "balcony area", "bedroom",
                "configuration", "unit type"]
    if sum(1 for kw in floor_kw if kw in lower) >= 2:
        return "floor_plan"

    # Amenities keywords
    amenity_kw = ["pool", "gym", "club", "clubhouse", "garden", "parking",
                  "security", "swimming", "jogging", "yoga", "play area",
                  "sports", "landscap", "ameniti", "recreation"]
    if sum(1 for kw in amenity_kw if kw in lower) >= 2:
        return "amenities"

    # Location keywords
    location_kw = ["located", "near", "km from", "minutes", "highway", "metro",
                   "station", "airport", "school", "hospital", "connectivity",
                   "distance", "neighbourhood", "location advantage"]
    if sum(1 for kw in location_kw if kw in lower) >= 2:
        return "location"

    # Specifications keywords
    spec_kw = ["specification", "fitting", "vitrified", "marble", "modular",
               "kitchen", "granite", "ceramic", "aluminium", "electrical",
               "plumbing", "paint", "door", "window", "toilet"]
    if sum(1 for kw in spec_kw if kw in lower) >= 2:
        return "specifications"

    return "general"
