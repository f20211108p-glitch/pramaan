"""
Local embeddings using fastembed — free, no API key, runs on CPU.

Model: sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2
- 384 dimensions
- Supports 50+ languages incl. English, Hindi, Hinglish
- ~90MB download on first use, cached permanently after
- Zero cost forever

NOTE: if EMBEDDING_MODEL ever changes, ALL brochure_chunks must be
re-ingested — vectors from different models are not comparable, and
search will silently degrade rather than fail.

Why not OpenAI embeddings?
- Would require a second API key (OpenAI) alongside Anthropic
- fastembed runs locally — no API, no cost, no rate limits
"""
import asyncio
import logging
from functools import lru_cache

logger = logging.getLogger(__name__)

# Model choice: multilingual for Hindi/Hinglish support in Indian real estate
# paraphrase-multilingual-MiniLM-L12-v2: 384 dims, supports 50+ languages including Hindi
EMBEDDING_MODEL = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
EMBEDDING_DIMS = 384
MAX_BATCH_SIZE = 100


@lru_cache(maxsize=1)
def _get_embedding_model():
    """
    Load and cache the embedding model.
    First call downloads ~90MB model to ~/.cache/fastembed/.
    Subsequent calls are instant (cached in memory).
    """
    from fastembed import TextEmbedding
    logger.info("[embedder] Loading embedding model: %s", EMBEDDING_MODEL)
    model = TextEmbedding(model_name=EMBEDDING_MODEL)
    logger.info("[embedder] Model loaded — %d dimensions", EMBEDDING_DIMS)
    return model


def _embed_sync(texts: list[str]) -> list[list[float]]:
    """CPU-bound embedding — must run off the event loop."""
    model = _get_embedding_model()
    embeddings_gen = model.embed(texts, batch_size=MAX_BATCH_SIZE)
    return [emb.tolist() for emb in embeddings_gen]


async def embed_texts(texts: list[str]) -> list[list[float]]:
    """
    Embed a list of texts using fastembed (local, free).
    Returns list of 384-dimensional vectors.

    Runs in a worker thread: model load (first call, seconds) and inference
    are CPU-bound and would otherwise stall the event loop / webhook worker.
    """
    if not texts:
        return []

    try:
        embeddings = await asyncio.to_thread(_embed_sync, texts)
        logger.info("[embedder] Embedded %d texts → %d-dim vectors", len(embeddings), EMBEDDING_DIMS)
        return embeddings
    except Exception as e:
        logger.error("[embedder] Embedding failed: %s", e)
        # Return zero vectors as fallback (search won't work but ingest won't crash)
        return [[0.0] * EMBEDDING_DIMS for _ in texts]


async def embed_query(query: str) -> list[float]:
    """
    Embed a single search query (off the event loop).
    Used at conversation time when doing RAG retrieval.
    """
    results = await embed_texts([query])
    return results[0] if results else [0.0] * EMBEDDING_DIMS
