"""
Brochure ingestion pipeline: PDF → text → chunks → embeddings → pgvector.

Runs ONCE per PDF upload (not per conversation).
Cost: ~₹0.30 per 180-page brochure for embeddings.

Pipeline:
  1. Extract text from PDF (PyMuPDF/fitz)
  2. Chunk text (~400 tokens, 50-token overlap)
  3. Classify each chunk type (heuristic — no LLM)
  4. Embed all chunks (OpenAI text-embedding-3-small)
  5. Insert into brochure_chunks table with pgvector
"""
import logging
import uuid
from pathlib import Path

import fitz  # PyMuPDF

from sqlalchemy import delete, select, func
from sqlalchemy.ext.asyncio import AsyncSession

from src.db.tables import BrochureChunk
from src.rag.chunker import chunk_text, classify_chunk_type
from src.rag.embedder import embed_texts

logger = logging.getLogger(__name__)


def extract_pdf_text(pdf_path: str) -> list[dict]:
    """
    Extract text from a PDF file page by page.

    Returns:
        list of {"page_number": int, "text": str}
    """
    path = Path(pdf_path)
    if not path.exists():
        raise FileNotFoundError(f"PDF not found: {pdf_path}")

    doc = fitz.open(str(path))
    pages = []

    for page_num in range(len(doc)):
        page = doc[page_num]
        text = page.get_text()

        # Also try to extract table data
        try:
            tables = page.find_tables()
            if tables and tables.tables:
                for table in tables.tables:
                    table_text = "\n".join(
                        " | ".join(str(cell) if cell else "" for cell in row)
                        for row in table.extract()
                    )
                    text += f"\n\n[Table]\n{table_text}\n"
        except Exception:
            pass  # Table extraction is best-effort

        if text.strip():
            pages.append({"page_number": page_num + 1, "text": text.strip()})

    doc.close()
    logger.info("Extracted %d pages from %s", len(pages), path.name)
    return pages


def _assign_page_numbers(chunks: list[dict], pages: list[dict]) -> list[dict]:
    """
    Assign page numbers to chunks based on character position mapping.
    Since we concatenate all pages into one text, we track page boundaries.
    """
    if not pages:
        return chunks

    # Build page boundary map
    page_boundaries = []
    offset = 0
    for page in pages:
        page_len = len(page["text"]) + 2  # +2 for \n\n separator
        page_boundaries.append({
            "page_number": page["page_number"],
            "start": offset,
            "end": offset + page_len,
        })
        offset += page_len

    # Assign page number to each chunk based on start_char
    for chunk in chunks:
        chunk_start = chunk.get("start_char", 0)
        chunk["page_number"] = 1  # default
        for pb in page_boundaries:
            if pb["start"] <= chunk_start < pb["end"]:
                chunk["page_number"] = pb["page_number"]
                break

    return chunks


async def ingest_brochure(
    db: AsyncSession,
    pdf_path: str,
    client_id: str,
    project_id: str,
    project_name: str,
) -> dict:
    """
    Full ingestion pipeline: PDF → chunks → embeddings → pgvector.

    Returns:
        {"chunks_ingested": int, "project_id": str, "pages_extracted": int}
    """
    logger.info("Starting ingest: project=%s, client=%s, file=%s",
                project_name, client_id, pdf_path)

    import asyncio

    # Step 0: Idempotent re-ingestion — drop existing chunks for this project
    # first. Without this, re-uploading a brochure doubled the knowledge base
    # and skewed retrieval toward the duplicated project.
    deleted = await delete_project_chunks(db, client_id, project_id)
    if deleted:
        logger.info("Replaced %d existing chunks for project %s", deleted, project_id)

    # Step 1: Extract text from PDF — PyMuPDF + table detection is heavy
    # CPU work; run off the event loop so webhooks keep flowing.
    pages = await asyncio.to_thread(extract_pdf_text, pdf_path)
    if not pages:
        logger.warning("No text extracted from %s", pdf_path)
        return {"chunks_ingested": 0, "project_id": project_id, "pages_extracted": 0}

    # Combine all pages into one text for chunking
    full_text = "\n\n".join(p["text"] for p in pages)

    # Step 2: Chunk the text (CPU-bound on large brochures)
    chunks = await asyncio.to_thread(chunk_text, full_text)
    if not chunks:
        logger.warning("No chunks generated from %s", pdf_path)
        return {"chunks_ingested": 0, "project_id": project_id, "pages_extracted": len(pages)}

    # Step 3: Assign page numbers to chunks
    chunks = _assign_page_numbers(chunks, pages)

    # Step 4: Classify chunk types
    for chunk in chunks:
        chunk["chunk_type"] = classify_chunk_type(chunk["text"])

    # Step 5: Embed all chunk texts
    texts = [c["text"] for c in chunks]
    embeddings = await embed_texts(texts)

    # Step 6: Insert into database
    client_uuid = uuid.UUID(client_id) if isinstance(client_id, str) else client_id
    project_uuid = uuid.UUID(project_id) if isinstance(project_id, str) else project_id

    db_chunks = []
    for i, chunk in enumerate(chunks):
        db_chunks.append(BrochureChunk(
            client_id=client_uuid,
            project_id=project_uuid,
            project_name=project_name,
            chunk_type=chunk["chunk_type"],
            text=chunk["text"],
            embedding=embeddings[i] if i < len(embeddings) else None,
            page_number=chunk.get("page_number"),
        ))

    db.add_all(db_chunks)
    await db.commit()

    result = {
        "chunks_ingested": len(db_chunks),
        "project_id": str(project_uuid),
        "pages_extracted": len(pages),
    }
    logger.info("Ingest complete: %s", result)
    return result


async def delete_project_chunks(
    db: AsyncSession,
    client_id: str,
    project_id: str,
) -> int:
    """
    Delete all chunks for a project (before re-ingestion).
    Returns the number of deleted rows.
    """
    client_uuid = uuid.UUID(client_id) if isinstance(client_id, str) else client_id
    project_uuid = uuid.UUID(project_id) if isinstance(project_id, str) else project_id

    result = await db.execute(
        delete(BrochureChunk).where(
            BrochureChunk.client_id == client_uuid,
            BrochureChunk.project_id == project_uuid,
        )
    )
    await db.commit()
    deleted = result.rowcount
    logger.info("Deleted %d chunks for project %s", deleted, project_id)
    return deleted


async def list_projects(
    db: AsyncSession,
    client_id: str,
) -> list[dict]:
    """
    List all projects with chunk counts for a client.
    """
    client_uuid = uuid.UUID(client_id) if isinstance(client_id, str) else client_id

    result = await db.execute(
        select(
            BrochureChunk.project_id,
            BrochureChunk.project_name,
            func.count(BrochureChunk.id).label("chunk_count"),
            func.min(BrochureChunk.created_at).label("ingested_at"),
        )
        .where(BrochureChunk.client_id == client_uuid)
        .group_by(BrochureChunk.project_id, BrochureChunk.project_name)
    )

    projects = []
    for row in result.all():
        projects.append({
            "project_id": str(row.project_id),
            "project_name": row.project_name,
            "chunk_count": row.chunk_count,
            "ingested_at": row.ingested_at.isoformat() if row.ingested_at else None,
        })

    return projects
