"""
Project Q&A ingestion — store builder-provided Q&A pairs as `project_qa` chunks.

These are SHORT, FACTUAL question/answer pairs that the existing brochure RAG
search retrieves automatically (same embeddings, same pgvector table, same
client/project scope).

Typical Q&A topics the brochure rarely covers:
  - Demographics ("Is this a Hindu-majority area?")
  - Nearby schools / hospitals / temples / mosques / metro
  - OC/CC status, RERA registration details
  - Possession date, payment milestones, builder track record
  - Cleanliness / safety / parking ratio
  - Loan tie-ups, NRI buying rules, registration fee
  - Resale/rental potential

The builder fills the questionnaire once per project, the answers are
embedded, and the qualifier picks them up via the standard RAG search the
next time a lead asks about that topic.
"""
import logging
import uuid
from datetime import datetime

from sqlalchemy import delete, select, func
from sqlalchemy.ext.asyncio import AsyncSession

from src.db.tables import BrochureChunk
from src.rag.embedder import embed_texts

logger = logging.getLogger(__name__)

QA_CHUNK_TYPE = "project_qa"


def _format_qa_text(question: str, answer: str) -> str:
    """Embed-friendly Q&A format. Question is a hint, answer is the payload."""
    q = (question or "").strip().rstrip("?")
    a = (answer or "").strip()
    return f"Q: {q}?\nA: {a}"


async def ingest_qa_pairs(
    db: AsyncSession,
    client_id: str,
    project_id: str,
    project_name: str,
    qa_pairs: list[dict],
    replace_existing: bool = True,
) -> dict:
    """
    Ingest a batch of {question, answer} pairs as project_qa chunks.

    Args:
        qa_pairs: list of {"question": str, "answer": str, "category": str?}
        replace_existing: if True, delete any existing QA chunks for this
                          project before inserting (idempotent re-ingestion).

    Returns:
        {"ingested": int, "project_id": str}
    """
    client_uuid = uuid.UUID(client_id) if isinstance(client_id, str) else client_id
    project_uuid = uuid.UUID(project_id) if isinstance(project_id, str) else project_id

    # Filter out empty entries
    pairs = [
        p for p in qa_pairs
        if p.get("question", "").strip() and p.get("answer", "").strip()
    ]
    if not pairs:
        return {"ingested": 0, "project_id": str(project_uuid), "skipped": "empty"}

    if replace_existing:
        await db.execute(
            delete(BrochureChunk).where(
                BrochureChunk.client_id == client_uuid,
                BrochureChunk.project_id == project_uuid,
                BrochureChunk.chunk_type == QA_CHUNK_TYPE,
            )
        )

    texts = [_format_qa_text(p["question"], p["answer"]) for p in pairs]
    embeddings = await embed_texts(texts)

    chunks = []
    for i, p in enumerate(pairs):
        chunks.append(BrochureChunk(
            client_id=client_uuid,
            project_id=project_uuid,
            project_name=project_name,
            chunk_type=QA_CHUNK_TYPE,
            text=texts[i],
            embedding=embeddings[i] if i < len(embeddings) else None,
            page_number=None,
        ))

    db.add_all(chunks)
    await db.commit()

    logger.info(
        "[qa_ingest] Stored %d Q&A pairs for project %s (client=%s)",
        len(chunks), project_name, client_id,
    )
    return {"ingested": len(chunks), "project_id": str(project_uuid)}


async def list_qa_pairs(
    db: AsyncSession,
    client_id: str,
    project_id: str,
) -> list[dict]:
    """Return stored Q&A pairs for a project, parsed back into {q, a} form."""
    client_uuid = uuid.UUID(client_id) if isinstance(client_id, str) else client_id
    project_uuid = uuid.UUID(project_id) if isinstance(project_id, str) else project_id

    rows = (await db.execute(
        select(BrochureChunk.id, BrochureChunk.text, BrochureChunk.created_at)
        .where(
            BrochureChunk.client_id == client_uuid,
            BrochureChunk.project_id == project_uuid,
            BrochureChunk.chunk_type == QA_CHUNK_TYPE,
        )
        .order_by(BrochureChunk.created_at)
    )).all()

    pairs = []
    for row in rows:
        text = row[1] or ""
        # Format is "Q: ...?\nA: ..."
        q, a = "", text
        if text.startswith("Q:"):
            try:
                q_line, a_line = text.split("\nA:", 1)
                q = q_line[2:].strip().rstrip("?")
                a = a_line.strip()
            except ValueError:
                pass
        pairs.append({
            "id": str(row[0]),
            "question": q,
            "answer": a,
            "created_at": row[2].isoformat() if row[2] else None,
        })
    return pairs


async def delete_project_qa(
    db: AsyncSession,
    client_id: str,
    project_id: str,
) -> int:
    """Delete only the Q&A chunks for a project (leaves brochure chunks intact)."""
    client_uuid = uuid.UUID(client_id) if isinstance(client_id, str) else client_id
    project_uuid = uuid.UUID(project_id) if isinstance(project_id, str) else project_id

    result = await db.execute(
        delete(BrochureChunk).where(
            BrochureChunk.client_id == client_uuid,
            BrochureChunk.project_id == project_uuid,
            BrochureChunk.chunk_type == QA_CHUNK_TYPE,
        )
    )
    await db.commit()
    return result.rowcount
