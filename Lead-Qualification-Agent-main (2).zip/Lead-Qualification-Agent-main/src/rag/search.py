"""
pgvector similarity search for brochure RAG.

Called by the qualifier node when a lead asks about a specific project,
price, amenities, floor plans, or specifications.

Uses cosine similarity on 384-dim fastembed vectors.
Multi-tenant safe: always filters by client_id.
"""
import logging
from typing import Literal

from sqlalchemy import select, text as sa_text, cast, String
from sqlalchemy.ext.asyncio import AsyncSession
from pgvector.sqlalchemy import Vector

from src.db.tables import BrochureChunk
from src.rag.embedder import embed_query

logger = logging.getLogger(__name__)

ChunkType = Literal["pricing_table", "amenities", "location", "floor_plan", "specifications", "general", None]

# RAG trigger keywords — if user message contains these, do a search
RAG_TRIGGER_KEYWORDS = [
    "price", "cost", "rate", "how much", "kitna", "kimat", "budget",
    "ameniti", "pool", "gym", "club", "parking", "facilities",
    "floor plan", "bhk", "carpet", "sqft", "sq ft", "configuration",
    "location", "near", "distance", "metro", "highway",
    "specification", "fitting", "marble", "kitchen",
    "brochure", "details", "tell me about", "bata", "batao",
    # Q&A-driven topics (community, services, financials, possession)
    "school", "schools", "hospital", "college", "coaching",
    "mandir", "temple", "mosque", "masjid", "gurudwara", "church",
    "hindu", "muslim", "religion", "community", "demographic",
    "safe", "safety", "clean", "cleanly", "cleanliness", "pollution",
    "rera", "oc", "occupancy", "possession", "completion",
    "loan", "subvention", "nri", "emi", "downpayment", "down payment",
    "resale", "rental", "yield", "appreciation",
    "pet", "pets", "veg", "vegetarian", "ev charging",
]


def should_trigger_rag(user_text: str) -> bool:
    """
    Heuristic: should we do a RAG search for this message?
    True if the message asks about property details.
    """
    lower = user_text.lower()
    return any(kw in lower for kw in RAG_TRIGGER_KEYWORDS)


async def rag_search(
    db: AsyncSession,
    query: str,
    client_id: str,
    top_k: int = 3,
    chunk_type: ChunkType = None,
) -> list[str]:
    """
    Find the top-k most relevant brochure chunks for a query.

    Args:
        db: async DB session
        query: the lead's message / search query
        client_id: tenant isolation — only search this client's chunks
        top_k: number of chunks to return (default 3)
        chunk_type: optional filter by chunk type (e.g. "pricing_table")

    Returns:
        list of chunk text strings, ordered by relevance
    """
    # Check if there are any chunks for this client first
    count_result = await db.execute(
        select(BrochureChunk.id).where(
            BrochureChunk.client_id == client_id,
            BrochureChunk.embedding.isnot(None),
        ).limit(1)
    )
    if not count_result.scalars().first():
        logger.info("[rag_search] No brochure chunks found for client %s", client_id)
        return []

    # Embed the query
    query_vector = await embed_query(query)

    # Build pgvector cosine similarity query.
    # The <=> operator computes cosine distance (lower = more similar).
    #
    # We pass the vector as a proper bind parameter (:qvec) and cast it
    # inside the SQL using ::vector. To avoid SQLAlchemy/asyncpg confusion
    # with the :: cast, we use a raw text() query with explicit bindparams.
    # The vector is passed as a string literal '[f1,f2,...]' and cast server-side.
    vector_str = "[" + ",".join(str(round(float(v), 8)) for v in query_vector) + "]"

    where_clause = "client_id = :client_id AND embedding IS NOT NULL"
    params: dict = {"client_id": client_id, "top_k": top_k, "qvec": vector_str}

    if chunk_type:
        where_clause += " AND chunk_type = :chunk_type"
        params["chunk_type"] = chunk_type

    # Use cast(:qvec AS vector) instead of :qvec::vector to avoid
    # asyncpg's named-param → $N translation issue with :: syntax.
    sql = sa_text(f"""
        SELECT text, chunk_type, project_name,
               embedding <=> cast(:qvec AS vector) AS distance
        FROM brochure_chunks
        WHERE {where_clause}
        ORDER BY distance
        LIMIT :top_k
    """)

    result = await db.execute(sql, params)
    rows = result.fetchall()

    # Format chunks with project context for the LLM
    chunks = []
    for row in rows:
        chunk_text = row[0]          # text column
        c_type = row[1]              # chunk_type column
        proj_name = row[2]           # project_name column
        chunks.append(f"[{proj_name} - {c_type}]: {chunk_text}")

    logger.info("[rag_search] Found %d chunks for query: %.50s...", len(chunks), query)
    return chunks
