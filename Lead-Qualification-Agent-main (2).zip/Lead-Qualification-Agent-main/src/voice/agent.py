"""
Voice agent — outbound qualification calls, rebuilt on LiveKit Agents 1.x.

DESIGN DECISIONS (vs the previous implementation, which mixed 0.x and 1.x
APIs and could not import under the pinned SDK):

  - ONE SDK generation: livekit-agents 1.x only (AgentSession / JobContext /
    explicit agent dispatch). No `livekit.agents.pipeline`, no 0.x ChatChunk.
  - OFFICIAL plugins only — no hand-rolled STT/LLM/TTS adapters:
      STT: livekit-plugins-openai pointed at the SELF-HOSTED Whisper
           (OpenAI-compatible /v1/audio/transcriptions) — still zero-cost.
      LLM: livekit-plugins-anthropic (Claude Haiku — fast, cheap, good
           enough for a guided qualification call).
      TTS: livekit-plugins-openai (requires OPENAI_API_KEY). The old
           edge-tts adapter is parked until someone writes a maintained
           1.x adapter for it.
  - Lead stage is NEVER touched by voice ("calling"/"contacted" were not
    valid stages and froze leads). Call state lives in billing_events
    (event_type="voice_call"), transcripts live in messages.
  - AI discloses itself. Always.

RUNNING:
  Worker (must be running for calls to connect — otherwise leads dial
  into silence):   python -m src.voice.agent
  Dial-out is triggered via src/voice/outbound.py → initiate_outbound_call().
"""
import asyncio
import json
import logging
import uuid
from typing import Any

from src.config import get_settings

logger = logging.getLogger(__name__)

AGENT_NAME = "leadengine-voice"


# ═══════════════════════════════════════════════════════════════════════════
# Instructions
# ═══════════════════════════════════════════════════════════════════════════

def build_instructions(
    client_name: str,
    language: str,
    lead_name: str | None,
    lead_context: dict,
    awaiting_fields: list[str],
) -> str:
    lang_line = {
        "english": "Speak in clear, simple English.",
        "hindi": "Speak in Hindi.",
        "hinglish": "Speak in Hinglish — natural Hindi-English mix, like a friendly Indian sales call.",
    }.get(language, "Speak in clear, simple English.")

    known = ", ".join(f"{k}={v}" for k, v in lead_context.items()) or "nothing yet"
    missing = ", ".join(awaiting_fields) or "nothing — just confirm interest"

    return f"""You are {client_name}'s AI voice assistant making a follow-up call to a property lead{f' named {lead_name}' if lead_name else ''}.

What we already know: {known}
What we still need: {missing}

RULES:
1. {lang_line}
2. Introduce yourself as {client_name}'s virtual assistant in the first sentence. If asked whether you are an AI, answer honestly — never deny it.
3. Confirm you're speaking with the right person before anything else.
4. Keep every reply under 2 short sentences — this is a phone call, not an essay.
5. Ask about ONE missing field at a time, conversationally.
6. Never repeat information the lead already gave.
7. If the lead is busy or uninterested, apologize briefly, offer WhatsApp follow-up, and end the call.
8. If all fields are collected, thank them warmly and say the team will WhatsApp them site-visit options.
9. For detailed property questions (exact pricing, RERA, floor plans), say the team will share specifics on WhatsApp.
10. Never promise discounts, prices, or availability."""


# ═══════════════════════════════════════════════════════════════════════════
# Post-call persistence (transcript → messages, fields → lead)
# ═══════════════════════════════════════════════════════════════════════════

async def persist_call_outcome(
    client_id: str,
    lead_id: str,
    transcript: list[dict],
) -> None:
    """
    Store the call transcript as conversation messages (NOT in
    billing_events metadata — that leaked PII to the billing page), and
    extract any newly-learned qualification fields into the lead row.
    Never raises.
    """
    if not transcript:
        return
    try:
        from src.db.engine import AsyncSessionFactory
        from src.db.queries import get_or_create_conversation, save_message, update_lead

        async with AsyncSessionFactory() as db:
            conv = await get_or_create_conversation(db, client_id, lead_id, channel="voice")
            for item in transcript:
                role = item.get("role", "assistant")
                content = (item.get("content") or "").strip()
                if not content:
                    continue
                await save_message(
                    db, client_id, conv.id,
                    direction="inbound" if role == "user" else "outbound",
                    content=f"[voice] {content}",
                    message_type="text",
                )

            # Extract structured fields from what the LEAD said
            lead_said = " ".join(
                i.get("content", "") for i in transcript if i.get("role") == "user"
            ).strip()
            if lead_said:
                from src.engine.nodes.qualifier import EXTRACTION_TOOL_SCHEMA
                from src.engine.llm import extract_structured, load_prompt

                extraction = await asyncio.to_thread(
                    extract_structured,
                    load_prompt("qualifier_extract.txt"),
                    lead_said,
                    "extract_lead_info",
                    EXTRACTION_TOOL_SCHEMA,
                )
                confidence = float(extraction.pop("extracted_confidence", 0) or 0)
                if confidence > 0.5:
                    field_map = {
                        "budget_min": "budget_min", "budget_max": "budget_max",
                        "timeline_months": "timeline_months", "urgency": "urgency",
                        "locations": "location_preferences",
                        "property_type": "property_type",
                        "financing_status": "financing_status",
                        "family_size": "family_size",
                    }
                    updates = {
                        dest: extraction[src]
                        for src, dest in field_map.items()
                        if extraction.get(src) not in (None, [], "")
                    }
                    if updates:
                        # NOTE: deliberately no stage change — voice augments
                        # the lead, the text pipeline owns the state machine.
                        await update_lead(db, client_id, lead_id, updates)
                        logger.info(
                            "[voice] Updated lead %s with %d fields from call",
                            lead_id[:8], len(updates),
                        )
    except Exception as e:
        logger.error("[voice] Failed to persist call outcome for %s: %s", lead_id, e)


# ═══════════════════════════════════════════════════════════════════════════
# Dial-out (called by outbound.py from the API process)
# ═══════════════════════════════════════════════════════════════════════════

async def initiate_outbound_call(
    phone_number: str,
    lead_id: str,
    client_id: str,
    client_name: str,
    language: str = "english",
    lead_name: str | None = None,
    lead_context: dict | None = None,
    awaiting_fields: list[str] | None = None,
) -> dict[str, Any]:
    """
    Create a room, dispatch the voice agent into it, then dial the lead via
    the SIP trunk. The agent worker (python -m src.voice.agent) MUST be
    running — the dispatch is explicit, so if no worker is registered the
    dispatch fails fast instead of dialing a human into silence.
    """
    settings = get_settings()
    if not (settings.livekit_api_key and settings.livekit_api_secret and settings.sip_trunk_id):
        return {"status": "error", "reason": "livekit_or_sip_not_configured"}

    from livekit import api

    room_name = f"call-{lead_id[:8]}-{uuid.uuid4().hex[:8]}"
    metadata = json.dumps({
        "lead_id": lead_id,
        "client_id": client_id,
        "client_name": client_name,
        "language": language,
        "lead_name": lead_name,
        "lead_context": lead_context or {},
        "awaiting_fields": awaiting_fields or [],
        "phone": phone_number,
    })

    lkapi = api.LiveKitAPI(
        settings.livekit_url,
        settings.livekit_api_key,
        settings.livekit_api_secret,
    )
    try:
        # 1. Dispatch the agent — fails fast if no worker is registered
        await lkapi.agent_dispatch.create_dispatch(
            api.CreateAgentDispatchRequest(
                agent_name=AGENT_NAME,
                room=room_name,
                metadata=metadata,
            )
        )

        # 2. Dial the lead into the same room via the SIP trunk
        await lkapi.sip.create_sip_participant(
            api.CreateSIPParticipantRequest(
                sip_trunk_id=settings.sip_trunk_id,
                sip_call_to=phone_number,
                room_name=room_name,
                participant_identity=f"lead-{lead_id[:8]}",
                participant_name=lead_name or "Lead",
            )
        )
        logger.info("[voice] Dialing %s into room %s", phone_number, room_name)
        return {"status": "dialing", "room_name": room_name}
    except Exception as e:
        logger.error("[voice] Outbound call failed for %s: %s", phone_number, e)
        return {"status": "error", "reason": str(e), "room_name": room_name}
    finally:
        await lkapi.aclose()


# ═══════════════════════════════════════════════════════════════════════════
# Agent worker (separate process: python -m src.voice.agent)
# ═══════════════════════════════════════════════════════════════════════════

async def entrypoint(ctx) -> None:
    """LiveKit Agents 1.x job entrypoint — one job per outbound call."""
    from livekit.agents import Agent, AgentSession
    from livekit.plugins import anthropic as lk_anthropic
    from livekit.plugins import openai as lk_openai
    from livekit.plugins import silero

    settings = get_settings()
    meta = json.loads(ctx.job.metadata or "{}")
    client_id = meta.get("client_id", "")
    lead_id = meta.get("lead_id", "")

    transcript: list[dict] = []

    session = AgentSession(
        vad=silero.VAD.load(),
        # Self-hosted Whisper exposes the OpenAI-compatible endpoint —
        # use the official plugin against it (zero cost, no custom adapter).
        stt=lk_openai.STT(
            base_url=f"{settings.whisper_url}/v1",
            api_key=settings.openai_api_key or "not-needed-for-self-hosted",
            model="whisper-1",
            language={"hindi": "hi", "hinglish": "hi"}.get(meta.get("language", ""), "en"),
        ),
        llm=lk_anthropic.LLM(
            model="claude-haiku-4-5",
            api_key=settings.anthropic_api_key,
        ),
        tts=lk_openai.TTS(
            api_key=settings.openai_api_key,
            voice="alloy",
        ),
    )

    @session.on("conversation_item_added")
    def _on_item(ev):
        try:
            transcript.append({
                "role": getattr(ev.item, "role", "assistant"),
                "content": getattr(ev.item, "text_content", None) or "",
            })
        except Exception:
            pass

    async def _persist():
        await persist_call_outcome(client_id, lead_id, transcript)

    ctx.add_shutdown_callback(_persist)

    await session.start(
        room=ctx.room,
        agent=Agent(
            instructions=build_instructions(
                client_name=meta.get("client_name", "our team"),
                language=meta.get("language", "english"),
                lead_name=meta.get("lead_name"),
                lead_context=meta.get("lead_context", {}),
                awaiting_fields=meta.get("awaiting_fields", []),
            ),
        ),
    )
    await session.generate_reply(
        instructions="Greet the lead, introduce yourself as the virtual assistant, "
                     "and confirm you're speaking with the right person.",
    )


def main() -> None:
    """Run the voice agent worker. Required for outbound calls to connect."""
    from livekit.agents import WorkerOptions, cli

    settings = get_settings()
    logging.basicConfig(level=settings.log_level)
    if not settings.openai_api_key:
        logger.warning(
            "[voice] OPENAI_API_KEY not set — TTS will fail. "
            "Set it before enabling outbound calls."
        )
    cli.run_app(
        WorkerOptions(
            entrypoint_fnc=entrypoint,
            agent_name=AGENT_NAME,
            ws_url=settings.livekit_url,
            api_key=settings.livekit_api_key,
            api_secret=settings.livekit_api_secret,
        )
    )


if __name__ == "__main__":
    main()
