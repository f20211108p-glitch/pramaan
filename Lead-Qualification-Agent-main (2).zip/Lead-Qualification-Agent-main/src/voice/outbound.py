"""
Outbound call orchestrator — auto-calls leads who go silent on WhatsApp.

Trigger logic:
  1. Find leads with tier=warm or tier=hot
  2. Who have NOT responded on WhatsApp in X hours (configurable)
  3. Who have NOT been called already (or last call was >24h ago)
  4. Who have consent for communication
  5. Initiate outbound call via LiveKit SIP

This can be run:
  - As a periodic task (e.g., every 30 min via cron or scheduler)
  - Manually via admin API endpoint
  - As a background task triggered by the scorer when a lead goes warm/hot

Multi-tenant: each client has their own WABA credentials, SIP trunk config,
and follow-up delay setting.
"""
import asyncio
import logging
from datetime import datetime, timedelta, timezone

from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from sqlalchemy import and_

from src.config import get_settings
from src.db.engine import AsyncSessionFactory
from src.db.tables import Lead, Conversation, Message, ClientConfig, BillingEvent
from src.db.queries import write_billing_event
from src.voice.agent import initiate_outbound_call

logger = logging.getLogger(__name__)

# ── Call cooldown ────────────────────────────────────────────────────────────
CALL_COOLDOWN_HOURS = 24  # Don't call the same lead within this window


async def find_leads_to_call(
    db: AsyncSession,
    client_id: str,
    delay_hours: int | None = None,
    limit: int = 10,
) -> list[dict]:
    """
    Find leads eligible for outbound follow-up calls.

    Criteria:
      - tier is 'warm' or 'hot'
      - stage is NOT 'scheduled' or 'handed_off' (already converted)
      - last inbound message was > delay_hours ago (lead went silent)
      - lead has NOT been called in the last 24 hours
      - lead is active (not archived)

    Args:
        db: async database session
        client_id: tenant UUID
        delay_hours: hours of silence before calling (default from config)
        limit: max leads to return per batch

    Returns:
        list of dicts with lead info for calling
    """
    settings = get_settings()
    if delay_hours is None:
        delay_hours = settings.voice_followup_delay_hours

    cutoff_time = datetime.now(timezone.utc) - timedelta(hours=delay_hours)

    try:
        # Subquery: last inbound message time per lead
        last_inbound_sq = (
            select(
                Message.conversation_id,
                func.max(Message.timestamp).label("last_inbound_at"),
            )
            .where(
                Message.client_id == client_id,
                Message.direction == "inbound",
            )
            .group_by(Message.conversation_id)
            .subquery()
        )

        # Subquery: conversations linked to leads
        conv_sq = (
            select(
                Conversation.lead_id,
                func.max(last_inbound_sq.c.last_inbound_at).label("last_msg_at"),
            )
            .join(last_inbound_sq, Conversation.id == last_inbound_sq.c.conversation_id)
            .where(Conversation.client_id == client_id)
            .group_by(Conversation.lead_id)
            .subquery()
        )

        # Subquery: leads called within cooldown window
        cooldown_cutoff = datetime.now(timezone.utc) - timedelta(hours=CALL_COOLDOWN_HOURS)
        recently_called_sq = (
            select(BillingEvent.lead_id)
            .where(
                BillingEvent.client_id == client_id,
                BillingEvent.event_type == "voice_call",
                BillingEvent.created_at > cooldown_cutoff,
            )
            .distinct()
            .subquery()
        )

        # Consent: only call leads with a recorded data_collection consent.
        # The module's contract promises this; without the join it robocalls.
        from src.db.tables import ConsentLog
        consent_sq = (
            select(ConsentLog.lead_id)
            .where(
                ConsentLog.client_id == client_id,
                ConsentLog.consent_type == "data_collection",
            )
            .distinct()
            .subquery()
        )

        from sqlalchemy import case
        # Main query: eligible leads
        query = (
            select(Lead)
            .join(conv_sq, Lead.id == conv_sq.c.lead_id)
            .join(consent_sq, Lead.id == consent_sq.c.lead_id)
            .outerjoin(recently_called_sq, Lead.id == recently_called_sq.c.lead_id)
            .where(
                Lead.client_id == client_id,
                Lead.tier.in_(["warm", "hot"]),
                Lead.stage.notin_(["scheduled", "handed_off", "converted"]),
                conv_sq.c.last_msg_at < cutoff_time,
                recently_called_sq.c.lead_id.is_(None),  # Not called recently
            )
            .order_by(
                # Hot before warm — NOTE: tier is a string; .desc() would sort
                # 'warm' first lexicographically. Use an explicit rank.
                case((Lead.tier == "hot", 0), else_=1),
                # Then by score (highest first)
                Lead.score.desc(),
            )
            .limit(limit)
        )

        result = await db.execute(query)
        leads = result.scalars().all()

        return [
            {
                "lead_id": str(lead.id),
                "client_id": str(lead.client_id),
                "phone": lead.phone,
                "name": lead.name,
                "language_pref": lead.language_pref,
                "tier": lead.tier,
                "score": lead.score,
                "intent": lead.intent,
                "budget_min": lead.budget_min,
                "budget_max": lead.budget_max,
                "timeline_months": lead.timeline_months,
                "location_preferences": lead.location_preferences,
                "property_type": lead.property_type,
                "financing_status": lead.financing_status,
                "family_size": lead.family_size,
            }
            for lead in leads
        ]

    except Exception as e:
        logger.error("[outbound] Error finding leads to call: %s", e, exc_info=True)
        return []


async def _check_call_cooldown(db: AsyncSession, client_id: str, lead_id: str) -> bool:
    """
    Check if a lead was called within the cooldown window.
    Returns True if the lead is on cooldown (should NOT be called).
    """
    cooldown_cutoff = datetime.now(timezone.utc) - timedelta(hours=CALL_COOLDOWN_HOURS)
    result = await db.execute(
        select(BillingEvent.id)
        .where(
            and_(
                BillingEvent.client_id == client_id,
                BillingEvent.lead_id == lead_id,
                BillingEvent.event_type == "voice_call",
                BillingEvent.created_at > cooldown_cutoff,
            )
        )
        .limit(1)
    )
    return result.scalars().first() is not None


async def call_lead(
    lead: dict,
    client_name: str,
) -> dict:
    """
    Initiate an outbound call to a single lead.
    Persists call result as a billing event and updates lead stage.

    Args:
        lead: dict from find_leads_to_call()
        client_name: display name of the client (used in greeting)

    Returns:
        dict with call status
    """
    lead_id = lead["lead_id"]
    client_id = lead["client_id"]

    # Calling-hours guard — TRAI mandates 09:00–21:00 IST for commercial
    # calls in India. Never robocall a lead at 3 AM, regardless of how the
    # batch was triggered.
    ist = timezone(timedelta(hours=5, minutes=30))
    hour_ist = datetime.now(ist).hour
    if not (9 <= hour_ist < 21):
        logger.warning(
            "[outbound] Blocked call to lead %s — outside calling hours (%02d:00 IST)",
            lead_id[:8], hour_ist,
        )
        return {"status": "skipped", "reason": "outside_calling_hours", "lead_id": lead_id}

    # Check cooldown — don't call the same lead twice within 24h
    async with AsyncSessionFactory() as db:
        on_cooldown = await _check_call_cooldown(db, client_id, lead_id)
    if on_cooldown:
        logger.info("[outbound] Lead %s on cooldown, skipping", lead_id[:8])
        return {"status": "skipped", "reason": "cooldown", "lead_id": lead_id}

    # Determine which fields are still missing
    awaiting = []
    if not lead.get("budget_min") and not lead.get("budget_max"):
        awaiting.append("budget")
    if not lead.get("timeline_months"):
        awaiting.append("timeline")
    if not lead.get("location_preferences"):
        awaiting.append("location")
    if not lead.get("property_type") or lead["property_type"] == "any":
        awaiting.append("property_type")
    if not lead.get("financing_status") or lead["financing_status"] == "unknown":
        awaiting.append("financing")
    if not lead.get("family_size"):
        awaiting.append("family_size")

    result = await initiate_outbound_call(
        phone_number=lead["phone"],
        lead_id=lead_id,
        client_id=client_id,
        client_name=client_name,
        language=lead.get("language_pref", "english"),
        lead_name=lead.get("name"),
        lead_context={
            k: lead[k] for k in [
                "budget_min", "budget_max", "timeline_months",
                "location_preferences", "property_type",
                "financing_status", "family_size",
            ] if lead.get(k)
        },
        awaiting_fields=awaiting,
    )

    # Persist call attempt as billing event + update lead
    async with AsyncSessionFactory() as db:
        try:
            call_status = result.get("status", "unknown")
            await write_billing_event(
                db=db,
                client_id=client_id,
                lead_id=lead_id,
                event_type="voice_call",
                amount_inr=0,  # Demo — no billing yet
                metadata={
                    "call_status": call_status,
                    "room_name": result.get("room_name"),
                    "phone": lead.get("phone"),
                    "language": lead.get("language_pref"),
                    "awaiting_fields": awaiting,
                },
            )

            # NOTE: deliberately NO stage change. "calling" was never a
            # valid LeadStage — it froze leads out of crons and re-calls.
            # Call state is tracked via the voice_call billing event above
            # (which also drives the 24h cooldown).
        except Exception as e:
            logger.warning("[outbound] Failed to persist call result: %s", e)

    logger.info(
        "[outbound] Call result for lead %s: %s",
        lead_id[:8], result.get("status"),
    )
    return result


async def run_outbound_batch(
    client_id: str,
    client_name: str,
    delay_hours: int | None = None,
    max_calls: int = 5,
) -> list[dict]:
    """
    Run a batch of outbound calls for a client.

    Finds eligible leads and calls them one by one (with a short delay
    between calls to avoid overwhelming the SIP trunk).

    Args:
        client_id: tenant UUID
        client_name: display name
        delay_hours: override for silence threshold
        max_calls: max calls per batch (default 5)

    Returns:
        list of call results
    """
    results = []

    async with AsyncSessionFactory() as db:
        leads = await find_leads_to_call(
            db, client_id,
            delay_hours=delay_hours,
            limit=max_calls,
        )

    if not leads:
        logger.info("[outbound] No eligible leads to call for client %s", client_id[:8])
        return results

    logger.info("[outbound] Found %d leads to call for client %s", len(leads), client_id[:8])

    for lead in leads:
        result = await call_lead(lead, client_name)
        results.append(result)

        # Brief delay between calls (2s) to avoid SIP trunk overload
        if len(leads) > 1:
            await asyncio.sleep(2)

    return results


async def run_all_clients() -> dict[str, list[dict]]:
    """
    Run outbound batches for ALL active clients.

    This is the entry point for periodic/cron execution.
    Iterates through all active clients and runs a batch for each.
    """
    all_results = {}

    async with AsyncSessionFactory() as db:
        result = await db.execute(
            select(ClientConfig).where(ClientConfig.active.is_(True))
        )
        clients = result.scalars().all()

    for client in clients:
        client_id = str(client.id)
        client_name = client.client_name

        logger.info("[outbound] Running batch for client: %s (%s)", client_name, client_id[:8])
        results = await run_outbound_batch(client_id, client_name)
        if results:
            all_results[client_id] = results

    return all_results


# ── CLI entry point ──────────────────────────────────────────────────────

async def main():
    """Run outbound calls for all clients (CLI entry point)."""
    settings = get_settings()
    logging.basicConfig(
        level=settings.log_level,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    logger.info("[outbound] Starting outbound call batch...")
    results = await run_all_clients()

    total = sum(len(v) for v in results.values())
    logger.info("[outbound] Batch complete. %d calls initiated across %d clients.", total, len(results))


if __name__ == "__main__":
    asyncio.run(main())
