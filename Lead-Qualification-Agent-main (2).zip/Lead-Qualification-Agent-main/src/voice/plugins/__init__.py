"""LiveKit plugin adapters — Whisper STT, Edge-TTS, Claude LLM."""
