"""
Custom LiveKit LLM adapter wrapping Anthropic Claude for voice conversations.

Uses Claude Haiku for cost-effective real-time conversation (~₹0.02/turn).
Maintains a conversation history compatible with LiveKit's ChatContext.

Usage in VoicePipelineAgent:
    from src.voice.plugins.claude_llm import ClaudeLLM
    llm = ClaudeLLM()
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, AsyncIterator

import anthropic
from livekit.agents import llm, utils

logger = logging.getLogger(__name__)

HAIKU_MODEL = "claude-haiku-4-5-20251001"
SONNET_MODEL = "claude-sonnet-4-20250514"


@dataclass
class _ClaudeLLMOptions:
    model: str
    api_key: str
    temperature: float
    max_tokens: int


class ClaudeLLM(llm.LLM):
    """
    LiveKit LLM adapter for Anthropic Claude.

    Maps LiveKit's ChatContext (system + user/assistant messages) to
    Anthropic's messages API format.
    """

    def __init__(
        self,
        *,
        model: str = HAIKU_MODEL,
        api_key: str = "",
        temperature: float = 0.7,
        max_tokens: int = 256,
    ) -> None:
        super().__init__()
        if not api_key:
            from src.config import get_settings
            api_key = get_settings().anthropic_api_key

        self._opts = _ClaudeLLMOptions(
            model=model,
            api_key=api_key,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        self._client = anthropic.AsyncAnthropic(api_key=api_key)

    def chat(
        self,
        *,
        chat_ctx: llm.ChatContext,
        conn_options: llm.APIConnectOptions | None = None,
        fnc_ctx: llm.FunctionContext | None = None,
        temperature: float | None = None,
        n: int | None = None,
        parallel_tool_calls: bool | None = None,
    ) -> "ClaudeLLMStream":
        return ClaudeLLMStream(
            llm=self,
            chat_ctx=chat_ctx,
            opts=self._opts,
            temperature=temperature,
            conn_options=conn_options,
        )


class ClaudeLLMStream(llm.LLMStream):
    """Streams Claude responses into LiveKit's LLM output format."""

    def __init__(
        self,
        *,
        llm: ClaudeLLM,
        chat_ctx: llm.ChatContext,
        opts: _ClaudeLLMOptions,
        temperature: float | None = None,
        conn_options: llm.APIConnectOptions | None = None,
    ) -> None:
        super().__init__(
            llm=llm,
            chat_ctx=chat_ctx,
            conn_options=conn_options or llm.APIConnectOptions(),
            fnc_ctx=None,
        )
        self._opts = opts
        self._temperature = temperature or opts.temperature

    async def _run(self) -> None:
        """Call Claude API with streaming and push chunks."""
        system_prompt, messages = _chat_ctx_to_anthropic(self._chat_ctx)

        if not messages:
            # Need at least one user message for Anthropic API
            messages = [{"role": "user", "content": "Hello"}]

        try:
            stream = await self._llm._client.messages.create(
                model=self._opts.model,
                max_tokens=self._opts.max_tokens,
                temperature=self._temperature,
                system=system_prompt or "You are a helpful assistant.",
                messages=messages,
                stream=True,
            )

            request_id = utils.shortuuid()

            async for event in stream:
                if event.type == "content_block_delta":
                    delta = getattr(event.delta, "text", "")
                    if delta:
                        self._event_ch.send_nowait(
                            llm.ChatChunk(
                                request_id=request_id,
                                choices=[
                                    llm.Choice(
                                        delta=llm.ChoiceDelta(
                                            role="assistant",
                                            content=delta,
                                        ),
                                        index=0,
                                    )
                                ],
                            )
                        )

        except anthropic.APIError as e:
            logger.error("[claude_llm] API error: %s", e)
        except Exception as e:
            logger.error("[claude_llm] Unexpected error: %s", e, exc_info=True)


def _chat_ctx_to_anthropic(
    chat_ctx: llm.ChatContext,
) -> tuple[str | None, list[dict[str, str]]]:
    """
    Convert LiveKit ChatContext to Anthropic messages format.

    Returns (system_prompt, messages_list).
    Anthropic requires system prompt separate from messages,
    and messages must alternate user/assistant.
    """
    system_prompt = None
    messages: list[dict[str, str]] = []

    for msg in chat_ctx.items:
        role = msg.role

        # Extract text content
        text = ""
        if isinstance(msg.content, str):
            text = msg.content
        elif isinstance(msg.content, list):
            text = " ".join(
                c.get("text", "") if isinstance(c, dict) else str(c)
                for c in msg.content
            )

        if not text:
            continue

        if role == "system":
            system_prompt = text
        elif role == "user":
            messages.append({"role": "user", "content": text})
        elif role == "assistant":
            messages.append({"role": "assistant", "content": text})

    # Anthropic requires alternating user/assistant — merge consecutive same-role
    merged: list[dict[str, str]] = []
    for m in messages:
        if merged and merged[-1]["role"] == m["role"]:
            merged[-1]["content"] += "\n" + m["content"]
        else:
            merged.append(m)

    # Must start with user message
    if merged and merged[0]["role"] == "assistant":
        merged.insert(0, {"role": "user", "content": "Hello"})

    return system_prompt, merged
