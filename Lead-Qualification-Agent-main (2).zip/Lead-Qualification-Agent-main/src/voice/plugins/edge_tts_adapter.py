"""
Custom LiveKit TTS adapter wrapping Microsoft Edge-TTS (free, no API key).

Supports Indian voices: Hindi, English, Marathi, Gujarati, Tamil, Telugu, etc.
Uses the `edge-tts` library to stream audio chunks.

Usage in VoicePipelineAgent:
    from src.voice.plugins.edge_tts_adapter import EdgeTTSAdapter
    tts = EdgeTTSAdapter(voice="hi-IN-SwaraNeural")
"""
from __future__ import annotations

import asyncio
import io
import logging
from dataclasses import dataclass
from typing import AsyncIterator

import edge_tts
from livekit.agents import tts, utils

logger = logging.getLogger(__name__)

# Voice catalogue for Indian real estate use case
INDIAN_VOICES = {
    # Female voices
    "hi-IN-SwaraNeural": "Hindi Female",
    "en-IN-NeerjaNeural": "English (India) Female",
    "mr-IN-AarohiNeural": "Marathi Female",
    "gu-IN-DhwaniNeural": "Gujarati Female",
    "ta-IN-PallaviNeural": "Tamil Female",
    "te-IN-ShrutiNeural": "Telugu Female",
    "kn-IN-SapnaNeural": "Kannada Female",
    "bn-IN-TanishaaNeural": "Bengali Female",
    # Male voices
    "hi-IN-MadhurNeural": "Hindi Male",
    "en-IN-PrabhatNeural": "English (India) Male",
    "mr-IN-ManoharNeural": "Marathi Male",
    "gu-IN-NiranjanNeural": "Gujarati Male",
}


@dataclass
class _EdgeTTSOptions:
    voice: str
    rate: str      # e.g., "+0%", "-10%", "+20%"
    volume: str    # e.g., "+0%", "-10%"
    pitch: str     # e.g., "+0Hz", "-5Hz"


class EdgeTTSAdapter(tts.TTS):
    """
    Non-streaming TTS using Microsoft Edge-TTS (free neural voices).

    Generates complete audio per utterance. For VoicePipelineAgent,
    this is fine — the agent buffers each TTS response anyway.
    """

    def __init__(
        self,
        *,
        voice: str = "hi-IN-SwaraNeural",
        rate: str = "+0%",
        volume: str = "+0%",
        pitch: str = "+0Hz",
        sample_rate: int = 24000,
    ) -> None:
        super().__init__(
            capabilities=tts.TTSCapabilities(streaming=False),
            sample_rate=sample_rate,
            num_channels=1,
        )
        self._opts = _EdgeTTSOptions(
            voice=voice,
            rate=rate,
            volume=volume,
            pitch=pitch,
        )

    def update_options(self, *, voice: str | None = None, rate: str | None = None) -> None:
        if voice is not None:
            self._opts.voice = voice
        if rate is not None:
            self._opts.rate = rate

    def synthesize(self, text: str, *, conn_options: tts.APIConnectOptions | None = None) -> "EdgeTTSChunkedStream":
        return EdgeTTSChunkedStream(
            tts=self,
            text=text,
            opts=self._opts,
            conn_options=conn_options,
        )


class EdgeTTSChunkedStream(tts.ChunkedStream):
    """Generates audio from edge-tts and yields as LiveKit audio frames."""

    def __init__(
        self,
        *,
        tts: EdgeTTSAdapter,
        text: str,
        opts: _EdgeTTSOptions,
        conn_options: tts.APIConnectOptions | None = None,
    ) -> None:
        super().__init__(tts=tts, input_text=text, conn_options=conn_options or tts.APIConnectOptions())
        self._opts = opts

    async def _run(self) -> None:
        """Generate TTS audio and push frames to the output queue."""
        try:
            communicate = edge_tts.Communicate(
                text=self._input_text,
                voice=self._opts.voice,
                rate=self._opts.rate,
                volume=self._opts.volume,
                pitch=self._opts.pitch,
            )

            # Collect MP3 chunks from edge-tts
            mp3_data = io.BytesIO()
            async for chunk in communicate.stream():
                if chunk["type"] == "audio":
                    mp3_data.write(chunk["data"])

            mp3_bytes = mp3_data.getvalue()
            if not mp3_bytes:
                logger.warning("[edge_tts] No audio generated for: %s", self._input_text[:50])
                return

            # Decode MP3 to raw PCM using the utils decoder
            pcm_frames = _decode_mp3_to_frames(mp3_bytes, sample_rate=self._tts_instance.sample_rate)
            if pcm_frames:
                self._event_ch.send_nowait(
                    tts.SynthesizedAudio(
                        request_id=utils.shortuuid(),
                        frame=pcm_frames,
                    )
                )

        except Exception as e:
            logger.error("[edge_tts] Synthesis failed: %s", e, exc_info=True)

    @property
    def _tts_instance(self) -> EdgeTTSAdapter:
        return self._tts  # type: ignore[return-value]


def _decode_mp3_to_frames(
    mp3_bytes: bytes,
    sample_rate: int = 24000,
) -> utils.AudioFrame | None:
    """
    Decode MP3 to a raw AudioFrame.

    Uses pydub (which wraps ffmpeg) for reliable MP3 decoding.
    Falls back to raw passthrough if pydub is unavailable.
    """
    try:
        from pydub import AudioSegment

        audio = AudioSegment.from_mp3(io.BytesIO(mp3_bytes))
        audio = audio.set_frame_rate(sample_rate).set_channels(1).set_sample_width(2)

        return utils.AudioFrame(
            data=audio.raw_data,
            sample_rate=sample_rate,
            num_channels=1,
            samples_per_channel=len(audio.raw_data) // 2,
        )
    except ImportError:
        logger.warning("[edge_tts] pydub not available — install pydub + ffmpeg for MP3 decoding")
        return None
    except Exception as e:
        logger.error("[edge_tts] MP3 decode failed: %s", e)
        return None
