"""
Custom LiveKit STT adapter wrapping self-hosted Whisper.

Since Whisper is a batch (non-streaming) model, we use LiveKit's
StreamAdapter + Silero VAD to get real-time turn detection.

Usage in VoicePipelineAgent:
    from src.voice.plugins.whisper_stt import WhisperSTT
    stt = WhisperSTT(whisper_url="http://localhost:9000")
"""
from __future__ import annotations

import io
import logging
from dataclasses import dataclass

import httpx
from livekit.agents import stt, utils

logger = logging.getLogger(__name__)


@dataclass
class _WhisperSTTOptions:
    whisper_url: str
    language: str | None
    prompt: str | None
    timeout: float


class WhisperSTT(stt.STT):
    """
    Non-streaming STT that POSTs audio to a self-hosted Whisper endpoint.

    Compatible with faster-whisper-server, whisper.cpp server, or
    any OpenAI-compatible /v1/audio/transcriptions endpoint.

    Wrap with `stt.StreamAdapter(this, vad)` for real-time use in
    VoicePipelineAgent.
    """

    def __init__(
        self,
        *,
        whisper_url: str = "http://localhost:9000",
        language: str | None = None,
        prompt: str | None = None,
        timeout: float = 30.0,
    ) -> None:
        super().__init__(
            capabilities=stt.STTCapabilities(streaming=False, interim_results=False),
        )
        self._opts = _WhisperSTTOptions(
            whisper_url=whisper_url.rstrip("/"),
            language=language,
            prompt=prompt,
            timeout=timeout,
        )

    def update_options(self, *, language: str | None = None, prompt: str | None = None) -> None:
        if language is not None:
            self._opts.language = language
        if prompt is not None:
            self._opts.prompt = prompt

    async def _recognize_impl(
        self,
        buffer: utils.AudioBuffer,
        *,
        language: str | None = None,
    ) -> stt.SpeechEvent:
        """
        Transcribe audio via self-hosted Whisper.

        Args:
            buffer: PCM audio buffer from LiveKit
            language: ISO 639-1 hint (e.g., "hi", "en")

        Returns:
            SpeechEvent with FINAL_TRANSCRIPT
        """
        # Encode PCM buffer to WAV bytes for Whisper
        frame = utils.merge_frames(buffer)
        wav_bytes = _pcm_to_wav(
            frame.data.tobytes(),
            sample_rate=frame.sample_rate,
            num_channels=frame.num_channels,
        )

        lang = language or self._opts.language

        # Build multipart form for the OpenAI-compatible endpoint
        data: dict[str, str] = {
            "model": "whisper-1",
            "response_format": "verbose_json",
        }
        if lang:
            data["language"] = lang
        if self._opts.prompt:
            data["prompt"] = self._opts.prompt

        files = {"file": ("audio.wav", wav_bytes, "audio/wav")}

        try:
            async with httpx.AsyncClient(timeout=self._opts.timeout) as client:
                resp = await client.post(
                    f"{self._opts.whisper_url}/v1/audio/transcriptions",
                    data=data,
                    files=files,
                )
                resp.raise_for_status()
                result = resp.json()

            text = result.get("text", "").strip()
            detected_lang = result.get("language", lang or "en")
            confidence = 0.0

            # Extract confidence from segments if available
            segments = result.get("segments", [])
            if segments:
                avg_logprob = sum(s.get("avg_log_prob", s.get("avg_logprob", -1.0)) for s in segments) / len(segments)
                # Convert log probability to 0-1 confidence
                import math
                confidence = min(1.0, max(0.0, math.exp(avg_logprob)))

            if not text:
                return _empty_event()

            return stt.SpeechEvent(
                type=stt.SpeechEventType.FINAL_TRANSCRIPT,
                alternatives=[
                    stt.SpeechData(
                        language=detected_lang,
                        text=text,
                        confidence=confidence,
                    )
                ],
            )

        except httpx.TimeoutException:
            logger.warning("[whisper_stt] Transcription timed out (%.0fs)", self._opts.timeout)
            return _empty_event()
        except Exception as e:
            logger.error("[whisper_stt] Transcription failed: %s", e)
            return _empty_event()


def _empty_event() -> stt.SpeechEvent:
    return stt.SpeechEvent(
        type=stt.SpeechEventType.FINAL_TRANSCRIPT,
        alternatives=[stt.SpeechData(language="", text="", confidence=0.0)],
    )


def _pcm_to_wav(pcm: bytes, sample_rate: int, num_channels: int) -> bytes:
    """Convert raw PCM bytes to a WAV file in memory."""
    import struct

    bits_per_sample = 16
    byte_rate = sample_rate * num_channels * bits_per_sample // 8
    block_align = num_channels * bits_per_sample // 8
    data_size = len(pcm)

    buf = io.BytesIO()
    # RIFF header
    buf.write(b"RIFF")
    buf.write(struct.pack("<I", 36 + data_size))
    buf.write(b"WAVE")
    # fmt chunk
    buf.write(b"fmt ")
    buf.write(struct.pack("<I", 16))  # chunk size
    buf.write(struct.pack("<H", 1))   # PCM format
    buf.write(struct.pack("<H", num_channels))
    buf.write(struct.pack("<I", sample_rate))
    buf.write(struct.pack("<I", byte_rate))
    buf.write(struct.pack("<H", block_align))
    buf.write(struct.pack("<H", bits_per_sample))
    # data chunk
    buf.write(b"data")
    buf.write(struct.pack("<I", data_size))
    buf.write(pcm)

    return buf.getvalue()
