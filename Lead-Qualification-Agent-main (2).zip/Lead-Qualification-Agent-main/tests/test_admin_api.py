"""
Tests for Admin API endpoints — Chunk 7A.

Uses FastAPI dependency override to inject the test DB session.
Covers: clients CRUD, leads list/get/update, conversations, billing, stats.
"""
import uuid
import pytest
import pytest_asyncio
from datetime import datetime

from httpx import AsyncClient, ASGITransport
from sqlalchemy.ext.asyncio import AsyncSession

from src.db.tables import ClientConfig, Lead, Conversation, Message, BillingEvent
from src.db.engine import get_db
from src.main import app


# ── Fixture: override get_db to use test session ─────────────────────────────

@pytest_asyncio.fixture
async def client(db: AsyncSession):
    """
    httpx AsyncClient with FastAPI's get_db overridden to use the test DB session.
    This ensures seeded test data is visible to the API endpoints.
    """
    async def _override_get_db():
        yield db

    app.dependency_overrides[get_db] = _override_get_db
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c
    app.dependency_overrides.clear()


@pytest.fixture
def admin_headers():
    from src.config import get_settings
    return {"x-admin-key": get_settings().secret_key}


# ── Helpers ──────────────────────────────────────────────────────────────────

def _make_client(**kwargs) -> ClientConfig:
    defaults = dict(
        client_name="Test Builder",
        waba_number=f"91{uuid.uuid4().hex[:10]}",
        waba_phone_number_id=f"WABA_{uuid.uuid4().hex[:8]}",
        waba_token="test_token",
        broker_wa_numbers=["+919820099001"],
        active=True,
    )
    defaults.update(kwargs)
    return ClientConfig(**defaults)


async def _seed_lead(db: AsyncSession, client_id, phone: str, **kwargs) -> Lead:
    defaults = dict(
        client_id=client_id, phone=phone, name="Test Lead",
        intent="buyer", stage="qualifying", tier="warm", score=55,
        language_pref="english", urgency="unknown",
        financing_status="unknown", property_type="apartment",
    )
    defaults.update(kwargs)
    lead = Lead(**defaults)
    db.add(lead)
    await db.flush()
    return lead


async def _seed_conversation(db: AsyncSession, client_id, lead_id) -> Conversation:
    conv = Conversation(client_id=client_id, lead_id=lead_id)
    db.add(conv)
    await db.flush()
    return conv


async def _seed_message(db, client_id, conversation_id, direction="inbound", content="Hello") -> Message:
    msg = Message(
        client_id=client_id, conversation_id=conversation_id,
        direction=direction, content=content, message_type="text",
        timestamp=datetime.utcnow(),
    )
    db.add(msg)
    await db.flush()
    return msg


async def _seed_billing(db, client_id, lead_id) -> BillingEvent:
    event = BillingEvent(
        client_id=client_id, lead_id=lead_id,
        event_type="qualified_lead",
        extra_data={"score": 85, "tier": "hot"},
    )
    db.add(event)
    await db.flush()
    return event


# ═══════════════════════════════════════════════════════════════════════════════
# AUTH TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestAdminAuth:
    @pytest.mark.asyncio
    async def test_missing_credentials_returns_403(self, client):
        resp = await client.get("/admin/clients")
        assert resp.status_code == 403

    @pytest.mark.asyncio
    async def test_wrong_admin_key_returns_403(self, client):
        resp = await client.get("/admin/clients", headers={"x-admin-key": "wrong"})
        assert resp.status_code == 403


# ═══════════════════════════════════════════════════════════════════════════════
# CLIENT ENDPOINTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestClientEndpoints:
    @pytest.mark.asyncio
    async def test_create_client(self, client, admin_headers):
        resp = await client.post("/admin/clients", headers=admin_headers, json={
            "client_name": "New Builder",
            "waba_number": f"91{uuid.uuid4().hex[:10]}",
            "waba_phone_number_id": f"WABA_{uuid.uuid4().hex[:8]}",
            "waba_token": "tok_123",
            "broker_wa_numbers": ["+919820099001"],
        })
        assert resp.status_code == 201
        data = resp.json()
        assert data["client_name"] == "New Builder"
        assert "id" in data

    @pytest.mark.asyncio
    async def test_list_clients(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        resp = await client.get("/admin/clients", headers=admin_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert "clients" in data
        assert len(data["clients"]) >= 1

    @pytest.mark.asyncio
    async def test_get_client_not_found(self, client, admin_headers):
        fake_id = str(uuid.uuid4())
        resp = await client.get(f"/admin/clients/{fake_id}", headers=admin_headers)
        assert resp.status_code == 404

    @pytest.mark.asyncio
    async def test_get_client_by_id(self, client, admin_headers, db):
        c = _make_client(client_name="Lookup Builder")
        db.add(c)
        await db.flush()

        resp = await client.get(f"/admin/clients/{c.id}", headers=admin_headers)
        assert resp.status_code == 200
        assert resp.json()["client_name"] == "Lookup Builder"

    @pytest.mark.asyncio
    async def test_update_client(self, client, admin_headers, db):
        c = _make_client(client_name="Old Name")
        db.add(c)
        await db.flush()

        resp = await client.patch(
            f"/admin/clients/{c.id}", headers=admin_headers,
            json={"client_name": "New Name"},
        )
        assert resp.status_code == 200
        assert resp.json()["client_name"] == "New Name"

    @pytest.mark.asyncio
    async def test_update_client_empty_body(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        resp = await client.patch(
            f"/admin/clients/{c.id}", headers=admin_headers, json={},
        )
        assert resp.status_code == 400


# ═══════════════════════════════════════════════════════════════════════════════
# LEAD ENDPOINTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestLeadEndpoints:
    @pytest.mark.asyncio
    async def test_list_leads(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        await _seed_lead(db, c.id, phone="+911111100001", tier="hot", score=85)
        await _seed_lead(db, c.id, phone="+911111100002", tier="warm", score=50)

        resp = await client.get(f"/admin/clients/{c.id}/leads", headers=admin_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 2
        assert len(data["leads"]) == 2

    @pytest.mark.asyncio
    async def test_list_leads_filter_by_tier(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        await _seed_lead(db, c.id, phone="+912222200001", tier="hot", score=85)
        await _seed_lead(db, c.id, phone="+912222200002", tier="cold", score=10)

        resp = await client.get(
            f"/admin/clients/{c.id}/leads?tier=hot", headers=admin_headers,
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 1
        assert data["leads"][0]["tier"] == "hot"

    @pytest.mark.asyncio
    async def test_list_leads_search_by_phone(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        await _seed_lead(db, c.id, phone="+913333300001", name="Alpha")
        await _seed_lead(db, c.id, phone="+913333300002", name="Beta")

        resp = await client.get(
            f"/admin/clients/{c.id}/leads?search=00001", headers=admin_headers,
        )
        assert resp.status_code == 200
        assert resp.json()["total"] == 1

    @pytest.mark.asyncio
    async def test_get_lead_detail(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        lead = await _seed_lead(db, c.id, phone="+914444400001", name="Detail Lead")

        resp = await client.get(
            f"/admin/clients/{c.id}/leads/{lead.id}", headers=admin_headers,
        )
        assert resp.status_code == 200
        assert resp.json()["name"] == "Detail Lead"

    @pytest.mark.asyncio
    async def test_get_lead_not_found(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        fake_id = str(uuid.uuid4())
        resp = await client.get(
            f"/admin/clients/{c.id}/leads/{fake_id}", headers=admin_headers,
        )
        assert resp.status_code == 404

    @pytest.mark.asyncio
    async def test_update_lead_stage(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        lead = await _seed_lead(db, c.id, phone="+915555500001", stage="qualifying")

        resp = await client.patch(
            f"/admin/clients/{c.id}/leads/{lead.id}", headers=admin_headers,
            json={"stage": "handed_off"},
        )
        assert resp.status_code == 200
        assert resp.json()["stage"] == "handed_off"

    @pytest.mark.asyncio
    async def test_multi_tenant_isolation(self, client, admin_headers, db):
        """Leads from client A must NOT appear in client B's list."""
        c1 = _make_client(client_name="Client A")
        c2 = _make_client(client_name="Client B")
        db.add_all([c1, c2])
        await db.flush()

        await _seed_lead(db, c1.id, phone="+916666600001")
        await _seed_lead(db, c2.id, phone="+916666600002")

        resp1 = await client.get(f"/admin/clients/{c1.id}/leads", headers=admin_headers)
        resp2 = await client.get(f"/admin/clients/{c2.id}/leads", headers=admin_headers)

        assert resp1.json()["total"] == 1
        assert resp2.json()["total"] == 1
        assert resp1.json()["leads"][0]["phone"] != resp2.json()["leads"][0]["phone"]


# ═══════════════════════════════════════════════════════════════════════════════
# CONVERSATION + MESSAGE ENDPOINTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestConversationEndpoints:
    @pytest.mark.asyncio
    async def test_list_conversations_for_lead(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        lead = await _seed_lead(db, c.id, phone="+917777700001")
        await _seed_conversation(db, c.id, lead.id)

        resp = await client.get(
            f"/admin/clients/{c.id}/leads/{lead.id}/conversations",
            headers=admin_headers,
        )
        assert resp.status_code == 200
        assert len(resp.json()["conversations"]) == 1

    @pytest.mark.asyncio
    async def test_get_messages(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        lead = await _seed_lead(db, c.id, phone="+918888800001")
        conv = await _seed_conversation(db, c.id, lead.id)
        await _seed_message(db, c.id, conv.id, "inbound", "Hi there")
        await _seed_message(db, c.id, conv.id, "outbound", "Welcome!")

        resp = await client.get(
            f"/admin/clients/{c.id}/conversations/{conv.id}/messages",
            headers=admin_headers,
        )
        assert resp.status_code == 200
        data = resp.json()
        assert len(data["messages"]) == 2
        assert data["messages"][0]["direction"] == "inbound"
        assert data["messages"][1]["direction"] == "outbound"


# ═══════════════════════════════════════════════════════════════════════════════
# BILLING ENDPOINTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestBillingEndpoints:
    @pytest.mark.asyncio
    async def test_list_billing_events(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        lead = await _seed_lead(db, c.id, phone="+919999900001")
        await _seed_billing(db, c.id, lead.id)

        resp = await client.get(
            f"/admin/clients/{c.id}/billing", headers=admin_headers,
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] >= 1
        assert data["events"][0]["event_type"] == "qualified_lead"

    @pytest.mark.asyncio
    async def test_billing_pagination(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        lead = await _seed_lead(db, c.id, phone="+919999900002")
        for _ in range(3):
            await _seed_billing(db, c.id, lead.id)

        resp = await client.get(
            f"/admin/clients/{c.id}/billing?limit=2&offset=0",
            headers=admin_headers,
        )
        data = resp.json()
        assert data["total"] == 3
        assert len(data["events"]) == 2


# ═══════════════════════════════════════════════════════════════════════════════
# STATS ENDPOINT
# ═══════════════════════════════════════════════════════════════════════════════

class TestStatsEndpoint:
    @pytest.mark.asyncio
    async def test_pipeline_stats(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        await _seed_lead(db, c.id, phone="+910000000001", tier="hot", stage="scheduling", score=85)
        await _seed_lead(db, c.id, phone="+910000000002", tier="warm", stage="qualifying", score=50)
        await _seed_lead(db, c.id, phone="+910000000003", tier="cold", stage="handed_off", score=15)

        lead = await _seed_lead(db, c.id, phone="+910000000004", tier="warm", stage="nurturing")
        conv = await _seed_conversation(db, c.id, lead.id)
        await _seed_message(db, c.id, conv.id, "inbound", "Hi")
        await _seed_message(db, c.id, conv.id, "outbound", "Hello!")

        resp = await client.get(
            f"/admin/clients/{c.id}/stats", headers=admin_headers,
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["total_leads"] == 4
        assert data["by_tier"]["hot"] == 1
        assert data["by_tier"]["warm"] == 2
        assert data["by_tier"]["cold"] == 1
        assert data["total_conversations"] == 1
        assert data["total_messages"] == 2

    @pytest.mark.asyncio
    async def test_stats_empty_client(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        resp = await client.get(
            f"/admin/clients/{c.id}/stats", headers=admin_headers,
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["total_leads"] == 0
        assert data["by_tier"] == {}
        assert data["by_stage"] == {}
