"""
Tests for auth API — login, JWT validation, user creation, role-based access.

ALL tests use mocked DB — no real database or LLM calls.
"""
import uuid
import pytest
from unittest.mock import patch, AsyncMock, MagicMock
from datetime import datetime

from jose import jwt


# ── Helpers ────────────────────────────────────────────────────────────────

def _make_user(
    role="admin",
    client_id=None,
    email="admin@getpramaan.com",
    name="Test Admin",
    password_hash="$2b$12$fakehash",
    active=True,
):
    """Create a mock User ORM object."""
    user = MagicMock()
    user.id = uuid.uuid4()
    user.email = email
    user.name = name
    user.role = role
    user.client_id = client_id
    user.password_hash = password_hash
    user.active = active
    user.created_at = datetime(2026, 1, 1)
    user.updated_at = datetime(2026, 1, 1)
    return user


# ═══════════════════════════════════════════════════════════════════════════════
# LOGIN TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestLogin:
    """Test POST /auth/login endpoint."""

    @pytest.mark.asyncio
    async def test_login_success_returns_token(self):
        """Valid credentials return JWT token + user info."""
        from src.api.auth import router, pwd_context
        from fastapi import FastAPI
        from httpx import AsyncClient, ASGITransport

        app = FastAPI()
        app.include_router(router)

        mock_user = _make_user(
            email="admin@getpramaan.com",
            password_hash=pwd_context.hash("pramaan2026"),
        )

        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = mock_user

        mock_db = AsyncMock()
        mock_db.execute = AsyncMock(return_value=mock_result)

        with patch("src.api.auth.get_db", return_value=mock_db):
            # Override get_db dependency
            from src.db.engine import get_db
            app.dependency_overrides[get_db] = lambda: mock_db

            async with AsyncClient(
                transport=ASGITransport(app=app),
                base_url="http://test",
            ) as client:
                resp = await client.post("/auth/login", json={
                    "email": "admin@getpramaan.com",
                    "password": "pramaan2026",
                })

        assert resp.status_code == 200
        data = resp.json()
        assert "access_token" in data
        assert data["token_type"] == "bearer"
        assert data["user"]["email"] == "admin@getpramaan.com"
        assert data["user"]["role"] == "admin"

    @pytest.mark.asyncio
    async def test_login_wrong_password_returns_401(self):
        """Wrong password returns 401."""
        from src.api.auth import router, pwd_context
        from fastapi import FastAPI
        from httpx import AsyncClient, ASGITransport

        app = FastAPI()
        app.include_router(router)

        mock_user = _make_user(
            password_hash=pwd_context.hash("correct_password"),
        )

        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = mock_user

        mock_db = AsyncMock()
        mock_db.execute = AsyncMock(return_value=mock_result)

        from src.db.engine import get_db
        app.dependency_overrides[get_db] = lambda: mock_db

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.post("/auth/login", json={
                "email": "admin@getpramaan.com",
                "password": "wrong_password",
            })

        assert resp.status_code == 401

    @pytest.mark.asyncio
    async def test_login_nonexistent_email_returns_401(self):
        """Non-existent email returns 401."""
        from src.api.auth import router
        from fastapi import FastAPI
        from httpx import AsyncClient, ASGITransport

        app = FastAPI()
        app.include_router(router)

        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = None

        mock_db = AsyncMock()
        mock_db.execute = AsyncMock(return_value=mock_result)

        from src.db.engine import get_db
        app.dependency_overrides[get_db] = lambda: mock_db

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.post("/auth/login", json={
                "email": "nobody@test.com",
                "password": "anything",
            })

        assert resp.status_code == 401

    @pytest.mark.asyncio
    async def test_login_inactive_user_returns_403(self):
        """Inactive user returns 403."""
        from src.api.auth import router, pwd_context
        from fastapi import FastAPI
        from httpx import AsyncClient, ASGITransport

        app = FastAPI()
        app.include_router(router)

        mock_user = _make_user(
            password_hash=pwd_context.hash("pass123"),
            active=False,
        )

        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = mock_user

        mock_db = AsyncMock()
        mock_db.execute = AsyncMock(return_value=mock_result)

        from src.db.engine import get_db
        app.dependency_overrides[get_db] = lambda: mock_db

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.post("/auth/login", json={
                "email": "admin@getpramaan.com",
                "password": "pass123",
            })

        assert resp.status_code == 403


# ═══════════════════════════════════════════════════════════════════════════════
# JWT VALIDATION TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestJWT:
    """Test JWT token creation and validation."""

    def test_create_token_is_decodable(self):
        """Created token can be decoded with the secret key."""
        from src.api.auth import _create_access_token
        from src.config import get_settings

        settings = get_settings()
        token = _create_access_token({"sub": "user-123", "role": "admin"})

        payload = jwt.decode(token, settings.secret_key, algorithms=["HS256"])
        assert payload["sub"] == "user-123"
        assert payload["role"] == "admin"
        assert "exp" in payload

    def test_token_contains_expiry(self):
        """Token has expiration claim."""
        from src.api.auth import _create_access_token
        from src.config import get_settings

        settings = get_settings()
        token = _create_access_token({"sub": "user-456"})
        payload = jwt.decode(token, settings.secret_key, algorithms=["HS256"])
        assert "exp" in payload

    @pytest.mark.asyncio
    async def test_get_me_with_valid_token(self):
        """GET /auth/me with valid token returns user info."""
        from src.api.auth import router, _create_access_token
        from fastapi import FastAPI
        from httpx import AsyncClient, ASGITransport

        app = FastAPI()
        app.include_router(router)

        user = _make_user()
        token = _create_access_token({"sub": str(user.id), "role": "admin"})

        # First call: get user by ID, Second call: get client name
        mock_result_user = MagicMock()
        mock_result_user.scalar_one_or_none.return_value = user

        mock_db = AsyncMock()
        mock_db.execute = AsyncMock(return_value=mock_result_user)

        from src.db.engine import get_db
        app.dependency_overrides[get_db] = lambda: mock_db

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.get("/auth/me", headers={
                "Authorization": f"Bearer {token}",
            })

        assert resp.status_code == 200
        data = resp.json()
        assert data["email"] == "admin@getpramaan.com"
        assert data["role"] == "admin"

    @pytest.mark.asyncio
    async def test_get_me_without_token_returns_401(self):
        """GET /auth/me without token returns 401."""
        from src.api.auth import router
        from fastapi import FastAPI
        from httpx import AsyncClient, ASGITransport

        app = FastAPI()
        app.include_router(router)

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.get("/auth/me")

        assert resp.status_code in (401, 422)

    @pytest.mark.asyncio
    async def test_get_me_with_expired_token_returns_401(self):
        """GET /auth/me with expired token returns 401."""
        from src.api.auth import router
        from src.config import get_settings
        from fastapi import FastAPI
        from httpx import AsyncClient, ASGITransport

        app = FastAPI()
        app.include_router(router)

        settings = get_settings()
        # Create expired token
        expired_token = jwt.encode(
            {"sub": "user-123", "exp": 1000000000},  # expired long ago
            settings.secret_key,
            algorithm="HS256",
        )

        mock_db = AsyncMock()
        from src.db.engine import get_db
        app.dependency_overrides[get_db] = lambda: mock_db

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.get("/auth/me", headers={
                "Authorization": f"Bearer {expired_token}",
            })

        assert resp.status_code == 401


# ═══════════════════════════════════════════════════════════════════════════════
# ROLE-BASED ACCESS TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestRoleAccess:
    """Test role-based access control."""

    @pytest.mark.asyncio
    async def test_client_user_cannot_create_users(self):
        """Client-role user cannot access POST /auth/users."""
        from src.api.auth import router, _create_access_token
        from fastapi import FastAPI
        from httpx import AsyncClient, ASGITransport

        app = FastAPI()
        app.include_router(router)

        client_user = _make_user(role="client", client_id=uuid.uuid4())
        token = _create_access_token({"sub": str(client_user.id), "role": "client"})

        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = client_user

        mock_db = AsyncMock()
        mock_db.execute = AsyncMock(return_value=mock_result)

        from src.db.engine import get_db
        app.dependency_overrides[get_db] = lambda: mock_db

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.post("/auth/users", headers={
                "Authorization": f"Bearer {token}",
            }, json={
                "email": "new@test.com",
                "password": "pass123",
                "name": "New User",
                "role": "client",
                "client_id": str(uuid.uuid4()),
            })

        assert resp.status_code == 403

    @pytest.mark.asyncio
    async def test_client_user_cannot_list_users(self):
        """Client-role user cannot access GET /auth/users."""
        from src.api.auth import router, _create_access_token
        from fastapi import FastAPI
        from httpx import AsyncClient, ASGITransport

        app = FastAPI()
        app.include_router(router)

        client_user = _make_user(role="client", client_id=uuid.uuid4())
        token = _create_access_token({"sub": str(client_user.id)})

        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = client_user

        mock_db = AsyncMock()
        mock_db.execute = AsyncMock(return_value=mock_result)

        from src.db.engine import get_db
        app.dependency_overrides[get_db] = lambda: mock_db

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.get("/auth/users", headers={
                "Authorization": f"Bearer {token}",
            })

        assert resp.status_code == 403


# ═══════════════════════════════════════════════════════════════════════════════
# PASSWORD HASHING TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestPasswordHashing:
    """Test password hashing utilities."""

    def test_hash_and_verify(self):
        """Hashed password can be verified."""
        from src.api.auth import _hash_password, _verify_password

        hashed = _hash_password("my_secret_password")
        assert _verify_password("my_secret_password", hashed)
        assert not _verify_password("wrong_password", hashed)

    def test_hash_is_unique(self):
        """Same password produces different hashes (salted)."""
        from src.api.auth import _hash_password

        h1 = _hash_password("same_password")
        h2 = _hash_password("same_password")
        assert h1 != h2  # bcrypt uses random salt


# ═══════════════════════════════════════════════════════════════════════════════
# DUAL AUTH TESTS (legacy x-admin-key + JWT)
# ═══════════════════════════════════════════════════════════════════════════════

class TestDualAuth:
    """Test that admin API accepts both x-admin-key and JWT Bearer token."""

    @pytest.mark.asyncio
    async def test_admin_key_still_works(self):
        """Legacy x-admin-key header still authenticates via HTTP."""
        from src.api.admin import router
        from src.config import get_settings
        from fastapi import FastAPI
        from httpx import AsyncClient, ASGITransport

        app = FastAPI()
        app.include_router(router)

        settings = get_settings()

        mock_db = AsyncMock()
        mock_result = MagicMock()
        mock_result.scalars.return_value.all.return_value = []
        mock_db.execute = AsyncMock(return_value=mock_result)

        from src.db.engine import get_db
        app.dependency_overrides[get_db] = lambda: mock_db

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.get("/admin/clients", headers={
                "x-admin-key": settings.secret_key,
            })

        assert resp.status_code == 200

    @pytest.mark.asyncio
    async def test_jwt_bearer_works_for_admin_endpoints(self):
        """JWT Bearer token authenticates for admin endpoints via HTTP."""
        from src.api.admin import router
        from src.api.auth import _create_access_token
        from fastapi import FastAPI
        from httpx import AsyncClient, ASGITransport

        app = FastAPI()
        app.include_router(router)

        token = _create_access_token({"sub": "user-123"})

        mock_db = AsyncMock()
        mock_result = MagicMock()
        mock_result.scalars.return_value.all.return_value = []
        mock_db.execute = AsyncMock(return_value=mock_result)

        from src.db.engine import get_db
        app.dependency_overrides[get_db] = lambda: mock_db

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.get("/admin/clients", headers={
                "Authorization": f"Bearer {token}",
            })

        assert resp.status_code == 200

    @pytest.mark.asyncio
    async def test_no_credentials_returns_403(self):
        """No credentials returns 403 via HTTP."""
        from src.api.admin import router
        from fastapi import FastAPI
        from httpx import AsyncClient, ASGITransport

        app = FastAPI()
        app.include_router(router)

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.get("/admin/clients")

        assert resp.status_code == 403

    @pytest.mark.asyncio
    async def test_wrong_key_and_bad_token_returns_403(self):
        """Wrong key + invalid token returns 403."""
        from src.api.admin import router
        from fastapi import FastAPI
        from httpx import AsyncClient, ASGITransport

        app = FastAPI()
        app.include_router(router)

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.get("/admin/clients", headers={
                "x-admin-key": "wrong_key",
                "Authorization": "Bearer invalid.token.here",
            })

        assert resp.status_code == 403
