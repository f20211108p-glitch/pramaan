"""
Tests for broker notification module.

Covers:
  - Lead summary formatting (currency, locations, missing fields)
  - notify_brokers() — sends to all brokers, handles failures
  - Integration with router — HOT leads trigger notification
"""
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from src.notifications.broker import (
    _format_currency_lakhs,
    _format_lead_summary,
    notify_brokers,
)


# ── Unit: currency formatting ────────────────────────────────────────────────

class TestFormatCurrency:
    def test_none_returns_not_specified(self):
        assert _format_currency_lakhs(None) == "not specified"

    def test_lakhs(self):
        assert _format_currency_lakhs(7_000_000) == "₹70L"   # 70 lakh

    def test_crores(self):
        result = _format_currency_lakhs(15_000_000)  # 1.5 crore
        assert "₹" in result
        assert "Cr" in result

    def test_small_amount(self):
        assert _format_currency_lakhs(500_000) == "₹5L"


# ── Unit: lead summary formatting ───────────────────────────────────────────

class TestFormatLeadSummary:
    @pytest.fixture
    def hot_lead(self):
        return {
            "name": "Raj Sharma",
            "phone": "+919820011111",
            "score": 85,
            "tier": "hot",
            "intent": "buyer",
            "budget_min": 7_000_000,
            "budget_max": 9_000_000,
            "location_preferences": ["Whitefield", "Sarjapur Road"],
            "timeline_months": 2,
            "financing_status": "pre_approved",
            "property_type": "apartment",
            "family_size": 4,
        }

    def test_summary_contains_lead_name(self, hot_lead):
        summary = _format_lead_summary(hot_lead)
        assert "Raj Sharma" in summary

    def test_summary_contains_phone(self, hot_lead):
        summary = _format_lead_summary(hot_lead)
        assert "+919820011111" in summary

    def test_summary_contains_score(self, hot_lead):
        summary = _format_lead_summary(hot_lead)
        assert "85/100" in summary
        assert "HOT" in summary

    def test_summary_contains_budget(self, hot_lead):
        summary = _format_lead_summary(hot_lead)
        assert "70L" in summary
        assert "90L" in summary

    def test_summary_contains_locations(self, hot_lead):
        summary = _format_lead_summary(hot_lead)
        assert "Whitefield" in summary
        assert "Sarjapur Road" in summary

    def test_summary_contains_timeline(self, hot_lead):
        summary = _format_lead_summary(hot_lead)
        assert "2 months" in summary

    def test_summary_contains_financing(self, hot_lead):
        summary = _format_lead_summary(hot_lead)
        assert "Pre-approved" in summary

    def test_summary_contains_scoring_reasoning(self, hot_lead):
        summary = _format_lead_summary(hot_lead, scoring_reasoning="High-intent buyer ready to purchase")
        assert "High-intent buyer ready to purchase" in summary

    def test_summary_handles_missing_fields(self):
        sparse_lead = {
            "phone": "+919999900000",
            "score": 72,
            "tier": "hot",
        }
        summary = _format_lead_summary(sparse_lead)
        assert "Unknown" in summary  # name fallback
        assert "not specified" in summary  # budget, location, etc.

    def test_summary_handles_empty_locations(self):
        lead = {"phone": "+91999", "score": 50, "tier": "warm", "location_preferences": []}
        summary = _format_lead_summary(lead)
        assert "not specified" in summary


# ── Async: notify_brokers ────────────────────────────────────────────────────

class TestNotifyBrokers:
    @pytest.fixture
    def client_config(self):
        config = MagicMock()
        config.id = "test-client-id"
        config.waba_phone_number_id = "WABA_123"
        config.waba_token = "token_abc"
        config.broker_wa_numbers = ["+919820099001", "+919820099002"]
        return config

    @pytest.fixture
    def lead_data(self):
        return {
            "name": "Test Lead",
            "phone": "+919999900000",
            "score": 85,
            "tier": "hot",
            "intent": "buyer",
            "budget_min": 8_000_000,
            "budget_max": 10_000_000,
            "location_preferences": ["Whitefield"],
            "timeline_months": 3,
            "financing_status": "pre_approved",
            "property_type": "apartment",
            "family_size": 3,
        }

    @pytest.mark.asyncio
    async def test_notifies_all_brokers(self, client_config, lead_data):
        with patch.object(
            __import__("src.channels.whatsapp", fromlist=["WhatsAppChannel"]).WhatsAppChannel,
            "send_message",
            new_callable=AsyncMock,
            return_value=True,
        ):
            results = await notify_brokers(client_config, lead_data)

        assert len(results) == 2
        assert all(r["success"] for r in results)

    @pytest.mark.asyncio
    async def test_returns_empty_when_no_brokers(self, lead_data):
        config = MagicMock()
        config.id = "test-client"
        config.broker_wa_numbers = []

        results = await notify_brokers(config, lead_data)
        assert results == []

    @pytest.mark.asyncio
    async def test_returns_empty_when_brokers_none(self, lead_data):
        config = MagicMock()
        config.id = "test-client"
        config.broker_wa_numbers = None

        results = await notify_brokers(config, lead_data)
        assert results == []

    @pytest.mark.asyncio
    async def test_handles_partial_failure(self, client_config, lead_data):
        """One broker succeeds, one fails — both reported."""
        call_count = 0

        async def _alternating_send(**kwargs):
            nonlocal call_count
            call_count += 1
            return call_count % 2 == 1  # first succeeds, second fails

        with patch(
            "src.notifications.broker.WhatsAppChannel.send_message",
            side_effect=_alternating_send,
        ):
            results = await notify_brokers(client_config, lead_data)

        assert len(results) == 2
        assert results[0]["success"] is True
        assert results[1]["success"] is False

    @pytest.mark.asyncio
    async def test_handles_exception_in_send(self, client_config, lead_data):
        """Exception during send — caught, reported as failure."""
        with patch(
            "src.notifications.broker.WhatsAppChannel.send_message",
            side_effect=Exception("Network error"),
        ):
            results = await notify_brokers(client_config, lead_data)

        assert len(results) == 2
        assert all(r["success"] is False for r in results)

    @pytest.mark.asyncio
    async def test_sends_correct_content(self, client_config, lead_data):
        """Verify the message content sent to WhatsApp contains lead info."""
        captured_content = []

        async def _capture_send(**kwargs):
            captured_content.append(kwargs.get("content", ""))
            return True

        with patch(
            "src.notifications.broker.WhatsAppChannel.send_message",
            side_effect=_capture_send,
        ):
            await notify_brokers(client_config, lead_data, scoring_reasoning="Strong buyer")

        assert len(captured_content) == 2
        # Both brokers get the same message
        msg = captured_content[0]
        assert "Test Lead" in msg
        assert "85/100" in msg
        assert "Strong buyer" in msg

    @pytest.mark.asyncio
    async def test_uses_client_waba_credentials(self, client_config, lead_data):
        """Verify we use the client's WABA credentials, not a global token."""
        captured_kwargs = []

        async def _capture_send(**kwargs):
            captured_kwargs.append(kwargs)
            return True

        with patch(
            "src.notifications.broker.WhatsAppChannel.send_message",
            side_effect=_capture_send,
        ):
            await notify_brokers(client_config, lead_data)

        assert captured_kwargs[0]["waba_phone_number_id"] == "WABA_123"
        assert captured_kwargs[0]["waba_token"] == "token_abc"
