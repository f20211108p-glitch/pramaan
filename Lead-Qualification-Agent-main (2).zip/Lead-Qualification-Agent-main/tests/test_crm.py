"""
Tests for CRM adapters — Chunk 7B.

Covers:
  - CRMLeadPayload construction + serialization
  - Webhook adapter: push, update, note, health check, error handling
  - Sell.Do adapter: field mapping, push, update, note, auth errors
  - Registry: lookup, unknown type, custom registration
  - Sync orchestrator: routing to correct adapter, no-CRM skip, error resilience
  - Admin API: CRM health check + adapter list endpoints
"""
import uuid
import pytest
import pytest_asyncio
from datetime import datetime
from unittest.mock import AsyncMock, MagicMock, patch, PropertyMock
from typing import Any

import httpx

from src.crm.base import (
    BaseCRMAdapter, CRMLeadPayload, CRMSyncResult, CRMSyncStatus,
)
from src.crm.webhook_adapter import WebhookCRMAdapter
from src.crm.selldo_adapter import (
    SellDoCRMAdapter,
    _map_stage_to_selldo,
    _map_tier_to_selldo_rating,
    _format_budget_lakhs,
    _build_selldo_payload,
)
from src.crm.registry import get_adapter, list_adapters, register_adapter
from src.crm.sync import sync_lead_to_crm, sync_note_to_crm, check_crm_health


# ── Test data ────────────────────────────────────────────────────────────────

def _sample_lead_dict(**overrides) -> dict[str, Any]:
    defaults = {
        "id": str(uuid.uuid4()),
        "phone": "+919820011111",
        "name": "Raj Sharma",
        "email": "raj@example.com",
        "intent": "buyer",
        "budget_min": 7_000_000,
        "budget_max": 9_000_000,
        "timeline_months": 3,
        "urgency": "1_3_months",
        "financing_status": "pre_approved",
        "location_preferences": ["Whitefield", "Sarjapur Road"],
        "property_type": "apartment",
        "family_size": 4,
        "score": 85,
        "tier": "hot",
        "stage": "qualified",
        "source_channel": "whatsapp",
        "language_pref": "hinglish",
    }
    defaults.update(overrides)
    return defaults


def _mock_client_config(crm_type=None, crm_token=None):
    config = MagicMock()
    config.id = uuid.uuid4()
    config.crm_type = crm_type
    config.crm_token = crm_token
    config.client_name = "Test Builder"
    return config


# ═══════════════════════════════════════════════════════════════════════════════
# CRMLeadPayload TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestCRMLeadPayload:
    def test_from_lead_dict(self):
        lead = _sample_lead_dict()
        payload = CRMLeadPayload.from_lead_dict(lead, client_id="c1")
        assert payload.phone == "+919820011111"
        assert payload.name == "Raj Sharma"
        assert payload.budget_min == 7_000_000
        assert payload.tier == "hot"
        assert payload.leadengine_client_id == "c1"
        assert payload.leadengine_lead_id == lead["id"]

    def test_from_lead_dict_minimal(self):
        lead = {"phone": "+91999", "intent": "unknown"}
        payload = CRMLeadPayload.from_lead_dict(lead)
        assert payload.phone == "+91999"
        assert payload.name is None
        assert payload.budget_min is None
        assert payload.leadengine_lead_id is None

    def test_to_dict_roundtrip(self):
        lead = _sample_lead_dict()
        payload = CRMLeadPayload.from_lead_dict(lead)
        d = payload.to_dict()
        assert d["phone"] == "+919820011111"
        assert d["location_preferences"] == ["Whitefield", "Sarjapur Road"]
        assert d["score"] == 85

    def test_defaults(self):
        payload = CRMLeadPayload(phone="+91123")
        assert payload.intent == "unknown"
        assert payload.stage == "new"
        assert payload.language_pref == "english"
        assert payload.location_preferences == []


# ═══════════════════════════════════════════════════════════════════════════════
# SELL.DO MAPPING TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestSellDoMappings:
    def test_stage_mapping(self):
        assert _map_stage_to_selldo("new") == "New"
        assert _map_stage_to_selldo("qualifying") == "Contacted"
        assert _map_stage_to_selldo("qualified") == "Qualified"
        assert _map_stage_to_selldo("scheduling") == "Site Visit Scheduled"
        assert _map_stage_to_selldo("handed_off") == "Negotiation"
        assert _map_stage_to_selldo("converted") == "Won"
        assert _map_stage_to_selldo("lost") == "Lost"
        assert _map_stage_to_selldo("unknown_stage") == "New"  # fallback

    def test_tier_to_rating(self):
        assert _map_tier_to_selldo_rating("hot") == "A"
        assert _map_tier_to_selldo_rating("warm") == "B"
        assert _map_tier_to_selldo_rating("cold") == "C"
        assert _map_tier_to_selldo_rating(None) == "C"  # fallback

    def test_format_budget_lakhs(self):
        assert _format_budget_lakhs(None) is None
        assert _format_budget_lakhs(7_000_000) == "70 L"
        assert _format_budget_lakhs(15_000_000) == "1.5 Cr"
        assert _format_budget_lakhs(500_000) == "5 L"
        assert _format_budget_lakhs(100_000_000) == "10.0 Cr"

    def test_build_selldo_payload(self):
        lead = _sample_lead_dict()
        payload = CRMLeadPayload.from_lead_dict(lead)
        data = _build_selldo_payload(payload)

        assert data["lead[phone]"] == "+919820011111"
        assert data["lead[name]"] == "Raj Sharma"
        assert data["lead[email]"] == "raj@example.com"
        assert data["lead[stage]"] == "Qualified"
        assert data["lead[rating]"] == "A"
        assert data["lead[budget_min]"] == "70 L"
        assert data["lead[budget_max]"] == "90 L"
        assert data["lead[location]"] == "Whitefield, Sarjapur Road"
        assert data["lead[property_type]"] == "Apartment"
        assert data["lead[custom_field][timeline_months]"] == "3"
        assert data["lead[custom_field][financing_status]"] == "pre_approved"
        assert data["lead[custom_field][leadengine_score]"] == "85"
        assert data["lead[custom_field][language]"] == "hinglish"

    def test_build_selldo_payload_minimal(self):
        payload = CRMLeadPayload(phone="+91123")
        data = _build_selldo_payload(payload)
        assert data["lead[phone]"] == "+91123"
        assert data["lead[stage]"] == "New"
        assert "lead[name]" not in data
        assert "lead[email]" not in data
        assert "lead[budget_min]" not in data


# ═══════════════════════════════════════════════════════════════════════════════
# WEBHOOK ADAPTER TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestWebhookAdapter:
    @pytest.fixture
    def adapter(self):
        return WebhookCRMAdapter()

    @pytest.mark.asyncio
    async def test_push_lead_success(self, adapter):
        payload = CRMLeadPayload.from_lead_dict(_sample_lead_dict())
        mock_resp = httpx.Response(200, json={"id": "ext-123"})

        with patch("src.crm.webhook_adapter.httpx.AsyncClient") as MockClient:
            mock_client = AsyncMock()
            mock_client.post.return_value = mock_resp
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = mock_client

            result = await adapter.push_lead("https://hooks.example.com/lead", payload)

        assert result.status == CRMSyncStatus.SUCCESS
        assert result.external_id == "ext-123"
        assert result.crm_type == "webhook"

    @pytest.mark.asyncio
    async def test_push_lead_empty_url_skips(self, adapter):
        payload = CRMLeadPayload(phone="+91123")
        result = await adapter.push_lead("", payload)
        assert result.status == CRMSyncStatus.SKIPPED

    @pytest.mark.asyncio
    async def test_push_lead_auth_error(self, adapter):
        payload = CRMLeadPayload(phone="+91123")
        mock_resp = httpx.Response(401, text="Unauthorized")

        with patch("src.crm.webhook_adapter.httpx.AsyncClient") as MockClient:
            mock_client = AsyncMock()
            mock_client.post.return_value = mock_resp
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = mock_client

            result = await adapter.push_lead("https://hooks.example.com", payload)

        assert result.status == CRMSyncStatus.AUTH_ERROR

    @pytest.mark.asyncio
    async def test_push_lead_server_error(self, adapter):
        payload = CRMLeadPayload(phone="+91123")
        mock_resp = httpx.Response(500, text="Internal Server Error")

        with patch("src.crm.webhook_adapter.httpx.AsyncClient") as MockClient:
            mock_client = AsyncMock()
            mock_client.post.return_value = mock_resp
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = mock_client

            result = await adapter.push_lead("https://hooks.example.com", payload)

        assert result.status == CRMSyncStatus.FAILED

    @pytest.mark.asyncio
    async def test_push_lead_timeout(self, adapter):
        payload = CRMLeadPayload(phone="+91123")

        with patch("src.crm.webhook_adapter.httpx.AsyncClient") as MockClient:
            mock_client = AsyncMock()
            mock_client.post.side_effect = httpx.TimeoutException("Timed out")
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = mock_client

            result = await adapter.push_lead("https://hooks.example.com", payload)

        assert result.status == CRMSyncStatus.FAILED
        assert "Timeout" in result.message

    @pytest.mark.asyncio
    async def test_update_lead(self, adapter):
        payload = CRMLeadPayload.from_lead_dict(_sample_lead_dict())
        mock_resp = httpx.Response(200, json={"ok": True})

        with patch("src.crm.webhook_adapter.httpx.AsyncClient") as MockClient:
            mock_client = AsyncMock()
            mock_client.post.return_value = mock_resp
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = mock_client

            result = await adapter.update_lead(
                "https://hooks.example.com", payload,
                external_id="ext-123",
                fields={"score": 90},
            )

        assert result.status == CRMSyncStatus.UPDATED

    @pytest.mark.asyncio
    async def test_push_note(self, adapter):
        mock_resp = httpx.Response(200, json={"ok": True})

        with patch("src.crm.webhook_adapter.httpx.AsyncClient") as MockClient:
            mock_client = AsyncMock()
            mock_client.post.return_value = mock_resp
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = mock_client

            result = await adapter.push_note(
                "https://hooks.example.com",
                phone="+91123",
                note="Lead qualified with score 85",
            )

        assert result.status == CRMSyncStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_health_check_reachable(self, adapter):
        mock_resp = httpx.Response(200, text="OK")

        with patch("src.crm.webhook_adapter.httpx.AsyncClient") as MockClient:
            mock_client = AsyncMock()
            mock_client.get.return_value = mock_resp
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = mock_client

            result = await adapter.check_health("https://hooks.example.com")

        assert result.status == CRMSyncStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_health_check_unreachable(self, adapter):
        with patch("src.crm.webhook_adapter.httpx.AsyncClient") as MockClient:
            mock_client = AsyncMock()
            mock_client.get.side_effect = httpx.ConnectError("Connection refused")
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = mock_client

            result = await adapter.check_health("https://hooks.example.com")

        assert result.status == CRMSyncStatus.FAILED

    def test_crm_type(self, adapter):
        assert adapter.crm_type == "webhook"


# ═══════════════════════════════════════════════════════════════════════════════
# SELL.DO ADAPTER TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestSellDoAdapter:
    @pytest.fixture
    def adapter(self):
        return SellDoCRMAdapter(base_url="https://test.sell.do/api")

    @pytest.mark.asyncio
    async def test_push_lead_created(self, adapter):
        payload = CRMLeadPayload.from_lead_dict(_sample_lead_dict())
        mock_resp = httpx.Response(201, json={"id": "selldo-456"})

        with patch("src.crm.selldo_adapter.httpx.AsyncClient") as MockClient:
            mock_client = AsyncMock()
            mock_client.post.return_value = mock_resp
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = mock_client

            result = await adapter.push_lead("selldo_api_key_123", payload)

        assert result.status == CRMSyncStatus.CREATED
        assert result.external_id == "selldo-456"
        assert result.crm_type == "selldo"

    @pytest.mark.asyncio
    async def test_push_lead_updated(self, adapter):
        """Sell.Do returns 200 when upserting an existing lead."""
        payload = CRMLeadPayload.from_lead_dict(_sample_lead_dict())
        mock_resp = httpx.Response(200, json={"id": "selldo-456"})

        with patch("src.crm.selldo_adapter.httpx.AsyncClient") as MockClient:
            mock_client = AsyncMock()
            mock_client.post.return_value = mock_resp
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = mock_client

            result = await adapter.push_lead("key", payload)

        assert result.status == CRMSyncStatus.UPDATED

    @pytest.mark.asyncio
    async def test_push_lead_no_token_skips(self, adapter):
        payload = CRMLeadPayload(phone="+91123")
        result = await adapter.push_lead("", payload)
        assert result.status == CRMSyncStatus.SKIPPED

    @pytest.mark.asyncio
    async def test_push_lead_auth_error(self, adapter):
        payload = CRMLeadPayload(phone="+91123")
        mock_resp = httpx.Response(401, json={"message": "Invalid API key"})

        with patch("src.crm.selldo_adapter.httpx.AsyncClient") as MockClient:
            mock_client = AsyncMock()
            mock_client.post.return_value = mock_resp
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = mock_client

            result = await adapter.push_lead("bad_key", payload)

        assert result.status == CRMSyncStatus.AUTH_ERROR

    @pytest.mark.asyncio
    async def test_update_lead_with_external_id(self, adapter):
        payload = CRMLeadPayload.from_lead_dict(_sample_lead_dict())
        mock_resp = httpx.Response(200, json={"ok": True})

        with patch("src.crm.selldo_adapter.httpx.AsyncClient") as MockClient:
            mock_client = AsyncMock()
            mock_client.post.return_value = mock_resp
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = mock_client

            result = await adapter.update_lead("key", payload, external_id="selldo-456")

        assert result.status == CRMSyncStatus.UPDATED

    @pytest.mark.asyncio
    async def test_update_lead_without_external_id_falls_back_to_push(self, adapter):
        """Without external_id, Sell.Do adapter falls back to upsert via push_lead."""
        payload = CRMLeadPayload.from_lead_dict(_sample_lead_dict())

        with patch.object(adapter, "push_lead", new_callable=AsyncMock) as mock_push:
            mock_push.return_value = CRMSyncResult(
                status=CRMSyncStatus.UPDATED, crm_type="selldo"
            )
            result = await adapter.update_lead("key", payload)

        mock_push.assert_called_once()
        assert result.status == CRMSyncStatus.UPDATED

    @pytest.mark.asyncio
    async def test_push_note(self, adapter):
        mock_resp = httpx.Response(201, json={"ok": True})

        with patch("src.crm.selldo_adapter.httpx.AsyncClient") as MockClient:
            mock_client = AsyncMock()
            mock_client.post.return_value = mock_resp
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = mock_client

            result = await adapter.push_note(
                "key", external_id="selldo-456", note="Score: 85"
            )

        assert result.status == CRMSyncStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_push_note_needs_id_or_phone(self, adapter):
        result = await adapter.push_note("key", note="Test note")
        assert result.status == CRMSyncStatus.FAILED
        assert "Need external_id or phone" in result.message

    @pytest.mark.asyncio
    async def test_health_check_success(self, adapter):
        mock_resp = httpx.Response(200, json=[])

        with patch("src.crm.selldo_adapter.httpx.AsyncClient") as MockClient:
            mock_client = AsyncMock()
            mock_client.get.return_value = mock_resp
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = mock_client

            result = await adapter.check_health("key")

        assert result.status == CRMSyncStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_health_check_auth_fail(self, adapter):
        mock_resp = httpx.Response(401, json={"error": "unauthorized"})

        with patch("src.crm.selldo_adapter.httpx.AsyncClient") as MockClient:
            mock_client = AsyncMock()
            mock_client.get.return_value = mock_resp
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = mock_client

            result = await adapter.check_health("bad_key")

        assert result.status == CRMSyncStatus.AUTH_ERROR

    def test_crm_type(self, adapter):
        assert adapter.crm_type == "selldo"

    @pytest.mark.asyncio
    async def test_push_lead_timeout(self, adapter):
        payload = CRMLeadPayload(phone="+91123")

        with patch("src.crm.selldo_adapter.httpx.AsyncClient") as MockClient:
            mock_client = AsyncMock()
            mock_client.post.side_effect = httpx.TimeoutException("Timed out")
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            MockClient.return_value = mock_client

            result = await adapter.push_lead("key", payload)

        assert result.status == CRMSyncStatus.FAILED
        assert "Timeout" in result.message


# ═══════════════════════════════════════════════════════════════════════════════
# REGISTRY TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestCRMRegistry:
    def test_get_adapter_selldo(self):
        adapter = get_adapter("selldo")
        assert adapter is not None
        assert adapter.crm_type == "selldo"

    def test_get_adapter_webhook(self):
        adapter = get_adapter("webhook")
        assert adapter is not None
        assert adapter.crm_type == "webhook"

    def test_get_adapter_none(self):
        assert get_adapter(None) is None

    def test_get_adapter_empty(self):
        assert get_adapter("") is None

    def test_get_adapter_unknown(self):
        assert get_adapter("unknown_crm_xyz") is None

    def test_get_adapter_case_insensitive(self):
        adapter = get_adapter("SellDo")
        assert adapter is not None
        assert adapter.crm_type == "selldo"

    def test_list_adapters(self):
        adapters = list_adapters()
        assert "selldo" in adapters
        assert "webhook" in adapters

    def test_register_custom_adapter(self):
        class CustomAdapter(BaseCRMAdapter):
            @property
            def crm_type(self) -> str:
                return "custom_test"

            async def push_lead(self, crm_token, payload, **kw):
                return self._make_result(CRMSyncStatus.SUCCESS)

            async def update_lead(self, crm_token, payload, **kw):
                return self._make_result(CRMSyncStatus.SUCCESS)

            async def push_note(self, crm_token, **kw):
                return self._make_result(CRMSyncStatus.SUCCESS)

            async def check_health(self, crm_token):
                return self._make_result(CRMSyncStatus.SUCCESS)

        register_adapter(CustomAdapter())
        adapter = get_adapter("custom_test")
        assert adapter is not None
        assert adapter.crm_type == "custom_test"


# ═══════════════════════════════════════════════════════════════════════════════
# SYNC ORCHESTRATOR TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestCRMSync:
    @pytest.mark.asyncio
    async def test_sync_no_crm_configured(self):
        config = _mock_client_config(crm_type=None, crm_token=None)
        result = await sync_lead_to_crm(config, _sample_lead_dict())
        assert result is None

    @pytest.mark.asyncio
    async def test_sync_crm_type_but_no_token(self):
        config = _mock_client_config(crm_type="selldo", crm_token=None)
        result = await sync_lead_to_crm(config, _sample_lead_dict())
        assert result is None

    @pytest.mark.asyncio
    async def test_sync_unknown_crm_type(self):
        config = _mock_client_config(crm_type="nonexistent_crm", crm_token="tok")
        result = await sync_lead_to_crm(config, _sample_lead_dict())
        assert result is not None
        assert result.status == CRMSyncStatus.FAILED
        assert "Unknown CRM type" in result.message

    @pytest.mark.asyncio
    async def test_sync_routes_to_webhook(self):
        config = _mock_client_config(crm_type="webhook", crm_token="https://hooks.example.com")

        with patch("src.crm.sync.get_adapter") as mock_get:
            mock_adapter = AsyncMock(spec=BaseCRMAdapter)
            mock_adapter.push_lead.return_value = CRMSyncResult(
                status=CRMSyncStatus.SUCCESS, crm_type="webhook"
            )
            mock_get.return_value = mock_adapter

            result = await sync_lead_to_crm(config, _sample_lead_dict())

        assert result.status == CRMSyncStatus.SUCCESS
        mock_adapter.push_lead.assert_called_once()

    @pytest.mark.asyncio
    async def test_sync_with_fields_updated_uses_update(self):
        config = _mock_client_config(crm_type="webhook", crm_token="https://hooks.example.com")

        with patch("src.crm.sync.get_adapter") as mock_get:
            mock_adapter = AsyncMock(spec=BaseCRMAdapter)
            mock_adapter.update_lead.return_value = CRMSyncResult(
                status=CRMSyncStatus.UPDATED, crm_type="webhook"
            )
            mock_get.return_value = mock_adapter

            result = await sync_lead_to_crm(
                config, _sample_lead_dict(),
                fields_updated={"score": 90, "tier": "hot"},
            )

        assert result.status == CRMSyncStatus.UPDATED
        mock_adapter.update_lead.assert_called_once()

    @pytest.mark.asyncio
    async def test_sync_exception_doesnt_raise(self):
        """CRM sync failures must NEVER bubble up."""
        config = _mock_client_config(crm_type="webhook", crm_token="https://hooks.example.com")

        with patch("src.crm.sync.get_adapter") as mock_get:
            mock_adapter = AsyncMock(spec=BaseCRMAdapter)
            mock_adapter.push_lead.side_effect = RuntimeError("Unexpected crash")
            mock_get.return_value = mock_adapter

            result = await sync_lead_to_crm(config, _sample_lead_dict())

        assert result is not None
        assert result.status == CRMSyncStatus.FAILED

    @pytest.mark.asyncio
    async def test_sync_note_success(self):
        config = _mock_client_config(crm_type="webhook", crm_token="https://hooks.example.com")

        with patch("src.crm.sync.get_adapter") as mock_get:
            mock_adapter = AsyncMock(spec=BaseCRMAdapter)
            mock_adapter.push_note.return_value = CRMSyncResult(
                status=CRMSyncStatus.SUCCESS, crm_type="webhook"
            )
            mock_get.return_value = mock_adapter

            result = await sync_note_to_crm(config, "+91123", "Lead scored 85")

        assert result.status == CRMSyncStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_sync_note_no_crm(self):
        config = _mock_client_config()
        result = await sync_note_to_crm(config, "+91123", "Note")
        assert result is None

    @pytest.mark.asyncio
    async def test_check_health_success(self):
        config = _mock_client_config(crm_type="webhook", crm_token="https://hooks.example.com")

        with patch("src.crm.sync.get_adapter") as mock_get:
            mock_adapter = AsyncMock(spec=BaseCRMAdapter)
            mock_adapter.check_health.return_value = CRMSyncResult(
                status=CRMSyncStatus.SUCCESS, crm_type="webhook"
            )
            mock_get.return_value = mock_adapter

            result = await check_crm_health(config)

        assert result.status == CRMSyncStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_check_health_no_crm(self):
        config = _mock_client_config()
        result = await check_crm_health(config)
        assert result is None


# ═══════════════════════════════════════════════════════════════════════════════
# CRM SYNC RESULT TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestCRMSyncResult:
    def test_to_dict(self):
        result = CRMSyncResult(
            status=CRMSyncStatus.SUCCESS,
            crm_type="webhook",
            external_id="ext-123",
            message="OK",
        )
        d = result.to_dict()
        assert d["status"] == "success"
        assert d["crm_type"] == "webhook"
        assert d["external_id"] == "ext-123"
        assert "synced_at" in d

    def test_status_enum_values(self):
        assert CRMSyncStatus.SUCCESS.value == "success"
        assert CRMSyncStatus.AUTH_ERROR.value == "auth_error"
        assert CRMSyncStatus.SKIPPED.value == "skipped"


# ═══════════════════════════════════════════════════════════════════════════════
# ADMIN API CRM ENDPOINTS
# ═══════════════════════════════════════════════════════════════════════════════

from httpx import AsyncClient, ASGITransport
from sqlalchemy.ext.asyncio import AsyncSession
from src.db.tables import ClientConfig
from src.db.engine import get_db
from src.main import app


@pytest_asyncio.fixture
async def api_client(db: AsyncSession):
    async def _override_get_db():
        yield db

    app.dependency_overrides[get_db] = _override_get_db
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c
    app.dependency_overrides.clear()


@pytest.fixture
def admin_headers():
    from src.config import get_settings
    return {"x-admin-key": get_settings().secret_key}


def _make_client_config_orm(**kwargs) -> ClientConfig:
    defaults = dict(
        client_name="Test Builder",
        waba_number=f"91{uuid.uuid4().hex[:10]}",
        waba_phone_number_id=f"WABA_{uuid.uuid4().hex[:8]}",
        waba_token="test_token",
        broker_wa_numbers=["+919820099001"],
        active=True,
    )
    defaults.update(kwargs)
    return ClientConfig(**defaults)


class TestCRMAdminEndpoints:
    @pytest.mark.asyncio
    async def test_list_crm_adapters(self, api_client, admin_headers):
        resp = await api_client.get("/admin/crm/adapters", headers=admin_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert "adapters" in data
        assert "selldo" in data["adapters"]
        assert "webhook" in data["adapters"]

    @pytest.mark.asyncio
    async def test_crm_health_no_crm_configured(self, api_client, admin_headers, db):
        c = _make_client_config_orm(crm_type=None, crm_token=None)
        db.add(c)
        await db.flush()

        resp = await api_client.get(
            f"/admin/clients/{c.id}/crm/health", headers=admin_headers,
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["crm_configured"] is False
        assert data["status"] == "not_configured"

    @pytest.mark.asyncio
    async def test_crm_health_configured(self, api_client, admin_headers, db):
        c = _make_client_config_orm(crm_type="webhook", crm_token="https://hooks.example.com")
        db.add(c)
        await db.flush()

        with patch("src.api.admin.check_crm_health", new_callable=AsyncMock) as mock_health:
            mock_health.return_value = CRMSyncResult(
                status=CRMSyncStatus.SUCCESS, crm_type="webhook", message="OK"
            )

            resp = await api_client.get(
                f"/admin/clients/{c.id}/crm/health", headers=admin_headers,
            )

        assert resp.status_code == 200
        data = resp.json()
        assert data["crm_configured"] is True
        assert data["crm_type"] == "webhook"
        assert data["status"] == "success"

    @pytest.mark.asyncio
    async def test_crm_health_client_not_found(self, api_client, admin_headers):
        fake_id = str(uuid.uuid4())
        resp = await api_client.get(
            f"/admin/clients/{fake_id}/crm/health", headers=admin_headers,
        )
        assert resp.status_code == 404
