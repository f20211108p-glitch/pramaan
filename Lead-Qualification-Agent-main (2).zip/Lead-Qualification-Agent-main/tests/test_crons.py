"""
Tests for Chunk 11 — APScheduler cron jobs.
All DB queries and WhatsApp calls are mocked — no real infra needed.
All LLM calls are mocked — no real Anthropic tokens consumed.
"""
import uuid
from datetime import datetime, timedelta, timezone
from unittest.mock import patch, AsyncMock, MagicMock, PropertyMock

import pytest

IST = timezone(timedelta(hours=5, minutes=30))


# ── Helpers ───────────────────────────────────────────────────────────────────

def _make_client(
    client_id=None,
    client_name="Test Realty",
    broker_numbers=None,
    active=True,
):
    """Create a mock ClientConfig ORM object."""
    c = MagicMock()
    c.id = uuid.UUID(client_id) if client_id else uuid.uuid4()
    c.client_name = client_name
    c.waba_phone_number_id = "WABA_TEST"
    c.waba_token = "test_token"
    c.broker_wa_numbers = broker_numbers if broker_numbers is not None else ["919000000001"]
    c.active = active
    return c


def _make_lead(
    name="Raj",
    phone="919111111111",
    tier="hot",
    stage="new",
    score=85,
    property_type="apartment",
    location_prefs=None,
    created_at=None,
    updated_at=None,
):
    """Create a mock Lead ORM object."""
    lead = MagicMock()
    lead.id = uuid.uuid4()
    lead.name = name
    lead.phone = phone
    lead.tier = tier
    lead.stage = stage
    lead.score = score
    lead.property_type = property_type
    lead.location_preferences = location_prefs if location_prefs is not None else ["Whitefield"]
    lead.created_at = created_at or datetime.utcnow()
    lead.updated_at = updated_at or datetime.utcnow()
    return lead


# ═══════════════════════════════════════════════════════════════════════════════
# Test: _format_digest
# ═══════════════════════════════════════════════════════════════════════════════

class TestFormatDigest:
    """Test the digest text formatter."""

    def test_format_digest_all_tiers(self):
        from src.crons.jobs import _format_digest

        text = _format_digest(
            client_name="Prestige Group",
            date_str="27 May 2026",
            leads_by_tier={"hot": 3, "warm": 7, "cold": 12},
            total_new=22,
            appointments_booked=2,
            avg_response_min=4.5,
        )

        assert "Prestige Group" in text
        assert "27 May 2026" in text
        assert "22" in text          # total
        assert "Hot: 3" in text
        assert "Warm: 7" in text
        assert "Cold: 12" in text
        assert "Appointments Booked: 2" in text
        assert "4 min" in text       # avg response (4.5 rounds to 4 with :.0f)

    def test_format_digest_no_response_time(self):
        from src.crons.jobs import _format_digest

        text = _format_digest(
            client_name="Test",
            date_str="27 May 2026",
            leads_by_tier={"hot": 1},
            total_new=1,
            appointments_booked=0,
            avg_response_min=None,
        )
        assert "N/A" in text

    def test_format_digest_zero_tiers(self):
        from src.crons.jobs import _format_digest

        text = _format_digest(
            client_name="Test",
            date_str="27 May 2026",
            leads_by_tier={},
            total_new=5,
            appointments_booked=0,
            avg_response_min=None,
        )
        assert "Hot: 0" in text
        assert "Warm: 0" in text


# ═══════════════════════════════════════════════════════════════════════════════
# Test: _build_reengagement_message
# ═══════════════════════════════════════════════════════════════════════════════

class TestReengagementMessage:
    """Test the re-engagement message builder."""

    def test_message_with_name_and_location(self):
        from src.crons.jobs import _build_reengagement_message

        lead = _make_lead(name="Priya", property_type="villa", location_prefs=["Sarjapur Road"])
        msg = _build_reengagement_message(lead)

        assert "Priya" in msg
        assert "villa" in msg
        assert "Sarjapur Road" in msg
        assert "Prices have been updated" in msg

    def test_message_with_no_name(self):
        from src.crons.jobs import _build_reengagement_message

        lead = _make_lead(name=None, location_prefs=[])
        msg = _build_reengagement_message(lead)

        assert "Hi there" in msg
        assert "your preferred area" in msg


# ═══════════════════════════════════════════════════════════════════════════════
# Test: daily_digest()
# ═══════════════════════════════════════════════════════════════════════════════

class TestDailyDigest:
    """Test the daily_digest job end-to-end with mocked DB and WhatsApp."""

    @pytest.mark.asyncio
    async def test_daily_digest_sends_to_brokers(self):
        """Should query yesterday's leads and send digest to all broker numbers."""
        from src.crons.jobs import daily_digest

        client = _make_client(broker_numbers=["919000000001", "919000000002"])

        # Mock DB session
        mock_db = AsyncMock()

        # Mock: select(ClientConfig) → returns our client
        mock_clients_result = MagicMock()
        mock_clients_result.scalars.return_value.all.return_value = [client]

        # Mock: select(Lead.tier, count) → returns tier counts
        mock_tier_result = MagicMock()
        mock_tier_result.all.return_value = [("hot", 3), ("warm", 5), ("cold", 2)]

        # Mock: select(count(BillingEvent)) → returns 1 appointment
        mock_appt_result = MagicMock()
        mock_appt_result.scalar.return_value = 1

        # Set up execute to return different results for different queries
        call_count = 0

        async def mock_execute(query, *args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return mock_clients_result  # clients query
            elif call_count == 2:
                return mock_tier_result     # tier query
            elif call_count == 3:
                return mock_appt_result     # appointment count
            return MagicMock()

        mock_db.execute = mock_execute

        # Mock AsyncSessionFactory as context manager
        mock_session_ctx = AsyncMock()
        mock_session_ctx.__aenter__ = AsyncMock(return_value=mock_db)
        mock_session_ctx.__aexit__ = AsyncMock(return_value=None)

        with patch("src.crons.jobs.AsyncSessionFactory", return_value=mock_session_ctx):
            with patch("src.crons.jobs.WhatsAppChannel.send_template_message",
                       new_callable=AsyncMock, return_value=True) as mock_send:
                result = await daily_digest()

        # Should have sent to both broker numbers
        assert mock_send.call_count == 2
        client_result = result[str(client.id)]
        assert client_result["sent"] == 2
        assert client_result["total_brokers"] == 2

    @pytest.mark.asyncio
    async def test_daily_digest_skips_no_brokers(self):
        """Client with no broker numbers should be skipped."""
        from src.crons.jobs import daily_digest

        client = _make_client(broker_numbers=[])

        mock_db = AsyncMock()
        mock_clients_result = MagicMock()
        mock_clients_result.scalars.return_value.all.return_value = [client]
        mock_db.execute = AsyncMock(return_value=mock_clients_result)

        mock_session_ctx = AsyncMock()
        mock_session_ctx.__aenter__ = AsyncMock(return_value=mock_db)
        mock_session_ctx.__aexit__ = AsyncMock(return_value=None)

        with patch("src.crons.jobs.AsyncSessionFactory", return_value=mock_session_ctx):
            result = await daily_digest()

        client_result = result[str(client.id)]
        assert client_result["skipped"] is True
        assert client_result["reason"] == "no_brokers"

    @pytest.mark.asyncio
    async def test_daily_digest_skips_no_activity(self):
        """Client with zero leads and zero appointments should be skipped."""
        from src.crons.jobs import daily_digest

        client = _make_client(broker_numbers=["919000000001"])

        mock_db = AsyncMock()
        mock_clients_result = MagicMock()
        mock_clients_result.scalars.return_value.all.return_value = [client]

        # Zero tier results, zero appointments
        mock_tier_result = MagicMock()
        mock_tier_result.all.return_value = []

        mock_appt_result = MagicMock()
        mock_appt_result.scalar.return_value = 0

        call_count = 0

        async def mock_execute(query, *args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return mock_clients_result
            elif call_count == 2:
                return mock_tier_result
            elif call_count == 3:
                return mock_appt_result
            return MagicMock()

        mock_db.execute = mock_execute

        mock_session_ctx = AsyncMock()
        mock_session_ctx.__aenter__ = AsyncMock(return_value=mock_db)
        mock_session_ctx.__aexit__ = AsyncMock(return_value=None)

        with patch("src.crons.jobs.AsyncSessionFactory", return_value=mock_session_ctx):
            with patch("src.crons.jobs.WhatsAppChannel.send_template_message",
                       new_callable=AsyncMock) as mock_send:
                result = await daily_digest()

        # No sends — nothing to report
        mock_send.assert_not_called()
        client_result = result[str(client.id)]
        assert client_result["skipped"] is True
        assert client_result["reason"] == "no_activity"


# ═══════════════════════════════════════════════════════════════════════════════
# Test: stale_reengagement()
# ═══════════════════════════════════════════════════════════════════════════════

class TestStaleReengagement:
    """Test the stale lead re-engagement job."""

    @pytest.mark.asyncio
    async def test_reengagement_picks_stale_leads(self):
        """Should only pick nurturing leads older than 7 days."""
        from src.crons.jobs import stale_reengagement

        client = _make_client()
        stale_lead = _make_lead(
            name="Stale Lead",
            stage="nurturing",
            updated_at=datetime.utcnow() - timedelta(days=10),
        )

        mock_db = AsyncMock()

        # First call: clients, second call: stale leads
        mock_clients_result = MagicMock()
        mock_clients_result.scalars.return_value.all.return_value = [client]

        mock_stale_result = MagicMock()
        mock_stale_result.scalars.return_value.all.return_value = [stale_lead]

        call_count = 0

        async def mock_execute(query, *args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return mock_clients_result
            elif call_count == 2:
                return mock_stale_result
            return MagicMock()

        mock_db.execute = mock_execute
        mock_db.commit = AsyncMock()

        mock_session_ctx = AsyncMock()
        mock_session_ctx.__aenter__ = AsyncMock(return_value=mock_db)
        mock_session_ctx.__aexit__ = AsyncMock(return_value=None)

        with patch("src.crons.jobs.AsyncSessionFactory", return_value=mock_session_ctx):
            with patch("src.crons.jobs.WhatsAppChannel.send_template_message",
                       new_callable=AsyncMock, return_value=True) as mock_send:
                result = await stale_reengagement()

        # Should have sent to the stale lead
        mock_send.assert_called_once()
        call_args = mock_send.call_args
        assert call_args.kwargs["to"] == stale_lead.phone
        assert call_args.kwargs["template_name"] == "stale_reengagement"

        client_result = result[str(client.id)]
        assert client_result["stale_found"] == 1
        assert client_result["sent"] == 1

    @pytest.mark.asyncio
    async def test_reengagement_max_50_limit(self):
        """Should cap at MAX_REENGAGEMENTS_PER_CLIENT (50)."""
        from src.crons.jobs import stale_reengagement, MAX_REENGAGEMENTS_PER_CLIENT

        # Verify the constant is 50
        assert MAX_REENGAGEMENTS_PER_CLIENT == 50

    @pytest.mark.asyncio
    async def test_reengagement_skips_no_stale(self):
        """Client with no stale leads should be skipped."""
        from src.crons.jobs import stale_reengagement

        client = _make_client()

        mock_db = AsyncMock()
        mock_clients_result = MagicMock()
        mock_clients_result.scalars.return_value.all.return_value = [client]

        mock_stale_result = MagicMock()
        mock_stale_result.scalars.return_value.all.return_value = []

        call_count = 0

        async def mock_execute(query, *args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return mock_clients_result
            elif call_count == 2:
                return mock_stale_result
            return MagicMock()

        mock_db.execute = mock_execute

        mock_session_ctx = AsyncMock()
        mock_session_ctx.__aenter__ = AsyncMock(return_value=mock_db)
        mock_session_ctx.__aexit__ = AsyncMock(return_value=None)

        with patch("src.crons.jobs.AsyncSessionFactory", return_value=mock_session_ctx):
            with patch("src.crons.jobs.WhatsAppChannel.send_template_message",
                       new_callable=AsyncMock) as mock_send:
                result = await stale_reengagement()

        mock_send.assert_not_called()
        client_result = result[str(client.id)]
        assert client_result["skipped"] is True


# ═══════════════════════════════════════════════════════════════════════════════
# Test: warm_lead_digest()
# ═══════════════════════════════════════════════════════════════════════════════

class TestWarmLeadDigest:
    """Test the warm lead evening digest."""

    @pytest.mark.asyncio
    async def test_warm_digest_sends_to_primary_broker_only(self):
        """Should send only to the first broker number."""
        from src.crons.jobs import warm_lead_digest

        client = _make_client(broker_numbers=["919000000001", "919000000002"])
        warm_lead = _make_lead(name="Warm User", tier="warm", score=55)

        mock_db = AsyncMock()
        mock_clients_result = MagicMock()
        mock_clients_result.scalars.return_value.all.return_value = [client]

        mock_warm_result = MagicMock()
        mock_warm_result.scalars.return_value.all.return_value = [warm_lead]

        call_count = 0

        async def mock_execute(query, *args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return mock_clients_result
            elif call_count == 2:
                return mock_warm_result
            return MagicMock()

        mock_db.execute = mock_execute

        mock_session_ctx = AsyncMock()
        mock_session_ctx.__aenter__ = AsyncMock(return_value=mock_db)
        mock_session_ctx.__aexit__ = AsyncMock(return_value=None)

        with patch("src.crons.jobs.AsyncSessionFactory", return_value=mock_session_ctx):
            with patch("src.crons.jobs.WhatsAppChannel.send_template_message",
                       new_callable=AsyncMock, return_value=True) as mock_send:
                result = await warm_lead_digest()

        # Only one call — to primary broker
        mock_send.assert_called_once()
        assert mock_send.call_args.kwargs["to"] == "919000000001"

        client_result = result[str(client.id)]
        assert client_result["sent"] == 1
        assert client_result["warm_count"] == 1

    @pytest.mark.asyncio
    async def test_warm_digest_skips_no_warm_leads(self):
        """No warm leads → skip."""
        from src.crons.jobs import warm_lead_digest

        client = _make_client()

        mock_db = AsyncMock()
        mock_clients_result = MagicMock()
        mock_clients_result.scalars.return_value.all.return_value = [client]

        mock_warm_result = MagicMock()
        mock_warm_result.scalars.return_value.all.return_value = []

        call_count = 0

        async def mock_execute(query, *args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return mock_clients_result
            elif call_count == 2:
                return mock_warm_result
            return MagicMock()

        mock_db.execute = mock_execute

        mock_session_ctx = AsyncMock()
        mock_session_ctx.__aenter__ = AsyncMock(return_value=mock_db)
        mock_session_ctx.__aexit__ = AsyncMock(return_value=None)

        with patch("src.crons.jobs.AsyncSessionFactory", return_value=mock_session_ctx):
            result = await warm_lead_digest()

        client_result = result[str(client.id)]
        assert client_result["skipped"] is True


# ═══════════════════════════════════════════════════════════════════════════════
# Test: Scheduler setup
# ═══════════════════════════════════════════════════════════════════════════════

class TestSchedulerSetup:
    """Test the APScheduler wiring."""

    @pytest.mark.asyncio
    async def test_start_and_stop_scheduler(self):
        """Scheduler should start with 3 jobs and shut down cleanly."""
        from src.crons.setup import start_scheduler, stop_scheduler, get_scheduler

        sched = start_scheduler()
        try:
            assert sched is not None
            assert sched.running is True

            jobs = sched.get_jobs()
            job_ids = {j.id for j in jobs}
            assert "daily_digest" in job_ids
            assert "stale_reengagement" in job_ids
            assert "warm_lead_digest" in job_ids
            assert len(jobs) == 3

            # Verify get_scheduler returns same instance
            assert get_scheduler() is sched
        finally:
            stop_scheduler()

        assert get_scheduler() is None
