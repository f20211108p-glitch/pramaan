"""
Tests for Dashboard API endpoints — Chunk 8.

Covers:
  - Dashboard home (combined stats + recent leads + activity)
  - Lead detail view (lead + conversations + messages + billing in one call)
  - Lead timeline (chronological activity feed)
  - Bulk lead updates (batch stage/tier changes)
  - Activity feed (recent messages across all leads)
  - CSV export (leads download)
  - Conversation export (text + json formats)
"""
import uuid
import csv
import io
import pytest
import pytest_asyncio
from datetime import datetime

from httpx import AsyncClient, ASGITransport
from sqlalchemy.ext.asyncio import AsyncSession

from src.db.tables import (
    ClientConfig, Lead, Conversation, Message, BillingEvent, ConsentLog,
)
from src.db.engine import get_db
from src.main import app


# ── Fixtures ────────────────────────────────────────────────────────────────

@pytest_asyncio.fixture
async def client(db: AsyncSession):
    """httpx AsyncClient with get_db overridden to use test session."""
    async def _override_get_db():
        yield db

    app.dependency_overrides[get_db] = _override_get_db
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        yield c
    app.dependency_overrides.clear()


@pytest.fixture
def admin_headers():
    from src.config import get_settings
    return {"x-admin-key": get_settings().secret_key}


# ── Helpers ─────────────────────────────────────────────────────────────────

def _make_client(**kwargs) -> ClientConfig:
    defaults = dict(
        client_name="Dashboard Test Builder",
        waba_number=f"91{uuid.uuid4().hex[:10]}",
        waba_phone_number_id=f"WABA_{uuid.uuid4().hex[:8]}",
        waba_token="test_token",
        broker_wa_numbers=["+919820099001"],
        crm_type="webhook",
        crm_token="https://hooks.example.com",
        active=True,
    )
    defaults.update(kwargs)
    return ClientConfig(**defaults)


async def _seed_lead(db, client_id, phone, **kwargs) -> Lead:
    defaults = dict(
        client_id=client_id, phone=phone, name="Test Lead",
        intent="buyer", stage="qualifying", tier="warm", score=55,
        language_pref="english", urgency="unknown",
        financing_status="unknown", property_type="apartment",
    )
    defaults.update(kwargs)
    lead = Lead(**defaults)
    db.add(lead)
    await db.flush()
    return lead


async def _seed_conversation(db, client_id, lead_id) -> Conversation:
    conv = Conversation(client_id=client_id, lead_id=lead_id)
    db.add(conv)
    await db.flush()
    return conv


async def _seed_message(db, client_id, conversation_id,
                        direction="inbound", content="Hello") -> Message:
    msg = Message(
        client_id=client_id, conversation_id=conversation_id,
        direction=direction, content=content, message_type="text",
        timestamp=datetime.utcnow(),
    )
    db.add(msg)
    await db.flush()
    return msg


async def _seed_billing(db, client_id, lead_id,
                        event_type="qualified_lead") -> BillingEvent:
    event = BillingEvent(
        client_id=client_id, lead_id=lead_id,
        event_type=event_type,
        extra_data={"score": 85, "tier": "hot"},
    )
    db.add(event)
    await db.flush()
    return event


async def _seed_consent(db, client_id, lead_id) -> ConsentLog:
    consent = ConsentLog(
        client_id=client_id, lead_id=lead_id,
        consent_type="data_collection", source="first_message",
    )
    db.add(consent)
    await db.flush()
    return consent


async def _seed_full_lead(db, client_id, phone, **lead_kwargs):
    """Seed a lead with conversation, messages, billing, and consent."""
    lead = await _seed_lead(db, client_id, phone, **lead_kwargs)
    conv = await _seed_conversation(db, client_id, lead.id)
    await _seed_message(db, client_id, conv.id, "inbound", "Hi, looking for flat")
    await _seed_message(db, client_id, conv.id, "outbound", "Welcome! What's your budget?")
    await _seed_billing(db, client_id, lead.id)
    await _seed_consent(db, client_id, lead.id)
    return lead, conv


# ═══════════════════════════════════════════════════════════════════════════════
# DASHBOARD HOME TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestDashboardHome:
    @pytest.mark.asyncio
    async def test_home_returns_all_sections(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        await _seed_full_lead(db, c.id, "+910000000001", tier="hot", score=85)
        await _seed_full_lead(db, c.id, "+910000000002", tier="warm", score=55)

        resp = await client.get(
            f"/dashboard/{c.id}/home", headers=admin_headers,
        )
        assert resp.status_code == 200
        data = resp.json()

        # All sections present
        assert "client" in data
        assert "stats" in data
        assert "hot_leads" in data
        assert "recent_leads" in data
        assert "recent_activity" in data

        # Client info
        assert data["client"]["client_name"] == "Dashboard Test Builder"
        assert data["client"]["crm_configured"] is True

        # Stats
        assert data["stats"]["total_leads"] == 2
        assert data["stats"]["by_tier"]["hot"] == 1
        assert data["stats"]["by_tier"]["warm"] == 1

        # Hot leads (only the hot one)
        assert len(data["hot_leads"]) == 1
        assert data["hot_leads"][0]["tier"] == "hot"

        # Recent leads (both)
        assert len(data["recent_leads"]) == 2

        # Activity feed (4 messages total: 2 leads × 2 msgs each)
        assert len(data["recent_activity"]) == 4

    @pytest.mark.asyncio
    async def test_home_empty_client(self, client, admin_headers, db):
        c = _make_client(crm_type=None, crm_token=None)
        db.add(c)
        await db.flush()

        resp = await client.get(
            f"/dashboard/{c.id}/home", headers=admin_headers,
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["stats"]["total_leads"] == 0
        assert data["hot_leads"] == []
        assert data["recent_activity"] == []
        assert data["client"]["crm_configured"] is False

    @pytest.mark.asyncio
    async def test_home_client_not_found(self, client, admin_headers):
        fake_id = str(uuid.uuid4())
        resp = await client.get(
            f"/dashboard/{fake_id}/home", headers=admin_headers,
        )
        assert resp.status_code == 404


# ═══════════════════════════════════════════════════════════════════════════════
# LEAD DETAIL TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestLeadDetail:
    @pytest.mark.asyncio
    async def test_detail_returns_everything(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        lead, conv = await _seed_full_lead(
            db, c.id, "+911111100001", name="Detail Lead", tier="hot", score=90,
        )

        resp = await client.get(
            f"/dashboard/{c.id}/leads/{lead.id}/detail",
            headers=admin_headers,
        )
        assert resp.status_code == 200
        data = resp.json()

        # Lead profile
        assert data["lead"]["name"] == "Detail Lead"
        assert data["lead"]["tier"] == "hot"
        assert data["lead"]["score"] == 90

        # Conversations with nested messages
        assert len(data["conversations"]) == 1
        conv_data = data["conversations"][0]
        assert conv_data["message_count"] == 2
        assert len(conv_data["messages"]) == 2
        assert conv_data["messages"][0]["direction"] == "inbound"
        assert conv_data["messages"][1]["direction"] == "outbound"

        # Billing events
        assert len(data["billing_events"]) == 1
        assert data["billing_events"][0]["event_type"] == "qualified_lead"

        # Consent
        assert len(data["consents"]) == 1
        assert data["consents"][0]["consent_type"] == "data_collection"

        # Summary
        assert data["summary"]["total_conversations"] == 1
        assert data["summary"]["total_messages"] == 2
        assert data["summary"]["total_billing_events"] == 1
        assert data["summary"]["has_consent"] is True

    @pytest.mark.asyncio
    async def test_detail_lead_not_found(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        fake_lead = str(uuid.uuid4())
        resp = await client.get(
            f"/dashboard/{c.id}/leads/{fake_lead}/detail",
            headers=admin_headers,
        )
        assert resp.status_code == 404

    @pytest.mark.asyncio
    async def test_detail_multiple_conversations(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        lead = await _seed_lead(db, c.id, "+911111100002", name="Multi Conv")
        conv1 = await _seed_conversation(db, c.id, lead.id)
        conv2 = await _seed_conversation(db, c.id, lead.id)
        await _seed_message(db, c.id, conv1.id, "inbound", "Conv1 msg1")
        await _seed_message(db, c.id, conv1.id, "outbound", "Conv1 msg2")
        await _seed_message(db, c.id, conv2.id, "inbound", "Conv2 msg1")

        resp = await client.get(
            f"/dashboard/{c.id}/leads/{lead.id}/detail",
            headers=admin_headers,
        )
        assert resp.status_code == 200
        data = resp.json()

        assert len(data["conversations"]) == 2
        assert data["summary"]["total_messages"] == 3


# ═══════════════════════════════════════════════════════════════════════════════
# LEAD TIMELINE TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestLeadTimeline:
    @pytest.mark.asyncio
    async def test_timeline_merges_messages_and_billing(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        lead, conv = await _seed_full_lead(db, c.id, "+912222200001")

        resp = await client.get(
            f"/dashboard/{c.id}/leads/{lead.id}/timeline",
            headers=admin_headers,
        )
        assert resp.status_code == 200
        data = resp.json()

        assert data["lead_phone"] == "+912222200001"
        assert data["total_events"] >= 3  # 2 messages + 1 billing event

        # Check event types present
        event_types = {e["type"] for e in data["events"]}
        assert "message" in event_types
        assert "billing" in event_types

        # Events should be chronologically sorted
        timestamps = [e["timestamp"] for e in data["events"]]
        assert timestamps == sorted(timestamps)

    @pytest.mark.asyncio
    async def test_timeline_lead_not_found(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        fake_lead = str(uuid.uuid4())
        resp = await client.get(
            f"/dashboard/{c.id}/leads/{fake_lead}/timeline",
            headers=admin_headers,
        )
        assert resp.status_code == 404

    @pytest.mark.asyncio
    async def test_timeline_empty_lead(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        lead = await _seed_lead(db, c.id, "+912222200002")

        resp = await client.get(
            f"/dashboard/{c.id}/leads/{lead.id}/timeline",
            headers=admin_headers,
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["total_events"] == 0
        assert data["events"] == []


# ═══════════════════════════════════════════════════════════════════════════════
# BULK UPDATE TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestBulkUpdate:
    @pytest.mark.asyncio
    async def test_bulk_update_stage(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        lead1 = await _seed_lead(db, c.id, "+913333300001", stage="qualifying")
        lead2 = await _seed_lead(db, c.id, "+913333300002", stage="qualifying")
        lead3 = await _seed_lead(db, c.id, "+913333300003", stage="qualifying")

        resp = await client.post(
            f"/dashboard/{c.id}/leads/bulk-update",
            headers=admin_headers,
            json={
                "lead_ids": [str(lead1.id), str(lead2.id), str(lead3.id)],
                "stage": "handed_off",
            },
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["updated"] == 3

    @pytest.mark.asyncio
    async def test_bulk_update_tier(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        lead1 = await _seed_lead(db, c.id, "+913333300004", tier="warm")
        lead2 = await _seed_lead(db, c.id, "+913333300005", tier="cold")

        resp = await client.post(
            f"/dashboard/{c.id}/leads/bulk-update",
            headers=admin_headers,
            json={
                "lead_ids": [str(lead1.id), str(lead2.id)],
                "tier": "hot",
            },
        )
        assert resp.status_code == 200
        assert resp.json()["updated"] == 2

    @pytest.mark.asyncio
    async def test_bulk_update_invalid_stage(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        lead = await _seed_lead(db, c.id, "+913333300006")

        resp = await client.post(
            f"/dashboard/{c.id}/leads/bulk-update",
            headers=admin_headers,
            json={
                "lead_ids": [str(lead.id)],
                "stage": "invalid_stage",
            },
        )
        assert resp.status_code == 400

    @pytest.mark.asyncio
    async def test_bulk_update_invalid_tier(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        lead = await _seed_lead(db, c.id, "+913333300007")

        resp = await client.post(
            f"/dashboard/{c.id}/leads/bulk-update",
            headers=admin_headers,
            json={
                "lead_ids": [str(lead.id)],
                "tier": "super_hot",
            },
        )
        assert resp.status_code == 400

    @pytest.mark.asyncio
    async def test_bulk_update_empty_fields(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        lead = await _seed_lead(db, c.id, "+913333300008")

        resp = await client.post(
            f"/dashboard/{c.id}/leads/bulk-update",
            headers=admin_headers,
            json={"lead_ids": [str(lead.id)]},
        )
        assert resp.status_code == 400

    @pytest.mark.asyncio
    async def test_bulk_update_nonexistent_leads(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        fake_ids = [str(uuid.uuid4()), str(uuid.uuid4())]
        resp = await client.post(
            f"/dashboard/{c.id}/leads/bulk-update",
            headers=admin_headers,
            json={"lead_ids": fake_ids, "stage": "lost"},
        )
        assert resp.status_code == 200
        assert resp.json()["updated"] == 0  # no leads matched

    @pytest.mark.asyncio
    async def test_bulk_update_multi_tenant_isolation(self, client, admin_headers, db):
        """Bulk update should only affect leads belonging to the specified client."""
        c1 = _make_client(client_name="Client 1")
        c2 = _make_client(client_name="Client 2")
        db.add_all([c1, c2])
        await db.flush()

        lead_c1 = await _seed_lead(db, c1.id, "+913333300009", stage="qualifying")
        lead_c2 = await _seed_lead(db, c2.id, "+913333300010", stage="qualifying")

        # Try to update c2's lead via c1's endpoint
        resp = await client.post(
            f"/dashboard/{c1.id}/leads/bulk-update",
            headers=admin_headers,
            json={"lead_ids": [str(lead_c2.id)], "stage": "handed_off"},
        )
        assert resp.status_code == 200
        assert resp.json()["updated"] == 0  # c2's lead NOT updated


# ═══════════════════════════════════════════════════════════════════════════════
# ACTIVITY FEED TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestActivityFeed:
    @pytest.mark.asyncio
    async def test_activity_feed_returns_messages(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        await _seed_full_lead(db, c.id, "+914444400001", name="Alpha Lead")
        await _seed_full_lead(db, c.id, "+914444400002", name="Beta Lead")

        resp = await client.get(
            f"/dashboard/{c.id}/activity", headers=admin_headers,
        )
        assert resp.status_code == 200
        data = resp.json()

        assert data["count"] == 4  # 2 leads × 2 messages each
        # Each activity has lead info
        for a in data["activity"]:
            assert "lead_phone" in a
            assert "lead_name" in a
            assert "direction" in a
            assert "content" in a
            assert "timestamp" in a

    @pytest.mark.asyncio
    async def test_activity_feed_respects_limit(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        # Seed 3 leads with 2 msgs each = 6 total
        await _seed_full_lead(db, c.id, "+914444400003")
        await _seed_full_lead(db, c.id, "+914444400004")
        await _seed_full_lead(db, c.id, "+914444400005")

        resp = await client.get(
            f"/dashboard/{c.id}/activity?limit=2", headers=admin_headers,
        )
        assert resp.status_code == 200
        assert resp.json()["count"] == 2

    @pytest.mark.asyncio
    async def test_activity_feed_empty(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        resp = await client.get(
            f"/dashboard/{c.id}/activity", headers=admin_headers,
        )
        assert resp.status_code == 200
        assert resp.json()["activity"] == []
        assert resp.json()["count"] == 0

    @pytest.mark.asyncio
    async def test_activity_feed_multi_tenant(self, client, admin_headers, db):
        """Activity from client A should NOT appear in client B's feed."""
        c1 = _make_client(client_name="Feed Client A")
        c2 = _make_client(client_name="Feed Client B")
        db.add_all([c1, c2])
        await db.flush()

        await _seed_full_lead(db, c1.id, "+914444400006")
        await _seed_full_lead(db, c2.id, "+914444400007")

        resp1 = await client.get(
            f"/dashboard/{c1.id}/activity", headers=admin_headers,
        )
        resp2 = await client.get(
            f"/dashboard/{c2.id}/activity", headers=admin_headers,
        )

        # Each client should only see their own activity
        phones_1 = {a["lead_phone"] for a in resp1.json()["activity"]}
        phones_2 = {a["lead_phone"] for a in resp2.json()["activity"]}
        assert phones_1 == {"+914444400006"}
        assert phones_2 == {"+914444400007"}


# ═══════════════════════════════════════════════════════════════════════════════
# CSV EXPORT TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestCSVExport:
    @pytest.mark.asyncio
    async def test_export_csv(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        await _seed_lead(db, c.id, "+915555500001", name="CSV Lead 1",
                         tier="hot", score=90, stage="qualified")
        await _seed_lead(db, c.id, "+915555500002", name="CSV Lead 2",
                         tier="warm", score=55, stage="nurturing")

        resp = await client.get(
            f"/dashboard/{c.id}/leads/export", headers=admin_headers,
        )
        assert resp.status_code == 200
        assert "text/csv" in resp.headers["content-type"]
        assert "attachment" in resp.headers["content-disposition"]

        # Parse the CSV
        reader = csv.reader(io.StringIO(resp.text))
        rows = list(reader)

        # Header + 2 data rows
        assert len(rows) == 3
        header = rows[0]
        assert "phone" in header
        assert "name" in header
        assert "tier" in header
        assert "score" in header

        # Data
        phones = {rows[1][header.index("phone")], rows[2][header.index("phone")]}
        assert "+915555500001" in phones
        assert "+915555500002" in phones

    @pytest.mark.asyncio
    async def test_export_csv_with_tier_filter(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        await _seed_lead(db, c.id, "+915555500003", tier="hot", score=85)
        await _seed_lead(db, c.id, "+915555500004", tier="cold", score=15)

        resp = await client.get(
            f"/dashboard/{c.id}/leads/export?tier=hot",
            headers=admin_headers,
        )
        assert resp.status_code == 200

        reader = csv.reader(io.StringIO(resp.text))
        rows = list(reader)
        assert len(rows) == 2  # header + 1 hot lead

    @pytest.mark.asyncio
    async def test_export_csv_empty(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        resp = await client.get(
            f"/dashboard/{c.id}/leads/export", headers=admin_headers,
        )
        assert resp.status_code == 200
        reader = csv.reader(io.StringIO(resp.text))
        rows = list(reader)
        assert len(rows) == 1  # just header


# ═══════════════════════════════════════════════════════════════════════════════
# CONVERSATION EXPORT TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestConversationExport:
    @pytest.mark.asyncio
    async def test_export_text(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        lead = await _seed_lead(db, c.id, "+916666600001")
        conv = await _seed_conversation(db, c.id, lead.id)
        await _seed_message(db, c.id, conv.id, "inbound", "Hi, interested in flat")
        await _seed_message(db, c.id, conv.id, "outbound", "Welcome! Budget?")
        await _seed_message(db, c.id, conv.id, "inbound", "80 lakh")

        resp = await client.get(
            f"/dashboard/{c.id}/conversations/{conv.id}/export?format=text",
            headers=admin_headers,
        )
        assert resp.status_code == 200
        assert "text/plain" in resp.headers["content-type"]

        text = resp.text
        assert "Lead: Hi, interested in flat" in text
        assert "Bot: Welcome! Budget?" in text
        assert "Lead: 80 lakh" in text

    @pytest.mark.asyncio
    async def test_export_json(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        lead = await _seed_lead(db, c.id, "+916666600002")
        conv = await _seed_conversation(db, c.id, lead.id)
        await _seed_message(db, c.id, conv.id, "inbound", "Hello")
        await _seed_message(db, c.id, conv.id, "outbound", "Hi!")

        resp = await client.get(
            f"/dashboard/{c.id}/conversations/{conv.id}/export?format=json",
            headers=admin_headers,
        )
        assert resp.status_code == 200
        data = resp.json()
        assert len(data["messages"]) == 2
        assert data["messages"][0]["direction"] == "inbound"
        assert data["messages"][1]["direction"] == "outbound"

    @pytest.mark.asyncio
    async def test_export_empty_conversation(self, client, admin_headers, db):
        c = _make_client()
        db.add(c)
        await db.flush()

        fake_conv = str(uuid.uuid4())
        resp = await client.get(
            f"/dashboard/{c.id}/conversations/{fake_conv}/export",
            headers=admin_headers,
        )
        assert resp.status_code == 404


# ═══════════════════════════════════════════════════════════════════════════════
# AUTH TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestDashboardAuth:
    @pytest.mark.asyncio
    async def test_missing_admin_key(self, client):
        fake_id = str(uuid.uuid4())
        resp = await client.get(f"/dashboard/{fake_id}/home")
        assert resp.status_code == 403

    @pytest.mark.asyncio
    async def test_wrong_admin_key(self, client):
        fake_id = str(uuid.uuid4())
        resp = await client.get(
            f"/dashboard/{fake_id}/home",
            headers={"x-admin-key": "wrong"},
        )
        assert resp.status_code == 403
