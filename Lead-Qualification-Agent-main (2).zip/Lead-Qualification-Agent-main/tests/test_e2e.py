"""
End-to-end integration tests — full pipeline with mocked LLM + Redis.

These tests prove the ENTIRE pipeline works:
  webhook payload → parse → dedup → tenant → lead → consent → conversation
  → save inbound → RAG → engine (mocked LLM) → persist → save outbound

No Claude API key needed. No Redis needed. Only a test PostgreSQL.

Test matrix:
  1. Hot lead (4-turn Hinglish) → score ≥ 70, billing event written
  2. Cold lead ("just browsing") → score < 40, no billing
  3. Voice note → "please send text" reply
  4. Consent written on first message, not duplicated on second
  5. All messages saved with correct client_id
  6. Multi-tenant isolation — two clients don't see each other's leads
  7. Full 6-turn Hinglish journey with RAG + eval judges
"""
import uuid
from unittest.mock import patch, AsyncMock, MagicMock

import pytest
import pytest_asyncio
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from src.db.tables import (
    ClientConfig, Lead, Message, BillingEvent,
    ConsentLog, Conversation,
)
from src.channels.router import MessageRouter


# ── Test client data ─────────────────────────────────────────────────────────

WABA_PHONE_ID = "E2E_TEST_PHONE_ID"
LEAD_PHONE = "919999900000"


def _make_client_config(client_id: uuid.UUID | None = None,
                        waba_phone_id: str = WABA_PHONE_ID) -> ClientConfig:
    """Create a test ClientConfig row with a unique ID per call."""
    cid = client_id or uuid.uuid4()
    return ClientConfig(
        id=cid,
        client_name="E2E Test Realty",
        waba_number=f"+91{uuid.uuid4().hex[:10]}",  # unique per call
        waba_phone_number_id=waba_phone_id,
        waba_token="test_token",
        project_ids=[],
        prompt_overrides={},
        language_config={
            "primary_language": "hinglish",
            "formality_level": "formal",
            "hindi_pronoun": "aap",
        },
        broker_wa_numbers=["+919820099999"],
        active=True,
    )


def _make_payload(text: str, turn: int, message_type: str = "text",
                  media_id: str | None = None,
                  waba_phone_id: str = WABA_PHONE_ID,
                  sender_phone: str = LEAD_PHONE) -> dict:
    """Build a WhatsApp Cloud API webhook payload."""
    msg = {
        "from": sender_phone,
        "id": f"wamid.e2e_turn_{turn}_{uuid.uuid4().hex[:8]}",
        "timestamp": "1716500000",
        "type": message_type,
    }
    if message_type == "text":
        msg["text"] = {"body": text}
    elif message_type == "audio":
        msg["audio"] = {"id": media_id or "audio_123"}

    return {
        "object": "whatsapp_business_account",
        "entry": [{
            "id": "WABA_ID",
            "changes": [{
                "value": {
                    "messaging_product": "whatsapp",
                    "metadata": {
                        "display_phone_number": "+919820011111",
                        "phone_number_id": waba_phone_id,
                    },
                    "messages": [msg],
                    "contacts": [{
                        "profile": {"name": "Test Lead"},
                        "wa_id": sender_phone,
                    }],
                },
                "field": "messages",
            }],
        }],
    }


# ── Fixtures ─────────────────────────────────────────────────────────────────

@pytest_asyncio.fixture
async def seeded_db(db: AsyncSession):
    """DB session with a test client already inserted. Returns (db, client_id, waba_phone_id)."""
    # Each test gets a unique waba_phone_id to avoid collision with other tests
    unique_waba = f"E2E_WABA_{uuid.uuid4().hex[:10]}"
    client = _make_client_config(waba_phone_id=unique_waba)
    db.add(client)
    await db.commit()
    await db.refresh(client)
    return db, client.id, client.waba_phone_number_id


@pytest.fixture
def mock_dedup():
    """Mock Redis dedup to always return False (not duplicate)."""
    with patch("src.channels.router.is_duplicate", new_callable=AsyncMock, return_value=False) as m:
        yield m


@pytest.fixture(autouse=True)
def mock_redis_in_tenant():
    """
    Mock the Redis calls inside resolve_client so tests don't need Redis.
    Redis.get returns None (cache miss) → falls through to DB lookup.
    Redis.setex is a no-op.
    """
    mock_redis = AsyncMock()
    mock_redis.get = AsyncMock(return_value=None)  # cache miss → DB fallback
    mock_redis.setex = AsyncMock()
    with patch("src.core.tenant._get_redis", return_value=mock_redis):
        yield mock_redis


@pytest.fixture
def mock_whatsapp():
    """Mock WhatsApp send + mark_as_read + rate limit + broker + CRM so no HTTP/Redis calls are made."""
    with patch("src.channels.router.WhatsAppChannel.send_message", new_callable=AsyncMock) as send, \
         patch("src.channels.router.WhatsAppChannel.mark_as_read", new_callable=AsyncMock) as read, \
         patch("src.channels.router.notify_brokers", new_callable=AsyncMock) as _broker, \
         patch("src.channels.router.sync_lead_to_crm", new_callable=AsyncMock) as _crm, \
         patch("src.channels.router.check_rate_limit", new_callable=AsyncMock, return_value=True) as _rate:
        yield send, read


def _mock_graph_invoke_hot(state, config):
    """
    Simulate what the LangGraph engine returns for a HOT lead.

    This is what graph.invoke() returns after processing all nodes.
    In production, each node (language_detector, greeter, qualifier, scorer)
    runs sequentially and modifies the state dict.

    We simulate the FINAL output — as if the lead provided budget, timeline,
    location, and financing (= score 90, tier hot).
    """
    messages = list(state.get("messages", []))
    messages.append({
        "role": "assistant",
        "content": "Bahut accha! Aapke liye best options dhundhte hain.",
    })

    return {
        **state,
        "messages": messages,
        "lead": {
            **state.get("lead", {}),
            "score": 90,
            "tier": "hot",
            "stage": "qualified",
            "intent": "buyer",
            "language_pref": "hinglish",
            "budget_min": 7_000_000,
            "budget_max": 9_000_000,
            "timeline_months": 2,
            "urgency": "1_3_months",
            "financing_status": "loan_approved",
            "location_preferences": ["Whitefield"],
            "property_type": "apartment",
            "family_size": 4,
        },
        "next_action": "schedule",
        "billing_event": {
            "event_type": "qualified_lead",
            "metadata": {
                "score": 90,
                "tier": "hot",
                "reasoning": "High intent buyer with confirmed financing",
                "reasons": ["budget provided", "urgent timeline", "location specified", "financing confirmed"],
            },
        },
    }


def _mock_graph_invoke_cold(state, config):
    """Simulate what the engine returns for a COLD lead (just browsing)."""
    messages = list(state.get("messages", []))
    messages.append({
        "role": "assistant",
        "content": "No problem! Feel free to reach out whenever you're ready.",
    })

    return {
        **state,
        "messages": messages,
        "lead": {
            **state.get("lead", {}),
            "score": 0,
            "tier": "cold",
            "stage": "qualified",
            "intent": "browsing",
        },
        "next_action": "handoff",
        "billing_event": None,
    }


# ── Test: HOT lead (4-turn Hinglish) ────────────────────────────────────────

@pytest.mark.asyncio
class TestHotLeadE2E:
    """
    Full pipeline: 4 messages → HOT lead → billing event.

    This is the core demo scenario. A Hinglish-speaking buyer provides
    all key info over 4 turns. The scorer assigns score=90 (hot).
    The router writes a billing_event to the DB.
    """

    async def test_hot_lead_full_pipeline(self, seeded_db, mock_dedup, mock_whatsapp):
        db, client_id, waba_phone_id = seeded_db
        send_mock, read_mock = mock_whatsapp

        router = MessageRouter()
        # Mock the compiled graph's invoke method
        router._graph = MagicMock()
        router._graph.invoke = _mock_graph_invoke_hot

        messages = [
            "Hi, mujhe 2BHK chahiye Whitefield mein",
            "Budget 80 lakh ke aaspaas",
            "2 mahine mein shift karna hai",
            "SBI se pre-approval hai",
        ]

        results = []
        for i, msg in enumerate(messages, 1):
            payload = _make_payload(msg, i, waba_phone_id=waba_phone_id)
            result = await router.route_inbound(payload, db)
            results.append(result)

        # ── Assert: no turns were skipped ────────────────────────────────
        for i, r in enumerate(results):
            assert "skipped" not in r, f"Turn {i+1} was skipped: {r}"
            assert r["lead_id"] is not None
            assert r["conversation_id"] is not None

        # All turns should reference the same lead and conversation
        lead_ids = {r["lead_id"] for r in results}
        conv_ids = {r["conversation_id"] for r in results}
        assert len(lead_ids) == 1, "All turns should be the same lead"
        assert len(conv_ids) == 1, "All turns should be the same conversation"

        lead_id = results[0]["lead_id"]

        # ── Assert: Lead scored as HOT ───────────────────────────────────
        lead_result = await db.execute(
            select(Lead).where(Lead.id == lead_id)
        )
        lead = lead_result.scalar_one()

        assert lead.score == 90
        assert lead.tier == "hot"
        assert lead.stage == "qualified"
        assert lead.budget_min == 7_000_000
        assert lead.budget_max == 9_000_000
        assert lead.timeline_months == 2
        assert lead.financing_status == "loan_approved"
        assert lead.location_preferences == ["Whitefield"]
        assert lead.property_type == "apartment"
        assert lead.family_size == 4

        # ── Assert: Billing event written ────────────────────────────────
        billing_result = await db.execute(
            select(BillingEvent).where(
                BillingEvent.client_id == client_id,
                BillingEvent.lead_id == lead_id,
            )
        )
        events = billing_result.scalars().all()
        assert len(events) >= 1, "HOT lead should have at least 1 billing event"

        # Find the qualified_lead event (may have multiple from multiple turns)
        qualified_events = [e for e in events if e.event_type == "qualified_lead"]
        assert len(qualified_events) >= 1
        ev = qualified_events[0]
        assert ev.extra_data["score"] == 90
        assert ev.extra_data["tier"] == "hot"

        # ── Assert: Consent written (first message only) ─────────────────
        consent_result = await db.execute(
            select(ConsentLog).where(
                ConsentLog.client_id == client_id,
                ConsentLog.lead_id == lead_id,
            )
        )
        consents = consent_result.scalars().all()
        assert len(consents) == 1, "Consent should be written once, not per turn"
        assert consents[0].consent_type == "data_collection"
        assert consents[0].source == "first_message"

        # ── Assert: Messages saved ───────────────────────────────────────
        msg_result = await db.execute(
            select(Message).where(Message.client_id == client_id)
        )
        msgs = msg_result.scalars().all()

        # 4 inbound + 4 outbound = 8 messages
        inbound = [m for m in msgs if m.direction == "inbound"]
        outbound = [m for m in msgs if m.direction == "outbound"]
        assert len(inbound) == 4, f"Expected 4 inbound messages, got {len(inbound)}"
        assert len(outbound) == 4, f"Expected 4 outbound messages, got {len(outbound)}"

        # All messages have correct client_id (multi-tenant check)
        for m in msgs:
            assert str(m.client_id) == str(client_id)

        # ── Assert: WhatsApp API called ──────────────────────────────────
        assert send_mock.call_count == 4, "Should send 4 WhatsApp replies"
        assert read_mock.call_count == 4, "Should mark 4 messages as read"


# ── Test: COLD lead ──────────────────────────────────────────────────────────

@pytest.mark.asyncio
class TestColdLeadE2E:
    """Cold lead: just browsing → score < 40, no billing event."""

    async def test_cold_lead_no_billing(self, seeded_db, mock_dedup, mock_whatsapp):
        db, client_id, waba_phone_id = seeded_db
        send_mock, _ = mock_whatsapp

        router = MessageRouter()
        router._graph = MagicMock()
        router._graph.invoke = _mock_graph_invoke_cold

        cold_phone = "919888800000"
        payload = _make_payload("just browsing, no plans", 1,
                                waba_phone_id=waba_phone_id, sender_phone=cold_phone)

        result = await router.route_inbound(payload, db)
        assert "skipped" not in result
        lead_id = result["lead_id"]

        # Lead should be cold
        lead_result = await db.execute(select(Lead).where(Lead.id == lead_id))
        lead = lead_result.scalar_one()
        assert lead.score == 0
        assert lead.tier == "cold"

        # No billing event for cold leads
        billing_result = await db.execute(
            select(BillingEvent).where(
                BillingEvent.client_id == client_id,
                BillingEvent.lead_id == lead_id,
            )
        )
        assert billing_result.scalars().first() is None, "Cold leads should NOT have billing events"


# ── Test: Voice note handling ────────────────────────────────────────────────

@pytest.mark.asyncio
class TestVoiceNoteE2E:
    """Voice note → "please send text" reply, no engine invocation."""

    async def test_voice_note_returns_text_prompt(self, seeded_db, mock_dedup, mock_whatsapp):
        db, client_id, waba_phone_id = seeded_db
        send_mock, _ = mock_whatsapp

        router = MessageRouter()
        # Note: we don't mock the graph because voice notes should NOT invoke it
        router._graph = MagicMock()

        voice_phone = "919777700000"
        payload = _make_payload("", 1, message_type="audio", media_id="audio_test_123",
                                waba_phone_id=waba_phone_id, sender_phone=voice_phone)

        result = await router.route_inbound(payload, db)

        assert "skipped" not in result
        assert "text" in result["response"].lower()

        # Graph should NOT have been invoked
        router._graph.invoke.assert_not_called()

        # WhatsApp send should still be called (to reply with "send text" message)
        assert send_mock.call_count == 1


# ── Test: Consent idempotency ────────────────────────────────────────────────

@pytest.mark.asyncio
class TestConsentE2E:
    """Consent written once on first message, not duplicated on subsequent."""

    async def test_consent_not_duplicated(self, seeded_db, mock_dedup, mock_whatsapp):
        db, client_id, waba_phone_id = seeded_db
        send_mock, _ = mock_whatsapp

        router = MessageRouter()
        router._graph = MagicMock()
        router._graph.invoke = _mock_graph_invoke_cold  # doesn't matter which mock

        consent_phone = "919666600000"
        for turn in range(1, 4):
            payload = _make_payload(f"message {turn}", turn,
                                    waba_phone_id=waba_phone_id, sender_phone=consent_phone)
            await router.route_inbound(payload, db)

        # Find the lead
        lead_result = await db.execute(
            select(Lead).where(Lead.client_id == client_id, Lead.phone == consent_phone)
        )
        lead = lead_result.scalar_one()

        # Count consent records — should be exactly 1
        consent_count = await db.execute(
            select(func.count(ConsentLog.id)).where(
                ConsentLog.client_id == client_id,
                ConsentLog.lead_id == lead.id,
            )
        )
        assert consent_count.scalar() == 1, "Consent should be recorded exactly once"


# ── Test: Multi-tenant isolation ─────────────────────────────────────────────

@pytest.mark.asyncio
class TestMultiTenantE2E:
    """Two clients can't see each other's leads or messages."""

    async def test_tenant_isolation(self, db: AsyncSession, mock_dedup, mock_whatsapp):
        send_mock, _ = mock_whatsapp

        # Create two separate clients with unique WABA phone IDs
        client_a_id = uuid.uuid4()
        client_b_id = uuid.uuid4()
        waba_a = f"TENANT_A_{uuid.uuid4().hex[:6]}"
        waba_b = f"TENANT_B_{uuid.uuid4().hex[:6]}"

        client_a = _make_client_config(client_id=client_a_id, waba_phone_id=waba_a)
        client_a.client_name = "Tenant A"
        client_b = _make_client_config(client_id=client_b_id, waba_phone_id=waba_b)
        client_b.client_name = "Tenant B"

        db.add_all([client_a, client_b])
        await db.commit()

        router = MessageRouter()
        router._graph = MagicMock()
        router._graph.invoke = _mock_graph_invoke_cold

        shared_phone = "919555500000"

        # Message from shared_phone to Tenant A
        payload_a = _make_payload("Hello A", 1, waba_phone_id=waba_a, sender_phone=shared_phone)
        result_a = await router.route_inbound(payload_a, db)

        # Message from shared_phone to Tenant B
        payload_b = _make_payload("Hello B", 2, waba_phone_id=waba_b, sender_phone=shared_phone)
        result_b = await router.route_inbound(payload_b, db)

        # Different leads should be created (same phone, different clients)
        assert result_a["lead_id"] != result_b["lead_id"], \
            "Same phone number under different clients must create separate leads"

        # Verify in DB: two distinct lead rows
        leads_a = await db.execute(
            select(Lead).where(Lead.client_id == client_a_id, Lead.phone == shared_phone)
        )
        leads_b = await db.execute(
            select(Lead).where(Lead.client_id == client_b_id, Lead.phone == shared_phone)
        )
        assert leads_a.scalar_one() is not None
        assert leads_b.scalar_one() is not None

        # Messages scoped by client_id
        msgs_a = await db.execute(
            select(Message).where(Message.client_id == client_a_id)
        )
        msgs_b = await db.execute(
            select(Message).where(Message.client_id == client_b_id)
        )
        a_msgs = msgs_a.scalars().all()
        b_msgs = msgs_b.scalars().all()

        # Each should have their own messages
        for m in a_msgs:
            assert str(m.client_id) == str(client_a_id)
        for m in b_msgs:
            assert str(m.client_id) == str(client_b_id)


# ── Test: Dedup skips duplicate messages ─────────────────────────────────────

@pytest.mark.asyncio
class TestDedupE2E:
    """Duplicate message_id should be skipped."""

    async def test_duplicate_skipped(self, seeded_db, mock_whatsapp):
        db, client_id, waba_phone_id = seeded_db

        router = MessageRouter()
        router._graph = MagicMock()
        router._graph.invoke = _mock_graph_invoke_cold

        payload = _make_payload("test dedup", 1, waba_phone_id=waba_phone_id)

        # First call: dedup returns False (not duplicate) → processes
        with patch("src.channels.router.is_duplicate", new_callable=AsyncMock, return_value=False):
            result1 = await router.route_inbound(payload, db)
        assert "skipped" not in result1

        # Second call: dedup returns True (duplicate) → skipped
        with patch("src.channels.router.is_duplicate", new_callable=AsyncMock, return_value=True):
            result2 = await router.route_inbound(payload, db)
        assert result2.get("skipped") is True
        assert result2.get("reason") == "duplicate"


# ── Test: Status update / unparseable payload ────────────────────────────────

@pytest.mark.asyncio
class TestPayloadEdgeCases:
    """Non-message webhooks (status updates, etc.) are ignored gracefully."""

    async def test_status_update_skipped(self, seeded_db, mock_dedup, mock_whatsapp):
        db, client_id, waba_phone_id = seeded_db
        router = MessageRouter()

        # Status update payload (no "messages" key)
        status_payload = {
            "object": "whatsapp_business_account",
            "entry": [{
                "id": "WABA_ID",
                "changes": [{
                    "value": {
                        "messaging_product": "whatsapp",
                        "metadata": {
                            "display_phone_number": "+919820011111",
                            "phone_number_id": waba_phone_id,
                        },
                        "statuses": [{
                            "id": "wamid.status_123",
                            "status": "delivered",
                            "timestamp": "1716500000",
                        }],
                    },
                    "field": "messages",
                }],
            }],
        }

        result = await router.route_inbound(status_payload, db)
        assert result.get("skipped") is True
        assert result.get("reason") == "status_update_or_unparseable"

    async def test_empty_payload_skipped(self, seeded_db, mock_dedup, mock_whatsapp):
        db, client_id, waba_phone_id = seeded_db
        router = MessageRouter()

        result = await router.route_inbound({}, db)
        assert result.get("skipped") is True


# ── Test: Full 6-turn Hinglish journey with RAG + evals ───────────────────

def _mock_graph_invoke_hinglish_journey(state, config):
    """
    Simulate the LangGraph engine for a 6-turn Hinglish buyer.

    Each turn returns progressively richer lead data. The final state
    includes RAG-sourced pricing info, hinglish language, all fields
    populated, score=88, tier=hot, and a billing event.
    """
    messages = list(state.get("messages", []))
    rag_context = state.get("rag_context", [])
    turn = len([m for m in messages if m.get("role") == "user"])

    # RAG-enriched reply on the last turn (brochure pricing)
    if rag_context:
        reply = (
            "Prestige Sunrise Park mein 2BHK ka price ₹72 lakh se shuru hai. "
            "Swimming pool, gym, aur clubhouse bhi hai. "
            "Carpet area approximately 950 sq ft hai. "
            "Kya aap site visit karna chahenge?"
        )
    else:
        reply = "Bahut accha! Aapke liye Whitefield mein 2BHK dhundhte hain."

    messages.append({"role": "assistant", "content": reply})

    return {
        **state,
        "messages": messages,
        "lead": {
            **state.get("lead", {}),
            "score": 88,
            "tier": "hot",
            "stage": "qualified",
            "intent": "buyer",
            "language_pref": "hinglish",
            "budget_min": 7_000_000,
            "budget_max": 9_000_000,
            "timeline_months": 2,
            "urgency": "1_3_months",
            "financing_status": "loan_approved",
            "location_preferences": ["Whitefield"],
            "property_type": "apartment",
            "family_size": 3,
        },
        "language": "hinglish",
        "next_action": "schedule",
        "billing_event": {
            "event_type": "qualified_lead",
            "metadata": {
                "score": 88,
                "tier": "hot",
                "reasoning": "Hinglish buyer, pre-approved loan, budget + timeline confirmed",
                "reasons": [
                    "budget provided", "urgent timeline",
                    "location specified", "financing confirmed",
                ],
            },
        },
    }


@pytest.mark.asyncio
class TestFullJourneyE2E:
    """
    Full 6-turn Hinglish journey with RAG and eval judges.

    Build plan Chunk 13 spec:
      a. Seed client with brochure
      b. Simulate 6 turns of Hinglish conversation
      c. Assert: language = hinglish
      d. Assert: all LeadProfile fields populated
      e. Assert: score > 70, tier = hot
      f. Assert: billing_event for qualified_lead
      g. Assert: consent_log written
      h. Assert: RAG response contains pricing from brochure
      i. Assert: eval judges score > 0.7 (mocked LLM for naturalness)
    """

    async def test_six_turn_hinglish_journey(self, seeded_db, mock_dedup, mock_whatsapp):
        db, client_id, waba_phone_id = seeded_db
        send_mock, read_mock = mock_whatsapp

        router = MessageRouter()
        router._graph = MagicMock()
        router._graph.invoke = _mock_graph_invoke_hinglish_journey

        # 6-turn Hinglish conversation per build plan spec
        turns = [
            "Hi, mujhe flat chahiye",
            "Whitefield mein, 2BHK",
            "Budget 80 lakh ke aaspaas",
            "2 mahine mein shift karna hai",
            "SBI se loan approved hai",
            "Prestige Sunrise ka price kya hai?",  # ← triggers RAG
        ]

        # Mock RAG: should_trigger_rag returns True for the last turn,
        # rag_search returns brochure pricing chunks
        rag_chunks = [
            "Prestige Sunrise Park: 2BHK starts from ₹72 Lakh. Carpet area 950 sq ft.",
            "Amenities: Swimming pool, gym, clubhouse, landscaped gardens.",
        ]

        results = []
        for i, msg in enumerate(turns, 1):
            # RAG triggers only on last message (brochure query)
            trigger_rag = (i == len(turns))

            with patch("src.channels.router.should_trigger_rag", return_value=trigger_rag), \
                 patch("src.channels.router.rag_search", new_callable=AsyncMock,
                       return_value=rag_chunks if trigger_rag else []):
                payload = _make_payload(msg, i, waba_phone_id=waba_phone_id)
                result = await router.route_inbound(payload, db)
                results.append(result)

        # ── (a) No turns skipped ──────────────────────────────────────
        for i, r in enumerate(results):
            assert "skipped" not in r, f"Turn {i+1} was skipped: {r}"

        # All turns → same lead + conversation
        lead_ids = {r["lead_id"] for r in results}
        conv_ids = {r["conversation_id"] for r in results}
        assert len(lead_ids) == 1, "All 6 turns should reference the same lead"
        assert len(conv_ids) == 1, "All 6 turns should reference the same conversation"

        lead_id = results[0]["lead_id"]

        # ── (c) Language = hinglish ───────────────────────────────────
        lead_result = await db.execute(
            select(Lead).where(Lead.id == lead_id)
        )
        lead = lead_result.scalar_one()
        assert lead.language_pref == "hinglish"

        # ── (d) All LeadProfile fields populated ──────────────────────
        assert lead.intent == "buyer"
        assert lead.property_type == "apartment"
        assert lead.location_preferences == ["Whitefield"]
        assert lead.budget_min == 7_000_000
        assert lead.budget_max == 9_000_000
        assert lead.timeline_months == 2
        assert lead.financing_status == "loan_approved"
        assert lead.family_size == 3

        # ── (e) Score > 70, tier = hot ────────────────────────────────
        assert lead.score > 70, f"Expected score > 70, got {lead.score}"
        assert lead.tier == "hot"
        assert lead.stage == "qualified"

        # ── (f) Billing event for qualified_lead ──────────────────────
        billing_result = await db.execute(
            select(BillingEvent).where(
                BillingEvent.client_id == client_id,
                BillingEvent.lead_id == lead_id,
            )
        )
        events = billing_result.scalars().all()
        qualified = [e for e in events if e.event_type == "qualified_lead"]
        assert len(qualified) >= 1, "Should have qualified_lead billing event"
        assert qualified[0].extra_data["score"] == 88
        assert qualified[0].extra_data["tier"] == "hot"

        # ── (g) Consent log written (once) ────────────────────────────
        consent_result = await db.execute(
            select(ConsentLog).where(
                ConsentLog.client_id == client_id,
                ConsentLog.lead_id == lead_id,
            )
        )
        consents = consent_result.scalars().all()
        assert len(consents) == 1, "Consent should be written exactly once"
        assert consents[0].consent_type == "data_collection"
        assert consents[0].source == "first_message"

        # ── (h) RAG response contains pricing ─────────────────────────
        last_reply = results[-1]["response"]
        assert "72" in last_reply, f"RAG reply should contain pricing, got: {last_reply}"
        assert "Prestige" in last_reply or "prestige" in last_reply.lower()

        # ── (i) Eval judges score > 0.7 (mocked LLM) ─────────────────
        # Run the eval judges on the final engine result
        from src.evals.runner import evaluate_case

        test_case = {
            "expected_intent": "buyer",
            "expected_budget_min": 7_000_000,
            "expected_budget_max": 9_000_000,
            "expected_tier": "hot",
            "expected_score_range": [70, 100],
            "expected_fields": [
                "intent", "property_type", "location_preferences",
                "budget_min", "timeline_months", "financing_status", "family_size",
            ],
        }
        eval_result = {
            "intent": lead.intent,
            "property_type": lead.property_type,
            "location_preferences": lead.location_preferences,
            "budget_min": lead.budget_min,
            "budget_max": lead.budget_max,
            "timeline_months": lead.timeline_months,
            "financing_status": lead.financing_status,
            "family_size": lead.family_size,
            "score": lead.score,
            "tier": lead.tier,
            "language": lead.language_pref,
            "reply": last_reply,
        }

        # Mock LLM for naturalness + any fuzzy intent checks
        with patch("src.evals.judges.generate", return_value="0.9"):
            scores = evaluate_case(test_case, eval_result)

        for judge_name, score in scores.items():
            assert score >= 0.7, f"Judge {judge_name} scored {score} (expected >= 0.7)"

        # ── Messages saved: 6 inbound + 6 outbound ───────────────────
        msg_result = await db.execute(
            select(Message).where(Message.client_id == client_id)
        )
        msgs = msg_result.scalars().all()
        inbound = [m for m in msgs if m.direction == "inbound"]
        outbound = [m for m in msgs if m.direction == "outbound"]
        assert len(inbound) == 6, f"Expected 6 inbound, got {len(inbound)}"
        assert len(outbound) == 6, f"Expected 6 outbound, got {len(outbound)}"

        # WhatsApp API calls
        assert send_mock.call_count == 6
        assert read_mock.call_count == 6
