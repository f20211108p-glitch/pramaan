"""
Tests for Chunk 12 — Eval judges, runner, and tracing decorators.
All LLM calls are mocked — no real Anthropic tokens consumed.
"""
import json
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest


# ═══════════════════════════════════════════════════════════════════════════════
# Test: Tracing decorators
# ═══════════════════════════════════════════════════════════════════════════════

class TestTracing:
    """Test @trace_node and @trace_llm decorators."""

    def test_trace_node_passthrough_when_langfuse_disabled(self):
        """Decorator should be transparent when Langfuse is not configured."""
        from src.core.tracing import trace_node

        @trace_node("test_node")
        def my_node(state):
            return {"reply": "hello", "language": "english"}

        state = {
            "lead": {"id": "l1"},
            "client_config": {"id": "c1"},
            "language": "english",
            "turn_count": 1,
            "messages": [],
        }
        result = my_node(state)
        assert result["reply"] == "hello"

    def test_trace_llm_passthrough_when_langfuse_disabled(self):
        """Decorator should be transparent when Langfuse is not configured."""
        from src.core.tracing import trace_llm

        @trace_llm("test_call")
        def my_llm_call(prompt, text):
            return "classified"

        result = my_llm_call("system", "user text")
        assert result == "classified"

    def test_estimate_cost_inr_sonnet(self):
        """Sonnet cost estimation should match expected rates."""
        from src.core.tracing import estimate_cost_inr

        # 1000 input + 100 output tokens on Sonnet
        cost = estimate_cost_inr("claude-sonnet-4-5", 1000, 100)
        # (1000 * 291 + 100 * 1455) / 1_000_000 = 0.291 + 0.1455 = 0.4365
        assert abs(cost - 0.4365) < 0.001

    def test_estimate_cost_inr_haiku(self):
        """Haiku cost estimation should match expected rates."""
        from src.core.tracing import estimate_cost_inr

        cost = estimate_cost_inr("claude-haiku-4-5", 1000, 100)
        # (1000 * 97 + 100 * 485) / 1_000_000 = 0.097 + 0.0485 = 0.1455
        assert abs(cost - 0.1455) < 0.001

    def test_summarize_state_truncates(self):
        """State summary should truncate long fields."""
        from src.core.tracing import _summarize_state

        state = {
            "messages": [{"role": "user", "text": "hi"}] * 50,
            "rag_context": ["chunk1", "chunk2", "chunk3"],
            "language": "english",
            "lead": {"id": "abc", "name": "Test"},
        }
        summary = _summarize_state(state)
        assert summary["messages"] == "[50 messages]"
        assert summary["rag_context"] == "[3 chunks]"
        assert summary["language"] == "english"


# ═══════════════════════════════════════════════════════════════════════════════
# Test: Individual judges (no LLM calls — deterministic logic only)
# ═══════════════════════════════════════════════════════════════════════════════

class TestIntentAccuracyJudge:
    """Test intent accuracy judge."""

    def test_exact_match_returns_1(self):
        from src.evals.judges import IntentAccuracyJudge

        judge = IntentAccuracyJudge()
        score = judge.evaluate(
            {"expected_intent": "buyer"},
            {"intent": "buyer"},
        )
        assert score == 1.0

    def test_no_expected_returns_1(self):
        from src.evals.judges import IntentAccuracyJudge

        judge = IntentAccuracyJudge()
        score = judge.evaluate({}, {"intent": "buyer"})
        assert score == 1.0

    @patch("src.evals.judges.generate", return_value="0.0")
    def test_mismatch_uses_llm(self, mock_gen):
        from src.evals.judges import IntentAccuracyJudge

        judge = IntentAccuracyJudge()
        score = judge.evaluate(
            {"expected_intent": "seller"},
            {"intent": "buyer"},
        )
        assert score == 0.0
        mock_gen.assert_called_once()


class TestBudgetExtractionJudge:
    """Test budget extraction judge."""

    def test_exact_budget_match(self):
        from src.evals.judges import BudgetExtractionJudge

        judge = BudgetExtractionJudge()
        score = judge.evaluate(
            {"expected_budget_min": 5000000, "expected_budget_max": 7000000},
            {"budget_min": 5000000, "budget_max": 7000000},
        )
        assert score == 1.0

    def test_no_budget_expected_passes(self):
        from src.evals.judges import BudgetExtractionJudge

        judge = BudgetExtractionJudge()
        score = judge.evaluate({}, {"budget_min": None, "budget_max": None})
        assert score == 1.0

    def test_budget_expected_not_extracted(self):
        from src.evals.judges import BudgetExtractionJudge

        judge = BudgetExtractionJudge()
        score = judge.evaluate(
            {"expected_budget_min": 5000000},
            {"budget_min": None, "budget_max": None},
        )
        assert score == 0.0

    def test_close_budget_high_score(self):
        from src.evals.judges import BudgetExtractionJudge

        judge = BudgetExtractionJudge()
        score = judge.evaluate(
            {"expected_budget_min": 5000000, "expected_budget_max": 7000000},
            {"budget_min": 4800000, "budget_max": 7200000},
        )
        # Should be high (close match)
        assert score > 0.9


class TestQualificationCompletenessJudge:
    """Test qualification completeness judge."""

    def test_all_fields_filled(self):
        from src.evals.judges import QualificationCompletenessJudge

        judge = QualificationCompletenessJudge()
        score = judge.evaluate(
            {"expected_fields": ["intent", "property_type", "budget_min"]},
            {"intent": "buyer", "property_type": "apartment", "budget_min": 5000000},
        )
        assert score == 1.0

    def test_no_fields_filled(self):
        from src.evals.judges import QualificationCompletenessJudge

        judge = QualificationCompletenessJudge()
        score = judge.evaluate(
            {"expected_fields": ["intent", "property_type", "budget_min"]},
            {"intent": "unknown", "property_type": "any", "budget_min": None},
        )
        assert score == 0.0

    def test_partial_fields(self):
        from src.evals.judges import QualificationCompletenessJudge

        judge = QualificationCompletenessJudge()
        score = judge.evaluate(
            {"expected_fields": ["intent", "property_type", "budget_min", "timeline_months"]},
            {"intent": "buyer", "property_type": "apartment", "budget_min": None, "timeline_months": None},
        )
        assert score == 0.5  # 2 out of 4


class TestHandoffTimingJudge:
    """Test handoff timing judge."""

    def test_exact_tier_match(self):
        from src.evals.judges import HandoffTimingJudge

        judge = HandoffTimingJudge()
        score = judge.evaluate(
            {"expected_tier": "hot", "expected_score_range": [70, 100]},
            {"tier": "hot", "score": 85},
        )
        assert score == 1.0

    def test_adjacent_tier_penalty(self):
        from src.evals.judges import HandoffTimingJudge

        judge = HandoffTimingJudge()
        score = judge.evaluate(
            {"expected_tier": "hot"},
            {"tier": "warm"},
        )
        assert score == 0.5  # one tier off

    def test_opposite_tier_low_score(self):
        from src.evals.judges import HandoffTimingJudge

        judge = HandoffTimingJudge()
        score = judge.evaluate(
            {"expected_tier": "hot"},
            {"tier": "cold"},
        )
        assert score == 0.0  # two tiers off

    def test_score_in_range(self):
        from src.evals.judges import HandoffTimingJudge

        judge = HandoffTimingJudge()
        score = judge.evaluate(
            {"expected_score_range": [70, 100]},
            {"score": 85},
        )
        assert score == 1.0

    def test_score_out_of_range(self):
        from src.evals.judges import HandoffTimingJudge

        judge = HandoffTimingJudge()
        score = judge.evaluate(
            {"expected_score_range": [70, 100]},
            {"score": 30},
        )
        assert score < 0.5


class TestConversationNaturalnessJudge:
    """Test conversation naturalness judge (mocked LLM)."""

    @patch("src.evals.judges.generate", return_value="0.85")
    def test_naturalness_returns_llm_score(self, mock_gen):
        from src.evals.judges import ConversationNaturalnessJudge

        judge = ConversationNaturalnessJudge()
        score = judge.evaluate(
            {},
            {"reply": "Hello! How can I help you find your dream home?", "language": "english"},
        )
        assert score == 0.85
        mock_gen.assert_called_once()

    def test_empty_reply_returns_0(self):
        from src.evals.judges import ConversationNaturalnessJudge

        judge = ConversationNaturalnessJudge()
        score = judge.evaluate({}, {"reply": "", "language": "english"})
        assert score == 0.0


# ═══════════════════════════════════════════════════════════════════════════════
# Test: Judge registry
# ═══════════════════════════════════════════════════════════════════════════════

class TestJudgeRegistry:
    """Test the ALL_JUDGES registry."""

    def test_all_judges_registered(self):
        from src.evals.judges import ALL_JUDGES

        names = {j.name for j in ALL_JUDGES}
        assert "intent_accuracy" in names
        assert "budget_extraction" in names
        assert "qualification_completeness" in names
        assert "conversation_naturalness" in names
        assert "handoff_timing" in names
        assert len(ALL_JUDGES) == 5

    def test_get_judge(self):
        from src.evals.judges import get_judge

        j = get_judge("intent_accuracy")
        assert j is not None
        assert j.name == "intent_accuracy"

        assert get_judge("nonexistent") is None

    def test_all_judges_return_0_to_1(self):
        """Every judge should return a score in [0, 1] for basic inputs."""
        from src.evals.judges import ALL_JUDGES

        test_case = {
            "expected_intent": "buyer",
            "expected_budget_min": 5000000,
            "expected_budget_max": 7000000,
            "expected_tier": "hot",
            "expected_score_range": [70, 100],
            "expected_fields": ["intent", "property_type"],
        }
        result = {
            "intent": "buyer",
            "property_type": "apartment",
            "budget_min": 5000000,
            "budget_max": 7000000,
            "score": 85,
            "tier": "hot",
            "language": "english",
            "reply": "Great choice!",
        }

        for judge in ALL_JUDGES:
            # Mock the LLM for naturalness judge
            if judge.name == "conversation_naturalness":
                with patch("src.evals.judges.generate", return_value="0.9"):
                    score = judge.evaluate(test_case, result)
            else:
                score = judge.evaluate(test_case, result)
            assert 0.0 <= score <= 1.0, f"{judge.name} returned {score}"


# ═══════════════════════════════════════════════════════════════════════════════
# Test: Dataset loading
# ═══════════════════════════════════════════════════════════════════════════════

class TestDatasetLoading:
    """Test the dataset loader."""

    def test_load_qualification_v1(self):
        from src.evals.runner import load_dataset

        dataset = load_dataset("src/evals/datasets/qualification_v1.json")
        assert len(dataset) == 12
        assert dataset[0]["name"].startswith("1.")

    def test_all_cases_have_required_fields(self):
        from src.evals.runner import load_dataset

        dataset = load_dataset("src/evals/datasets/qualification_v1.json")
        for case in dataset:
            assert "name" in case, f"Case missing name: {case}"
            assert "messages" in case, f"Case missing messages: {case['name']}"
            assert "result" in case, f"Case missing result: {case['name']}"
            assert "expected_intent" in case, f"Case missing expected_intent: {case['name']}"

    def test_load_nonexistent_raises(self):
        from src.evals.runner import load_dataset

        with pytest.raises(FileNotFoundError):
            load_dataset("nonexistent.json")


# ═══════════════════════════════════════════════════════════════════════════════
# Test: Eval runner
# ═══════════════════════════════════════════════════════════════════════════════

class TestEvalRunner:
    """Test the offline eval runner."""

    def test_evaluate_single_case(self):
        """evaluate_case should return scores from all judges."""
        from src.evals.runner import evaluate_case

        test_case = {
            "expected_intent": "buyer",
            "expected_tier": "hot",
            "expected_score_range": [70, 100],
            "expected_fields": ["intent", "property_type"],
        }
        result = {
            "intent": "buyer",
            "property_type": "apartment",
            "score": 85,
            "tier": "hot",
            "language": "english",
            "reply": "Hello!",
        }

        with patch("src.evals.judges.generate", return_value="0.8"):
            scores = evaluate_case(test_case, result)

        assert len(scores) == 5
        for jname, score in scores.items():
            assert 0.0 <= score <= 1.0, f"{jname} = {score}"

    def test_run_offline_eval_on_dataset(self):
        """Runner should process all 12 cases and return aggregate scores."""
        from src.evals.runner import run_offline_eval, load_dataset

        dataset = load_dataset("src/evals/datasets/qualification_v1.json")

        # Mock LLM calls for naturalness and intent fuzzy matching
        with patch("src.evals.judges.generate", return_value="0.8"):
            report = run_offline_eval(dataset)

        assert report["total_cases"] == 12
        assert len(report["aggregate"]) == 5
        assert len(report["per_case"]) == 12

        # All scores should be valid
        for jname, avg in report["aggregate"].items():
            assert 0.0 <= avg <= 1.0, f"Aggregate {jname} = {avg}"

    def test_happy_path_cases_score_high(self):
        """Happy path test cases (1-3) should score > 0.7 on deterministic judges."""
        from src.evals.runner import evaluate_case, load_dataset

        dataset = load_dataset("src/evals/datasets/qualification_v1.json")
        happy_cases = dataset[:3]  # Cases 1, 2, 3

        for case in happy_cases:
            with patch("src.evals.judges.generate", return_value="0.9"):
                scores = evaluate_case(case, case["result"])

            # Deterministic judges should score high
            assert scores["intent_accuracy"] >= 0.7, f"{case['name']}: intent={scores['intent_accuracy']}"
            assert scores["budget_extraction"] >= 0.7, f"{case['name']}: budget={scores['budget_extraction']}"
            assert scores["handoff_timing"] >= 0.7, f"{case['name']}: handoff={scores['handoff_timing']}"

    def test_report_pass_on_good_data(self):
        """Report should pass when all cases have matching results."""
        from src.evals.runner import run_offline_eval, load_dataset

        dataset = load_dataset("src/evals/datasets/qualification_v1.json")

        with patch("src.evals.judges.generate", return_value="0.8"):
            report = run_offline_eval(dataset)

        # With well-crafted test data + mocked naturalness, should pass
        assert report["pass"] is True, f"Report failed: {report['aggregate']}"
