"""Tests for LangGraph — Chunk 1B (updated for Chunk 2B real nodes)."""
from unittest.mock import patch
from src.engine.graph import build_graph, compile_graph, make_state_key
from src.engine.state import QualificationState


def test_graph_compiles_without_errors():
    graph = compile_graph()
    assert graph is not None


def test_graph_has_all_nodes():
    graph = build_graph()
    node_names = set(graph.nodes.keys())
    expected = {
        "language_detector", "greeter", "intent_detector",
        "qualifier", "scorer", "scheduler", "nurturer", "handoff",
    }
    assert expected.issubset(node_names), f"Missing nodes: {expected - node_names}"


@patch("src.engine.nodes.qualifier.generate", return_value="What's your budget?")
@patch("src.engine.nodes.qualifier.extract_structured", return_value={"extracted_confidence": 0.5})
@patch("src.engine.nodes.intent_detector.classify", return_value="buyer")
@patch("src.engine.nodes.greeter.generate", return_value="Welcome! How can I help?")
@patch("src.engine.nodes.language_detector.classify", return_value="english")
def test_stub_flow_first_message(mock_lang, mock_greet, mock_intent, mock_extract, mock_qual_gen):
    """First message: language_detector → greeter → intent_detector → qualifier → scorer → nurturer (warm stub)."""
    graph = compile_graph()
    initial_state: QualificationState = {
        "messages": [{"role": "user", "content": "Hi, I want to buy a flat in Andheri"}],
        "lead": {"phone": "919876543210", "client_id": "test-client", "intent": "unknown", "stage": "new"},
        "client_config": {"id": "test-client", "client_name": "Test Builder",
                         "prompt_overrides": {}, "language_config": {}},
        "current_node": "",
        "turn_count": 0,
        "awaiting_info": [],
        "last_extraction": {},
        "should_handoff": False,
        "handoff_reason": None,
        "next_action": None,
        "language": "english",
        "rag_context": [],
        "errors": [],
    }

    result = graph.invoke(initial_state)

    assert result["current_node"] in ("scorer", "nurturer", "handoff", "scheduler")
    assert result["lead"]["stage"] in ("qualified", "nurturing", "handed_off", "scheduling")


def test_state_key_includes_client_id():
    key = make_state_key("client-abc", "919876543210")
    thread_id = key["configurable"]["thread_id"]
    assert "client-abc" in thread_id
    assert "919876543210" in thread_id


def test_state_key_different_clients_different_keys():
    k1 = make_state_key("client-a", "919876543210")
    k2 = make_state_key("client-b", "919876543210")
    assert k1["configurable"]["thread_id"] != k2["configurable"]["thread_id"]


@patch("src.engine.nodes.intent_detector.classify", return_value="seller")
@patch("src.engine.nodes.greeter.generate", return_value="Welcome!")
@patch("src.engine.nodes.language_detector.classify", return_value="english")
def test_seller_intent_goes_to_handoff(mock_lang, mock_greet, mock_intent):
    """Seller intent should route to handoff, not qualifier."""
    graph = compile_graph()
    state: QualificationState = {
        "messages": [{"role": "user", "content": "I want to sell my property"}],
        "lead": {"phone": "91x", "client_id": "c1", "intent": "unknown", "stage": "new"},
        "client_config": {"id": "c1", "client_name": "Test",
                         "prompt_overrides": {}, "language_config": {}},
        "current_node": "",
        "turn_count": 0,
        "awaiting_info": [],
        "last_extraction": {},
        "should_handoff": False,
        "handoff_reason": None,
        "next_action": None,
        "language": "english",
        "rag_context": [],
        "errors": [],
    }

    result = graph.invoke(state)

    assert result["lead"]["stage"] == "handed_off"
    assert result["should_handoff"] is True
