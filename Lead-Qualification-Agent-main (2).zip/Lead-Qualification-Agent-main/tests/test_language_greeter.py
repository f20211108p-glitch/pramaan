"""
Tests for Chunk 2B — Language Detector, Greeter, Intent Detector.
All Claude API calls are mocked — no real API usage during tests.
"""
import pytest
from unittest.mock import patch, MagicMock


# ── Language Detector Tests ──────────────────────────────────────────────────

class TestLanguageDetector:
    """Tests for the language_detector node."""

    def _make_state(self, text: str) -> dict:
        return {
            "messages": [{"role": "user", "content": text}],
            "lead": {"phone": "919111111111", "client_id": "test-client"},
            "client_config": {"id": "test-client", "client_name": "Test Realty"},
            "language": "english",
            "current_node": "",
        }

    @patch("src.engine.nodes.language_detector.classify")
    def test_english_detected(self, mock_classify):
        from src.engine.nodes.language_detector import language_detector
        mock_classify.return_value = "english"
        result = language_detector(self._make_state("I want a 2BHK in Andheri"))
        assert result["language"] == "english"
        assert result["lead"]["language_pref"] == "english"

    @patch("src.engine.nodes.language_detector.classify")
    def test_hinglish_roman_script(self, mock_classify):
        """Roman-script Hindi MUST be 'hinglish', not Italian/Portuguese."""
        from src.engine.nodes.language_detector import language_detector
        mock_classify.return_value = "hinglish"
        result = language_detector(self._make_state("mujhe 2BHK chahiye Andheri mein"))
        assert result["language"] == "hinglish"

    @patch("src.engine.nodes.language_detector.classify")
    def test_hindi_devanagari(self, mock_classify):
        from src.engine.nodes.language_detector import language_detector
        mock_classify.return_value = "hindi"
        result = language_detector(self._make_state("मुझे अंधेरी में 2BHK चाहिए"))
        assert result["language"] == "hindi"

    @patch("src.engine.nodes.language_detector.classify")
    def test_regional_script(self, mock_classify):
        from src.engine.nodes.language_detector import language_detector
        mock_classify.return_value = "regional"
        result = language_detector(self._make_state("எனக்கு ஒரு வீடு வேண்டும்"))
        assert result["language"] == "regional"

    def test_no_user_message_defaults_english(self):
        from src.engine.nodes.language_detector import language_detector
        state = {"messages": [], "lead": {"phone": "919111111111"}}
        result = language_detector(state)
        assert result["language"] == "english"

    @patch("src.engine.nodes.language_detector.classify")
    def test_updates_lead_language_pref(self, mock_classify):
        """language_detector must set lead.language_pref so it persists to DB."""
        from src.engine.nodes.language_detector import language_detector
        mock_classify.return_value = "hinglish"
        result = language_detector(self._make_state("flat dikhao yaar"))
        assert result["lead"]["language_pref"] == "hinglish"


# ── Greeter Tests ────────────────────────────────────────────────────────────

class TestGreeter:
    """Tests for the greeter node."""

    def _make_state(self, text: str, language: str = "english",
                    client_name: str = "Test Realty",
                    prompt_overrides: dict = None,
                    language_config: dict = None) -> dict:
        return {
            "messages": [{"role": "user", "content": text}],
            "lead": {"phone": "919111111111", "client_id": "test-client"},
            "client_config": {
                "id": "test-client",
                "client_name": client_name,
                "prompt_overrides": prompt_overrides or {},
                "language_config": language_config or {},
            },
            "language": language,
            "current_node": "",
            "turn_count": 0,
        }

    @patch("src.engine.nodes.greeter.generate")
    def test_english_greeting(self, mock_generate):
        from src.engine.nodes.greeter import greeter
        mock_generate.return_value = "Welcome to Test Realty! What kind of property are you looking for?"
        result = greeter(self._make_state("Hi"))
        assert result["turn_count"] == 1
        assert len(result["messages"]) == 2  # user + assistant
        assert result["messages"][-1]["role"] == "assistant"
        assert "Test Realty" in result["messages"][-1]["content"]

    @patch("src.engine.nodes.greeter.generate")
    def test_hinglish_greeting(self, mock_generate):
        from src.engine.nodes.greeter import greeter
        mock_generate.return_value = "Hi! Test Realty mein aapka swagat hai 🙏 Kis tarah ki property chahiye?"
        result = greeter(self._make_state("namaste", language="hinglish"))
        assert "swagat" in result["messages"][-1]["content"]

    @patch("src.engine.nodes.greeter.generate")
    def test_formality_passed_to_prompt(self, mock_generate):
        """Client language_config should influence the prompt formatting."""
        from src.engine.nodes.greeter import greeter
        mock_generate.return_value = "Aapka swagat hai!"
        state = self._make_state(
            "hello", language="hinglish",
            language_config={"formality_level": "formal", "hindi_pronoun": "aap"},
        )
        greeter(state)
        # Check that generate was called with a prompt containing "aap"
        call_args = mock_generate.call_args
        system_prompt = call_args.args[0] if call_args.args else call_args.kwargs.get("system_prompt", "")
        assert "aap" in system_prompt

    @patch("src.engine.nodes.greeter.generate")
    def test_casual_formality(self, mock_generate):
        from src.engine.nodes.greeter import greeter
        mock_generate.return_value = "Hey! Kya dhundh raha hai?"
        state = self._make_state(
            "hi bhai", language="hinglish",
            language_config={"formality_level": "casual", "hindi_pronoun": "tum"},
        )
        greeter(state)
        call_args = mock_generate.call_args
        system_prompt = call_args.args[0]
        assert "tum" in system_prompt

    @patch("src.engine.nodes.greeter.generate")
    def test_client_prompt_override(self, mock_generate):
        """Per-client prompt_overrides['greeter'] takes priority over default."""
        from src.engine.nodes.greeter import greeter
        custom_prompt = "You are {client_name}'s custom bot. Say hello. {user_message} {formality} {pronoun}"
        mock_generate.return_value = "Custom hello!"
        state = self._make_state(
            "hi", prompt_overrides={"greeter": custom_prompt},
        )
        greeter(state)
        call_args = mock_generate.call_args
        system_prompt = call_args.args[0]
        assert "custom bot" in system_prompt

    @patch("src.engine.nodes.greeter.generate")
    def test_fallback_when_claude_fails(self, mock_generate):
        """When Claude API call fails (returns ''), use fallback greeting."""
        from src.engine.nodes.greeter import greeter
        mock_generate.return_value = ""  # simulate failure
        result = greeter(self._make_state("hi"))
        assert result["messages"][-1]["role"] == "assistant"
        assert result["messages"][-1]["content"] != ""  # fallback should fire

    @patch("src.engine.nodes.greeter.generate")
    def test_property_info_in_first_message(self, mock_generate):
        """If first message has property details, greeting should acknowledge them."""
        from src.engine.nodes.greeter import greeter
        mock_generate.return_value = "Great! You're looking for a 2BHK in Andheri. What's your budget?"
        result = greeter(self._make_state(
            "I need a 2BHK in Andheri West under 1.5 crore"
        ))
        assert result["messages"][-1]["role"] == "assistant"
        # The user message is passed to Claude, which should acknowledge it
        mock_generate.assert_called_once()


# ── Intent Detector Tests ────────────────────────────────────────────────────

class TestIntentDetector:
    """Tests for the intent_detector node."""

    def _make_state(self, text: str, existing_intent: str = "unknown") -> dict:
        return {
            "messages": [{"role": "user", "content": text}],
            "lead": {
                "phone": "919111111111",
                "client_id": "test-client",
                "intent": existing_intent,
            },
            "current_node": "",
        }

    @patch("src.engine.nodes.intent_detector.classify")
    def test_buyer_intent(self, mock_classify):
        from src.engine.nodes.intent_detector import intent_detector
        mock_classify.return_value = "buyer"
        result = intent_detector(self._make_state("I want to buy a 3BHK"))
        assert result["lead"]["intent"] == "buyer"
        assert result["should_handoff"] is False

    @patch("src.engine.nodes.intent_detector.classify")
    def test_seller_intent_triggers_handoff(self, mock_classify):
        from src.engine.nodes.intent_detector import intent_detector
        mock_classify.return_value = "seller"
        result = intent_detector(self._make_state("I want to sell my flat"))
        assert result["lead"]["intent"] == "seller"
        assert result["should_handoff"] is True
        assert result["handoff_reason"] is not None

    @patch("src.engine.nodes.intent_detector.classify")
    def test_investor_intent(self, mock_classify):
        from src.engine.nodes.intent_detector import intent_detector
        mock_classify.return_value = "investor"
        result = intent_detector(self._make_state("What's the ROI on Worli properties?"))
        assert result["lead"]["intent"] == "investor"
        assert result["should_handoff"] is False

    @patch("src.engine.nodes.intent_detector.classify")
    def test_renter_intent(self, mock_classify):
        from src.engine.nodes.intent_detector import intent_detector
        mock_classify.return_value = "renter"
        result = intent_detector(self._make_state("Looking for a flat on rent in Bandra"))
        assert result["lead"]["intent"] == "renter"

    def test_preserves_existing_intent(self):
        """If intent is already set (not unknown), don't re-classify."""
        from src.engine.nodes.intent_detector import intent_detector
        result = intent_detector(self._make_state("some text", existing_intent="buyer"))
        assert result["lead"]["intent"] == "buyer"

    def test_no_user_message_stays_unknown(self):
        from src.engine.nodes.intent_detector import intent_detector
        state = {
            "messages": [],
            "lead": {"phone": "919111111111", "intent": "unknown"},
        }
        result = intent_detector(state)
        assert result["lead"]["intent"] == "unknown"


# ── LLM Helper Tests ────────────────────────────────────────────────────────

class TestLLMHelper:
    """Tests for src.engine.llm module utilities."""

    def test_load_prompt_exists(self):
        from src.engine.llm import load_prompt
        prompt = load_prompt("language_detect.txt")
        assert "classify" in prompt.lower()
        assert "hinglish" in prompt.lower()

    def test_load_prompt_missing_raises(self):
        from src.engine.llm import load_prompt
        with pytest.raises(FileNotFoundError):
            load_prompt("nonexistent_prompt.txt")

    def test_all_prompt_files_exist(self):
        from src.engine.llm import load_prompt
        for f in ["language_detect.txt", "greeter_en.txt", "greeter_hi.txt",
                   "greeter_hinglish.txt", "intent_detect.txt"]:
            prompt = load_prompt(f)
            assert len(prompt) > 50, f"{f} seems too short"

    @patch("src.engine.llm.get_anthropic_client")
    def test_classify_returns_valid_value(self, mock_client):
        from src.engine.llm import classify
        mock_response = MagicMock()
        mock_response.content = [MagicMock(text="english")]
        mock_client.return_value.messages.create.return_value = mock_response
        result = classify("system", "hello", ["english", "hindi", "hinglish"])
        assert result == "english"

    @patch("src.engine.llm.get_anthropic_client")
    def test_classify_fuzzy_match(self, mock_client):
        """If Claude returns 'The language is english', still match 'english'."""
        from src.engine.llm import classify
        mock_response = MagicMock()
        mock_response.content = [MagicMock(text="The language is english")]
        mock_client.return_value.messages.create.return_value = mock_response
        result = classify("system", "hello", ["english", "hindi"])
        assert result == "english"

    @patch("src.engine.llm.get_anthropic_client")
    def test_classify_fallback_on_garbage(self, mock_client):
        """Unexpected output → fallback to first valid value."""
        from src.engine.llm import classify
        mock_response = MagicMock()
        mock_response.content = [MagicMock(text="qwerty")]
        mock_client.return_value.messages.create.return_value = mock_response
        result = classify("system", "hello", ["english", "hindi"])
        assert result == "english"  # first value = fallback

    @patch("src.engine.llm.get_anthropic_client")
    def test_classify_fallback_on_exception(self, mock_client):
        """API error → fallback to first valid value."""
        from src.engine.llm import classify
        mock_client.return_value.messages.create.side_effect = Exception("API down")
        result = classify("system", "hello", ["english", "hindi"])
        assert result == "english"

    @patch("src.engine.llm.get_anthropic_client")
    def test_generate_returns_text(self, mock_client):
        from src.engine.llm import generate
        mock_response = MagicMock()
        mock_response.content = [MagicMock(text="Welcome to our service!")]
        mock_client.return_value.messages.create.return_value = mock_response
        result = generate("system prompt", "hi")
        assert result == "Welcome to our service!"

    @patch("src.engine.llm.get_anthropic_client")
    def test_generate_returns_empty_on_error(self, mock_client):
        from src.engine.llm import generate
        mock_client.return_value.messages.create.side_effect = Exception("timeout")
        result = generate("system", "hi")
        assert result == ""


# ── Integration: Graph flow with mocked Claude ──────────────────────────────

class TestGraphFlowMocked:
    """Test the full graph flow with Claude calls mocked."""

    @patch("src.engine.nodes.qualifier.generate", return_value="What's your budget?")
    @patch("src.engine.nodes.qualifier.extract_structured", return_value={"extracted_confidence": 0.5})
    @patch("src.engine.nodes.intent_detector.classify")
    @patch("src.engine.nodes.greeter.generate")
    @patch("src.engine.nodes.language_detector.classify")
    def test_full_first_turn_english(self, mock_lang, mock_greet, mock_intent, mock_extract, mock_qual_gen):
        """First turn: language → greeter → intent → qualifier → scorer → nurturer."""
        from src.engine.graph import compile_graph, make_state_key

        mock_lang.return_value = "english"
        mock_greet.return_value = "Welcome! What kind of property are you looking for?"
        mock_intent.return_value = "buyer"

        graph = compile_graph()
        state = {
            "messages": [{"role": "user", "content": "Hi, I want a flat in Mumbai"}],
            "lead": {"phone": "919111111111", "client_id": "c1", "intent": "unknown"},
            "client_config": {"id": "c1", "client_name": "Test Realty",
                             "prompt_overrides": {}, "language_config": {}},
            "current_node": "",
            "turn_count": 0,
            "awaiting_info": [],
            "last_extraction": {},
            "should_handoff": False,
            "handoff_reason": None,
            "next_action": None,
            "language": "english",
            "rag_context": [],
            "errors": [],
        }
        config = make_state_key("c1", "919111111111")
        result = graph.invoke(state, config)

        # Language detected
        assert result["language"] == "english"
        # Greeting was generated
        assert any("Welcome" in m.get("content", "") for m in result["messages"]
                   if m.get("role") == "assistant")
        # Intent classified
        assert result["lead"]["intent"] == "buyer"
        # Turn count set
        assert result["turn_count"] >= 1

    @patch("src.engine.nodes.intent_detector.classify")
    @patch("src.engine.nodes.greeter.generate")
    @patch("src.engine.nodes.language_detector.classify")
    def test_seller_goes_to_handoff(self, mock_lang, mock_greet, mock_intent):
        """Seller intent should route to handoff node."""
        from src.engine.graph import compile_graph, make_state_key

        mock_lang.return_value = "english"
        mock_greet.return_value = "Welcome!"
        mock_intent.return_value = "seller"

        graph = compile_graph()
        state = {
            "messages": [{"role": "user", "content": "I want to sell my flat"}],
            "lead": {"phone": "919111111111", "client_id": "c1", "intent": "unknown"},
            "client_config": {"id": "c1", "client_name": "Test Realty",
                             "prompt_overrides": {}, "language_config": {}},
            "current_node": "",
            "turn_count": 0,
            "awaiting_info": [],
            "last_extraction": {},
            "should_handoff": False,
            "handoff_reason": None,
            "next_action": None,
            "language": "english",
            "rag_context": [],
            "errors": [],
        }
        config = make_state_key("c1", "919111111111")
        result = graph.invoke(state, config)

        assert result["lead"]["intent"] == "seller"
        assert result["should_handoff"] is True
