"""Tests for Pydantic models — Chunk 1B."""
import pytest
from pydantic import ValidationError

from src.models.lead import LeadProfile, LeadScore, Budget, Timeline
from src.models.client import ClientConfig, LanguageConfig
from src.models.billing import BillingEvent
from src.models.message import UnifiedMessage
from src.models.conversation import Conversation


# ── LeadScore tier validation ─────────────────────────────────────────────────

def test_lead_score_hot():
    s = LeadScore(score=80, tier="hot", reasoning="budget + timeline")
    assert s.tier == "hot"


def test_lead_score_warm():
    s = LeadScore(score=50, tier="warm", reasoning="partial info")
    assert s.tier == "warm"


def test_lead_score_cold():
    s = LeadScore(score=20, tier="cold", reasoning="no info")
    assert s.tier == "cold"


def test_lead_score_boundary_hot():
    s = LeadScore(score=70, tier="hot")
    assert s.tier == "hot"


def test_lead_score_boundary_warm():
    s = LeadScore(score=40, tier="warm")
    assert s.tier == "warm"


def test_lead_score_tier_mismatch_raises():
    with pytest.raises(ValidationError, match="does not match score"):
        LeadScore(score=80, tier="cold")


def test_lead_score_tier_mismatch_warm_for_hot():
    with pytest.raises(ValidationError, match="does not match score"):
        LeadScore(score=75, tier="warm")


# ── LeadProfile ───────────────────────────────────────────────────────────────

def test_lead_profile_minimal():
    lead = LeadProfile(phone="919876543210", client_id="abc-123")
    assert lead.phone == "919876543210"
    assert lead.client_id == "abc-123"
    assert lead.intent == "unknown"
    assert lead.stage == "new"
    assert lead.budget_min is None
    assert lead.location_preferences == []


def test_lead_profile_missing_fields():
    lead = LeadProfile(phone="919876543210", client_id="abc-123")
    missing = lead.missing_fields()
    assert "budget" in missing
    assert "timeline" in missing
    assert "location" in missing
    assert "intent" in missing


def test_lead_profile_no_missing_fields_when_filled():
    lead = LeadProfile(
        phone="919876543210",
        client_id="abc-123",
        intent="buyer",
        budget_min=5000000,
        timeline_months=6,
        location_preferences=["Andheri"],
        property_type="apartment",
        financing_status="pre_approved",
    )
    assert lead.missing_fields() == []


def test_lead_profile_compute_tier():
    lead = LeadProfile(phone="91x", client_id="c", score=85)
    assert lead.compute_tier() == "hot"

    lead.score = 55
    assert lead.compute_tier() == "warm"

    lead.score = 10
    assert lead.compute_tier() == "cold"

    lead.score = None
    assert lead.compute_tier() is None


# ── ClientConfig ──────────────────────────────────────────────────────────────

def test_client_config_language_defaults():
    cfg = ClientConfig(
        id="c1",
        client_name="Test",
        waba_number="91123",
        waba_phone_number_id="pn1",
        waba_token="tok",
    )
    assert cfg.language_config.primary_language == "english"
    assert cfg.language_config.formality_level == "formal"
    assert cfg.language_config.hindi_pronoun == "aap"
    assert cfg.language_config.regional_languages == []


def test_client_config_custom_language():
    cfg = ClientConfig(
        id="c1",
        client_name="Test",
        waba_number="91123",
        waba_phone_number_id="pn1",
        waba_token="tok",
        language_config=LanguageConfig(
            primary_language="hinglish",
            formality_level="casual",
            hindi_pronoun="tum",
        ),
    )
    assert cfg.language_config.primary_language == "hinglish"
    assert cfg.language_config.hindi_pronoun == "tum"


# ── BillingEvent ──────────────────────────────────────────────────────────────

def test_billing_event_serialization():
    event = BillingEvent(
        id="ev1",
        client_id="c1",
        lead_id="l1",
        event_type="qualified_lead",
        amount_inr=500,
        metadata={"score": 80, "tier": "hot"},
    )
    data = event.model_dump()
    assert data["event_type"] == "qualified_lead"
    assert data["amount_inr"] == 500
    assert data["metadata"]["tier"] == "hot"


def test_billing_event_no_lead():
    event = BillingEvent(
        id="ev2",
        client_id="c1",
        event_type="conversation_completed",
    )
    assert event.lead_id is None
    assert event.amount_inr is None


# ── UnifiedMessage ────────────────────────────────────────────────────────────

def test_unified_message_defaults():
    msg = UnifiedMessage(
        direction="inbound",
        sender_id="919876543210",
        content="Hi, I want to buy a flat",
    )
    assert msg.channel == "whatsapp"
    assert msg.message_type == "text"
    assert msg.channel_message_id is None
