"""
Tests for Chunk 3B — Qualifier node, Scorer node, RAG search trigger.
All Claude API calls are mocked — no real API usage.
"""
import pytest
from unittest.mock import patch, AsyncMock, MagicMock


# ── Scorer Tests (no mocking needed — pure rules) ────────────────────────────

class TestScorer:
    """Scorer is rules-based — no LLM, no mocks needed."""

    def _make_state(self, **lead_fields) -> dict:
        lead = {"phone": "919111111111", "client_id": "c1", "stage": "qualifying"}
        lead.update(lead_fields)
        return {
            "lead": lead,
            "client_config": {"id": "c1"},
            "messages": [],
        }

    def test_hot_lead_all_fields(self):
        from src.engine.nodes.scorer import scorer
        state = self._make_state(
            budget_min=8000000, budget_max=12000000,
            timeline_months=3,
            location_preferences=["Andheri West"],
            financing_status="loan_approved",
            family_size=4,
        )
        result = scorer(state)
        assert result["lead"]["tier"] == "hot"
        assert result["lead"]["score"] >= 70
        assert result["next_action"] == "schedule"

    def test_warm_lead_partial_fields(self):
        from src.engine.nodes.scorer import scorer
        state = self._make_state(
            budget_min=5000000,
            timeline_months=9,
            location_preferences=["Bandra"],
        )
        result = scorer(state)
        assert result["lead"]["tier"] == "warm"
        assert 40 <= result["lead"]["score"] < 70
        assert result["next_action"] == "nurture"

    def test_cold_lead_no_info(self):
        from src.engine.nodes.scorer import scorer
        state = self._make_state()
        result = scorer(state)
        assert result["lead"]["tier"] == "cold"
        assert result["lead"]["score"] < 40
        assert result["next_action"] == "handoff"

    def test_budget_adds_30_points(self):
        from src.engine.nodes.scorer import _score_lead
        score_without, _, _ = _score_lead({"phone": "x"})
        score_with, _, _ = _score_lead({"phone": "x", "budget_max": 10000000})
        assert score_with - score_without == 30

    def test_urgent_timeline_adds_25(self):
        from src.engine.nodes.scorer import _score_lead
        score, _, reasons = _score_lead({"timeline_months": 3})
        assert score == 25
        assert any("urgent" in r for r in reasons)

    def test_medium_timeline_adds_15(self):
        from src.engine.nodes.scorer import _score_lead
        score, _, _ = _score_lead({"timeline_months": 9})
        assert score == 15

    def test_long_timeline_adds_5(self):
        from src.engine.nodes.scorer import _score_lead
        score, _, _ = _score_lead({"timeline_months": 24})
        assert score == 5

    def test_location_adds_20(self):
        from src.engine.nodes.scorer import _score_lead
        score, _, _ = _score_lead({"location_preferences": ["Powai"]})
        assert score == 20

    def test_loan_approved_adds_15(self):
        from src.engine.nodes.scorer import _score_lead
        score, _, _ = _score_lead({"financing_status": "loan_approved"})
        assert score == 15

    def test_loan_needed_adds_8(self):
        from src.engine.nodes.scorer import _score_lead
        score, _, _ = _score_lead({"financing_status": "loan_needed"})
        assert score == 8

    def test_score_capped_at_100(self):
        from src.engine.nodes.scorer import _score_lead
        score, tier, _ = _score_lead({
            "budget_max": 10000000,
            "timeline_months": 2,
            "location_preferences": ["Andheri"],
            "financing_status": "self_funded",
            "family_size": 3,
        })
        assert score <= 100
        assert tier == "hot"

    def test_stage_set_to_qualified(self):
        from src.engine.nodes.scorer import scorer
        result = scorer(self._make_state())
        assert result["lead"]["stage"] == "qualified"


# ── Qualifier Tests (Claude calls mocked) ────────────────────────────────────

class TestQualifier:
    """Qualifier tests with Claude extract_structured and generate mocked."""

    def _make_state(self, text: str, language: str = "english", lead: dict = None) -> dict:
        base_lead = {
            "phone": "919111111111", "client_id": "c1",
            "intent": "buyer", "stage": "new",
        }
        if lead:
            base_lead.update(lead)
        return {
            "messages": [{"role": "user", "content": text}],
            "lead": base_lead,
            "client_config": {
                "id": "c1", "client_name": "Test Realty",
                "prompt_overrides": {}, "language_config": {},
            },
            "language": language,
            "rag_context": [],
            "turn_count": 1,
            "awaiting_info": ["budget", "timeline", "location"],
        }

    @patch("src.engine.nodes.qualifier.generate", return_value="What's your budget?")
    @patch("src.engine.nodes.qualifier.extract_structured")
    def test_extracts_budget_from_message(self, mock_extract, mock_gen):
        from src.engine.nodes.qualifier import qualifier
        mock_extract.return_value = {
            "budget_min": 8000000,
            "budget_max": 12000000,
            "extracted_confidence": 0.9,
        }
        result = qualifier(self._make_state("I want to spend around 80 lakh to 1.2 crore"))
        assert result["lead"]["budget_min"] == 8000000
        assert result["lead"]["budget_max"] == 12000000

    @patch("src.engine.nodes.qualifier.generate", return_value="When do you need it?")
    @patch("src.engine.nodes.qualifier.extract_structured")
    def test_extracts_location(self, mock_extract, mock_gen):
        from src.engine.nodes.qualifier import qualifier
        mock_extract.return_value = {
            "locations": ["Andheri West", "Bandra"],
            "extracted_confidence": 0.85,
        }
        result = qualifier(self._make_state("Looking in Andheri West or Bandra"))
        assert "Andheri West" in result["lead"]["location_preferences"]
        assert "Bandra" in result["lead"]["location_preferences"]

    @patch("src.engine.nodes.qualifier.generate", return_value="Got it!")
    @patch("src.engine.nodes.qualifier.extract_structured")
    def test_low_confidence_skips_merge(self, mock_extract, mock_gen):
        """Fields should NOT be merged when confidence <= 0.5."""
        from src.engine.nodes.qualifier import qualifier
        mock_extract.return_value = {
            "budget_min": 5000000,
            "extracted_confidence": 0.3,  # too low
        }
        result = qualifier(self._make_state("maybe around 50 lakh I think"))
        assert result["lead"].get("budget_min") is None

    @patch("src.engine.nodes.qualifier.generate", return_value="Which area?")
    @patch("src.engine.nodes.qualifier.extract_structured")
    def test_increments_turn_count(self, mock_extract, mock_gen):
        from src.engine.nodes.qualifier import qualifier
        mock_extract.return_value = {"extracted_confidence": 0.5}
        state = self._make_state("hi")
        state["turn_count"] = 3
        result = qualifier(state)
        assert result["turn_count"] == 4

    @patch("src.engine.nodes.qualifier.generate", return_value="Great!")
    @patch("src.engine.nodes.qualifier.extract_structured")
    def test_appends_assistant_message(self, mock_extract, mock_gen):
        from src.engine.nodes.qualifier import qualifier
        mock_extract.return_value = {"extracted_confidence": 0.5}
        result = qualifier(self._make_state("hello"))
        assert result["messages"][-1]["role"] == "assistant"
        assert result["messages"][-1]["content"] == "Great!"

    @patch("src.engine.nodes.qualifier.generate", return_value="")
    @patch("src.engine.nodes.qualifier.extract_structured")
    def test_fallback_when_generate_fails(self, mock_extract, mock_gen):
        """When Claude generation fails, use keyword fallback."""
        from src.engine.nodes.qualifier import qualifier
        mock_extract.return_value = {"extracted_confidence": 0.5}
        result = qualifier(self._make_state("hi"))
        assert result["messages"][-1]["role"] == "assistant"
        assert len(result["messages"][-1]["content"]) > 0  # fallback fires

    @patch("src.engine.nodes.qualifier.generate", return_value="Budget?")
    @patch("src.engine.nodes.qualifier.extract_structured")
    def test_awaiting_info_updated_after_extraction(self, mock_extract, mock_gen):
        """Budget filled → budget removed from awaiting_info."""
        from src.engine.nodes.qualifier import qualifier
        mock_extract.return_value = {
            "budget_min": 7000000, "budget_max": 10000000,
            "extracted_confidence": 0.9,
        }
        state = self._make_state("my budget is 70L to 1Cr")
        result = qualifier(state)
        assert "budget" not in result["awaiting_info"]

    @patch("src.engine.nodes.qualifier.generate", return_value="Shukriya!")
    @patch("src.engine.nodes.qualifier.extract_structured")
    def test_hinglish_prompt_loaded(self, mock_extract, mock_gen):
        """Hinglish language → hinglish prompt used."""
        from src.engine.nodes.qualifier import qualifier
        mock_extract.return_value = {"extracted_confidence": 0.5}
        qualifier(self._make_state("mujhe flat chahiye", language="hinglish"))
        call_args = mock_gen.call_args
        system_prompt = call_args.args[0]
        # Hinglish prompt should contain Hinglish text markers
        assert any(word in system_prompt for word in ["aap", "Aap", "ABHI", "baare"])


# ── RAG Search Trigger Tests ──────────────────────────────────────────────────

class TestRAGTrigger:
    """Tests for should_trigger_rag heuristic."""

    def test_price_question_triggers_rag(self):
        from src.rag.search import should_trigger_rag
        assert should_trigger_rag("What is the price of 2BHK?") is True

    def test_amenities_triggers_rag(self):
        from src.rag.search import should_trigger_rag
        assert should_trigger_rag("Do you have a swimming pool and gym?") is True

    def test_floor_plan_triggers_rag(self):
        from src.rag.search import should_trigger_rag
        assert should_trigger_rag("Show me the floor plan for 3BHK") is True

    def test_hinglish_price_triggers_rag(self):
        from src.rag.search import should_trigger_rag
        assert should_trigger_rag("bhai kitna budget hai flat ka") is True

    def test_generic_hi_no_trigger(self):
        from src.rag.search import should_trigger_rag
        assert should_trigger_rag("Hi, I'm interested in buying a flat") is False

    def test_tell_me_about_triggers_rag(self):
        from src.rag.search import should_trigger_rag
        assert should_trigger_rag("tell me about the project") is True


# ── _compute_awaiting_info Tests ──────────────────────────────────────────────

class TestComputeAwaitingInfo:
    """Tests for the field-missing logic."""

    def test_empty_lead_missing_all(self):
        from src.engine.nodes.qualifier import _compute_awaiting_info
        missing = _compute_awaiting_info({"phone": "x"})
        assert "budget" in missing
        assert "timeline" in missing
        assert "location" in missing

    def test_filled_lead_missing_none(self):
        from src.engine.nodes.qualifier import _compute_awaiting_info
        lead = {
            "budget_min": 5000000,
            "timeline_months": 6,
            "location_preferences": ["Andheri"],
            "property_type": "apartment",
            "financing_status": "loan_approved",
            "family_size": 3,
        }
        missing = _compute_awaiting_info(lead)
        assert missing == []

    def test_budget_filled_not_in_missing(self):
        from src.engine.nodes.qualifier import _compute_awaiting_info
        missing = _compute_awaiting_info({"budget_max": 10000000})
        assert "budget" not in missing

    def test_property_type_any_still_missing(self):
        from src.engine.nodes.qualifier import _compute_awaiting_info
        missing = _compute_awaiting_info({"property_type": "any"})
        assert "property_type" in missing


# ── Budget Conversion Tests ───────────────────────────────────────────────────

class TestBudgetFormatting:
    """Test the INR budget summary formatter."""

    def test_lakh_display(self):
        from src.engine.nodes.qualifier import _format_filled_summary
        summary = _format_filled_summary({"budget_min": 7000000, "budget_max": 12000000})
        assert "70L" in summary
        assert "120L" in summary

    def test_no_budget_not_in_summary(self):
        from src.engine.nodes.qualifier import _format_filled_summary
        summary = _format_filled_summary({"timeline_months": 6})
        assert "Budget" not in summary
        assert "Timeline" in summary
