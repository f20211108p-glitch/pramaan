"""
Tests for Chunk 3A — RAG ingestion pipeline.
Tests chunking, chunk-type classification, fastembed local embeddings, and PDF extraction.
No API keys needed — fastembed runs locally for free.
"""
import pytest
from pathlib import Path
from unittest.mock import patch

from src.rag.chunker import chunk_text, classify_chunk_type
from src.rag.embedder import embed_texts, embed_query, EMBEDDING_DIMS, EMBEDDING_MODEL
from src.rag.ingest import extract_pdf_text

SAMPLE_PDF = str(Path(__file__).parent.parent / "scripts" / "sample_brochure.pdf")


# ── Chunker Tests ────────────────────────────────────────────────────────────

class TestChunker:
    """Tests for text chunking."""

    def test_basic_chunking(self):
        """Text gets split into chunks."""
        text = " ".join([f"word{i}" for i in range(600)])
        chunks = chunk_text(text, chunk_size=300, overlap=40)
        assert len(chunks) >= 2
        for chunk in chunks:
            assert "text" in chunk
            assert "start_char" in chunk
            assert "end_char" in chunk
            assert "chunk_index" in chunk

    def test_chunk_size_approximately_correct(self):
        """Each chunk should have roughly chunk_size words."""
        text = " ".join([f"word{i}" for i in range(900)])
        chunks = chunk_text(text, chunk_size=300, overlap=40)
        for chunk in chunks[:-1]:  # last chunk can be shorter
            word_count = len(chunk["text"].split())
            assert 200 <= word_count <= 350, f"Chunk has {word_count} words"

    def test_overlap_exists(self):
        """Consecutive chunks should share some content (overlap)."""
        text = " ".join([f"unique_word_{i}" for i in range(600)])
        chunks = chunk_text(text, chunk_size=300, overlap=50)
        if len(chunks) >= 2:
            words_0 = set(chunks[0]["text"].split())
            words_1 = set(chunks[1]["text"].split())
            overlap_words = words_0 & words_1
            assert len(overlap_words) > 0, "No overlap between consecutive chunks"

    def test_empty_text_returns_empty(self):
        assert chunk_text("") == []
        assert chunk_text("   ") == []
        assert chunk_text(None) == []

    def test_short_text_single_chunk(self):
        """Text shorter than chunk_size → single chunk."""
        text = "This is a short text with just a few words."
        chunks = chunk_text(text, chunk_size=300, overlap=40)
        assert len(chunks) == 1
        assert chunks[0]["text"] == text

    def test_chunk_index_sequential(self):
        text = " ".join([f"w{i}" for i in range(900)])
        chunks = chunk_text(text)
        for i, chunk in enumerate(chunks):
            assert chunk["chunk_index"] == i


# ── Chunk Type Classification Tests ──────────────────────────────────────────

class TestChunkTypeClassifier:
    """Tests for heuristic chunk type classification."""

    def test_pricing_detection(self):
        text = "2 BHK Compact: ₹1.15 Crore onwards. Price per sqft is ₹17,700. EMI starting from ₹85,000."
        assert classify_chunk_type(text) == "pricing_table"

    def test_pricing_lakh_crore(self):
        text = "The booking amount is 5 lakh. Total cost comes to 1.5 crore."
        assert classify_chunk_type(text) == "pricing_table"

    def test_floor_plan_detection(self):
        text = "2 BHK Premium: Carpet Area 780 sqft. Built-up Area 1020 sqft. Configuration includes 2 bedrooms."
        assert classify_chunk_type(text) == "floor_plan"

    def test_amenities_detection(self):
        text = "World-class amenities include a swimming pool, fully equipped gymnasium, and clubhouse with garden."
        assert classify_chunk_type(text) == "amenities"

    def test_location_detection(self):
        text = "Located near Andheri metro station, just 2 km from highway. Airport is 15 minutes away."
        assert classify_chunk_type(text) == "location"

    def test_specifications_detection(self):
        text = "Bathroom fittings include vitrified tiles and modular kitchen with granite platform."
        assert classify_chunk_type(text) == "specifications"

    def test_general_fallback(self):
        text = "Welcome to Paradise Heights, an iconic residential tower by Demo Realty Group."
        assert classify_chunk_type(text) == "general"

    def test_mixed_content_strongest_wins(self):
        """When multiple types present, the first matching category wins."""
        text = "Price ₹1.5 crore for 2BHK near metro station."
        result = classify_chunk_type(text)
        # Pricing has strongest match (₹ + crore)
        assert result in ("pricing_table", "floor_plan", "location")


# ── PDF Extraction Tests ─────────────────────────────────────────────────────

class TestPDFExtraction:
    """Tests for PDF text extraction (requires sample_brochure.pdf)."""

    @pytest.fixture
    def sample_pdf(self):
        path = Path(SAMPLE_PDF)
        if not path.exists():
            pytest.skip("Sample brochure PDF not found. Run: python scripts/create_sample_pdf.py")
        return str(path)

    def test_extracts_pages(self, sample_pdf):
        pages = extract_pdf_text(sample_pdf)
        assert len(pages) == 6  # Our sample has 6 pages

    def test_each_page_has_content(self, sample_pdf):
        pages = extract_pdf_text(sample_pdf)
        for page in pages:
            assert page["page_number"] >= 1
            assert len(page["text"]) > 50  # Each page should have substantial content

    def test_page_numbers_sequential(self, sample_pdf):
        pages = extract_pdf_text(sample_pdf)
        for i, page in enumerate(pages):
            assert page["page_number"] == i + 1

    def test_content_contains_expected_text(self, sample_pdf):
        pages = extract_pdf_text(sample_pdf)
        all_text = " ".join(p["text"] for p in pages)
        assert "Paradise Heights" in all_text
        assert "Andheri" in all_text
        assert "BHK" in all_text

    def test_missing_pdf_raises(self):
        with pytest.raises(FileNotFoundError):
            extract_pdf_text("/nonexistent/path/file.pdf")


# ── Embedder Tests ───────────────────────────────────────────────────────────

class TestEmbedder:
    """Tests for fastembed local embeddings — no API key, no mocking needed."""

    def test_correct_model_name(self):
        """Verify we're using the free multilingual model, not OpenAI."""
        assert EMBEDDING_MODEL == "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
        assert EMBEDDING_DIMS == 384

    @pytest.mark.asyncio
    async def test_embed_texts_returns_correct_dimensions(self):
        vectors = await embed_texts(["hello world", "test text"])
        assert len(vectors) == 2
        assert len(vectors[0]) == EMBEDDING_DIMS
        assert len(vectors[1]) == EMBEDDING_DIMS

    @pytest.mark.asyncio
    async def test_embed_texts_empty_list(self):
        vectors = await embed_texts([])
        assert vectors == []

    @pytest.mark.asyncio
    async def test_embed_query_returns_single_vector(self):
        vector = await embed_query("2BHK flat in Andheri")
        assert len(vector) == EMBEDDING_DIMS

    @pytest.mark.asyncio
    async def test_hinglish_text_embeds(self):
        """Multilingual model handles Hinglish correctly."""
        vector = await embed_texts(["mujhe 2BHK chahiye Andheri mein budget 80 lakh"])
        assert len(vector) == 1
        assert len(vector[0]) == EMBEDDING_DIMS

    @pytest.mark.asyncio
    async def test_vectors_are_non_zero(self):
        """fastembed returns non-zero vectors (pgvector cosine handles any magnitude)."""
        vectors = await embed_texts(["test property search"])
        vec = vectors[0]
        norm = sum(x * x for x in vec) ** 0.5
        assert norm > 0.0  # non-zero vector

    @pytest.mark.asyncio
    async def test_similar_texts_closer_than_dissimilar(self):
        """Semantic similarity: property queries should be closer to each other than to random text."""
        vecs = await embed_texts([
            "2BHK flat in Andheri for 1 crore",
            "2 bedroom apartment in Andheri budget 1 crore",
            "mujhe pizza khana hai aaj",
        ])
        v1, v2, v3 = vecs
        # Dot product as cosine similarity (vectors are unit normalized)
        sim_12 = sum(a * b for a, b in zip(v1, v2))
        sim_13 = sum(a * b for a, b in zip(v1, v3))
        assert sim_12 > sim_13, "Similar property queries should be more similar to each other"


# ── Full Pipeline Tests (mocked DB + embeddings) ────────────────────────────

class TestIngestPipeline:
    """Integration tests for the full ingest pipeline (mocked DB)."""

    @pytest.fixture
    def sample_pdf(self):
        path = Path(SAMPLE_PDF)
        if not path.exists():
            pytest.skip("Sample brochure PDF not found")
        return str(path)

    def test_full_pipeline_chunking_and_classification(self, sample_pdf):
        """Extract text from PDF, chunk it, classify chunk types."""
        pages = extract_pdf_text(sample_pdf)
        all_text = "\n\n".join(p["text"] for p in pages)

        chunks = chunk_text(all_text)
        assert len(chunks) > 0

        # Classify each chunk
        chunk_types = [classify_chunk_type(c["text"]) for c in chunks]

        # We should see multiple chunk types from our diverse brochure
        unique_types = set(chunk_types)
        assert len(unique_types) >= 2, f"Expected diverse types, got: {unique_types}"

        # At least one pricing chunk (we have a pricing page)
        has_variety = any(t != "general" for t in chunk_types)
        assert has_variety, "All chunks classified as 'general' — classification not working"

    @pytest.mark.asyncio
    async def test_embed_all_chunks(self, sample_pdf):
        """Embed all chunks from the PDF — verify dimensions."""
        pages = extract_pdf_text(sample_pdf)
        all_text = "\n\n".join(p["text"] for p in pages)
        chunks = chunk_text(all_text)
        texts = [c["text"] for c in chunks]

        embeddings = await embed_texts(texts)
        assert len(embeddings) == len(chunks)
        for emb in embeddings:
            assert len(emb) == EMBEDDING_DIMS


# ── Admin API Tests ──────────────────────────────────────────────────────────

class TestAdminAPI:
    """Tests for admin API endpoints."""

    def test_admin_auth_required(self):
        """Admin endpoints should reject missing/wrong key."""
        from fastapi.testclient import TestClient
        from src.main import app

        client = TestClient(app, raise_server_exceptions=False)

        # No auth header → 403 (no valid credentials)
        resp = client.get("/admin/projects", params={"client_id": "test"})
        assert resp.status_code == 403

        # Wrong auth header → 403
        resp = client.get(
            "/admin/projects",
            params={"client_id": "test"},
            headers={"x-admin-key": "wrong_key"},
        )
        assert resp.status_code == 403

    def test_ingest_rejects_non_pdf(self):
        """Ingest endpoint should only accept PDF files."""
        from fastapi.testclient import TestClient
        from src.main import app
        from src.config import get_settings

        client = TestClient(app, raise_server_exceptions=False)
        settings = get_settings()

        resp = client.post(
            "/admin/ingest",
            headers={"x-admin-key": settings.secret_key},
            files={"file": ("test.txt", b"not a pdf", "text/plain")},
            data={"client_id": "test-id", "project_name": "Test"},
        )
        assert resp.status_code == 400
        assert "PDF" in resp.json()["detail"]
