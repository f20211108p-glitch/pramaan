"""
Tests for Chunk 4A — RAG search integration + voice note handling + router RAG wiring.
No real DB or API keys needed — everything is mocked.
"""
import pytest
from unittest.mock import patch, AsyncMock, MagicMock


# ── RAG Search Function Tests ────────────────────────────────────────────────

class TestRAGSearchFunction:
    """Tests for rag_search() with mocked DB and embeddings."""

    @pytest.mark.asyncio
    async def test_returns_empty_for_client_with_no_chunks(self):
        """Client with no brochure chunks → empty list."""
        from src.rag.search import rag_search

        mock_db = AsyncMock()
        # Simulate no chunks found
        mock_result = MagicMock()
        mock_result.scalars.return_value.first.return_value = None
        mock_db.execute.return_value = mock_result

        result = await rag_search(mock_db, "what is the price?", "client-no-chunks")
        assert result == []

    @pytest.mark.asyncio
    @patch("src.rag.search.embed_query", return_value=[0.1] * 384)
    async def test_search_filters_by_client_id(self, mock_embed):
        """rag_search always includes client_id in the WHERE clause."""
        from src.rag.search import rag_search

        mock_db = AsyncMock()
        # First execute: check if chunks exist → yes
        mock_check = MagicMock()
        mock_check.scalars.return_value.first.return_value = MagicMock()
        # Second execute: actual vector search → raw SQL returns tuples
        # Columns: (text, chunk_type, project_name, distance)
        mock_row = ("2BHK starts at ₹72 lakh", "pricing_table", "Prestige Sunrise", 0.15)
        mock_search = MagicMock()
        mock_search.fetchall.return_value = [mock_row]

        mock_db.execute.side_effect = [mock_check, mock_search]

        result = await rag_search(mock_db, "what is the price?", "client-123")
        assert len(result) == 1
        assert "72 lakh" in result[0]
        assert "Prestige Sunrise" in result[0]  # project name included in formatted output

    @pytest.mark.asyncio
    @patch("src.rag.search.embed_query", return_value=[0.1] * 384)
    async def test_search_respects_top_k(self, mock_embed):
        """top_k limits results."""
        from src.rag.search import rag_search

        mock_db = AsyncMock()
        mock_check = MagicMock()
        mock_check.scalars.return_value.first.return_value = MagicMock()

        # Raw SQL returns tuples: (text, chunk_type, project_name, distance)
        rows = [(f"chunk_{i}", "general", "Project X", 0.1 + i * 0.05) for i in range(2)]
        mock_search = MagicMock()
        mock_search.fetchall.return_value = rows  # top_k=2 limits

        mock_db.execute.side_effect = [mock_check, mock_search]

        result = await rag_search(mock_db, "tell me about the project", "c1", top_k=2)
        assert len(result) == 2

    @pytest.mark.asyncio
    @patch("src.rag.search.embed_query", return_value=[0.1] * 384)
    async def test_search_with_chunk_type_filter(self, mock_embed):
        """chunk_type filter narrows results."""
        from src.rag.search import rag_search

        mock_db = AsyncMock()
        mock_check = MagicMock()
        mock_check.scalars.return_value.first.return_value = MagicMock()

        # Raw SQL returns tuples: (text, chunk_type, project_name, distance)
        mock_row = ("Swimming pool, gym, clubhouse", "amenities", "Green Acres", 0.12)
        mock_search = MagicMock()
        mock_search.fetchall.return_value = [mock_row]

        mock_db.execute.side_effect = [mock_check, mock_search]

        result = await rag_search(mock_db, "do you have a pool?", "c1", chunk_type="amenities")
        assert len(result) == 1
        assert "pool" in result[0].lower()


# ── should_trigger_rag Tests (extended from test_qualifier.py) ───────────────

class TestShouldTriggerRAGExtended:
    """Additional RAG trigger tests for edge cases."""

    def test_specifications_trigger(self):
        from src.rag.search import should_trigger_rag
        assert should_trigger_rag("What are the specifications?") is True

    def test_brochure_request_triggers(self):
        from src.rag.search import should_trigger_rag
        assert should_trigger_rag("Can you share the brochure?") is True

    def test_details_request_triggers(self):
        from src.rag.search import should_trigger_rag
        assert should_trigger_rag("Give me details about this project") is True

    def test_budget_query_does_not_trigger(self):
        """User stating budget ≠ asking about price."""
        from src.rag.search import should_trigger_rag
        # "budget" is in the trigger list, so this is True (user might be asking project budget range)
        assert should_trigger_rag("my budget is 80 lakh") is True

    def test_simple_greeting_no_trigger(self):
        from src.rag.search import should_trigger_rag
        assert should_trigger_rag("Hello, good morning") is False

    def test_just_name_no_trigger(self):
        from src.rag.search import should_trigger_rag
        assert should_trigger_rag("My name is Rahul") is False

    def test_hinglish_batao_triggers(self):
        from src.rag.search import should_trigger_rag
        assert should_trigger_rag("project ke baare mein batao") is True


# ── Voice Note Handling Tests ────────────────────────────────────────────────

class TestVoiceNoteHandling:
    """Voice notes should be handled gracefully (ask user for text)."""

    def _make_audio_payload(self, media_id="media_123"):
        """Create a WhatsApp webhook payload with an audio message."""
        return {
            "object": "whatsapp_business_account",
            "entry": [{
                "id": "0",
                "changes": [{
                    "value": {
                        "messaging_product": "whatsapp",
                        "metadata": {"phone_number_id": "TEST_WABA_ID"},
                        "messages": [{
                            "id": "msg_audio_001",
                            "from": "919111111111",
                            "type": "audio",
                            "audio": {"id": media_id, "mime_type": "audio/ogg"},
                        }],
                    }
                }],
            }],
        }

    @patch("src.channels.router.save_message", new_callable=AsyncMock)
    @patch("src.channels.router.has_consent", new_callable=AsyncMock, return_value=True)
    @patch("src.channels.router.get_or_create_conversation", new_callable=AsyncMock)
    @patch("src.channels.router.get_or_create_lead", new_callable=AsyncMock)
    @patch("src.channels.router.resolve_client", new_callable=AsyncMock)
    @patch("src.channels.router.is_duplicate", new_callable=AsyncMock, return_value=False)
    @patch("src.channels.router.WhatsAppChannel.send_message", new_callable=AsyncMock, return_value=True)
    @patch("src.channels.router.check_rate_limit", new_callable=AsyncMock, return_value=True)
    @pytest.mark.asyncio
    async def test_audio_message_returns_text_prompt(
        self, mock_rate, mock_send, mock_dedup, mock_resolve, mock_lead,
        mock_convo, mock_consent, mock_save
    ):
        """Audio message → ask user to send text, don't run engine."""
        from src.channels.router import MessageRouter

        # Setup mocks
        mock_client = MagicMock()
        mock_client.id = "c1"
        mock_client.waba_phone_number_id = "TEST_WABA_ID"
        mock_client.waba_token = "test_token"
        mock_client.client_name = "Test"
        mock_resolve.return_value = mock_client

        mock_lead_obj = MagicMock()
        mock_lead_obj.id = "lead1"
        mock_lead.return_value = mock_lead_obj

        mock_convo_obj = MagicMock()
        mock_convo_obj.id = "conv1"
        mock_convo.return_value = mock_convo_obj

        router = MessageRouter()
        mock_db = AsyncMock()
        result = await router.route_inbound(self._make_audio_payload(), mock_db)

        # Should have sent a text-only message
        assert "text messages" in result["response"].lower()
        assert result["lead_id"] == "lead1"
        # send_message should have been called with the voice reply
        mock_send.assert_called_once()


# ── Router RAG Wiring Tests ─────────────────────────────────────────────────

class TestRouterRAGWiring:
    """Test that the router triggers RAG search and passes context to engine."""

    def _make_text_payload(self, text="What is the price of 2BHK?"):
        return {
            "object": "whatsapp_business_account",
            "entry": [{
                "id": "0",
                "changes": [{
                    "value": {
                        "messaging_product": "whatsapp",
                        "metadata": {"phone_number_id": "TEST_WABA_ID"},
                        "messages": [{
                            "id": "msg_text_001",
                            "from": "919111111111",
                            "type": "text",
                            "text": {"body": text},
                        }],
                    }
                }],
            }],
        }

    @patch("src.channels.router.save_message", new_callable=AsyncMock)
    @patch("src.channels.router.has_consent", new_callable=AsyncMock, return_value=True)
    @patch("src.channels.router.get_or_create_conversation", new_callable=AsyncMock)
    @patch("src.channels.router.get_or_create_lead", new_callable=AsyncMock)
    @patch("src.channels.router.resolve_client", new_callable=AsyncMock)
    @patch("src.channels.router.is_duplicate", new_callable=AsyncMock, return_value=False)
    @patch("src.channels.router.WhatsAppChannel.send_message", new_callable=AsyncMock, return_value=True)
    @patch("src.channels.router.WhatsAppChannel.mark_as_read", new_callable=AsyncMock)
    @patch("src.channels.router.rag_search", new_callable=AsyncMock)
    @patch("src.channels.router.should_trigger_rag", return_value=True)
    @patch("src.channels.router.check_rate_limit", new_callable=AsyncMock, return_value=True)
    @pytest.mark.asyncio
    async def test_rag_triggered_for_price_question(
        self, mock_rate, mock_trigger, mock_rag, mock_read, mock_send,
        mock_dedup, mock_resolve, mock_lead, mock_convo,
        mock_consent, mock_save
    ):
        """Price question → should_trigger_rag returns True → rag_search called."""
        from src.channels.router import MessageRouter

        mock_client = MagicMock()
        mock_client.id = "c1"
        mock_client.waba_phone_number_id = "TEST_WABA_ID"
        mock_client.waba_token = "test_token"
        mock_client.client_name = "Test"
        mock_client.prompt_overrides = {}
        mock_client.language_config = {}
        mock_resolve.return_value = mock_client

        mock_lead_obj = MagicMock()
        mock_lead_obj.id = "lead1"
        mock_lead_obj.name = None
        mock_lead_obj.intent = "unknown"
        mock_lead_obj.stage = "new"
        mock_lead_obj.language_pref = "english"
        mock_lead.return_value = mock_lead_obj

        mock_convo_obj = MagicMock()
        mock_convo_obj.id = "conv1"
        mock_convo.return_value = mock_convo_obj

        mock_rag.return_value = ["2BHK starts at ₹72 lakh"]

        router = MessageRouter()
        # Mock the engine to avoid needing Claude API key
        with patch.object(router, "_run_engine", new_callable=AsyncMock, return_value={"reply": "The 2BHK starts at ₹72 lakh.", "lead_data": {}, "billing_event": None, "next_action": None}):
            mock_db = AsyncMock()
            result = await router.route_inbound(self._make_text_payload("What is the price of 2BHK?"), mock_db)

        # RAG search should have been called
        mock_rag.assert_called_once()
        call_args = mock_rag.call_args
        assert call_args[0][1] == "What is the price of 2BHK?"  # query
        assert call_args[0][2] == "c1"  # client_id

    @patch("src.channels.router.save_message", new_callable=AsyncMock)
    @patch("src.channels.router.has_consent", new_callable=AsyncMock, return_value=True)
    @patch("src.channels.router.get_or_create_conversation", new_callable=AsyncMock)
    @patch("src.channels.router.get_or_create_lead", new_callable=AsyncMock)
    @patch("src.channels.router.resolve_client", new_callable=AsyncMock)
    @patch("src.channels.router.is_duplicate", new_callable=AsyncMock, return_value=False)
    @patch("src.channels.router.WhatsAppChannel.send_message", new_callable=AsyncMock, return_value=True)
    @patch("src.channels.router.WhatsAppChannel.mark_as_read", new_callable=AsyncMock)
    @patch("src.channels.router.rag_search", new_callable=AsyncMock)
    @patch("src.channels.router.should_trigger_rag", return_value=False)
    @patch("src.channels.router.check_rate_limit", new_callable=AsyncMock, return_value=True)
    @pytest.mark.asyncio
    async def test_rag_not_triggered_for_greeting(
        self, mock_rate, mock_trigger, mock_rag, mock_read, mock_send,
        mock_dedup, mock_resolve, mock_lead, mock_convo,
        mock_consent, mock_save
    ):
        """Greeting → should_trigger_rag returns False → rag_search NOT called."""
        from src.channels.router import MessageRouter

        mock_client = MagicMock()
        mock_client.id = "c1"
        mock_client.waba_phone_number_id = "TEST_WABA_ID"
        mock_client.waba_token = "test_token"
        mock_client.client_name = "Test"
        mock_client.prompt_overrides = {}
        mock_client.language_config = {}
        mock_resolve.return_value = mock_client

        mock_lead_obj = MagicMock()
        mock_lead_obj.id = "lead1"
        mock_lead_obj.name = None
        mock_lead_obj.intent = "unknown"
        mock_lead_obj.stage = "new"
        mock_lead_obj.language_pref = "english"
        mock_lead.return_value = mock_lead_obj

        mock_convo_obj = MagicMock()
        mock_convo_obj.id = "conv1"
        mock_convo.return_value = mock_convo_obj

        router = MessageRouter()
        with patch.object(router, "_run_engine", new_callable=AsyncMock, return_value={"reply": "Hello!", "lead_data": {}, "billing_event": None, "next_action": None}):
            mock_db = AsyncMock()
            result = await router.route_inbound(self._make_text_payload("Hi, good morning"), mock_db)

        # RAG search should NOT have been called
        mock_rag.assert_not_called()

    @patch("src.channels.router.save_message", new_callable=AsyncMock)
    @patch("src.channels.router.has_consent", new_callable=AsyncMock, return_value=True)
    @patch("src.channels.router.get_or_create_conversation", new_callable=AsyncMock)
    @patch("src.channels.router.get_or_create_lead", new_callable=AsyncMock)
    @patch("src.channels.router.resolve_client", new_callable=AsyncMock)
    @patch("src.channels.router.is_duplicate", new_callable=AsyncMock, return_value=False)
    @patch("src.channels.router.WhatsAppChannel.send_message", new_callable=AsyncMock, return_value=True)
    @patch("src.channels.router.WhatsAppChannel.mark_as_read", new_callable=AsyncMock)
    @patch("src.channels.router.rag_search", new_callable=AsyncMock, side_effect=Exception("DB down"))
    @patch("src.channels.router.should_trigger_rag", return_value=True)
    @patch("src.channels.router.check_rate_limit", new_callable=AsyncMock, return_value=True)
    @pytest.mark.asyncio
    async def test_rag_failure_doesnt_crash_router(
        self, mock_rate, mock_trigger, mock_rag, mock_read, mock_send,
        mock_dedup, mock_resolve, mock_lead, mock_convo,
        mock_consent, mock_save
    ):
        """If RAG search fails, router continues without crashing."""
        from src.channels.router import MessageRouter

        mock_client = MagicMock()
        mock_client.id = "c1"
        mock_client.waba_phone_number_id = "TEST_WABA_ID"
        mock_client.waba_token = "test_token"
        mock_client.client_name = "Test"
        mock_client.prompt_overrides = {}
        mock_client.language_config = {}
        mock_resolve.return_value = mock_client

        mock_lead_obj = MagicMock()
        mock_lead_obj.id = "lead1"
        mock_lead_obj.name = None
        mock_lead_obj.intent = "unknown"
        mock_lead_obj.stage = "new"
        mock_lead_obj.language_pref = "english"
        mock_lead.return_value = mock_lead_obj

        mock_convo_obj = MagicMock()
        mock_convo_obj.id = "conv1"
        mock_convo.return_value = mock_convo_obj

        router = MessageRouter()
        with patch.object(router, "_run_engine", new_callable=AsyncMock, return_value={"reply": "How can I help?", "lead_data": {}, "billing_event": None, "next_action": None}):
            mock_db = AsyncMock()
            result = await router.route_inbound(self._make_text_payload("What is the price?"), mock_db)

        # Should still get a response despite RAG failure
        assert result["response"] == "How can I help?"
        assert "skipped" not in result

    @patch("src.channels.router.save_message", new_callable=AsyncMock)
    @patch("src.channels.router.has_consent", new_callable=AsyncMock, return_value=True)
    @patch("src.channels.router.get_or_create_conversation", new_callable=AsyncMock)
    @patch("src.channels.router.get_or_create_lead", new_callable=AsyncMock)
    @patch("src.channels.router.resolve_client", new_callable=AsyncMock)
    @patch("src.channels.router.is_duplicate", new_callable=AsyncMock, return_value=False)
    @patch("src.channels.router.WhatsAppChannel.send_message", new_callable=AsyncMock, return_value=True)
    @patch("src.channels.router.WhatsAppChannel.mark_as_read", new_callable=AsyncMock)
    @patch("src.channels.router.rag_search", new_callable=AsyncMock)
    @patch("src.channels.router.should_trigger_rag", return_value=True)
    @patch("src.channels.router.check_rate_limit", new_callable=AsyncMock, return_value=True)
    @pytest.mark.asyncio
    async def test_rag_context_passed_to_engine(
        self, mock_rate, mock_trigger, mock_rag, mock_read, mock_send,
        mock_dedup, mock_resolve, mock_lead, mock_convo,
        mock_consent, mock_save
    ):
        """RAG results should be passed as rag_context to _run_engine."""
        from src.channels.router import MessageRouter

        mock_client = MagicMock()
        mock_client.id = "c1"
        mock_client.waba_phone_number_id = "TEST_WABA_ID"
        mock_client.waba_token = "test_token"
        mock_client.client_name = "Test"
        mock_client.prompt_overrides = {}
        mock_client.language_config = {}
        mock_resolve.return_value = mock_client

        mock_lead_obj = MagicMock()
        mock_lead_obj.id = "lead1"
        mock_lead_obj.name = None
        mock_lead_obj.intent = "unknown"
        mock_lead_obj.stage = "new"
        mock_lead_obj.language_pref = "english"
        mock_lead.return_value = mock_lead_obj

        mock_convo_obj = MagicMock()
        mock_convo_obj.id = "conv1"
        mock_convo.return_value = mock_convo_obj

        rag_chunks = ["2BHK: ₹72L", "3BHK: ₹95L"]
        mock_rag.return_value = rag_chunks

        router = MessageRouter()
        with patch.object(router, "_run_engine", new_callable=AsyncMock, return_value={"reply": "Here are the prices.", "lead_data": {}, "billing_event": None, "next_action": None}) as mock_engine:
            mock_db = AsyncMock()
            await router.route_inbound(self._make_text_payload("What is the price?"), mock_db)

        # Verify rag_context was passed
        call_kwargs = mock_engine.call_args
        assert call_kwargs.kwargs.get("rag_context") == rag_chunks
