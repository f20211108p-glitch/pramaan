"""
Tests for Chunk 10A — Rate limiting, message queue, and async webhook mode.
All Redis interactions are mocked — no real Redis needed.
All LLM calls are mocked — no real Anthropic tokens consumed.
"""
import json
import time
import pytest
from unittest.mock import patch, AsyncMock, MagicMock, PropertyMock


def _make_redis_pipe_mock(execute_return):
    """
    Create a mock Redis pipeline.

    redis.asyncio pipeline commands (zremrangebyscore, zcard, zadd, expire)
    are synchronous (they queue commands). Only execute() is async.
    """
    pipe = MagicMock()
    pipe.execute = AsyncMock(return_value=execute_return)
    # Pipeline commands return self for chaining
    pipe.zremrangebyscore.return_value = pipe
    pipe.zcard.return_value = pipe
    pipe.zadd.return_value = pipe
    pipe.expire.return_value = pipe
    pipe.zrangebyscore.return_value = pipe
    return pipe


# ═══════════════════════════════════════════════════════════════════════════════
# RATE LIMITING TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestRateLimit:
    """Test per-lead rate limiting with sliding window."""

    @pytest.mark.asyncio
    @patch("src.core.rate_limit._get_redis")
    async def test_first_message_allowed(self, mock_get_redis):
        """First message should always be allowed."""
        from src.core.rate_limit import check_rate_limit

        mock_redis = MagicMock()
        mock_pipe = _make_redis_pipe_mock([None, 0, None, None])
        mock_redis.pipeline.return_value = mock_pipe
        mock_get_redis.return_value = mock_redis

        result = await check_rate_limit("client-1", "+919999900000")
        assert result is True  # allowed

    @pytest.mark.asyncio
    @patch("src.core.rate_limit._get_redis")
    async def test_under_limit_allowed(self, mock_get_redis):
        """Messages under the limit should be allowed."""
        from src.core.rate_limit import check_rate_limit

        mock_redis = MagicMock()
        mock_pipe = _make_redis_pipe_mock([None, 2, None, None])
        mock_redis.pipeline.return_value = mock_pipe
        mock_get_redis.return_value = mock_redis

        result = await check_rate_limit("client-1", "+919999900000")
        assert result is True

    @pytest.mark.asyncio
    @patch("src.core.rate_limit._get_redis")
    async def test_at_limit_blocked(self, mock_get_redis):
        """4th message within 5 minutes should be blocked (limit=3)."""
        from src.core.rate_limit import check_rate_limit

        mock_redis = MagicMock()
        mock_pipe = _make_redis_pipe_mock([None, 3, None, None])
        mock_redis.pipeline.return_value = mock_pipe
        mock_get_redis.return_value = mock_redis

        result = await check_rate_limit("client-1", "+919999900000")
        assert result is False  # blocked

    @pytest.mark.asyncio
    @patch("src.core.rate_limit._get_redis")
    async def test_custom_limits(self, mock_get_redis):
        """Custom max_messages and window should work."""
        from src.core.rate_limit import check_rate_limit

        mock_redis = MagicMock()
        mock_pipe = _make_redis_pipe_mock([None, 4, None, None])
        mock_redis.pipeline.return_value = mock_pipe
        mock_get_redis.return_value = mock_redis

        # Allow up to 5 messages — 4 in window should pass
        result = await check_rate_limit("c1", "+91x", max_messages=5, window_seconds=60)
        assert result is True

    @pytest.mark.asyncio
    @patch("src.core.rate_limit._get_redis")
    async def test_different_leads_independent(self, mock_get_redis):
        """Rate limits are per-lead — different leads have separate counters."""
        from src.core.rate_limit import check_rate_limit

        mock_redis = MagicMock()
        call_count = 0

        async def mock_execute():
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return [None, 3, None, None]  # Lead A → blocked
            return [None, 0, None, None]       # Lead B → allowed

        mock_pipe = MagicMock()
        mock_pipe.execute = mock_execute
        mock_redis.pipeline.return_value = mock_pipe
        mock_get_redis.return_value = mock_redis

        result_a = await check_rate_limit("c1", "+91-lead-a")
        assert result_a is False  # blocked

        result_b = await check_rate_limit("c1", "+91-lead-b")
        assert result_b is True   # allowed

    @pytest.mark.asyncio
    @patch("src.core.rate_limit._get_redis")
    async def test_get_rate_limit_info(self, mock_get_redis):
        """get_rate_limit_info returns correct remaining count."""
        from src.core.rate_limit import get_rate_limit_info

        mock_redis = MagicMock()
        mock_pipe = _make_redis_pipe_mock([None, 2, []])
        mock_redis.pipeline.return_value = mock_pipe
        mock_get_redis.return_value = mock_redis

        info = await get_rate_limit_info("c1", "+919999900000")
        assert info["remaining"] == 1  # 3 - 2 = 1
        assert info["total"] == 3


class TestClientRateLimit:
    """Test per-client rate limiting."""

    @pytest.mark.asyncio
    @patch("src.core.rate_limit._get_redis")
    async def test_client_under_limit(self, mock_get_redis):
        """Client under limit should be allowed."""
        from src.core.rate_limit import check_client_rate_limit

        mock_redis = MagicMock()
        mock_pipe = _make_redis_pipe_mock([None, 50, None, None])
        mock_redis.pipeline.return_value = mock_pipe
        mock_get_redis.return_value = mock_redis

        result = await check_client_rate_limit("client-1")
        assert result is True

    @pytest.mark.asyncio
    @patch("src.core.rate_limit._get_redis")
    async def test_client_over_limit(self, mock_get_redis):
        """Client over limit should be blocked."""
        from src.core.rate_limit import check_client_rate_limit

        mock_redis = MagicMock()
        mock_pipe = _make_redis_pipe_mock([None, 200, None, None])
        mock_redis.pipeline.return_value = mock_pipe
        mock_get_redis.return_value = mock_redis

        result = await check_client_rate_limit("client-1")
        assert result is False


# ═══════════════════════════════════════════════════════════════════════════════
# MESSAGE QUEUE TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestMessageQueue:
    """Test Redis Streams message queue operations."""

    @pytest.mark.asyncio
    @patch("src.core.message_queue._get_redis")
    async def test_ensure_consumer_group_creates(self, mock_get_redis):
        """Consumer group should be created on first call."""
        from src.core.message_queue import ensure_consumer_group

        mock_redis = AsyncMock()
        mock_get_redis.return_value = mock_redis

        await ensure_consumer_group()
        mock_redis.xgroup_create.assert_called_once()

    @pytest.mark.asyncio
    @patch("src.core.message_queue._get_redis")
    async def test_ensure_consumer_group_idempotent(self, mock_get_redis):
        """Creating group when it already exists should not error."""
        import redis.asyncio as aioredis
        from src.core.message_queue import ensure_consumer_group

        mock_redis = AsyncMock()
        mock_redis.xgroup_create.side_effect = aioredis.ResponseError("BUSYGROUP Consumer Group name already exists")
        mock_get_redis.return_value = mock_redis

        # Should not raise
        await ensure_consumer_group()

    @pytest.mark.asyncio
    @patch("src.core.message_queue._get_redis")
    async def test_enqueue_message(self, mock_get_redis):
        """enqueue_message should XADD to the stream."""
        from src.core.message_queue import enqueue_message

        mock_redis = AsyncMock()
        mock_redis.xadd.return_value = "1234567890-0"
        mock_get_redis.return_value = mock_redis

        payload = {"entry": [{"changes": [{"value": {"messages": []}}]}]}
        entry_id = await enqueue_message("client-1", payload)

        assert entry_id == "1234567890-0"
        mock_redis.xadd.assert_called_once()
        call_args = mock_redis.xadd.call_args
        # First positional arg is the stream name
        assert call_args[0][0] == "mq:messages"
        # Entry should contain client_id and serialized payload
        entry_data = call_args[0][1]
        assert entry_data["client_id"] == "client-1"
        assert json.loads(entry_data["payload"]) == payload

    @pytest.mark.asyncio
    @patch("src.core.message_queue._get_redis")
    async def test_dequeue_messages(self, mock_get_redis):
        """dequeue_messages should XREADGROUP and parse entries."""
        from src.core.message_queue import dequeue_messages

        mock_redis = AsyncMock()
        payload = {"test": "data"}
        mock_redis.xreadgroup.return_value = [
            ("mq:messages", [
                ("1234-0", {
                    "client_id": "c1",
                    "payload": json.dumps(payload),
                    "enqueued_at": str(time.time()),
                }),
            ]),
        ]
        mock_get_redis.return_value = mock_redis

        messages = await dequeue_messages("worker-1", count=5, block_ms=100)
        assert len(messages) == 1
        assert messages[0]["client_id"] == "c1"
        assert messages[0]["payload"] == payload
        assert messages[0]["entry_id"] == "1234-0"

    @pytest.mark.asyncio
    @patch("src.core.message_queue._get_redis")
    async def test_dequeue_empty(self, mock_get_redis):
        """dequeue_messages returns empty list when no messages."""
        from src.core.message_queue import dequeue_messages

        mock_redis = AsyncMock()
        mock_redis.xreadgroup.return_value = None
        mock_get_redis.return_value = mock_redis

        messages = await dequeue_messages("worker-1")
        assert messages == []

    @pytest.mark.asyncio
    @patch("src.core.message_queue._get_redis")
    async def test_ack_message(self, mock_get_redis):
        """ack_message should XACK the entry."""
        from src.core.message_queue import ack_message

        mock_redis = AsyncMock()
        mock_get_redis.return_value = mock_redis

        await ack_message("1234-0")
        mock_redis.xack.assert_called_once_with("mq:messages", "engine_workers", "1234-0")

    @pytest.mark.asyncio
    @patch("src.core.message_queue._get_redis")
    async def test_get_stream_length(self, mock_get_redis):
        """get_stream_length returns xlen result."""
        from src.core.message_queue import get_stream_length

        mock_redis = AsyncMock()
        mock_redis.xlen.return_value = 42
        mock_get_redis.return_value = mock_redis

        length = await get_stream_length()
        assert length == 42

    @pytest.mark.asyncio
    @patch("src.core.message_queue._get_redis")
    async def test_dequeue_bad_json_acked(self, mock_get_redis):
        """Entries with invalid JSON should be acked (not block the queue)."""
        from src.core.message_queue import dequeue_messages

        mock_redis = AsyncMock()
        mock_redis.xreadgroup.return_value = [
            ("mq:messages", [
                ("bad-1", {
                    "client_id": "c1",
                    "payload": "NOT VALID JSON{{{",
                    "enqueued_at": "0",
                }),
            ]),
        ]
        mock_get_redis.return_value = mock_redis

        messages = await dequeue_messages("worker-1")
        assert messages == []
        # Bad entry should have been acked
        mock_redis.xack.assert_called_once()


# ═══════════════════════════════════════════════════════════════════════════════
# WORKER TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestMessageWorker:
    """Test the background message worker."""

    @pytest.mark.asyncio
    async def test_worker_processes_message(self):
        """Worker should process a message and ack it."""
        # Import module first so patch paths resolve
        import src.core.worker as worker_mod
        from src.core.worker import MessageWorker

        payload = {
            "object": "whatsapp_business_account",
            "entry": [{"changes": [{"value": {
                "messaging_product": "whatsapp",
                "metadata": {"phone_number_id": "TEST_WABA"},
                "messages": [{"id": "msg1", "from": "91999", "type": "text", "text": {"body": "Hi"}}],
            }}]}],
        }

        mock_ack = AsyncMock()

        with patch.object(worker_mod, "ack_message", mock_ack):
            worker = MessageWorker(worker_name="test-worker")

            # Mock the router to avoid real processing
            with patch.object(worker, "_router") as mock_router:
                mock_router.route_inbound = AsyncMock(return_value={"response": "Hi!", "lead_id": "l1"})

                # Mock DB session
                mock_session = AsyncMock()
                mock_session.__aenter__ = AsyncMock(return_value=mock_session)
                mock_session.__aexit__ = AsyncMock(return_value=None)

                with patch.object(worker_mod, "AsyncSessionFactory", return_value=mock_session):
                    messages = [{
                        "entry_id": "test-1",
                        "client_id": "c1",
                        "payload": payload,
                        "enqueued_at": time.time(),
                    }]
                    for msg in messages:
                        await worker._process_message(msg)

        assert worker._processed == 1
        mock_ack.assert_called_once_with("test-1")

    @pytest.mark.asyncio
    async def test_worker_acks_on_error(self):
        """Worker should ack even when processing fails (prevent infinite loops)."""
        import src.core.worker as worker_mod
        from src.core.worker import MessageWorker

        mock_ack = AsyncMock()

        with patch.object(worker_mod, "ack_message", mock_ack):
            worker = MessageWorker(worker_name="test-worker")

            # Mock router to raise an exception
            with patch.object(worker, "_router") as mock_router:
                mock_router.route_inbound = AsyncMock(side_effect=Exception("boom"))

                mock_session = AsyncMock()
                mock_session.__aenter__ = AsyncMock(return_value=mock_session)
                mock_session.__aexit__ = AsyncMock(return_value=None)

                with patch.object(worker_mod, "AsyncSessionFactory", return_value=mock_session):
                    await worker._process_message({
                        "entry_id": "fail-1",
                        "client_id": "c1",
                        "payload": {},
                        "enqueued_at": time.time(),
                    })

        assert worker._errors == 1
        mock_ack.assert_called_once_with("fail-1")


# ═══════════════════════════════════════════════════════════════════════════════
# ROUTER RATE LIMIT INTEGRATION TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestRouterRateLimit:
    """Test that rate limiting is wired into the message router."""

    def _make_payload(self, text="Hello"):
        return {
            "object": "whatsapp_business_account",
            "entry": [{
                "changes": [{
                    "value": {
                        "messaging_product": "whatsapp",
                        "metadata": {"phone_number_id": "TEST_WABA_ID"},
                        "messages": [{
                            "id": "msg_rl_001",
                            "from": "919111111111",
                            "type": "text",
                            "text": {"body": text},
                        }],
                    }
                }],
            }],
        }

    @patch("src.channels.router.sync_lead_to_crm", new_callable=AsyncMock)
    @patch("src.channels.router.notify_brokers", new_callable=AsyncMock)
    @patch("src.channels.router.save_message", new_callable=AsyncMock)
    @patch("src.channels.router.has_consent", new_callable=AsyncMock, return_value=True)
    @patch("src.channels.router.get_or_create_conversation", new_callable=AsyncMock)
    @patch("src.channels.router.get_or_create_lead", new_callable=AsyncMock)
    @patch("src.channels.router.resolve_client", new_callable=AsyncMock)
    @patch("src.channels.router.is_duplicate", new_callable=AsyncMock, return_value=False)
    @patch("src.channels.router.check_rate_limit", new_callable=AsyncMock, return_value=False)
    @patch("src.channels.router.WhatsAppChannel.send_message", new_callable=AsyncMock, return_value=True)
    @pytest.mark.asyncio
    async def test_rate_limited_message_returns_throttle_reply(
        self, mock_send, mock_rate, mock_dedup, mock_resolve, mock_lead,
        mock_convo, mock_consent, mock_save, mock_notify, mock_crm,
    ):
        """Rate-limited lead should get throttle message, not go through engine."""
        from src.channels.router import MessageRouter

        mock_client = MagicMock()
        mock_client.id = "c1"
        mock_client.waba_phone_number_id = "TEST_WABA_ID"
        mock_client.waba_token = "test_token"
        mock_client.client_name = "Test"
        mock_resolve.return_value = mock_client

        mock_lead_obj = MagicMock()
        mock_lead_obj.id = "lead1"
        mock_lead.return_value = mock_lead_obj

        mock_convo_obj = MagicMock()
        mock_convo_obj.id = "conv1"
        mock_convo.return_value = mock_convo_obj

        router = MessageRouter()
        mock_db = AsyncMock()
        result = await router.route_inbound(self._make_payload(), mock_db)

        assert result["next_action"] == "rate_limited"
        assert "processing" in result["response"].lower()
        # Should have sent the throttle message
        mock_send.assert_called_once()

    @patch("src.channels.router.sync_lead_to_crm", new_callable=AsyncMock)
    @patch("src.channels.router.notify_brokers", new_callable=AsyncMock)
    @patch("src.channels.router.save_message", new_callable=AsyncMock)
    @patch("src.channels.router.has_consent", new_callable=AsyncMock, return_value=True)
    @patch("src.channels.router.get_or_create_conversation", new_callable=AsyncMock)
    @patch("src.channels.router.get_or_create_lead", new_callable=AsyncMock)
    @patch("src.channels.router.resolve_client", new_callable=AsyncMock)
    @patch("src.channels.router.is_duplicate", new_callable=AsyncMock, return_value=False)
    @patch("src.channels.router.check_rate_limit", new_callable=AsyncMock, return_value=True)
    @patch("src.channels.router.WhatsAppChannel.send_message", new_callable=AsyncMock, return_value=True)
    @patch("src.channels.router.WhatsAppChannel.mark_as_read", new_callable=AsyncMock)
    @pytest.mark.asyncio
    async def test_allowed_message_goes_through_engine(
        self, mock_read, mock_send, mock_rate, mock_dedup, mock_resolve,
        mock_lead, mock_convo, mock_consent, mock_save, mock_notify, mock_crm,
    ):
        """Message under rate limit should proceed to engine normally."""
        from src.channels.router import MessageRouter

        mock_client = MagicMock()
        mock_client.id = "c1"
        mock_client.waba_phone_number_id = "TEST_WABA_ID"
        mock_client.waba_token = "test_token"
        mock_client.client_name = "Test"
        mock_client.prompt_overrides = {}
        mock_client.language_config = {}
        mock_resolve.return_value = mock_client

        mock_lead_obj = MagicMock()
        mock_lead_obj.id = "lead1"
        mock_lead_obj.name = None
        mock_lead_obj.intent = "unknown"
        mock_lead_obj.stage = "new"
        mock_lead_obj.language_pref = "english"
        mock_lead.return_value = mock_lead_obj

        mock_convo_obj = MagicMock()
        mock_convo_obj.id = "conv1"
        mock_convo.return_value = mock_convo_obj

        router = MessageRouter()
        with patch.object(router, "_run_engine", new_callable=AsyncMock, return_value={
            "reply": "Hello! How can I help?",
            "lead_data": {},
            "billing_event": None,
            "next_action": "continue",
        }):
            mock_db = AsyncMock()
            result = await router.route_inbound(self._make_payload(), mock_db)

        assert result["next_action"] == "continue"
        assert "Hello" in result["response"]


# ═══════════════════════════════════════════════════════════════════════════════
# WEBHOOK ASYNC MODE TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestWebhookAsyncMode:
    """Test that webhook can enqueue messages in async mode."""

    @pytest.mark.asyncio
    async def test_sync_mode_processes_inline(self):
        """In sync mode (default), webhook processes a status-update inline."""
        from src.api.webhooks import router as webhook_router
        from fastapi import FastAPI
        from fastapi.testclient import TestClient

        # Create minimal app without lifespan (avoids DB/scheduler startup)
        test_app = FastAPI()
        test_app.include_router(webhook_router)

        payload = {
            "object": "whatsapp_business_account",
            "entry": [{"changes": [{"value": {
                "messaging_product": "whatsapp",
                "metadata": {"phone_number_id": "TEST"},
                "statuses": [{"id": "s1", "status": "delivered"}],
            }}]}],
        }

        with TestClient(test_app) as client:
            response = client.post("/webhook/whatsapp", json=payload)
            assert response.status_code == 200
            assert response.json()["status"] == "ok"

    @pytest.mark.asyncio
    @patch("src.core.message_queue.enqueue_message", new_callable=AsyncMock, return_value="entry-1")
    @patch("src.core.dedup.is_duplicate", new_callable=AsyncMock, return_value=False)
    async def test_async_mode_enqueues(self, mock_dedup, mock_enqueue):
        """In async mode, webhook enqueues instead of processing inline."""
        from src.api.webhooks import receive_webhook
        from fastapi import Request

        payload = {
            "object": "whatsapp_business_account",
            "entry": [{"changes": [{"value": {
                "messaging_product": "whatsapp",
                "metadata": {"phone_number_id": "TEST_WABA"},
                "messages": [{"id": "msg1", "from": "91999", "type": "text", "text": {"body": "Hi"}}],
            }}]}],
        }

        # Mock the settings to return async mode
        with patch("src.api.webhooks.get_settings") as mock_settings:
            mock_settings.return_value.webhook_mode = "async"

            # Create a mock request
            mock_request = AsyncMock()
            mock_request.json.return_value = payload

            mock_db = AsyncMock()
            result = await receive_webhook(mock_request, mock_db)

        assert result == {"status": "ok"}
        mock_enqueue.assert_called_once()
