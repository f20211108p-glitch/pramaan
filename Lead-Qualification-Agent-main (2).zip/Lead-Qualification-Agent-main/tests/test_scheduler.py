"""
Tests for scheduler node, nurturer node, handoff node, and calendar module.

All LLM calls are mocked — no API key needed.
"""
import pytest
from datetime import datetime, timedelta
from unittest.mock import patch, MagicMock

from src.engine.nodes.scheduler import scheduler, _format_slots
from src.engine.nodes.nurturer import nurturer, _find_missing_fields
from src.engine.nodes.handoff import handoff, _generate_handoff_message
from src.scheduler.calendar import _generate_fallback_slots, _format_lead_for_event


# ═══════════════════════════════════════════════════════════════════════════════
# SCHEDULER NODE
# ═══════════════════════════════════════════════════════════════════════════════

class TestSchedulerNode:
    @pytest.fixture
    def hot_lead_state(self):
        return {
            "messages": [{"role": "user", "content": "I want to visit the property"}],
            "lead": {
                "phone": "+919820011111",
                "name": "Raj",
                "client_id": "client-1",
                "score": 85,
                "tier": "hot",
                "stage": "qualified",
                "intent": "buyer",
                "budget_min": 7_000_000,
                "budget_max": 9_000_000,
                "location_preferences": ["Whitefield"],
                "timeline_months": 2,
                "financing_status": "pre_approved",
                "property_type": "apartment",
                "language_pref": "english",
            },
            "client_config": {
                "client_name": "Prestige Group",
                "google_calendar_id": None,
            },
            "language": "english",
            "rag_context": [],
        }

    @patch("src.engine.nodes.scheduler.generate", return_value="Great! Here are available slots:\n1. Monday at 10 AM\n2. Tuesday at 3 PM\nWhich works for you?")
    @patch("src.engine.nodes.scheduler.load_prompt", return_value="{client_name}{score}{tier}{lead_name}{budget_summary}{location_summary}{timeline_summary}{property_type}{available_slots}{language}")
    def test_scheduler_sets_stage_to_scheduling(self, mock_prompt, mock_gen, hot_lead_state):
        result = scheduler(hot_lead_state)
        assert result["lead"]["stage"] == "scheduling"

    @patch("src.engine.nodes.scheduler.generate", return_value="Let's book a visit!")
    @patch("src.engine.nodes.scheduler.load_prompt", return_value="{client_name}{score}{tier}{lead_name}{budget_summary}{location_summary}{timeline_summary}{property_type}{available_slots}{language}")
    def test_scheduler_appends_assistant_message(self, mock_prompt, mock_gen, hot_lead_state):
        result = scheduler(hot_lead_state)
        messages = result["messages"]
        assert messages[-1]["role"] == "assistant"
        assert "visit" in messages[-1]["content"].lower()

    @patch("src.engine.nodes.scheduler.generate", return_value="")
    @patch("src.engine.nodes.scheduler.load_prompt", return_value="{client_name}{score}{tier}{lead_name}{budget_summary}{location_summary}{timeline_summary}{property_type}{available_slots}{language}")
    def test_scheduler_fallback_when_llm_fails(self, mock_prompt, mock_gen, hot_lead_state):
        result = scheduler(hot_lead_state)
        # Should still produce a response (fallback)
        messages = result["messages"]
        assert len(messages) >= 2
        assert messages[-1]["role"] == "assistant"
        assert len(messages[-1]["content"]) > 0

    @patch("src.engine.nodes.scheduler.generate", return_value="Here are slots!")
    @patch("src.engine.nodes.scheduler.load_prompt", return_value="{client_name}{score}{tier}{lead_name}{budget_summary}{location_summary}{timeline_summary}{property_type}{available_slots}{language}")
    def test_scheduler_returns_correct_keys(self, mock_prompt, mock_gen, hot_lead_state):
        result = scheduler(hot_lead_state)
        assert "lead" in result
        assert "messages" in result
        assert result["current_node"] == "scheduler"
        assert result["next_action"] == "schedule"

    def test_format_slots_empty(self):
        assert "ask the lead" in _format_slots([]).lower()

    def test_format_slots_with_data(self):
        slots = [
            {"display": "Monday, 26 May at 10:00 AM"},
            {"display": "Tuesday, 27 May at 03:00 PM"},
        ]
        formatted = _format_slots(slots)
        assert "1." in formatted
        assert "2." in formatted
        assert "Monday" in formatted


# ═══════════════════════════════════════════════════════════════════════════════
# NURTURER NODE
# ═══════════════════════════════════════════════════════════════════════════════

class TestNurturerNode:
    @pytest.fixture
    def warm_lead_state(self):
        return {
            "messages": [{"role": "user", "content": "I'm looking for a 2BHK"}],
            "lead": {
                "phone": "+919820022222",
                "name": "Priya",
                "client_id": "client-1",
                "score": 50,
                "tier": "warm",
                "stage": "qualifying",
                "intent": "buyer",
                "budget_min": None,
                "budget_max": None,
                "location_preferences": ["Whitefield"],
                "timeline_months": None,
                "financing_status": "unknown",
                "property_type": "apartment",
                "language_pref": "hinglish",
                "family_size": None,
            },
            "client_config": {
                "client_name": "Prestige Group",
            },
            "language": "hinglish",
            "rag_context": [],
        }

    @patch("src.engine.nodes.nurturer.generate", return_value="Nice! Whitefield mein bahut acche options hain. Aapka budget kya hai?")
    @patch("src.engine.nodes.nurturer.load_prompt", return_value="{client_name}{score}{lead_name}{intent}{budget_summary}{location_summary}{timeline_summary}{financing_status}{property_type}{missing_fields}{language}")
    def test_nurturer_sets_stage_to_nurturing(self, mock_prompt, mock_gen, warm_lead_state):
        result = nurturer(warm_lead_state)
        assert result["lead"]["stage"] == "nurturing"

    @patch("src.engine.nodes.nurturer.generate", return_value="Great choice!")
    @patch("src.engine.nodes.nurturer.load_prompt", return_value="{client_name}{score}{lead_name}{intent}{budget_summary}{location_summary}{timeline_summary}{financing_status}{property_type}{missing_fields}{language}")
    def test_nurturer_appends_assistant_message(self, mock_prompt, mock_gen, warm_lead_state):
        result = nurturer(warm_lead_state)
        assert result["messages"][-1]["role"] == "assistant"

    @patch("src.engine.nodes.nurturer.generate", return_value="")
    @patch("src.engine.nodes.nurturer.load_prompt", return_value="{client_name}{score}{lead_name}{intent}{budget_summary}{location_summary}{timeline_summary}{financing_status}{property_type}{missing_fields}{language}")
    def test_nurturer_fallback_when_llm_fails(self, mock_prompt, mock_gen, warm_lead_state):
        result = nurturer(warm_lead_state)
        assert len(result["messages"][-1]["content"]) > 0

    @patch("src.engine.nodes.nurturer.generate", return_value="Response")
    @patch("src.engine.nodes.nurturer.load_prompt", return_value="{client_name}{score}{lead_name}{intent}{budget_summary}{location_summary}{timeline_summary}{financing_status}{property_type}{missing_fields}{language}")
    def test_nurturer_returns_correct_keys(self, mock_prompt, mock_gen, warm_lead_state):
        result = nurturer(warm_lead_state)
        assert result["current_node"] == "nurturer"
        assert result["next_action"] == "nurture"


class TestFindMissingFields:
    def test_all_fields_missing(self):
        lead = {}
        missing = _find_missing_fields(lead)
        assert "budget" in missing
        assert "timeline" in missing
        assert "financing status" in missing
        assert "preferred location" in missing
        assert "family size" in missing

    def test_budget_filled(self):
        lead = {"budget_min": 7_000_000}
        missing = _find_missing_fields(lead)
        assert "budget" not in missing

    def test_all_filled(self):
        lead = {
            "budget_min": 7_000_000,
            "budget_max": 9_000_000,
            "timeline_months": 3,
            "financing_status": "pre_approved",
            "location_preferences": ["Whitefield"],
            "property_type": "apartment",
            "family_size": 4,
        }
        missing = _find_missing_fields(lead)
        assert len(missing) == 0

    def test_unknown_counts_as_missing(self):
        lead = {"financing_status": "unknown"}
        missing = _find_missing_fields(lead)
        assert "financing status" in missing

    def test_empty_list_counts_as_missing(self):
        lead = {"location_preferences": []}
        missing = _find_missing_fields(lead)
        assert "preferred location" in missing

    def test_any_counts_as_missing(self):
        lead = {"property_type": "any"}
        missing = _find_missing_fields(lead)
        assert "property type" in missing


# ═══════════════════════════════════════════════════════════════════════════════
# HANDOFF NODE
# ═══════════════════════════════════════════════════════════════════════════════

class TestHandoffNode:
    @pytest.fixture
    def cold_lead_state(self):
        return {
            "messages": [{"role": "user", "content": "Not interested right now"}],
            "lead": {
                "phone": "+919820033333",
                "name": "Amit",
                "score": 15,
                "tier": "cold",
                "stage": "qualifying",
                "intent": "unknown",
                "language_pref": "english",
            },
            "language": "english",
            "should_handoff": False,
            "handoff_reason": None,
        }

    def test_handoff_sets_stage(self, cold_lead_state):
        result = handoff(cold_lead_state)
        assert result["lead"]["stage"] == "handed_off"

    def test_handoff_sets_flag(self, cold_lead_state):
        result = handoff(cold_lead_state)
        assert result["should_handoff"] is True

    def test_handoff_appends_message(self, cold_lead_state):
        result = handoff(cold_lead_state)
        assert result["messages"][-1]["role"] == "assistant"
        assert len(result["messages"][-1]["content"]) > 0

    def test_seller_handoff(self, cold_lead_state):
        cold_lead_state["lead"]["intent"] = "seller"
        result = handoff(cold_lead_state)
        assert result["handoff_reason"] == "seller"
        assert "sell" in result["messages"][-1]["content"].lower()

    def test_human_requested_handoff(self, cold_lead_state):
        cold_lead_state["handoff_reason"] = "human_requested"
        result = handoff(cold_lead_state)
        assert result["handoff_reason"] == "human_requested"
        assert "connect" in result["messages"][-1]["content"].lower()

    def test_handoff_hindi(self, cold_lead_state):
        cold_lead_state["language"] = "hindi"
        cold_lead_state["lead"]["intent"] = "seller"
        result = handoff(cold_lead_state)
        # Hindi response should contain Hindi words
        msg = result["messages"][-1]["content"]
        assert "Namaste" in msg or "madad" in msg


class TestHandoffMessage:
    def test_seller_english(self):
        msg = _generate_handoff_message({"name": "Raj"}, "seller", "english")
        assert "Raj" in msg
        assert "sell" in msg.lower()

    def test_seller_hinglish(self):
        msg = _generate_handoff_message({"name": "Raj"}, "seller", "hinglish")
        assert "Raj" in msg

    def test_cold_lead_english(self):
        msg = _generate_handoff_message({}, "cold_lead", "english")
        assert "here to help" in msg.lower()

    def test_no_name(self):
        msg = _generate_handoff_message({}, "cold_lead", "english")
        # Should not have empty " " after greeting
        assert "  " not in msg


# ═══════════════════════════════════════════════════════════════════════════════
# CALENDAR MODULE
# ═══════════════════════════════════════════════════════════════════════════════

class TestCalendar:
    def test_fallback_slots_returns_slots(self):
        slots = _generate_fallback_slots(days_ahead=3)
        assert len(slots) > 0
        assert len(slots) <= 6

    def test_fallback_slots_have_required_keys(self):
        slots = _generate_fallback_slots()
        for slot in slots:
            assert "start" in slot
            assert "end" in slot
            assert "display" in slot
            assert isinstance(slot["start"], datetime)

    def test_fallback_slots_are_in_future(self):
        slots = _generate_fallback_slots()
        now = datetime.utcnow()
        for slot in slots:
            assert slot["start"] > now

    def test_fallback_slots_respect_business_hours(self):
        slots = _generate_fallback_slots(business_hours=(9, 17))
        for slot in slots:
            assert 9 <= slot["start"].hour < 17

    def test_format_lead_for_event(self):
        lead = {
            "name": "Test Lead",
            "phone": "+919999900000",
            "score": 85,
            "tier": "hot",
            "intent": "buyer",
            "budget_min": 8_000_000,
            "budget_max": 10_000_000,
            "location_preferences": ["Whitefield"],
            "property_type": "apartment",
            "financing_status": "pre_approved",
        }
        desc = _format_lead_for_event(lead)
        assert "Test Lead" in desc
        assert "+919999900000" in desc
        assert "85/100" in desc
        assert "Whitefield" in desc
        assert "LeadEngine" in desc
