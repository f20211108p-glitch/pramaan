"""
Tests for Chunk 4B — Enhanced scorer, prompt caching, billing events, lead persistence.
All Claude API calls are mocked — no real API usage.
"""
import pytest
from unittest.mock import patch, AsyncMock, MagicMock


# ── Prompt Caching Tests ─────────────────────────────────────────────────────

class TestPromptCaching:
    """Test that prompt caching is wired into LLM calls."""

    def test_build_system_with_cache_returns_two_blocks(self):
        """When cache=True, system prompt becomes a 2-block list: base (cached) + node (uncached)."""
        from src.engine.llm import _build_system_with_cache, _load_base_context
        result = _build_system_with_cache("Hello world", cache=True)
        assert isinstance(result, list)
        assert len(result) == 2
        # Block 1: cached base context
        assert result[0]["type"] == "text"
        assert result[0]["cache_control"] == {"type": "ephemeral"}
        assert "Pramaan" in result[0]["text"]  # base context mentions Pramaan
        # Block 2: uncached node prompt
        assert result[1]["type"] == "text"
        assert result[1]["text"] == "Hello world"
        assert "cache_control" not in result[1]

    def test_build_system_without_cache_returns_string(self):
        """When cache=False, system prompt stays as plain string (base + node concatenated)."""
        from src.engine.llm import _build_system_with_cache
        result = _build_system_with_cache("Hello world", cache=False)
        assert isinstance(result, str)
        assert "Hello world" in result

    @patch("src.engine.llm.get_anthropic_client")
    def test_classify_sends_cached_system(self, mock_client_fn):
        """classify() should send system prompt with cache_control."""
        from src.engine.llm import classify

        mock_client = MagicMock()
        mock_response = MagicMock()
        mock_response.content = [MagicMock(text="english")]
        mock_response.usage = MagicMock(
            input_tokens=50, output_tokens=1,
            cache_creation_input_tokens=50, cache_read_input_tokens=0,
        )
        mock_response.model = "claude-3-5-haiku-20241022"
        mock_client.messages.create.return_value = mock_response
        mock_client_fn.return_value = mock_client

        result = classify("Detect language", "Hello", ["english", "hindi"])
        assert result == "english"

        # Verify system prompt was sent as cached list
        call_kwargs = mock_client.messages.create.call_args.kwargs
        system = call_kwargs["system"]
        assert isinstance(system, list)
        assert system[0]["cache_control"] == {"type": "ephemeral"}

    @patch("src.engine.llm.get_anthropic_client")
    def test_generate_sends_cached_system(self, mock_client_fn):
        """generate() should send system prompt with cache_control."""
        from src.engine.llm import generate

        mock_client = MagicMock()
        mock_response = MagicMock()
        mock_response.content = [MagicMock(text="Welcome!")]
        mock_response.usage = MagicMock(
            input_tokens=100, output_tokens=20,
            cache_creation_input_tokens=0, cache_read_input_tokens=100,
        )
        mock_response.model = "claude-sonnet-4-5"
        mock_client.messages.create.return_value = mock_response
        mock_client_fn.return_value = mock_client

        result = generate("You are a greeter", "Hi", cache=True)
        assert result == "Welcome!"

        call_kwargs = mock_client.messages.create.call_args.kwargs
        system = call_kwargs["system"]
        assert isinstance(system, list)
        assert system[0]["cache_control"] == {"type": "ephemeral"}

    @patch("src.engine.llm.get_anthropic_client")
    def test_generate_no_cache(self, mock_client_fn):
        """generate(cache=False) sends plain string system prompt."""
        from src.engine.llm import generate

        mock_client = MagicMock()
        mock_response = MagicMock()
        mock_response.content = [MagicMock(text="Hello")]
        mock_response.usage = MagicMock(
            input_tokens=50, output_tokens=5,
        )
        mock_response.model = "claude-sonnet-4-5"
        mock_client.messages.create.return_value = mock_response
        mock_client_fn.return_value = mock_client

        generate("System prompt", "User text", cache=False)

        call_kwargs = mock_client.messages.create.call_args.kwargs
        assert isinstance(call_kwargs["system"], str)

    @patch("src.engine.llm.get_anthropic_client")
    def test_generate_model_override(self, mock_client_fn):
        """generate(model=HAIKU_MODEL) uses Haiku instead of Sonnet."""
        from src.engine.llm import generate, HAIKU_MODEL

        mock_client = MagicMock()
        mock_response = MagicMock()
        mock_response.content = [MagicMock(text="Quick response")]
        mock_response.usage = MagicMock(
            input_tokens=30, output_tokens=10,
        )
        mock_response.model = HAIKU_MODEL
        mock_client.messages.create.return_value = mock_response
        mock_client_fn.return_value = mock_client

        generate("System", "User", model=HAIKU_MODEL)

        call_kwargs = mock_client.messages.create.call_args.kwargs
        assert call_kwargs["model"] == HAIKU_MODEL


# ── Enhanced Scorer Tests ────────────────────────────────────────────────────

class TestScorerEnhanced:
    """Test the enhanced scorer with reasoning + billing event."""

    def _make_state(self, **lead_fields) -> dict:
        lead = {"phone": "919111111111", "client_id": "c1", "stage": "qualifying"}
        lead.update(lead_fields)
        return {
            "lead": lead,
            "client_config": {"id": "c1"},
            "messages": [],
        }

    @patch("src.engine.nodes.scorer._generate_reasoning", return_value="Scored 85 (hot) — strong buyer signals.")
    def test_hot_lead_triggers_billing_event(self, mock_reasoning):
        """HOT lead → billing_event dict in result."""
        from src.engine.nodes.scorer import scorer
        state = self._make_state(
            budget_min=8000000, budget_max=12000000,
            timeline_months=3,
            location_preferences=["Andheri West"],
            financing_status="loan_approved",
        )
        result = scorer(state)
        assert result["lead"]["tier"] == "hot"
        assert result["billing_event"] is not None
        assert result["billing_event"]["event_type"] == "qualified_lead"
        assert result["billing_event"]["metadata"]["score"] >= 70
        assert result["billing_event"]["metadata"]["tier"] == "hot"

    @patch("src.engine.nodes.scorer._generate_reasoning", return_value="Scored 50 (warm) — some info missing.")
    def test_warm_lead_no_billing_event(self, mock_reasoning):
        """WARM lead → no billing event."""
        from src.engine.nodes.scorer import scorer
        state = self._make_state(
            budget_min=5000000,
            timeline_months=9,
            location_preferences=["Bandra"],
        )
        result = scorer(state)
        assert result["lead"]["tier"] == "warm"
        assert result["billing_event"] is None

    @patch("src.engine.nodes.scorer._generate_reasoning", return_value="Scored 0 (cold) — no info.")
    def test_cold_lead_no_billing_event(self, mock_reasoning):
        """COLD lead → no billing event."""
        from src.engine.nodes.scorer import scorer
        state = self._make_state()
        result = scorer(state)
        assert result["lead"]["tier"] == "cold"
        assert result["billing_event"] is None

    @patch("src.engine.nodes.scorer._generate_reasoning", return_value="Scored 85 (hot) — strong signals.")
    def test_scoring_reasoning_in_lead(self, mock_reasoning):
        """Scorer adds scoring_reasoning to lead dict."""
        from src.engine.nodes.scorer import scorer
        state = self._make_state(
            budget_min=8000000, budget_max=12000000,
            timeline_months=3, location_preferences=["Whitefield"],
            financing_status="self_funded",
        )
        result = scorer(state)
        assert "scoring_reasoning" in result["lead"]
        assert len(result["lead"]["scoring_reasoning"]) > 0

    def test_reasoning_fallback_without_api_key(self):
        """Reasoning generation fails gracefully without API key."""
        from src.engine.nodes.scorer import _generate_reasoning
        # When generate() raises RuntimeError (no API key), fallback is used
        reasoning = _generate_reasoning(
            lead={"budget_max": 10000000},
            score=30,
            tier="cold",
            reasons=["budget provided"],
        )
        assert "30" in reasoning
        assert "cold" in reasoning

    def test_billing_event_contains_reasons(self):
        """Billing event metadata includes scoring reasons list."""
        from src.engine.nodes.scorer import scorer
        with patch("src.engine.nodes.scorer._generate_reasoning", return_value="Hot lead."):
            state = self._make_state(
                budget_min=8000000, budget_max=12000000,
                timeline_months=2,
                location_preferences=["Whitefield"],
                financing_status="loan_approved",
            )
            result = scorer(state)
        meta = result["billing_event"]["metadata"]
        assert "reasons" in meta
        assert "budget provided" in meta["reasons"]


# ── Scorer Prompt File Tests ─────────────────────────────────────────────────

class TestScorerPrompt:
    """Test scorer.txt prompt file exists and has correct placeholders."""

    def test_scorer_prompt_exists(self):
        from src.engine.llm import load_prompt
        prompt = load_prompt("scorer.txt")
        assert len(prompt) > 0

    def test_scorer_prompt_has_placeholders(self):
        from src.engine.llm import load_prompt
        prompt = load_prompt("scorer.txt")
        expected = ["{score}", "{tier}", "{budget_summary}", "{timeline_summary}",
                    "{financing_status}", "{location_summary}", "{property_type}",
                    "{family_size}", "{reasons}"]
        for placeholder in expected:
            assert placeholder in prompt, f"Missing placeholder: {placeholder}"


# ── Router Persistence Tests ─────────────────────────────────────────────────

class TestRouterPersistence:
    """Test that the router persists scoring data and billing events."""

    @pytest.mark.asyncio
    async def test_persist_updates_lead_fields(self):
        """Lead scoring data should be written to DB via update_lead."""
        from src.channels.router import MessageRouter

        router = MessageRouter()
        mock_db = AsyncMock()

        engine_result = {
            "lead_data": {
                "score": 85,
                "tier": "hot",
                "stage": "qualified",
                "intent": "buyer",
                "budget_min": 8000000,
                "budget_max": 12000000,
            },
            "billing_event": None,
        }

        with patch("src.channels.router.update_lead", new_callable=AsyncMock) as mock_update:
            await router._persist_engine_results(mock_db, "c1", "lead1", engine_result)

        mock_update.assert_called_once()
        call_args = mock_update.call_args
        assert call_args[0][0] == mock_db
        assert call_args[0][1] == "c1"
        assert call_args[0][2] == "lead1"
        fields = call_args[0][3]
        assert fields["score"] == 85
        assert fields["tier"] == "hot"
        assert fields["budget_min"] == 8000000

    @pytest.mark.asyncio
    async def test_persist_writes_billing_event_for_hot(self):
        """HOT lead → billing event written to DB."""
        from src.channels.router import MessageRouter

        router = MessageRouter()
        mock_db = AsyncMock()

        engine_result = {
            "lead_data": {"score": 90, "tier": "hot", "stage": "qualified"},
            "billing_event": {
                "event_type": "qualified_lead",
                "metadata": {"score": 90, "tier": "hot"},
            },
        }

        with patch("src.channels.router.update_lead", new_callable=AsyncMock), \
             patch("src.channels.router.write_billing_event", new_callable=AsyncMock) as mock_billing:
            await router._persist_engine_results(mock_db, "c1", "lead1", engine_result)

        mock_billing.assert_called_once()
        call_kwargs = mock_billing.call_args.kwargs
        assert call_kwargs["client_id"] == "c1"
        assert call_kwargs["lead_id"] == "lead1"
        assert call_kwargs["event_type"] == "qualified_lead"

    @pytest.mark.asyncio
    async def test_persist_no_billing_for_warm(self):
        """WARM lead → no billing event written."""
        from src.channels.router import MessageRouter

        router = MessageRouter()
        mock_db = AsyncMock()

        engine_result = {
            "lead_data": {"score": 50, "tier": "warm", "stage": "qualified"},
            "billing_event": None,
        }

        with patch("src.channels.router.update_lead", new_callable=AsyncMock), \
             patch("src.channels.router.write_billing_event", new_callable=AsyncMock) as mock_billing:
            await router._persist_engine_results(mock_db, "c1", "lead1", engine_result)

        mock_billing.assert_not_called()

    @pytest.mark.asyncio
    async def test_persist_skips_none_fields(self):
        """Fields with None value should NOT be persisted."""
        from src.channels.router import MessageRouter

        router = MessageRouter()
        mock_db = AsyncMock()

        engine_result = {
            "lead_data": {"score": 30, "tier": "cold", "budget_min": None, "intent": "buyer"},
            "billing_event": None,
        }

        with patch("src.channels.router.update_lead", new_callable=AsyncMock) as mock_update:
            await router._persist_engine_results(mock_db, "c1", "lead1", engine_result)

        fields = mock_update.call_args[0][3]
        assert "budget_min" not in fields  # None should be excluded
        assert fields["intent"] == "buyer"

    @pytest.mark.asyncio
    async def test_persist_handles_empty_lead_data(self):
        """Empty lead_data → no update_lead call."""
        from src.channels.router import MessageRouter

        router = MessageRouter()
        mock_db = AsyncMock()

        engine_result = {
            "lead_data": {},
            "billing_event": None,
        }

        with patch("src.channels.router.update_lead", new_callable=AsyncMock) as mock_update:
            await router._persist_engine_results(mock_db, "c1", "lead1", engine_result)

        mock_update.assert_not_called()

    @pytest.mark.asyncio
    async def test_persist_db_error_doesnt_crash(self):
        """DB error in persist → log warning, don't crash."""
        from src.channels.router import MessageRouter

        router = MessageRouter()
        mock_db = AsyncMock()

        engine_result = {
            "lead_data": {"score": 85, "tier": "hot"},
            "billing_event": {"event_type": "qualified_lead", "metadata": {}},
        }

        with patch("src.channels.router.update_lead", new_callable=AsyncMock, side_effect=Exception("DB down")), \
             patch("src.channels.router.write_billing_event", new_callable=AsyncMock, side_effect=Exception("DB down")):
            # Should not raise
            await router._persist_engine_results(mock_db, "c1", "lead1", engine_result)


# ── Engine Result Format Tests ───────────────────────────────────────────────

class TestEngineResultFormat:
    """Test that _run_engine returns the expected dict format."""

    @patch("src.engine.nodes.qualifier.generate", return_value="What's your budget?")
    @patch("src.engine.nodes.qualifier.extract_structured", return_value={"extracted_confidence": 0.5})
    @patch("src.engine.nodes.scorer._generate_reasoning", return_value="Scored 0 (cold).")
    @patch("src.engine.nodes.intent_detector.classify", return_value="buyer")
    @patch("src.engine.nodes.greeter.generate", return_value="Welcome!")
    @patch("src.engine.nodes.language_detector.classify", return_value="english")
    @pytest.mark.asyncio
    async def test_run_engine_returns_dict(
        self, mock_lang, mock_greet, mock_intent, mock_reasoning,
        mock_extract, mock_qual_gen
    ):
        """_run_engine should return dict with reply, lead_data, billing_event."""
        from src.channels.router import MessageRouter

        router = MessageRouter()
        mock_lead = MagicMock()
        mock_lead.name = None
        mock_lead.intent = "unknown"
        mock_lead.stage = "new"
        mock_lead.language_pref = "english"

        mock_config = MagicMock()
        mock_config.client_name = "Test"
        mock_config.prompt_overrides = {}
        mock_config.language_config = {}

        result = await router._run_engine(
            client_id="c1",
            client_config=mock_config,
            lead=mock_lead,
            text="Hi, I want a flat",
            sender_phone="919111111111",
            message_type="text",
            media_id=None,
        )

        assert "reply" in result
        assert "lead_data" in result
        assert "billing_event" in result
        assert "next_action" in result
        assert isinstance(result["reply"], str)
        assert len(result["reply"]) > 0

    @pytest.mark.asyncio
    async def test_run_engine_error_returns_fallback(self):
        """Engine error → fallback reply + empty lead_data."""
        from src.channels.router import MessageRouter

        router = MessageRouter()
        # Force graph to fail
        router._graph = MagicMock()
        router._graph.invoke.side_effect = Exception("Graph exploded")

        mock_lead = MagicMock()
        mock_lead.name = None
        mock_lead.intent = "unknown"
        mock_lead.stage = "new"
        mock_lead.language_pref = "english"

        mock_config = MagicMock()
        mock_config.client_name = "Test"
        mock_config.prompt_overrides = {}
        mock_config.language_config = {}

        result = await router._run_engine(
            client_id="c1",
            client_config=mock_config,
            lead=mock_lead,
            text="Hi",
            sender_phone="919111111111",
            message_type="text",
            media_id=None,
        )

        assert "sorry" in result["reply"].lower()
        assert result["billing_event"] is None
        assert result["lead_data"] == {}
