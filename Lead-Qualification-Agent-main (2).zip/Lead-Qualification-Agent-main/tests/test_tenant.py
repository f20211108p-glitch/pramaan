"""
Tests for tenant resolution and core DB queries.
Requires a running Postgres instance (docker-compose up -d postgres).
"""
import uuid
import pytest
from unittest.mock import patch, AsyncMock

from sqlalchemy import select

from src.db.tables import ClientConfig, Lead
from src.db.queries import get_or_create_lead, get_or_create_conversation, write_billing_event, write_consent, has_consent
from src.core.tenant import resolve_client, _client_config_to_dict, _dict_to_client_config


# ── Mock Redis for all tenant tests ─────────────────────────────────────────

@pytest.fixture(autouse=True)
def mock_redis_for_tenant():
    """Mock Redis so resolve_client falls through to DB (no Redis needed)."""
    mock_redis = AsyncMock()
    mock_redis.get = AsyncMock(return_value=None)  # cache miss
    mock_redis.setex = AsyncMock()
    mock_redis.delete = AsyncMock()
    with patch("src.core.tenant._get_redis", return_value=mock_redis):
        yield mock_redis


# ── Helpers ──────────────────────────────────────────────────────────────────

async def _insert_client(db, waba_number: str,
                         waba_phone_number_id: str | None = None) -> ClientConfig:
    """Insert a test client. waba_phone_number_id defaults to a unique value."""
    phone_id = waba_phone_number_id or f"PHONE_{uuid.uuid4().hex[:8]}"
    client = ClientConfig(
        client_name="Test Builder",
        waba_number=waba_number,
        waba_phone_number_id=phone_id,
        waba_token="test_token",
        language_config={
            "primary_language": "english",
            "regional_languages": [],
            "formality_level": "formal",
            "hindi_pronoun": "aap",
        },
    )
    db.add(client)
    await db.commit()
    await db.refresh(client)
    return client


# ── resolve_client ────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_resolve_client_returns_config(db):
    """resolve_client looks up by waba_phone_number_id (what Meta sends in webhooks)."""
    waba_number = f"91{uuid.uuid4().hex[:10]}"
    phone_id = f"PHONE_{uuid.uuid4().hex[:8]}"
    client = await _insert_client(db, waba_number, waba_phone_number_id=phone_id)

    # resolve_client takes the waba_phone_number_id, NOT the phone number
    resolved = await resolve_client(db, phone_id)

    assert resolved is not None
    assert str(resolved.id) == str(client.id)
    assert resolved.waba_phone_number_id == phone_id


@pytest.mark.asyncio
async def test_resolve_client_unknown_number_returns_none(db):
    result = await resolve_client(db, "NONEXISTENT_PHONE_ID")
    assert result is None


@pytest.mark.asyncio
async def test_resolve_client_inactive_returns_none(db):
    waba_number = f"91{uuid.uuid4().hex[:10]}"
    phone_id = f"PHONE_{uuid.uuid4().hex[:8]}"
    client = await _insert_client(db, waba_number, waba_phone_number_id=phone_id)
    client.active = False
    await db.commit()

    result = await resolve_client(db, phone_id)
    assert result is None


# ── get_or_create_lead ────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_get_or_create_lead_creates_on_first_call(db):
    waba = f"91{uuid.uuid4().hex[:10]}"
    client = await _insert_client(db, waba)
    phone = "919999988888"

    lead = await get_or_create_lead(db, client.id, phone)

    assert lead is not None
    assert lead.phone == phone
    assert str(lead.client_id) == str(client.id)


@pytest.mark.asyncio
async def test_get_or_create_lead_returns_existing_on_second_call(db):
    waba = f"91{uuid.uuid4().hex[:10]}"
    client = await _insert_client(db, waba)
    phone = "919988776655"

    lead1 = await get_or_create_lead(db, client.id, phone)
    lead2 = await get_or_create_lead(db, client.id, phone)

    assert str(lead1.id) == str(lead2.id)


@pytest.mark.asyncio
async def test_get_or_create_lead_isolated_by_client_id(db):
    waba_a = f"91{uuid.uuid4().hex[:10]}"
    waba_b = f"91{uuid.uuid4().hex[:10]}"
    client_a = await _insert_client(db, waba_a)
    client_b = await _insert_client(db, waba_b)
    phone = "919111122222"

    lead_a = await get_or_create_lead(db, client_a.id, phone)
    lead_b = await get_or_create_lead(db, client_b.id, phone)

    assert str(lead_a.id) != str(lead_b.id)
    assert str(lead_a.client_id) == str(client_a.id)
    assert str(lead_b.client_id) == str(client_b.id)


# ── query client_id isolation ──────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_lead_query_always_includes_client_id(db):
    waba_a = f"91{uuid.uuid4().hex[:10]}"
    waba_b = f"91{uuid.uuid4().hex[:10]}"
    client_a = await _insert_client(db, waba_a)
    client_b = await _insert_client(db, waba_b)

    phone = "919333344444"
    await get_or_create_lead(db, client_a.id, phone)

    # Query with client_b should not find client_a's lead
    result = await db.execute(
        select(Lead).where(Lead.client_id == client_b.id, Lead.phone == phone)
    )
    assert result.scalar_one_or_none() is None


# ── conversation + billing + consent ──────────────────────────────────────────

@pytest.mark.asyncio
async def test_get_or_create_conversation(db):
    waba = f"91{uuid.uuid4().hex[:10]}"
    client = await _insert_client(db, waba)
    lead = await get_or_create_lead(db, client.id, "919555566666")

    conv = await get_or_create_conversation(db, client.id, lead.id)
    assert conv is not None
    assert str(conv.client_id) == str(client.id)

    conv2 = await get_or_create_conversation(db, client.id, lead.id)
    assert str(conv.id) == str(conv2.id)


@pytest.mark.asyncio
async def test_write_billing_event(db):
    waba = f"91{uuid.uuid4().hex[:10]}"
    client = await _insert_client(db, waba)

    event = await write_billing_event(db, client.id, None, "qualified_lead", {"score": 80})
    assert event is not None
    assert event.event_type == "qualified_lead"
    assert str(event.client_id) == str(client.id)


@pytest.mark.asyncio
async def test_write_consent_and_has_consent(db):
    waba = f"91{uuid.uuid4().hex[:10]}"
    client = await _insert_client(db, waba)
    lead = await get_or_create_lead(db, client.id, "919777788888")

    assert not await has_consent(db, client.id, lead.id)

    await write_consent(db, client.id, lead.id, "data_collection", "first_message")

    assert await has_consent(db, client.id, lead.id)


# ── serialization round-trip ──────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_client_config_dict_roundtrip(db):
    waba = f"91{uuid.uuid4().hex[:10]}"
    client = await _insert_client(db, waba)

    data = _client_config_to_dict(client)
    reconstructed = _dict_to_client_config(data)

    assert str(reconstructed.id) == str(client.id)
    assert reconstructed.waba_number == client.waba_number
    assert reconstructed.active == client.active
