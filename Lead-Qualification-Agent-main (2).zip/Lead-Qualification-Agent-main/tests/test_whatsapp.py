"""
Tests for WhatsApp webhook — Chunk 2A.
Tests message parsing, verification, dedup, and routing logic.
No external API calls — all mocked.
"""
import pytest
from unittest.mock import AsyncMock, patch, MagicMock

from src.channels.whatsapp import WhatsAppChannel
from src.core.dedup import is_duplicate


# ── Sample Meta webhook payloads ──────────────────────────────────────────────

def _make_text_payload(
    sender="919876543210",
    text="Hi, I want a 2BHK in Andheri",
    phone_number_id="1234567890",
    message_id="wamid.abc123",
):
    return {
        "object": "whatsapp_business_account",
        "entry": [{
            "id": "WHATSAPP_BUSINESS_ACCOUNT_ID",
            "changes": [{
                "value": {
                    "messaging_product": "whatsapp",
                    "metadata": {
                        "display_phone_number": "919876543210",
                        "phone_number_id": phone_number_id,
                    },
                    "messages": [{
                        "from": sender,
                        "id": message_id,
                        "timestamp": "1716422400",
                        "type": "text",
                        "text": {"body": text},
                    }],
                },
                "field": "messages",
            }],
        }],
    }


def _make_audio_payload(phone_number_id="1234567890"):
    return {
        "object": "whatsapp_business_account",
        "entry": [{
            "changes": [{
                "value": {
                    "metadata": {"phone_number_id": phone_number_id},
                    "messages": [{
                        "from": "919876543210",
                        "id": "wamid.audio456",
                        "timestamp": "1716422400",
                        "type": "audio",
                        "audio": {"id": "media_audio_789", "mime_type": "audio/ogg"},
                    }],
                },
            }],
        }],
    }


def _make_status_payload():
    return {
        "object": "whatsapp_business_account",
        "entry": [{
            "changes": [{
                "value": {
                    "metadata": {"phone_number_id": "1234567890"},
                    "statuses": [{
                        "id": "wamid.xyz",
                        "status": "delivered",
                        "timestamp": "1716422400",
                    }],
                },
            }],
        }],
    }


# ── Webhook verification ─────────────────────────────────────────────────────

def test_verify_webhook_correct_token():
    with patch("src.channels.whatsapp.get_settings") as mock_settings:
        mock_settings.return_value = MagicMock(whatsapp_verify_token="leadengine_verify_2026")
        result = WhatsAppChannel.verify_webhook("subscribe", "leadengine_verify_2026", "challenge_xyz")
        assert result == "challenge_xyz"


def test_verify_webhook_wrong_token():
    with patch("src.channels.whatsapp.get_settings") as mock_settings:
        mock_settings.return_value = MagicMock(whatsapp_verify_token="leadengine_verify_2026")
        result = WhatsAppChannel.verify_webhook("subscribe", "wrong_token", "challenge_xyz")
        assert result is None


def test_verify_webhook_wrong_mode():
    with patch("src.channels.whatsapp.get_settings") as mock_settings:
        mock_settings.return_value = MagicMock(whatsapp_verify_token="leadengine_verify_2026")
        result = WhatsAppChannel.verify_webhook("unsubscribe", "leadengine_verify_2026", "challenge_xyz")
        assert result is None


# ── Message parsing ───────────────────────────────────────────────────────────

def test_parse_text_message():
    payload = _make_text_payload()
    parsed = WhatsAppChannel.parse_webhook_payload(payload)

    assert parsed is not None
    assert parsed["waba_phone_number_id"] == "1234567890"
    assert parsed["sender_phone"] == "919876543210"
    assert parsed["text"] == "Hi, I want a 2BHK in Andheri"
    assert parsed["message_type"] == "text"
    assert parsed["message_id"] == "wamid.abc123"
    assert parsed["media_id"] is None


def test_parse_audio_message():
    payload = _make_audio_payload()
    parsed = WhatsAppChannel.parse_webhook_payload(payload)

    assert parsed is not None
    assert parsed["message_type"] == "audio"
    assert parsed["media_id"] == "media_audio_789"
    assert parsed["text"] == "[voice note]"


def test_parse_status_update_returns_none():
    payload = _make_status_payload()
    parsed = WhatsAppChannel.parse_webhook_payload(payload)
    assert parsed is None


def test_parse_empty_payload_returns_none():
    assert WhatsAppChannel.parse_webhook_payload({}) is None
    assert WhatsAppChannel.parse_webhook_payload({"entry": []}) is None


def test_parse_extracts_waba_phone_number_id():
    """Different WABA numbers → correct routing key extracted."""
    p1 = _make_text_payload(phone_number_id="client_a_phone_id")
    p2 = _make_text_payload(phone_number_id="client_b_phone_id")

    assert WhatsAppChannel.parse_webhook_payload(p1)["waba_phone_number_id"] == "client_a_phone_id"
    assert WhatsAppChannel.parse_webhook_payload(p2)["waba_phone_number_id"] == "client_b_phone_id"


def test_to_unified_message():
    payload = _make_text_payload()
    parsed = WhatsAppChannel.parse_webhook_payload(payload)
    msg = WhatsAppChannel.to_unified_message(parsed)

    assert msg.channel == "whatsapp"
    assert msg.direction == "inbound"
    assert msg.sender_id == "919876543210"
    assert msg.content == "Hi, I want a 2BHK in Andheri"
    assert msg.message_type == "text"


# ── Deduplication ─────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_dedup_first_call_returns_false():
    """First time seeing a message_id → not a duplicate."""
    mock_redis = AsyncMock()
    mock_redis.set.return_value = True  # key was set (new)

    with patch("src.core.dedup._get_redis", return_value=mock_redis):
        result = await is_duplicate("wamid.new_message")
        assert result is False


@pytest.mark.asyncio
async def test_dedup_second_call_returns_true():
    """Second time seeing same message_id → duplicate."""
    mock_redis = AsyncMock()
    mock_redis.set.return_value = False  # key already existed

    with patch("src.core.dedup._get_redis", return_value=mock_redis):
        result = await is_duplicate("wamid.already_seen")
        assert result is True


@pytest.mark.asyncio
async def test_dedup_empty_message_id_not_duplicate():
    """No message_id → can't dedup → process it."""
    result_empty = await is_duplicate("")
    assert result_empty is False


# ── Send uses per-client token ────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_send_uses_per_client_token():
    """Verify that send_message uses the provided client token, not a global one."""
    with patch("src.channels.whatsapp.httpx.AsyncClient") as MockClient:
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_client_instance = AsyncMock()
        mock_client_instance.post.return_value = mock_response
        mock_client_instance.__aenter__ = AsyncMock(return_value=mock_client_instance)
        mock_client_instance.__aexit__ = AsyncMock(return_value=False)
        MockClient.return_value = mock_client_instance

        await WhatsAppChannel.send_message(
            waba_phone_number_id="client_a_phone_id",
            waba_token="client_a_secret_token",
            to="919876543210",
            content="Hello from LeadEngine!",
        )

        # Verify the correct token was used
        call_args = mock_client_instance.post.call_args
        headers = call_args.kwargs.get("headers", {})
        assert headers["Authorization"] == "Bearer client_a_secret_token"

        # Verify the correct phone number ID in URL
        url = call_args.args[0] if call_args.args else call_args.kwargs.get("url", "")
        assert "client_a_phone_id" in url


# ── Signature verification ────────────────────────────────────────────────────

def test_signature_verification_valid():
    import hmac
    import hashlib
    secret = "test_app_secret"
    payload = b'{"test": "data"}'
    sig = "sha256=" + hmac.new(secret.encode(), payload, hashlib.sha256).hexdigest()

    assert WhatsAppChannel.verify_signature(payload, sig, secret) is True


def test_signature_verification_invalid():
    assert WhatsAppChannel.verify_signature(b"data", "sha256=wrong", "secret") is False


def test_signature_verification_missing():
    assert WhatsAppChannel.verify_signature(b"data", "", "secret") is False
    assert WhatsAppChannel.verify_signature(b"data", "not_sha256_prefix", "secret") is False
